/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var $miapp_template$ = __webpack_require__(11)
	var $miapp_style$ = __webpack_require__(12)
	var $miapp_script$ = __webpack_require__(13)
	
	$miapp_define$('@miapp-component/hello', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})
	
	$miapp_bootstrap$('@miapp-component/hello',{ packagerVersion: '0.0.3'})

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "app"
	  ],
	  "children": [
	    {
	      "type": "stack",
	      "attr": {},
	      "style": {
	        "flex": 1
	      },
	      "children": [
	        {
	          "type": "div",
	          "attr": {},
	          "classList": [
	            "modal"
	          ],
	          "shown": function () {return this.isShow}
	        }
	      ]
	    },
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "btn"
	      ],
	      "events": {
	        "click": "toggleShow"
	      },
	      "children": [
	        {
	          "type": "text",
	          "attr": {
	            "value": "Click me"
	          }
	        }
	      ]
	    },
	    {
	      "type": "text",
	      "attr": {
	        "value": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	      },
	      "style": {
	        "color": "#FF0000"
	      }
	    }
	  ]
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = {
	  ".app": {
	    "alignItems": "flex-start",
	    "flexDirection": "column"
	  },
	  ".modal": {
	    "position": "fixed",
	    "width": "200px",
	    "height": "200px",
	    "top": "200px",
	    "left": "200px",
	    "backgroundColor": "#FF0000"
	  },
	  ".btn": {
	    "width": "200px",
	    "height": "100px",
	    "backgroundColor": "#000000"
	  },
	  "text": {
	    "color": "#FFFFFF"
	  }
	}

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = function(module, exports, $miapp_require$){'use strict';
	
	var _stringify = __webpack_require__(14);
	
	var _stringify2 = _interopRequireDefault(_stringify);
	
	var _miui = $miapp_require$('@miapp-module/miui.device');
	
	var _miui2 = _interopRequireDefault(_miui);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	module.exports = {
	  data: function data() {
	    return {
	      isShow: true
	    };
	  },
	  toggleShow: function toggleShow() {
	    this.isShow = !this.isShow;
	    _miui2.default.getInfo({
	      success: function success(ret) {
	        console.log((0, _stringify2.default)(ret));
	      }
	    });
	  }
	};}

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	
	module.exports = { "default": __webpack_require__(15), __esModule: true };

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var core = __webpack_require__(16),
	    $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
	module.exports = function stringify(it) {
	  // eslint-disable-line no-unused-vars
	  return $JSON.stringify.apply($JSON, arguments);
	};

/***/ },
/* 16 */
/***/ function(module, exports) {

	'use strict';
	
	var core = module.exports = { version: '2.4.0' };
	if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef

/***/ }
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMzEzYWY0ZjQ0MTQ4OTRiMWVkYTM/M2ZiNSIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaGVsbG8ubWl4PzM1ZjIiLCJ3ZWJwYWNrOi8vLy4vc3JjL0hlbGxvL2hlbGxvLm1peD81YTQyIiwid2VicGFjazovLy8uL3NyYy9IZWxsby9oZWxsby5taXg/NDk4MyIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaGVsbG8ubWl4Iiwid2VicGFjazovLy8uL34vYmFiZWwtcnVudGltZS9jb3JlLWpzL2pzb24vc3RyaW5naWZ5LmpzIiwid2VicGFjazovLy8uL34vY29yZS1qcy9saWJyYXJ5L2ZuL2pzb24vc3RyaW5naWZ5LmpzIiwid2VicGFjazovLy8uL34vY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2NvcmUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsInJlcXVpcmUiLCJfX2VzTW9kdWxlIiwiY29yZSIsIiRKU09OIiwiSlNPTiIsInN0cmluZ2lmeSIsIml0IiwiYXBwbHkiLCJhcmd1bWVudHMiLCJ2ZXJzaW9uIiwiX19lIl0sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUJBQWU7QUFDZjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7OztBQ3RDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUM7O0FBRUQsNkNBQTRDLDBCQUEwQixDOzs7Ozs7Ozs7Ozs7Ozs7O0FDZHRFO0FBQ0E7QUFDQSxhQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWdCO0FBQ2hCO0FBQ0E7QUFDQSxRQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EscUJBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBLGlDQUFnQztBQUNoQztBQUNBO0FBQ0EsTUFBSztBQUNMO0FBQ0E7QUFDQSxpQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7QUNwREE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7O0FDUEE7Ozs7Ozs7eUJBRUE7O2VBR0E7QUFGQTtBQUlBO3FDQUNBO3lCQUNBOztzQ0FFQTs4Q0FDQTtBQUVBO0FBSkE7QUFLQTtBQWRBLEk7Ozs7Ozs7O0FDZkFBLFFBQU9DLE9BQVAsR0FBaUIsRUFBRSxXQUFXLG1CQUFBQyxDQUFRLEVBQVIsQ0FBYixFQUEyREMsWUFBWSxJQUF2RSxFQUFqQixDOzs7Ozs7OztBQ0FBLEtBQUlDLE9BQVEsbUJBQUFGLENBQVEsRUFBUixDQUFaO0FBQUEsS0FDSUcsUUFBUUQsS0FBS0UsSUFBTCxLQUFjRixLQUFLRSxJQUFMLEdBQVksRUFBQ0MsV0FBV0QsS0FBS0MsU0FBakIsRUFBMUIsQ0FEWjtBQUVBUCxRQUFPQyxPQUFQLEdBQWlCLFNBQVNNLFNBQVQsQ0FBbUJDLEVBQW5CLEVBQXNCO0FBQUU7QUFDdkMsVUFBT0gsTUFBTUUsU0FBTixDQUFnQkUsS0FBaEIsQ0FBc0JKLEtBQXRCLEVBQTZCSyxTQUE3QixDQUFQO0FBQ0QsRUFGRCxDOzs7Ozs7OztBQ0ZBLEtBQUlOLE9BQU9KLE9BQU9DLE9BQVAsR0FBaUIsRUFBQ1UsU0FBUyxPQUFWLEVBQTVCO0FBQ0EsS0FBRyxPQUFPQyxHQUFQLElBQWMsUUFBakIsRUFBMEJBLE1BQU1SLElBQU4sQyxDQUFZLCtCIiwiZmlsZSI6ImJ1aWxkL0hlbGxvL2hlbGxvLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pXG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG5cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGV4cG9ydHM6IHt9LFxuIFx0XHRcdGlkOiBtb2R1bGVJZCxcbiBcdFx0XHRsb2FkZWQ6IGZhbHNlXG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmxvYWRlZCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oMCk7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgMzEzYWY0ZjQ0MTQ4OTRiMWVkYTMiLCJ2YXIgJG1pYXBwX3RlbXBsYXRlJCA9IHJlcXVpcmUoXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL2hlbGxvLm1peFwiKVxudmFyICRtaWFwcF9zdHlsZSQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1zdHlsZS1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zdHlsZXMmcmVzb3VyY2VQYXRoPS9ob21lL3VuaXF1ZS9aWlovc3JjL0hlbGxvL2hlbGxvLm1peCEuL2hlbGxvLm1peFwiKVxudmFyICRtaWFwcF9zY3JpcHQkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc2NyaXB0LWxvYWRlci5qcyFiYWJlbC1sb2FkZXI/cHJlc2V0c1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcHJlc2V0cz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wcmVzZXQtZXMyMDE1JnBsdWdpbnNbXT0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmcGx1Z2lucz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmY29tbWVudHM9ZmFsc2UhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zY3JpcHRzIS4vaGVsbG8ubWl4XCIpXG5cbiRtaWFwcF9kZWZpbmUkKCdAbWlhcHAtY29tcG9uZW50L2hlbGxvJywgXG4gICAgICAgICAgICAgICAgW10sIGZ1bmN0aW9uKCRtaWFwcF9yZXF1aXJlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfbW9kdWxlJCl7XG4gICAgICRtaWFwcF9zY3JpcHQkKCRtaWFwcF9tb2R1bGUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9yZXF1aXJlJClcbiAgICAgaWYgKCRtaWFwcF9leHBvcnRzJC5fX2VzTW9kdWxlICYmICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0KSB7XG4gICAgICAgICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzID0gJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHRcbiAgICAgICAgfVxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnRlbXBsYXRlID0gJG1pYXBwX3RlbXBsYXRlJFxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnN0eWxlID0gJG1pYXBwX3N0eWxlJFxufSlcblxuJG1pYXBwX2Jvb3RzdHJhcCQoJ0BtaWFwcC1jb21wb25lbnQvaGVsbG8nLHsgcGFja2FnZXJWZXJzaW9uOiAnMC4wLjMnfSlcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL3NyYy9IZWxsby9oZWxsby5taXhcbi8vIG1vZHVsZSBpZCA9IDBcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIFwidHlwZVwiOiBcImRpdlwiLFxuICBcImF0dHJcIjoge30sXG4gIFwiY2xhc3NMaXN0XCI6IFtcbiAgICBcImFwcFwiXG4gIF0sXG4gIFwiY2hpbGRyZW5cIjogW1xuICAgIHtcbiAgICAgIFwidHlwZVwiOiBcInN0YWNrXCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcInN0eWxlXCI6IHtcbiAgICAgICAgXCJmbGV4XCI6IDFcbiAgICAgIH0sXG4gICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAge1xuICAgICAgICAgIFwidHlwZVwiOiBcImRpdlwiLFxuICAgICAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICBcIm1vZGFsXCJcbiAgICAgICAgICBdLFxuICAgICAgICAgIFwic2hvd25cIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLmlzU2hvd31cbiAgICAgICAgfVxuICAgICAgXVxuICAgIH0sXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgIFwiYnRuXCJcbiAgICAgIF0sXG4gICAgICBcImV2ZW50c1wiOiB7XG4gICAgICAgIFwiY2xpY2tcIjogXCJ0b2dnbGVTaG93XCJcbiAgICAgIH0sXG4gICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAge1xuICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgXCJ2YWx1ZVwiOiBcIkNsaWNrIG1lXCJcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIF1cbiAgICB9LFxuICAgIHtcbiAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgIFwidmFsdWVcIjogXCJhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYVwiXG4gICAgICB9LFxuICAgICAgXCJzdHlsZVwiOiB7XG4gICAgICAgIFwiY29sb3JcIjogXCIjRkYwMDAwXCJcbiAgICAgIH1cbiAgICB9XG4gIF1cbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC10ZW1wbGF0ZS1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT10ZW1wbGF0ZXMhLi9zcmMvSGVsbG8vaGVsbG8ubWl4XG4vLyBtb2R1bGUgaWQgPSAxMVxuLy8gbW9kdWxlIGNodW5rcyA9IDEiLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCIuYXBwXCI6IHtcbiAgICBcImFsaWduSXRlbXNcIjogXCJmbGV4LXN0YXJ0XCIsXG4gICAgXCJmbGV4RGlyZWN0aW9uXCI6IFwiY29sdW1uXCJcbiAgfSxcbiAgXCIubW9kYWxcIjoge1xuICAgIFwicG9zaXRpb25cIjogXCJmaXhlZFwiLFxuICAgIFwid2lkdGhcIjogXCIyMDBweFwiLFxuICAgIFwiaGVpZ2h0XCI6IFwiMjAwcHhcIixcbiAgICBcInRvcFwiOiBcIjIwMHB4XCIsXG4gICAgXCJsZWZ0XCI6IFwiMjAwcHhcIixcbiAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiNGRjAwMDBcIlxuICB9LFxuICBcIi5idG5cIjoge1xuICAgIFwid2lkdGhcIjogXCIyMDBweFwiLFxuICAgIFwiaGVpZ2h0XCI6IFwiMTAwcHhcIixcbiAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiMwMDAwMDBcIlxuICB9LFxuICBcInRleHRcIjoge1xuICAgIFwiY29sb3JcIjogXCIjRkZGRkZGXCJcbiAgfVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXN0eWxlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXN0eWxlcyZyZXNvdXJjZVBhdGg9L2hvbWUvdW5pcXVlL1paWi9zcmMvSGVsbG8vaGVsbG8ubWl4IS4vc3JjL0hlbGxvL2hlbGxvLm1peFxuLy8gbW9kdWxlIGlkID0gMTJcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwiPHRlbXBsYXRlPlxuICAgIDxkaXYgY2xhc3M9XCJhcHBcIj5cbiAgICAgICAgPHN0YWNrIHN0eWxlPVwiZmxleDoxO1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsXCIgaWY9XCJ7eyBpc1Nob3cgfX1cIj48L2Rpdj5cbiAgICAgICAgPC9zdGFjaz5cbiAgICAgICAgPGRpdiBjbGFzcz1cImJ0blwiIEBjbGljaz1cInRvZ2dsZVNob3dcIj5cbiAgICAgICAgICAgIDx0ZXh0PkNsaWNrIG1lPC90ZXh0PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHRleHQgc3R5bGU9XCJjb2xvcjpyZWQ7XCI+YWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWE8L3RleHQ+XG4gICAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0PlxuICAgIGltcG9ydCBkZXZpY2UgZnJvbSAnQG1peC9taXVpLmRldmljZSdcbiAgbW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgZGF0YSAoKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpc1Nob3c6IHRydWVcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgdG9nZ2xlU2hvdyAoKSB7XG4gICAgICB0aGlzLmlzU2hvdyA9ICF0aGlzLmlzU2hvd1xuICAgICAgZGV2aWNlLmdldEluZm8oe1xuICAgICAgICBzdWNjZXNzOiAocmV0KT0+e1xuICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJldCkpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9XG48L3NjcmlwdD5cblxuPHN0eWxlPlxuICAgIC5hcHAge1xuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICB9XG5cbiAgICAubW9kYWwge1xuICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgICAgIHdpZHRoOiAyMDBweDtcbiAgICAgICAgaGVpZ2h0OiAyMDBweDtcbiAgICAgICAgdG9wOiAyMDBweDtcbiAgICAgICAgbGVmdDogMjAwcHg7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbiAgICB9XG5cbiAgICAuYnRuIHtcbiAgICAgICAgd2lkdGg6IDIwMHB4O1xuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICB9XG5cbiAgICB0ZXh0IHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbjwvc3R5bGU+XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vc3JjL0hlbGxvL2hlbGxvLm1peD84YTM3YzE2NCIsIm1vZHVsZS5leHBvcnRzID0geyBcImRlZmF1bHRcIjogcmVxdWlyZShcImNvcmUtanMvbGlicmFyeS9mbi9qc29uL3N0cmluZ2lmeVwiKSwgX19lc01vZHVsZTogdHJ1ZSB9O1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vYmFiZWwtcnVudGltZS9jb3JlLWpzL2pzb24vc3RyaW5naWZ5LmpzIiwidmFyIGNvcmUgID0gcmVxdWlyZSgnLi4vLi4vbW9kdWxlcy9fY29yZScpXG4gICwgJEpTT04gPSBjb3JlLkpTT04gfHwgKGNvcmUuSlNPTiA9IHtzdHJpbmdpZnk6IEpTT04uc3RyaW5naWZ5fSk7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHN0cmluZ2lmeShpdCl7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgcmV0dXJuICRKU09OLnN0cmluZ2lmeS5hcHBseSgkSlNPTiwgYXJndW1lbnRzKTtcbn07XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jb3JlLWpzL2xpYnJhcnkvZm4vanNvbi9zdHJpbmdpZnkuanMiLCJ2YXIgY29yZSA9IG1vZHVsZS5leHBvcnRzID0ge3ZlcnNpb246ICcyLjQuMCd9O1xuaWYodHlwZW9mIF9fZSA9PSAnbnVtYmVyJylfX2UgPSBjb3JlOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVuZGVmXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fY29yZS5qcyJdLCJzb3VyY2VSb290IjoiIn0=