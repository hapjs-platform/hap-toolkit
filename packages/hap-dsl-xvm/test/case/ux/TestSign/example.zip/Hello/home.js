/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var $miapp_template$ = __webpack_require__(11)
	var $miapp_style$ = __webpack_require__(12)
	var $miapp_script$ = __webpack_require__(13)
	
	$miapp_define$('@miapp-component/home', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})
	
	$miapp_bootstrap$('@miapp-component/home',{ packagerVersion: '0.0.3'})

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "container"
	  ],
	  "children": [
	    {
	      "type": "richtext",
	      "attr": {
	        "type": "mix",
	        "value": function () {return this.mix}
	      }
	    }
	  ]
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = {
	  ".container": {
	    "flex": 1,
	    "flexDirection": "column"
	  },
	  ".artical-content": {
	    "paddingLeft": "12px",
	    "paddingRight": "12px",
	    "fontSize": "15px",
	    "lineHeight": "25px",
	    "flexDirection": "column"
	  },
	  "text": {
	    "paddingTop": "8px",
	    "paddingBottom": "8px"
	  },
	  "a": {
	    "color": "#025fad"
	  },
	  ".content-quote": {
	    "borderLeftColor": "#C01E2F",
	    "borderStyle": "solid",
	    "borderLeftWidth": "1px",
	    "paddingLeft": "10px",
	    "marginBottom": "25px"
	  },
	  ".item-container": {
	    "flexDirection": "column"
	  }
	}

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = function(module, exports, $miapp_require$){'use strict';
	
	var CryptoJS = __webpack_require__(14);
	
	module.exports = {
	  data: function () {return {
	    show: true,
	    html: '<p class="a" style="font-size: 16px;color:#FF0000;">    原标题：杭州进一步升级房地产市场调控措施 认房又认贷</p><p style="font-size: 16px;">    杭州市住房保障和房产管理局28日发布通知称，自2017年3月29日起，进一步完善住房限购及销售监管措施。其中包括，本市户籍成年单身(含离异)人士在限购区域内限购1套住房；在市区范围内，职工家庭名下已拥有一套住房或无住房但有住房贷款记录的，购买普通自住住房执行二套住房公积金贷款政策，贷款首付款比例不低于60%，公积金贷款利率按同期住房公积金贷款基准利率1.1倍执行……</p><img src="http://himg2.huanqiu.com/attachment2010/2017/0329/20170329071244364.jpg"><img src="http://himg2.huanqiu.com/attachment2010/2017/0329/20170329071245957.jpg">',
	    mix: '<div class="item-container"><text style="background-color: red;">text</text><text><span>span</span></text></div>​'
	  }},
	  onReady: function onReady() {
	    var _this = this;
	
	    setTimeout(function () {
	      _this.html = '<article class="artical-content" style="font-size: 18px;"><div class="artical-main-pic"><img src="http://i10.hoopchina.com.cn/hupuapp/kanqiu/201702/kanqiu_0_20170216170720_701070820.png?x-oss-process=image/resize,w_600/format,jpg/quality,Q_60"></div><p>赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-赞赏新闻测试-</p><p><br></p><p class="content-quote">"终于做了终于终于做了终于终于做了终于终于做了 终于lallalallalaaaaaalllalaallalallalaaaaaalllalalllallalallalaaaaaalllalalllallalallalaaaaaalllalalllallalallalaaaaaalllalalllllllllllllllllllllllsjdflsdfldsf"</p></article>';
	      _this.$page.setTitleBar({ text: "ABC", backgroundColor: "#00FF00", textColor: "#00FFFF" });
	    }, 5000);
	  },
	  onBackPress: function onBackPress() {
	    return false;
	  },
	  click: function click() {
	    this.keyword = '';
	  }
	};}

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(16), __webpack_require__(17), __webpack_require__(18), __webpack_require__(19), __webpack_require__(20), __webpack_require__(21), __webpack_require__(22), __webpack_require__(23), __webpack_require__(24), __webpack_require__(25), __webpack_require__(26), __webpack_require__(27), __webpack_require__(28), __webpack_require__(29), __webpack_require__(30), __webpack_require__(31), __webpack_require__(32), __webpack_require__(33), __webpack_require__(34), __webpack_require__(35), __webpack_require__(36), __webpack_require__(37), __webpack_require__(38), __webpack_require__(39), __webpack_require__(40), __webpack_require__(41), __webpack_require__(42), __webpack_require__(43), __webpack_require__(44), __webpack_require__(45), __webpack_require__(46), __webpack_require__(47));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(16), __webpack_require__(17), __webpack_require__(18), __webpack_require__(19), __webpack_require__(20), __webpack_require__(21), __webpack_require__(22), __webpack_require__(23), __webpack_require__(24), __webpack_require__(25), __webpack_require__(26), __webpack_require__(27), __webpack_require__(28), __webpack_require__(29), __webpack_require__(30), __webpack_require__(31), __webpack_require__(32), __webpack_require__(33), __webpack_require__(34), __webpack_require__(35), __webpack_require__(36), __webpack_require__(37), __webpack_require__(38), __webpack_require__(39), __webpack_require__(40), __webpack_require__(41), __webpack_require__(42), __webpack_require__(43), __webpack_require__(44), __webpack_require__(45), __webpack_require__(46), __webpack_require__(47)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			root.CryptoJS = factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		return CryptoJS;
	});

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory();
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			root.CryptoJS = factory();
		}
	})(undefined, function () {
	
		/**
	  * CryptoJS core components.
	  */
		var CryptoJS = CryptoJS || function (Math, undefined) {
			/*
	   * Local polyfil of Object.create
	   */
			var create = Object.create || function () {
				function F() {};
	
				return function (obj) {
					var subtype;
	
					F.prototype = obj;
	
					subtype = new F();
	
					F.prototype = null;
	
					return subtype;
				};
			}();
	
			/**
	   * CryptoJS namespace.
	   */
			var C = {};
	
			/**
	   * Library namespace.
	   */
			var C_lib = C.lib = {};
	
			/**
	   * Base object for prototypal inheritance.
	   */
			var Base = C_lib.Base = function () {
	
				return {
					/**
	     * Creates a new object that inherits from this object.
	     *
	     * @param {Object} overrides Properties to copy into the new object.
	     *
	     * @return {Object} The new object.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var MyType = CryptoJS.lib.Base.extend({
	     *         field: 'value',
	     *
	     *         method: function () {
	     *         }
	     *     });
	     */
					extend: function extend(overrides) {
						// Spawn
						var subtype = create(this);
	
						// Augment
						if (overrides) {
							subtype.mixIn(overrides);
						}
	
						// Create default initializer
						if (!subtype.hasOwnProperty('init') || this.init === subtype.init) {
							subtype.init = function () {
								subtype.$super.init.apply(this, arguments);
							};
						}
	
						// Initializer's prototype is the subtype object
						subtype.init.prototype = subtype;
	
						// Reference supertype
						subtype.$super = this;
	
						return subtype;
					},
	
					/**
	     * Extends this object and runs the init method.
	     * Arguments to create() will be passed to init().
	     *
	     * @return {Object} The new object.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var instance = MyType.create();
	     */
					create: function create() {
						var instance = this.extend();
						instance.init.apply(instance, arguments);
	
						return instance;
					},
	
					/**
	     * Initializes a newly created object.
	     * Override this method to add some logic when your objects are created.
	     *
	     * @example
	     *
	     *     var MyType = CryptoJS.lib.Base.extend({
	     *         init: function () {
	     *             // ...
	     *         }
	     *     });
	     */
					init: function init() {},
	
					/**
	     * Copies properties into this object.
	     *
	     * @param {Object} properties The properties to mix in.
	     *
	     * @example
	     *
	     *     MyType.mixIn({
	     *         field: 'value'
	     *     });
	     */
					mixIn: function mixIn(properties) {
						for (var propertyName in properties) {
							if (properties.hasOwnProperty(propertyName)) {
								this[propertyName] = properties[propertyName];
							}
						}
	
						// IE won't copy toString using the loop above
						if (properties.hasOwnProperty('toString')) {
							this.toString = properties.toString;
						}
					},
	
					/**
	     * Creates a copy of this object.
	     *
	     * @return {Object} The clone.
	     *
	     * @example
	     *
	     *     var clone = instance.clone();
	     */
					clone: function clone() {
						return this.init.prototype.extend(this);
					}
				};
			}();
	
			/**
	   * An array of 32-bit words.
	   *
	   * @property {Array} words The array of 32-bit words.
	   * @property {number} sigBytes The number of significant bytes in this word array.
	   */
			var WordArray = C_lib.WordArray = Base.extend({
				/**
	    * Initializes a newly created word array.
	    *
	    * @param {Array} words (Optional) An array of 32-bit words.
	    * @param {number} sigBytes (Optional) The number of significant bytes in the words.
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.lib.WordArray.create();
	    *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
	    *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
	    */
				init: function init(words, sigBytes) {
					words = this.words = words || [];
	
					if (sigBytes != undefined) {
						this.sigBytes = sigBytes;
					} else {
						this.sigBytes = words.length * 4;
					}
				},
	
				/**
	    * Converts this word array to a string.
	    *
	    * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
	    *
	    * @return {string} The stringified word array.
	    *
	    * @example
	    *
	    *     var string = wordArray + '';
	    *     var string = wordArray.toString();
	    *     var string = wordArray.toString(CryptoJS.enc.Utf8);
	    */
				toString: function toString(encoder) {
					return (encoder || Hex).stringify(this);
				},
	
				/**
	    * Concatenates a word array to this word array.
	    *
	    * @param {WordArray} wordArray The word array to append.
	    *
	    * @return {WordArray} This word array.
	    *
	    * @example
	    *
	    *     wordArray1.concat(wordArray2);
	    */
				concat: function concat(wordArray) {
					// Shortcuts
					var thisWords = this.words;
					var thatWords = wordArray.words;
					var thisSigBytes = this.sigBytes;
					var thatSigBytes = wordArray.sigBytes;
	
					// Clamp excess bits
					this.clamp();
	
					// Concat
					if (thisSigBytes % 4) {
						// Copy one byte at a time
						for (var i = 0; i < thatSigBytes; i++) {
							var thatByte = thatWords[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
							thisWords[thisSigBytes + i >>> 2] |= thatByte << 24 - (thisSigBytes + i) % 4 * 8;
						}
					} else {
						// Copy one word at a time
						for (var i = 0; i < thatSigBytes; i += 4) {
							thisWords[thisSigBytes + i >>> 2] = thatWords[i >>> 2];
						}
					}
					this.sigBytes += thatSigBytes;
	
					// Chainable
					return this;
				},
	
				/**
	    * Removes insignificant bits.
	    *
	    * @example
	    *
	    *     wordArray.clamp();
	    */
				clamp: function clamp() {
					// Shortcuts
					var words = this.words;
					var sigBytes = this.sigBytes;
	
					// Clamp
					words[sigBytes >>> 2] &= 0xffffffff << 32 - sigBytes % 4 * 8;
					words.length = Math.ceil(sigBytes / 4);
				},
	
				/**
	    * Creates a copy of this word array.
	    *
	    * @return {WordArray} The clone.
	    *
	    * @example
	    *
	    *     var clone = wordArray.clone();
	    */
				clone: function clone() {
					var clone = Base.clone.call(this);
					clone.words = this.words.slice(0);
	
					return clone;
				},
	
				/**
	    * Creates a word array filled with random bytes.
	    *
	    * @param {number} nBytes The number of random bytes to generate.
	    *
	    * @return {WordArray} The random word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.lib.WordArray.random(16);
	    */
				random: function random(nBytes) {
					var words = [];
	
					var r = function r(m_w) {
						var m_w = m_w;
						var m_z = 0x3ade68b1;
						var mask = 0xffffffff;
	
						return function () {
							m_z = 0x9069 * (m_z & 0xFFFF) + (m_z >> 0x10) & mask;
							m_w = 0x4650 * (m_w & 0xFFFF) + (m_w >> 0x10) & mask;
							var result = (m_z << 0x10) + m_w & mask;
							result /= 0x100000000;
							result += 0.5;
							return result * (Math.random() > .5 ? 1 : -1);
						};
					};
	
					for (var i = 0, rcache; i < nBytes; i += 4) {
						var _r = r((rcache || Math.random()) * 0x100000000);
	
						rcache = _r() * 0x3ade67b7;
						words.push(_r() * 0x100000000 | 0);
					}
	
					return new WordArray.init(words, nBytes);
				}
			});
	
			/**
	   * Encoder namespace.
	   */
			var C_enc = C.enc = {};
	
			/**
	   * Hex encoding strategy.
	   */
			var Hex = C_enc.Hex = {
				/**
	    * Converts a word array to a hex string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The hex string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					// Shortcuts
					var words = wordArray.words;
					var sigBytes = wordArray.sigBytes;
	
					// Convert
					var hexChars = [];
					for (var i = 0; i < sigBytes; i++) {
						var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
						hexChars.push((bite >>> 4).toString(16));
						hexChars.push((bite & 0x0f).toString(16));
					}
	
					return hexChars.join('');
				},
	
				/**
	    * Converts a hex string to a word array.
	    *
	    * @param {string} hexStr The hex string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
	    */
				parse: function parse(hexStr) {
					// Shortcut
					var hexStrLength = hexStr.length;
	
					// Convert
					var words = [];
					for (var i = 0; i < hexStrLength; i += 2) {
						words[i >>> 3] |= parseInt(hexStr.substr(i, 2), 16) << 24 - i % 8 * 4;
					}
	
					return new WordArray.init(words, hexStrLength / 2);
				}
			};
	
			/**
	   * Latin1 encoding strategy.
	   */
			var Latin1 = C_enc.Latin1 = {
				/**
	    * Converts a word array to a Latin1 string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The Latin1 string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					// Shortcuts
					var words = wordArray.words;
					var sigBytes = wordArray.sigBytes;
	
					// Convert
					var latin1Chars = [];
					for (var i = 0; i < sigBytes; i++) {
						var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
						latin1Chars.push(String.fromCharCode(bite));
					}
	
					return latin1Chars.join('');
				},
	
				/**
	    * Converts a Latin1 string to a word array.
	    *
	    * @param {string} latin1Str The Latin1 string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
	    */
				parse: function parse(latin1Str) {
					// Shortcut
					var latin1StrLength = latin1Str.length;
	
					// Convert
					var words = [];
					for (var i = 0; i < latin1StrLength; i++) {
						words[i >>> 2] |= (latin1Str.charCodeAt(i) & 0xff) << 24 - i % 4 * 8;
					}
	
					return new WordArray.init(words, latin1StrLength);
				}
			};
	
			/**
	   * UTF-8 encoding strategy.
	   */
			var Utf8 = C_enc.Utf8 = {
				/**
	    * Converts a word array to a UTF-8 string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The UTF-8 string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					try {
						return decodeURIComponent(escape(Latin1.stringify(wordArray)));
					} catch (e) {
						throw new Error('Malformed UTF-8 data');
					}
				},
	
				/**
	    * Converts a UTF-8 string to a word array.
	    *
	    * @param {string} utf8Str The UTF-8 string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
	    */
				parse: function parse(utf8Str) {
					return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
				}
			};
	
			/**
	   * Abstract buffered block algorithm template.
	   *
	   * The property blockSize must be implemented in a concrete subtype.
	   *
	   * @property {number} _minBufferSize The number of blocks that should be kept unprocessed in the buffer. Default: 0
	   */
			var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm = Base.extend({
				/**
	    * Resets this block algorithm's data buffer to its initial state.
	    *
	    * @example
	    *
	    *     bufferedBlockAlgorithm.reset();
	    */
				reset: function reset() {
					// Initial values
					this._data = new WordArray.init();
					this._nDataBytes = 0;
				},
	
				/**
	    * Adds new data to this block algorithm's buffer.
	    *
	    * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
	    *
	    * @example
	    *
	    *     bufferedBlockAlgorithm._append('data');
	    *     bufferedBlockAlgorithm._append(wordArray);
	    */
				_append: function _append(data) {
					// Convert string to WordArray, else assume WordArray already
					if (typeof data == 'string') {
						data = Utf8.parse(data);
					}
	
					// Append
					this._data.concat(data);
					this._nDataBytes += data.sigBytes;
				},
	
				/**
	    * Processes available data blocks.
	    *
	    * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
	    *
	    * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
	    *
	    * @return {WordArray} The processed data.
	    *
	    * @example
	    *
	    *     var processedData = bufferedBlockAlgorithm._process();
	    *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
	    */
				_process: function _process(doFlush) {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
					var dataSigBytes = data.sigBytes;
					var blockSize = this.blockSize;
					var blockSizeBytes = blockSize * 4;
	
					// Count blocks ready
					var nBlocksReady = dataSigBytes / blockSizeBytes;
					if (doFlush) {
						// Round up to include partial blocks
						nBlocksReady = Math.ceil(nBlocksReady);
					} else {
						// Round down to include only full blocks,
						// less the number of blocks that must remain in the buffer
						nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
					}
	
					// Count words ready
					var nWordsReady = nBlocksReady * blockSize;
	
					// Count bytes ready
					var nBytesReady = Math.min(nWordsReady * 4, dataSigBytes);
	
					// Process blocks
					if (nWordsReady) {
						for (var offset = 0; offset < nWordsReady; offset += blockSize) {
							// Perform concrete-algorithm logic
							this._doProcessBlock(dataWords, offset);
						}
	
						// Remove processed words
						var processedWords = dataWords.splice(0, nWordsReady);
						data.sigBytes -= nBytesReady;
					}
	
					// Return processed words
					return new WordArray.init(processedWords, nBytesReady);
				},
	
				/**
	    * Creates a copy of this object.
	    *
	    * @return {Object} The clone.
	    *
	    * @example
	    *
	    *     var clone = bufferedBlockAlgorithm.clone();
	    */
				clone: function clone() {
					var clone = Base.clone.call(this);
					clone._data = this._data.clone();
	
					return clone;
				},
	
				_minBufferSize: 0
			});
	
			/**
	   * Abstract hasher template.
	   *
	   * @property {number} blockSize The number of 32-bit words this hasher operates on. Default: 16 (512 bits)
	   */
			var Hasher = C_lib.Hasher = BufferedBlockAlgorithm.extend({
				/**
	    * Configuration options.
	    */
				cfg: Base.extend(),
	
				/**
	    * Initializes a newly created hasher.
	    *
	    * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
	    *
	    * @example
	    *
	    *     var hasher = CryptoJS.algo.SHA256.create();
	    */
				init: function init(cfg) {
					// Apply config defaults
					this.cfg = this.cfg.extend(cfg);
	
					// Set initial values
					this.reset();
				},
	
				/**
	    * Resets this hasher to its initial state.
	    *
	    * @example
	    *
	    *     hasher.reset();
	    */
				reset: function reset() {
					// Reset data buffer
					BufferedBlockAlgorithm.reset.call(this);
	
					// Perform concrete-hasher logic
					this._doReset();
				},
	
				/**
	    * Updates this hasher with a message.
	    *
	    * @param {WordArray|string} messageUpdate The message to append.
	    *
	    * @return {Hasher} This hasher.
	    *
	    * @example
	    *
	    *     hasher.update('message');
	    *     hasher.update(wordArray);
	    */
				update: function update(messageUpdate) {
					// Append
					this._append(messageUpdate);
	
					// Update the hash
					this._process();
	
					// Chainable
					return this;
				},
	
				/**
	    * Finalizes the hash computation.
	    * Note that the finalize operation is effectively a destructive, read-once operation.
	    *
	    * @param {WordArray|string} messageUpdate (Optional) A final message update.
	    *
	    * @return {WordArray} The hash.
	    *
	    * @example
	    *
	    *     var hash = hasher.finalize();
	    *     var hash = hasher.finalize('message');
	    *     var hash = hasher.finalize(wordArray);
	    */
				finalize: function finalize(messageUpdate) {
					// Final message update
					if (messageUpdate) {
						this._append(messageUpdate);
					}
	
					// Perform concrete-hasher logic
					var hash = this._doFinalize();
	
					return hash;
				},
	
				blockSize: 512 / 32,
	
				/**
	    * Creates a shortcut function to a hasher's object interface.
	    *
	    * @param {Hasher} hasher The hasher to create a helper for.
	    *
	    * @return {Function} The shortcut function.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
	    */
				_createHelper: function _createHelper(hasher) {
					return function (message, cfg) {
						return new hasher.init(cfg).finalize(message);
					};
				},
	
				/**
	    * Creates a shortcut function to the HMAC's object interface.
	    *
	    * @param {Hasher} hasher The hasher to use in this HMAC helper.
	    *
	    * @return {Function} The shortcut function.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
	    */
				_createHmacHelper: function _createHmacHelper(hasher) {
					return function (message, key) {
						return new C_algo.HMAC.init(hasher, key).finalize(message);
					};
				}
			});
	
			/**
	   * Algorithm namespace.
	   */
			var C_algo = C.algo = {};
	
			return C;
		}(Math);
	
		return CryptoJS;
	});

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function (undefined) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Base = C_lib.Base;
			var X32WordArray = C_lib.WordArray;
	
			/**
	   * x64 namespace.
	   */
			var C_x64 = C.x64 = {};
	
			/**
	   * A 64-bit word.
	   */
			var X64Word = C_x64.Word = Base.extend({
				/**
	    * Initializes a newly created 64-bit word.
	    *
	    * @param {number} high The high 32 bits.
	    * @param {number} low The low 32 bits.
	    *
	    * @example
	    *
	    *     var x64Word = CryptoJS.x64.Word.create(0x00010203, 0x04050607);
	    */
				init: function init(high, low) {
					this.high = high;
					this.low = low;
				}
	
				/**
	    * Bitwise NOTs this word.
	    *
	    * @return {X64Word} A new x64-Word object after negating.
	    *
	    * @example
	    *
	    *     var negated = x64Word.not();
	    */
				// not: function () {
				// var high = ~this.high;
				// var low = ~this.low;
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Bitwise ANDs this word with the passed word.
	    *
	    * @param {X64Word} word The x64-Word to AND with this word.
	    *
	    * @return {X64Word} A new x64-Word object after ANDing.
	    *
	    * @example
	    *
	    *     var anded = x64Word.and(anotherX64Word);
	    */
				// and: function (word) {
				// var high = this.high & word.high;
				// var low = this.low & word.low;
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Bitwise ORs this word with the passed word.
	    *
	    * @param {X64Word} word The x64-Word to OR with this word.
	    *
	    * @return {X64Word} A new x64-Word object after ORing.
	    *
	    * @example
	    *
	    *     var ored = x64Word.or(anotherX64Word);
	    */
				// or: function (word) {
				// var high = this.high | word.high;
				// var low = this.low | word.low;
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Bitwise XORs this word with the passed word.
	    *
	    * @param {X64Word} word The x64-Word to XOR with this word.
	    *
	    * @return {X64Word} A new x64-Word object after XORing.
	    *
	    * @example
	    *
	    *     var xored = x64Word.xor(anotherX64Word);
	    */
				// xor: function (word) {
				// var high = this.high ^ word.high;
				// var low = this.low ^ word.low;
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Shifts this word n bits to the left.
	    *
	    * @param {number} n The number of bits to shift.
	    *
	    * @return {X64Word} A new x64-Word object after shifting.
	    *
	    * @example
	    *
	    *     var shifted = x64Word.shiftL(25);
	    */
				// shiftL: function (n) {
				// if (n < 32) {
				// var high = (this.high << n) | (this.low >>> (32 - n));
				// var low = this.low << n;
				// } else {
				// var high = this.low << (n - 32);
				// var low = 0;
				// }
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Shifts this word n bits to the right.
	    *
	    * @param {number} n The number of bits to shift.
	    *
	    * @return {X64Word} A new x64-Word object after shifting.
	    *
	    * @example
	    *
	    *     var shifted = x64Word.shiftR(7);
	    */
				// shiftR: function (n) {
				// if (n < 32) {
				// var low = (this.low >>> n) | (this.high << (32 - n));
				// var high = this.high >>> n;
				// } else {
				// var low = this.high >>> (n - 32);
				// var high = 0;
				// }
	
				// return X64Word.create(high, low);
				// },
	
				/**
	    * Rotates this word n bits to the left.
	    *
	    * @param {number} n The number of bits to rotate.
	    *
	    * @return {X64Word} A new x64-Word object after rotating.
	    *
	    * @example
	    *
	    *     var rotated = x64Word.rotL(25);
	    */
				// rotL: function (n) {
				// return this.shiftL(n).or(this.shiftR(64 - n));
				// },
	
				/**
	    * Rotates this word n bits to the right.
	    *
	    * @param {number} n The number of bits to rotate.
	    *
	    * @return {X64Word} A new x64-Word object after rotating.
	    *
	    * @example
	    *
	    *     var rotated = x64Word.rotR(7);
	    */
				// rotR: function (n) {
				// return this.shiftR(n).or(this.shiftL(64 - n));
				// },
	
				/**
	    * Adds this word with the passed word.
	    *
	    * @param {X64Word} word The x64-Word to add with this word.
	    *
	    * @return {X64Word} A new x64-Word object after adding.
	    *
	    * @example
	    *
	    *     var added = x64Word.add(anotherX64Word);
	    */
				// add: function (word) {
				// var low = (this.low + word.low) | 0;
				// var carry = (low >>> 0) < (this.low >>> 0) ? 1 : 0;
				// var high = (this.high + word.high + carry) | 0;
	
				// return X64Word.create(high, low);
				// }
			});
	
			/**
	   * An array of 64-bit words.
	   *
	   * @property {Array} words The array of CryptoJS.x64.Word objects.
	   * @property {number} sigBytes The number of significant bytes in this word array.
	   */
			var X64WordArray = C_x64.WordArray = Base.extend({
				/**
	    * Initializes a newly created word array.
	    *
	    * @param {Array} words (Optional) An array of CryptoJS.x64.Word objects.
	    * @param {number} sigBytes (Optional) The number of significant bytes in the words.
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.x64.WordArray.create();
	    *
	    *     var wordArray = CryptoJS.x64.WordArray.create([
	    *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
	    *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
	    *     ]);
	    *
	    *     var wordArray = CryptoJS.x64.WordArray.create([
	    *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
	    *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
	    *     ], 10);
	    */
				init: function init(words, sigBytes) {
					words = this.words = words || [];
	
					if (sigBytes != undefined) {
						this.sigBytes = sigBytes;
					} else {
						this.sigBytes = words.length * 8;
					}
				},
	
				/**
	    * Converts this 64-bit word array to a 32-bit word array.
	    *
	    * @return {CryptoJS.lib.WordArray} This word array's data as a 32-bit word array.
	    *
	    * @example
	    *
	    *     var x32WordArray = x64WordArray.toX32();
	    */
				toX32: function toX32() {
					// Shortcuts
					var x64Words = this.words;
					var x64WordsLength = x64Words.length;
	
					// Convert
					var x32Words = [];
					for (var i = 0; i < x64WordsLength; i++) {
						var x64Word = x64Words[i];
						x32Words.push(x64Word.high);
						x32Words.push(x64Word.low);
					}
	
					return X32WordArray.create(x32Words, this.sigBytes);
				},
	
				/**
	    * Creates a copy of this word array.
	    *
	    * @return {X64WordArray} The clone.
	    *
	    * @example
	    *
	    *     var clone = x64WordArray.clone();
	    */
				clone: function clone() {
					var clone = Base.clone.call(this);
	
					// Clone "words" array
					var words = clone.words = this.words.slice(0);
	
					// Clone each X64Word object
					var wordsLength = words.length;
					for (var i = 0; i < wordsLength; i++) {
						words[i] = words[i].clone();
					}
	
					return clone;
				}
			});
		})();
	
		return CryptoJS;
	});

/***/ },
/* 17 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Check if typed arrays are supported
			if (typeof ArrayBuffer != 'function') {
				return;
			}
	
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
	
			// Reference original init
			var superInit = WordArray.init;
	
			// Augment WordArray.init to handle typed arrays
			var subInit = WordArray.init = function (typedArray) {
				// Convert buffers to uint8
				if (typedArray instanceof ArrayBuffer) {
					typedArray = new Uint8Array(typedArray);
				}
	
				// Convert other array views to uint8
				if (typedArray instanceof Int8Array || typeof Uint8ClampedArray !== "undefined" && typedArray instanceof Uint8ClampedArray || typedArray instanceof Int16Array || typedArray instanceof Uint16Array || typedArray instanceof Int32Array || typedArray instanceof Uint32Array || typedArray instanceof Float32Array || typedArray instanceof Float64Array) {
					typedArray = new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength);
				}
	
				// Handle Uint8Array
				if (typedArray instanceof Uint8Array) {
					// Shortcut
					var typedArrayByteLength = typedArray.byteLength;
	
					// Extract bytes
					var words = [];
					for (var i = 0; i < typedArrayByteLength; i++) {
						words[i >>> 2] |= typedArray[i] << 24 - i % 4 * 8;
					}
	
					// Initialize this word array
					superInit.call(this, words, typedArrayByteLength);
				} else {
					// Else call normal init
					superInit.apply(this, arguments);
				}
			};
	
			subInit.prototype = WordArray;
		})();
	
		return CryptoJS.lib.WordArray;
	});

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var C_enc = C.enc;
	
			/**
	   * UTF-16 BE encoding strategy.
	   */
			var Utf16BE = C_enc.Utf16 = C_enc.Utf16BE = {
				/**
	    * Converts a word array to a UTF-16 BE string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The UTF-16 BE string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var utf16String = CryptoJS.enc.Utf16.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					// Shortcuts
					var words = wordArray.words;
					var sigBytes = wordArray.sigBytes;
	
					// Convert
					var utf16Chars = [];
					for (var i = 0; i < sigBytes; i += 2) {
						var codePoint = words[i >>> 2] >>> 16 - i % 4 * 8 & 0xffff;
						utf16Chars.push(String.fromCharCode(codePoint));
					}
	
					return utf16Chars.join('');
				},
	
				/**
	    * Converts a UTF-16 BE string to a word array.
	    *
	    * @param {string} utf16Str The UTF-16 BE string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Utf16.parse(utf16String);
	    */
				parse: function parse(utf16Str) {
					// Shortcut
					var utf16StrLength = utf16Str.length;
	
					// Convert
					var words = [];
					for (var i = 0; i < utf16StrLength; i++) {
						words[i >>> 1] |= utf16Str.charCodeAt(i) << 16 - i % 2 * 16;
					}
	
					return WordArray.create(words, utf16StrLength * 2);
				}
			};
	
			/**
	   * UTF-16 LE encoding strategy.
	   */
			C_enc.Utf16LE = {
				/**
	    * Converts a word array to a UTF-16 LE string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The UTF-16 LE string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var utf16Str = CryptoJS.enc.Utf16LE.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					// Shortcuts
					var words = wordArray.words;
					var sigBytes = wordArray.sigBytes;
	
					// Convert
					var utf16Chars = [];
					for (var i = 0; i < sigBytes; i += 2) {
						var codePoint = swapEndian(words[i >>> 2] >>> 16 - i % 4 * 8 & 0xffff);
						utf16Chars.push(String.fromCharCode(codePoint));
					}
	
					return utf16Chars.join('');
				},
	
				/**
	    * Converts a UTF-16 LE string to a word array.
	    *
	    * @param {string} utf16Str The UTF-16 LE string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Utf16LE.parse(utf16Str);
	    */
				parse: function parse(utf16Str) {
					// Shortcut
					var utf16StrLength = utf16Str.length;
	
					// Convert
					var words = [];
					for (var i = 0; i < utf16StrLength; i++) {
						words[i >>> 1] |= swapEndian(utf16Str.charCodeAt(i) << 16 - i % 2 * 16);
					}
	
					return WordArray.create(words, utf16StrLength * 2);
				}
			};
	
			function swapEndian(word) {
				return word << 8 & 0xff00ff00 | word >>> 8 & 0x00ff00ff;
			}
		})();
	
		return CryptoJS.enc.Utf16;
	});

/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var C_enc = C.enc;
	
			/**
	   * Base64 encoding strategy.
	   */
			var Base64 = C_enc.Base64 = {
				/**
	    * Converts a word array to a Base64 string.
	    *
	    * @param {WordArray} wordArray The word array.
	    *
	    * @return {string} The Base64 string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);
	    */
				stringify: function stringify(wordArray) {
					// Shortcuts
					var words = wordArray.words;
					var sigBytes = wordArray.sigBytes;
					var map = this._map;
	
					// Clamp excess bits
					wordArray.clamp();
	
					// Convert
					var base64Chars = [];
					for (var i = 0; i < sigBytes; i += 3) {
						var byte1 = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
						var byte2 = words[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 0xff;
						var byte3 = words[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 0xff;
	
						var triplet = byte1 << 16 | byte2 << 8 | byte3;
	
						for (var j = 0; j < 4 && i + j * 0.75 < sigBytes; j++) {
							base64Chars.push(map.charAt(triplet >>> 6 * (3 - j) & 0x3f));
						}
					}
	
					// Add padding
					var paddingChar = map.charAt(64);
					if (paddingChar) {
						while (base64Chars.length % 4) {
							base64Chars.push(paddingChar);
						}
					}
	
					return base64Chars.join('');
				},
	
				/**
	    * Converts a Base64 string to a word array.
	    *
	    * @param {string} base64Str The Base64 string.
	    *
	    * @return {WordArray} The word array.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var wordArray = CryptoJS.enc.Base64.parse(base64String);
	    */
				parse: function parse(base64Str) {
					// Shortcuts
					var base64StrLength = base64Str.length;
					var map = this._map;
					var reverseMap = this._reverseMap;
	
					if (!reverseMap) {
						reverseMap = this._reverseMap = [];
						for (var j = 0; j < map.length; j++) {
							reverseMap[map.charCodeAt(j)] = j;
						}
					}
	
					// Ignore padding
					var paddingChar = map.charAt(64);
					if (paddingChar) {
						var paddingIndex = base64Str.indexOf(paddingChar);
						if (paddingIndex !== -1) {
							base64StrLength = paddingIndex;
						}
					}
	
					// Convert
					return parseLoop(base64Str, base64StrLength, reverseMap);
				},
	
				_map: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
			};
	
			function parseLoop(base64Str, base64StrLength, reverseMap) {
				var words = [];
				var nBytes = 0;
				for (var i = 0; i < base64StrLength; i++) {
					if (i % 4) {
						var bits1 = reverseMap[base64Str.charCodeAt(i - 1)] << i % 4 * 2;
						var bits2 = reverseMap[base64Str.charCodeAt(i)] >>> 6 - i % 4 * 2;
						words[nBytes >>> 2] |= (bits1 | bits2) << 24 - nBytes % 4 * 8;
						nBytes++;
					}
				}
				return WordArray.create(words, nBytes);
			}
		})();
	
		return CryptoJS.enc.Base64;
	});

/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function (Math) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var Hasher = C_lib.Hasher;
			var C_algo = C.algo;
	
			// Constants table
			var T = [];
	
			// Compute constants
			(function () {
				for (var i = 0; i < 64; i++) {
					T[i] = Math.abs(Math.sin(i + 1)) * 0x100000000 | 0;
				}
			})();
	
			/**
	   * MD5 hash algorithm.
	   */
			var MD5 = C_algo.MD5 = Hasher.extend({
				_doReset: function _doReset() {
					this._hash = new WordArray.init([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]);
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Swap endian
					for (var i = 0; i < 16; i++) {
						// Shortcuts
						var offset_i = offset + i;
						var M_offset_i = M[offset_i];
	
						M[offset_i] = (M_offset_i << 8 | M_offset_i >>> 24) & 0x00ff00ff | (M_offset_i << 24 | M_offset_i >>> 8) & 0xff00ff00;
					}
	
					// Shortcuts
					var H = this._hash.words;
	
					var M_offset_0 = M[offset + 0];
					var M_offset_1 = M[offset + 1];
					var M_offset_2 = M[offset + 2];
					var M_offset_3 = M[offset + 3];
					var M_offset_4 = M[offset + 4];
					var M_offset_5 = M[offset + 5];
					var M_offset_6 = M[offset + 6];
					var M_offset_7 = M[offset + 7];
					var M_offset_8 = M[offset + 8];
					var M_offset_9 = M[offset + 9];
					var M_offset_10 = M[offset + 10];
					var M_offset_11 = M[offset + 11];
					var M_offset_12 = M[offset + 12];
					var M_offset_13 = M[offset + 13];
					var M_offset_14 = M[offset + 14];
					var M_offset_15 = M[offset + 15];
	
					// Working varialbes
					var a = H[0];
					var b = H[1];
					var c = H[2];
					var d = H[3];
	
					// Computation
					a = FF(a, b, c, d, M_offset_0, 7, T[0]);
					d = FF(d, a, b, c, M_offset_1, 12, T[1]);
					c = FF(c, d, a, b, M_offset_2, 17, T[2]);
					b = FF(b, c, d, a, M_offset_3, 22, T[3]);
					a = FF(a, b, c, d, M_offset_4, 7, T[4]);
					d = FF(d, a, b, c, M_offset_5, 12, T[5]);
					c = FF(c, d, a, b, M_offset_6, 17, T[6]);
					b = FF(b, c, d, a, M_offset_7, 22, T[7]);
					a = FF(a, b, c, d, M_offset_8, 7, T[8]);
					d = FF(d, a, b, c, M_offset_9, 12, T[9]);
					c = FF(c, d, a, b, M_offset_10, 17, T[10]);
					b = FF(b, c, d, a, M_offset_11, 22, T[11]);
					a = FF(a, b, c, d, M_offset_12, 7, T[12]);
					d = FF(d, a, b, c, M_offset_13, 12, T[13]);
					c = FF(c, d, a, b, M_offset_14, 17, T[14]);
					b = FF(b, c, d, a, M_offset_15, 22, T[15]);
	
					a = GG(a, b, c, d, M_offset_1, 5, T[16]);
					d = GG(d, a, b, c, M_offset_6, 9, T[17]);
					c = GG(c, d, a, b, M_offset_11, 14, T[18]);
					b = GG(b, c, d, a, M_offset_0, 20, T[19]);
					a = GG(a, b, c, d, M_offset_5, 5, T[20]);
					d = GG(d, a, b, c, M_offset_10, 9, T[21]);
					c = GG(c, d, a, b, M_offset_15, 14, T[22]);
					b = GG(b, c, d, a, M_offset_4, 20, T[23]);
					a = GG(a, b, c, d, M_offset_9, 5, T[24]);
					d = GG(d, a, b, c, M_offset_14, 9, T[25]);
					c = GG(c, d, a, b, M_offset_3, 14, T[26]);
					b = GG(b, c, d, a, M_offset_8, 20, T[27]);
					a = GG(a, b, c, d, M_offset_13, 5, T[28]);
					d = GG(d, a, b, c, M_offset_2, 9, T[29]);
					c = GG(c, d, a, b, M_offset_7, 14, T[30]);
					b = GG(b, c, d, a, M_offset_12, 20, T[31]);
	
					a = HH(a, b, c, d, M_offset_5, 4, T[32]);
					d = HH(d, a, b, c, M_offset_8, 11, T[33]);
					c = HH(c, d, a, b, M_offset_11, 16, T[34]);
					b = HH(b, c, d, a, M_offset_14, 23, T[35]);
					a = HH(a, b, c, d, M_offset_1, 4, T[36]);
					d = HH(d, a, b, c, M_offset_4, 11, T[37]);
					c = HH(c, d, a, b, M_offset_7, 16, T[38]);
					b = HH(b, c, d, a, M_offset_10, 23, T[39]);
					a = HH(a, b, c, d, M_offset_13, 4, T[40]);
					d = HH(d, a, b, c, M_offset_0, 11, T[41]);
					c = HH(c, d, a, b, M_offset_3, 16, T[42]);
					b = HH(b, c, d, a, M_offset_6, 23, T[43]);
					a = HH(a, b, c, d, M_offset_9, 4, T[44]);
					d = HH(d, a, b, c, M_offset_12, 11, T[45]);
					c = HH(c, d, a, b, M_offset_15, 16, T[46]);
					b = HH(b, c, d, a, M_offset_2, 23, T[47]);
	
					a = II(a, b, c, d, M_offset_0, 6, T[48]);
					d = II(d, a, b, c, M_offset_7, 10, T[49]);
					c = II(c, d, a, b, M_offset_14, 15, T[50]);
					b = II(b, c, d, a, M_offset_5, 21, T[51]);
					a = II(a, b, c, d, M_offset_12, 6, T[52]);
					d = II(d, a, b, c, M_offset_3, 10, T[53]);
					c = II(c, d, a, b, M_offset_10, 15, T[54]);
					b = II(b, c, d, a, M_offset_1, 21, T[55]);
					a = II(a, b, c, d, M_offset_8, 6, T[56]);
					d = II(d, a, b, c, M_offset_15, 10, T[57]);
					c = II(c, d, a, b, M_offset_6, 15, T[58]);
					b = II(b, c, d, a, M_offset_13, 21, T[59]);
					a = II(a, b, c, d, M_offset_4, 6, T[60]);
					d = II(d, a, b, c, M_offset_11, 10, T[61]);
					c = II(c, d, a, b, M_offset_2, 15, T[62]);
					b = II(b, c, d, a, M_offset_9, 21, T[63]);
	
					// Intermediate hash value
					H[0] = H[0] + a | 0;
					H[1] = H[1] + b | 0;
					H[2] = H[2] + c | 0;
					H[3] = H[3] + d | 0;
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
	
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
	
					var nBitsTotalH = Math.floor(nBitsTotal / 0x100000000);
					var nBitsTotalL = nBitsTotal;
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 15] = (nBitsTotalH << 8 | nBitsTotalH >>> 24) & 0x00ff00ff | (nBitsTotalH << 24 | nBitsTotalH >>> 8) & 0xff00ff00;
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 14] = (nBitsTotalL << 8 | nBitsTotalL >>> 24) & 0x00ff00ff | (nBitsTotalL << 24 | nBitsTotalL >>> 8) & 0xff00ff00;
	
					data.sigBytes = (dataWords.length + 1) * 4;
	
					// Hash final blocks
					this._process();
	
					// Shortcuts
					var hash = this._hash;
					var H = hash.words;
	
					// Swap endian
					for (var i = 0; i < 4; i++) {
						// Shortcut
						var H_i = H[i];
	
						H[i] = (H_i << 8 | H_i >>> 24) & 0x00ff00ff | (H_i << 24 | H_i >>> 8) & 0xff00ff00;
					}
	
					// Return final computed hash
					return hash;
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
					clone._hash = this._hash.clone();
	
					return clone;
				}
			});
	
			function FF(a, b, c, d, x, s, t) {
				var n = a + (b & c | ~b & d) + x + t;
				return (n << s | n >>> 32 - s) + b;
			}
	
			function GG(a, b, c, d, x, s, t) {
				var n = a + (b & d | c & ~d) + x + t;
				return (n << s | n >>> 32 - s) + b;
			}
	
			function HH(a, b, c, d, x, s, t) {
				var n = a + (b ^ c ^ d) + x + t;
				return (n << s | n >>> 32 - s) + b;
			}
	
			function II(a, b, c, d, x, s, t) {
				var n = a + (c ^ (b | ~d)) + x + t;
				return (n << s | n >>> 32 - s) + b;
			}
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.MD5('message');
	   *     var hash = CryptoJS.MD5(wordArray);
	   */
			C.MD5 = Hasher._createHelper(MD5);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacMD5(message, key);
	   */
			C.HmacMD5 = Hasher._createHmacHelper(MD5);
		})(Math);
	
		return CryptoJS.MD5;
	});

/***/ },
/* 21 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var Hasher = C_lib.Hasher;
			var C_algo = C.algo;
	
			// Reusable object
			var W = [];
	
			/**
	   * SHA-1 hash algorithm.
	   */
			var SHA1 = C_algo.SHA1 = Hasher.extend({
				_doReset: function _doReset() {
					this._hash = new WordArray.init([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0]);
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcut
					var H = this._hash.words;
	
					// Working variables
					var a = H[0];
					var b = H[1];
					var c = H[2];
					var d = H[3];
					var e = H[4];
	
					// Computation
					for (var i = 0; i < 80; i++) {
						if (i < 16) {
							W[i] = M[offset + i] | 0;
						} else {
							var n = W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16];
							W[i] = n << 1 | n >>> 31;
						}
	
						var t = (a << 5 | a >>> 27) + e + W[i];
						if (i < 20) {
							t += (b & c | ~b & d) + 0x5a827999;
						} else if (i < 40) {
							t += (b ^ c ^ d) + 0x6ed9eba1;
						} else if (i < 60) {
							t += (b & c | b & d | c & d) - 0x70e44324;
						} else /* if (i < 80) */{
								t += (b ^ c ^ d) - 0x359d3e2a;
							}
	
						e = d;
						d = c;
						c = b << 30 | b >>> 2;
						b = a;
						a = t;
					}
	
					// Intermediate hash value
					H[0] = H[0] + a | 0;
					H[1] = H[1] + b | 0;
					H[2] = H[2] + c | 0;
					H[3] = H[3] + d | 0;
					H[4] = H[4] + e | 0;
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
	
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
					data.sigBytes = dataWords.length * 4;
	
					// Hash final blocks
					this._process();
	
					// Return final computed hash
					return this._hash;
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
					clone._hash = this._hash.clone();
	
					return clone;
				}
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA1('message');
	   *     var hash = CryptoJS.SHA1(wordArray);
	   */
			C.SHA1 = Hasher._createHelper(SHA1);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA1(message, key);
	   */
			C.HmacSHA1 = Hasher._createHmacHelper(SHA1);
		})();
	
		return CryptoJS.SHA1;
	});

/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function (Math) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var Hasher = C_lib.Hasher;
			var C_algo = C.algo;
	
			// Initialization and round constants tables
			var H = [];
			var K = [];
	
			// Compute constants
			(function () {
				function isPrime(n) {
					var sqrtN = Math.sqrt(n);
					for (var factor = 2; factor <= sqrtN; factor++) {
						if (!(n % factor)) {
							return false;
						}
					}
	
					return true;
				}
	
				function getFractionalBits(n) {
					return (n - (n | 0)) * 0x100000000 | 0;
				}
	
				var n = 2;
				var nPrime = 0;
				while (nPrime < 64) {
					if (isPrime(n)) {
						if (nPrime < 8) {
							H[nPrime] = getFractionalBits(Math.pow(n, 1 / 2));
						}
						K[nPrime] = getFractionalBits(Math.pow(n, 1 / 3));
	
						nPrime++;
					}
	
					n++;
				}
			})();
	
			// Reusable object
			var W = [];
	
			/**
	   * SHA-256 hash algorithm.
	   */
			var SHA256 = C_algo.SHA256 = Hasher.extend({
				_doReset: function _doReset() {
					this._hash = new WordArray.init(H.slice(0));
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcut
					var H = this._hash.words;
	
					// Working variables
					var a = H[0];
					var b = H[1];
					var c = H[2];
					var d = H[3];
					var e = H[4];
					var f = H[5];
					var g = H[6];
					var h = H[7];
	
					// Computation
					for (var i = 0; i < 64; i++) {
						if (i < 16) {
							W[i] = M[offset + i] | 0;
						} else {
							var gamma0x = W[i - 15];
							var gamma0 = (gamma0x << 25 | gamma0x >>> 7) ^ (gamma0x << 14 | gamma0x >>> 18) ^ gamma0x >>> 3;
	
							var gamma1x = W[i - 2];
							var gamma1 = (gamma1x << 15 | gamma1x >>> 17) ^ (gamma1x << 13 | gamma1x >>> 19) ^ gamma1x >>> 10;
	
							W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16];
						}
	
						var ch = e & f ^ ~e & g;
						var maj = a & b ^ a & c ^ b & c;
	
						var sigma0 = (a << 30 | a >>> 2) ^ (a << 19 | a >>> 13) ^ (a << 10 | a >>> 22);
						var sigma1 = (e << 26 | e >>> 6) ^ (e << 21 | e >>> 11) ^ (e << 7 | e >>> 25);
	
						var t1 = h + sigma1 + ch + K[i] + W[i];
						var t2 = sigma0 + maj;
	
						h = g;
						g = f;
						f = e;
						e = d + t1 | 0;
						d = c;
						c = b;
						b = a;
						a = t1 + t2 | 0;
					}
	
					// Intermediate hash value
					H[0] = H[0] + a | 0;
					H[1] = H[1] + b | 0;
					H[2] = H[2] + c | 0;
					H[3] = H[3] + d | 0;
					H[4] = H[4] + e | 0;
					H[5] = H[5] + f | 0;
					H[6] = H[6] + g | 0;
					H[7] = H[7] + h | 0;
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
	
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
					data.sigBytes = dataWords.length * 4;
	
					// Hash final blocks
					this._process();
	
					// Return final computed hash
					return this._hash;
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
					clone._hash = this._hash.clone();
	
					return clone;
				}
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA256('message');
	   *     var hash = CryptoJS.SHA256(wordArray);
	   */
			C.SHA256 = Hasher._createHelper(SHA256);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA256(message, key);
	   */
			C.HmacSHA256 = Hasher._createHmacHelper(SHA256);
		})(Math);
	
		return CryptoJS.SHA256;
	});

/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(22));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(22)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var C_algo = C.algo;
			var SHA256 = C_algo.SHA256;
	
			/**
	   * SHA-224 hash algorithm.
	   */
			var SHA224 = C_algo.SHA224 = SHA256.extend({
				_doReset: function _doReset() {
					this._hash = new WordArray.init([0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939, 0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4]);
				},
	
				_doFinalize: function _doFinalize() {
					var hash = SHA256._doFinalize.call(this);
	
					hash.sigBytes -= 4;
	
					return hash;
				}
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA224('message');
	   *     var hash = CryptoJS.SHA224(wordArray);
	   */
			C.SHA224 = SHA256._createHelper(SHA224);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA224(message, key);
	   */
			C.HmacSHA224 = SHA256._createHmacHelper(SHA224);
		})();
	
		return CryptoJS.SHA224;
	});

/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(16));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(16)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Hasher = C_lib.Hasher;
			var C_x64 = C.x64;
			var X64Word = C_x64.Word;
			var X64WordArray = C_x64.WordArray;
			var C_algo = C.algo;
	
			function X64Word_create() {
				return X64Word.create.apply(X64Word, arguments);
			}
	
			// Constants
			var K = [X64Word_create(0x428a2f98, 0xd728ae22), X64Word_create(0x71374491, 0x23ef65cd), X64Word_create(0xb5c0fbcf, 0xec4d3b2f), X64Word_create(0xe9b5dba5, 0x8189dbbc), X64Word_create(0x3956c25b, 0xf348b538), X64Word_create(0x59f111f1, 0xb605d019), X64Word_create(0x923f82a4, 0xaf194f9b), X64Word_create(0xab1c5ed5, 0xda6d8118), X64Word_create(0xd807aa98, 0xa3030242), X64Word_create(0x12835b01, 0x45706fbe), X64Word_create(0x243185be, 0x4ee4b28c), X64Word_create(0x550c7dc3, 0xd5ffb4e2), X64Word_create(0x72be5d74, 0xf27b896f), X64Word_create(0x80deb1fe, 0x3b1696b1), X64Word_create(0x9bdc06a7, 0x25c71235), X64Word_create(0xc19bf174, 0xcf692694), X64Word_create(0xe49b69c1, 0x9ef14ad2), X64Word_create(0xefbe4786, 0x384f25e3), X64Word_create(0x0fc19dc6, 0x8b8cd5b5), X64Word_create(0x240ca1cc, 0x77ac9c65), X64Word_create(0x2de92c6f, 0x592b0275), X64Word_create(0x4a7484aa, 0x6ea6e483), X64Word_create(0x5cb0a9dc, 0xbd41fbd4), X64Word_create(0x76f988da, 0x831153b5), X64Word_create(0x983e5152, 0xee66dfab), X64Word_create(0xa831c66d, 0x2db43210), X64Word_create(0xb00327c8, 0x98fb213f), X64Word_create(0xbf597fc7, 0xbeef0ee4), X64Word_create(0xc6e00bf3, 0x3da88fc2), X64Word_create(0xd5a79147, 0x930aa725), X64Word_create(0x06ca6351, 0xe003826f), X64Word_create(0x14292967, 0x0a0e6e70), X64Word_create(0x27b70a85, 0x46d22ffc), X64Word_create(0x2e1b2138, 0x5c26c926), X64Word_create(0x4d2c6dfc, 0x5ac42aed), X64Word_create(0x53380d13, 0x9d95b3df), X64Word_create(0x650a7354, 0x8baf63de), X64Word_create(0x766a0abb, 0x3c77b2a8), X64Word_create(0x81c2c92e, 0x47edaee6), X64Word_create(0x92722c85, 0x1482353b), X64Word_create(0xa2bfe8a1, 0x4cf10364), X64Word_create(0xa81a664b, 0xbc423001), X64Word_create(0xc24b8b70, 0xd0f89791), X64Word_create(0xc76c51a3, 0x0654be30), X64Word_create(0xd192e819, 0xd6ef5218), X64Word_create(0xd6990624, 0x5565a910), X64Word_create(0xf40e3585, 0x5771202a), X64Word_create(0x106aa070, 0x32bbd1b8), X64Word_create(0x19a4c116, 0xb8d2d0c8), X64Word_create(0x1e376c08, 0x5141ab53), X64Word_create(0x2748774c, 0xdf8eeb99), X64Word_create(0x34b0bcb5, 0xe19b48a8), X64Word_create(0x391c0cb3, 0xc5c95a63), X64Word_create(0x4ed8aa4a, 0xe3418acb), X64Word_create(0x5b9cca4f, 0x7763e373), X64Word_create(0x682e6ff3, 0xd6b2b8a3), X64Word_create(0x748f82ee, 0x5defb2fc), X64Word_create(0x78a5636f, 0x43172f60), X64Word_create(0x84c87814, 0xa1f0ab72), X64Word_create(0x8cc70208, 0x1a6439ec), X64Word_create(0x90befffa, 0x23631e28), X64Word_create(0xa4506ceb, 0xde82bde9), X64Word_create(0xbef9a3f7, 0xb2c67915), X64Word_create(0xc67178f2, 0xe372532b), X64Word_create(0xca273ece, 0xea26619c), X64Word_create(0xd186b8c7, 0x21c0c207), X64Word_create(0xeada7dd6, 0xcde0eb1e), X64Word_create(0xf57d4f7f, 0xee6ed178), X64Word_create(0x06f067aa, 0x72176fba), X64Word_create(0x0a637dc5, 0xa2c898a6), X64Word_create(0x113f9804, 0xbef90dae), X64Word_create(0x1b710b35, 0x131c471b), X64Word_create(0x28db77f5, 0x23047d84), X64Word_create(0x32caab7b, 0x40c72493), X64Word_create(0x3c9ebe0a, 0x15c9bebc), X64Word_create(0x431d67c4, 0x9c100d4c), X64Word_create(0x4cc5d4be, 0xcb3e42b6), X64Word_create(0x597f299c, 0xfc657e2a), X64Word_create(0x5fcb6fab, 0x3ad6faec), X64Word_create(0x6c44198c, 0x4a475817)];
	
			// Reusable objects
			var W = [];
			(function () {
				for (var i = 0; i < 80; i++) {
					W[i] = X64Word_create();
				}
			})();
	
			/**
	   * SHA-512 hash algorithm.
	   */
			var SHA512 = C_algo.SHA512 = Hasher.extend({
				_doReset: function _doReset() {
					this._hash = new X64WordArray.init([new X64Word.init(0x6a09e667, 0xf3bcc908), new X64Word.init(0xbb67ae85, 0x84caa73b), new X64Word.init(0x3c6ef372, 0xfe94f82b), new X64Word.init(0xa54ff53a, 0x5f1d36f1), new X64Word.init(0x510e527f, 0xade682d1), new X64Word.init(0x9b05688c, 0x2b3e6c1f), new X64Word.init(0x1f83d9ab, 0xfb41bd6b), new X64Word.init(0x5be0cd19, 0x137e2179)]);
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcuts
					var H = this._hash.words;
	
					var H0 = H[0];
					var H1 = H[1];
					var H2 = H[2];
					var H3 = H[3];
					var H4 = H[4];
					var H5 = H[5];
					var H6 = H[6];
					var H7 = H[7];
	
					var H0h = H0.high;
					var H0l = H0.low;
					var H1h = H1.high;
					var H1l = H1.low;
					var H2h = H2.high;
					var H2l = H2.low;
					var H3h = H3.high;
					var H3l = H3.low;
					var H4h = H4.high;
					var H4l = H4.low;
					var H5h = H5.high;
					var H5l = H5.low;
					var H6h = H6.high;
					var H6l = H6.low;
					var H7h = H7.high;
					var H7l = H7.low;
	
					// Working variables
					var ah = H0h;
					var al = H0l;
					var bh = H1h;
					var bl = H1l;
					var ch = H2h;
					var cl = H2l;
					var dh = H3h;
					var dl = H3l;
					var eh = H4h;
					var el = H4l;
					var fh = H5h;
					var fl = H5l;
					var gh = H6h;
					var gl = H6l;
					var hh = H7h;
					var hl = H7l;
	
					// Rounds
					for (var i = 0; i < 80; i++) {
						// Shortcut
						var Wi = W[i];
	
						// Extend message
						if (i < 16) {
							var Wih = Wi.high = M[offset + i * 2] | 0;
							var Wil = Wi.low = M[offset + i * 2 + 1] | 0;
						} else {
							// Gamma0
							var gamma0x = W[i - 15];
							var gamma0xh = gamma0x.high;
							var gamma0xl = gamma0x.low;
							var gamma0h = (gamma0xh >>> 1 | gamma0xl << 31) ^ (gamma0xh >>> 8 | gamma0xl << 24) ^ gamma0xh >>> 7;
							var gamma0l = (gamma0xl >>> 1 | gamma0xh << 31) ^ (gamma0xl >>> 8 | gamma0xh << 24) ^ (gamma0xl >>> 7 | gamma0xh << 25);
	
							// Gamma1
							var gamma1x = W[i - 2];
							var gamma1xh = gamma1x.high;
							var gamma1xl = gamma1x.low;
							var gamma1h = (gamma1xh >>> 19 | gamma1xl << 13) ^ (gamma1xh << 3 | gamma1xl >>> 29) ^ gamma1xh >>> 6;
							var gamma1l = (gamma1xl >>> 19 | gamma1xh << 13) ^ (gamma1xl << 3 | gamma1xh >>> 29) ^ (gamma1xl >>> 6 | gamma1xh << 26);
	
							// W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16]
							var Wi7 = W[i - 7];
							var Wi7h = Wi7.high;
							var Wi7l = Wi7.low;
	
							var Wi16 = W[i - 16];
							var Wi16h = Wi16.high;
							var Wi16l = Wi16.low;
	
							var Wil = gamma0l + Wi7l;
							var Wih = gamma0h + Wi7h + (Wil >>> 0 < gamma0l >>> 0 ? 1 : 0);
							var Wil = Wil + gamma1l;
							var Wih = Wih + gamma1h + (Wil >>> 0 < gamma1l >>> 0 ? 1 : 0);
							var Wil = Wil + Wi16l;
							var Wih = Wih + Wi16h + (Wil >>> 0 < Wi16l >>> 0 ? 1 : 0);
	
							Wi.high = Wih;
							Wi.low = Wil;
						}
	
						var chh = eh & fh ^ ~eh & gh;
						var chl = el & fl ^ ~el & gl;
						var majh = ah & bh ^ ah & ch ^ bh & ch;
						var majl = al & bl ^ al & cl ^ bl & cl;
	
						var sigma0h = (ah >>> 28 | al << 4) ^ (ah << 30 | al >>> 2) ^ (ah << 25 | al >>> 7);
						var sigma0l = (al >>> 28 | ah << 4) ^ (al << 30 | ah >>> 2) ^ (al << 25 | ah >>> 7);
						var sigma1h = (eh >>> 14 | el << 18) ^ (eh >>> 18 | el << 14) ^ (eh << 23 | el >>> 9);
						var sigma1l = (el >>> 14 | eh << 18) ^ (el >>> 18 | eh << 14) ^ (el << 23 | eh >>> 9);
	
						// t1 = h + sigma1 + ch + K[i] + W[i]
						var Ki = K[i];
						var Kih = Ki.high;
						var Kil = Ki.low;
	
						var t1l = hl + sigma1l;
						var t1h = hh + sigma1h + (t1l >>> 0 < hl >>> 0 ? 1 : 0);
						var t1l = t1l + chl;
						var t1h = t1h + chh + (t1l >>> 0 < chl >>> 0 ? 1 : 0);
						var t1l = t1l + Kil;
						var t1h = t1h + Kih + (t1l >>> 0 < Kil >>> 0 ? 1 : 0);
						var t1l = t1l + Wil;
						var t1h = t1h + Wih + (t1l >>> 0 < Wil >>> 0 ? 1 : 0);
	
						// t2 = sigma0 + maj
						var t2l = sigma0l + majl;
						var t2h = sigma0h + majh + (t2l >>> 0 < sigma0l >>> 0 ? 1 : 0);
	
						// Update working variables
						hh = gh;
						hl = gl;
						gh = fh;
						gl = fl;
						fh = eh;
						fl = el;
						el = dl + t1l | 0;
						eh = dh + t1h + (el >>> 0 < dl >>> 0 ? 1 : 0) | 0;
						dh = ch;
						dl = cl;
						ch = bh;
						cl = bl;
						bh = ah;
						bl = al;
						al = t1l + t2l | 0;
						ah = t1h + t2h + (al >>> 0 < t1l >>> 0 ? 1 : 0) | 0;
					}
	
					// Intermediate hash value
					H0l = H0.low = H0l + al;
					H0.high = H0h + ah + (H0l >>> 0 < al >>> 0 ? 1 : 0);
					H1l = H1.low = H1l + bl;
					H1.high = H1h + bh + (H1l >>> 0 < bl >>> 0 ? 1 : 0);
					H2l = H2.low = H2l + cl;
					H2.high = H2h + ch + (H2l >>> 0 < cl >>> 0 ? 1 : 0);
					H3l = H3.low = H3l + dl;
					H3.high = H3h + dh + (H3l >>> 0 < dl >>> 0 ? 1 : 0);
					H4l = H4.low = H4l + el;
					H4.high = H4h + eh + (H4l >>> 0 < el >>> 0 ? 1 : 0);
					H5l = H5.low = H5l + fl;
					H5.high = H5h + fh + (H5l >>> 0 < fl >>> 0 ? 1 : 0);
					H6l = H6.low = H6l + gl;
					H6.high = H6h + gh + (H6l >>> 0 < gl >>> 0 ? 1 : 0);
					H7l = H7.low = H7l + hl;
					H7.high = H7h + hh + (H7l >>> 0 < hl >>> 0 ? 1 : 0);
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
	
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
					dataWords[(nBitsLeft + 128 >>> 10 << 5) + 30] = Math.floor(nBitsTotal / 0x100000000);
					dataWords[(nBitsLeft + 128 >>> 10 << 5) + 31] = nBitsTotal;
					data.sigBytes = dataWords.length * 4;
	
					// Hash final blocks
					this._process();
	
					// Convert hash to 32-bit word array before returning
					var hash = this._hash.toX32();
	
					// Return final computed hash
					return hash;
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
					clone._hash = this._hash.clone();
	
					return clone;
				},
	
				blockSize: 1024 / 32
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA512('message');
	   *     var hash = CryptoJS.SHA512(wordArray);
	   */
			C.SHA512 = Hasher._createHelper(SHA512);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA512(message, key);
	   */
			C.HmacSHA512 = Hasher._createHmacHelper(SHA512);
		})();
	
		return CryptoJS.SHA512;
	});

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(16), __webpack_require__(24));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(16), __webpack_require__(24)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_x64 = C.x64;
			var X64Word = C_x64.Word;
			var X64WordArray = C_x64.WordArray;
			var C_algo = C.algo;
			var SHA512 = C_algo.SHA512;
	
			/**
	   * SHA-384 hash algorithm.
	   */
			var SHA384 = C_algo.SHA384 = SHA512.extend({
				_doReset: function _doReset() {
					this._hash = new X64WordArray.init([new X64Word.init(0xcbbb9d5d, 0xc1059ed8), new X64Word.init(0x629a292a, 0x367cd507), new X64Word.init(0x9159015a, 0x3070dd17), new X64Word.init(0x152fecd8, 0xf70e5939), new X64Word.init(0x67332667, 0xffc00b31), new X64Word.init(0x8eb44a87, 0x68581511), new X64Word.init(0xdb0c2e0d, 0x64f98fa7), new X64Word.init(0x47b5481d, 0xbefa4fa4)]);
				},
	
				_doFinalize: function _doFinalize() {
					var hash = SHA512._doFinalize.call(this);
	
					hash.sigBytes -= 16;
	
					return hash;
				}
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA384('message');
	   *     var hash = CryptoJS.SHA384(wordArray);
	   */
			C.SHA384 = SHA512._createHelper(SHA384);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA384(message, key);
	   */
			C.HmacSHA384 = SHA512._createHmacHelper(SHA384);
		})();
	
		return CryptoJS.SHA384;
	});

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(16));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(16)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function (Math) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var Hasher = C_lib.Hasher;
			var C_x64 = C.x64;
			var X64Word = C_x64.Word;
			var C_algo = C.algo;
	
			// Constants tables
			var RHO_OFFSETS = [];
			var PI_INDEXES = [];
			var ROUND_CONSTANTS = [];
	
			// Compute Constants
			(function () {
				// Compute rho offset constants
				var x = 1,
				    y = 0;
				for (var t = 0; t < 24; t++) {
					RHO_OFFSETS[x + 5 * y] = (t + 1) * (t + 2) / 2 % 64;
	
					var newX = y % 5;
					var newY = (2 * x + 3 * y) % 5;
					x = newX;
					y = newY;
				}
	
				// Compute pi index constants
				for (var x = 0; x < 5; x++) {
					for (var y = 0; y < 5; y++) {
						PI_INDEXES[x + 5 * y] = y + (2 * x + 3 * y) % 5 * 5;
					}
				}
	
				// Compute round constants
				var LFSR = 0x01;
				for (var i = 0; i < 24; i++) {
					var roundConstantMsw = 0;
					var roundConstantLsw = 0;
	
					for (var j = 0; j < 7; j++) {
						if (LFSR & 0x01) {
							var bitPosition = (1 << j) - 1;
							if (bitPosition < 32) {
								roundConstantLsw ^= 1 << bitPosition;
							} else /* if (bitPosition >= 32) */{
									roundConstantMsw ^= 1 << bitPosition - 32;
								}
						}
	
						// Compute next LFSR
						if (LFSR & 0x80) {
							// Primitive polynomial over GF(2): x^8 + x^6 + x^5 + x^4 + 1
							LFSR = LFSR << 1 ^ 0x71;
						} else {
							LFSR <<= 1;
						}
					}
	
					ROUND_CONSTANTS[i] = X64Word.create(roundConstantMsw, roundConstantLsw);
				}
			})();
	
			// Reusable objects for temporary values
			var T = [];
			(function () {
				for (var i = 0; i < 25; i++) {
					T[i] = X64Word.create();
				}
			})();
	
			/**
	   * SHA-3 hash algorithm.
	   */
			var SHA3 = C_algo.SHA3 = Hasher.extend({
				/**
	    * Configuration options.
	    *
	    * @property {number} outputLength
	    *   The desired number of bits in the output hash.
	    *   Only values permitted are: 224, 256, 384, 512.
	    *   Default: 512
	    */
				cfg: Hasher.cfg.extend({
					outputLength: 512
				}),
	
				_doReset: function _doReset() {
					var state = this._state = [];
					for (var i = 0; i < 25; i++) {
						state[i] = new X64Word.init();
					}
	
					this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcuts
					var state = this._state;
					var nBlockSizeLanes = this.blockSize / 2;
	
					// Absorb
					for (var i = 0; i < nBlockSizeLanes; i++) {
						// Shortcuts
						var M2i = M[offset + 2 * i];
						var M2i1 = M[offset + 2 * i + 1];
	
						// Swap endian
						M2i = (M2i << 8 | M2i >>> 24) & 0x00ff00ff | (M2i << 24 | M2i >>> 8) & 0xff00ff00;
						M2i1 = (M2i1 << 8 | M2i1 >>> 24) & 0x00ff00ff | (M2i1 << 24 | M2i1 >>> 8) & 0xff00ff00;
	
						// Absorb message into state
						var lane = state[i];
						lane.high ^= M2i1;
						lane.low ^= M2i;
					}
	
					// Rounds
					for (var round = 0; round < 24; round++) {
						// Theta
						for (var x = 0; x < 5; x++) {
							// Mix column lanes
							var tMsw = 0,
							    tLsw = 0;
							for (var y = 0; y < 5; y++) {
								var lane = state[x + 5 * y];
								tMsw ^= lane.high;
								tLsw ^= lane.low;
							}
	
							// Temporary values
							var Tx = T[x];
							Tx.high = tMsw;
							Tx.low = tLsw;
						}
						for (var x = 0; x < 5; x++) {
							// Shortcuts
							var Tx4 = T[(x + 4) % 5];
							var Tx1 = T[(x + 1) % 5];
							var Tx1Msw = Tx1.high;
							var Tx1Lsw = Tx1.low;
	
							// Mix surrounding columns
							var tMsw = Tx4.high ^ (Tx1Msw << 1 | Tx1Lsw >>> 31);
							var tLsw = Tx4.low ^ (Tx1Lsw << 1 | Tx1Msw >>> 31);
							for (var y = 0; y < 5; y++) {
								var lane = state[x + 5 * y];
								lane.high ^= tMsw;
								lane.low ^= tLsw;
							}
						}
	
						// Rho Pi
						for (var laneIndex = 1; laneIndex < 25; laneIndex++) {
							// Shortcuts
							var lane = state[laneIndex];
							var laneMsw = lane.high;
							var laneLsw = lane.low;
							var rhoOffset = RHO_OFFSETS[laneIndex];
	
							// Rotate lanes
							if (rhoOffset < 32) {
								var tMsw = laneMsw << rhoOffset | laneLsw >>> 32 - rhoOffset;
								var tLsw = laneLsw << rhoOffset | laneMsw >>> 32 - rhoOffset;
							} else /* if (rhoOffset >= 32) */{
									var tMsw = laneLsw << rhoOffset - 32 | laneMsw >>> 64 - rhoOffset;
									var tLsw = laneMsw << rhoOffset - 32 | laneLsw >>> 64 - rhoOffset;
								}
	
							// Transpose lanes
							var TPiLane = T[PI_INDEXES[laneIndex]];
							TPiLane.high = tMsw;
							TPiLane.low = tLsw;
						}
	
						// Rho pi at x = y = 0
						var T0 = T[0];
						var state0 = state[0];
						T0.high = state0.high;
						T0.low = state0.low;
	
						// Chi
						for (var x = 0; x < 5; x++) {
							for (var y = 0; y < 5; y++) {
								// Shortcuts
								var laneIndex = x + 5 * y;
								var lane = state[laneIndex];
								var TLane = T[laneIndex];
								var Tx1Lane = T[(x + 1) % 5 + 5 * y];
								var Tx2Lane = T[(x + 2) % 5 + 5 * y];
	
								// Mix rows
								lane.high = TLane.high ^ ~Tx1Lane.high & Tx2Lane.high;
								lane.low = TLane.low ^ ~Tx1Lane.low & Tx2Lane.low;
							}
						}
	
						// Iota
						var lane = state[0];
						var roundConstant = ROUND_CONSTANTS[round];
						lane.high ^= roundConstant.high;
						lane.low ^= roundConstant.low;;
					}
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
					var blockSizeBits = this.blockSize * 32;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x1 << 24 - nBitsLeft % 32;
					dataWords[(Math.ceil((nBitsLeft + 1) / blockSizeBits) * blockSizeBits >>> 5) - 1] |= 0x80;
					data.sigBytes = dataWords.length * 4;
	
					// Hash final blocks
					this._process();
	
					// Shortcuts
					var state = this._state;
					var outputLengthBytes = this.cfg.outputLength / 8;
					var outputLengthLanes = outputLengthBytes / 8;
	
					// Squeeze
					var hashWords = [];
					for (var i = 0; i < outputLengthLanes; i++) {
						// Shortcuts
						var lane = state[i];
						var laneMsw = lane.high;
						var laneLsw = lane.low;
	
						// Swap endian
						laneMsw = (laneMsw << 8 | laneMsw >>> 24) & 0x00ff00ff | (laneMsw << 24 | laneMsw >>> 8) & 0xff00ff00;
						laneLsw = (laneLsw << 8 | laneLsw >>> 24) & 0x00ff00ff | (laneLsw << 24 | laneLsw >>> 8) & 0xff00ff00;
	
						// Squeeze state to retrieve hash
						hashWords.push(laneLsw);
						hashWords.push(laneMsw);
					}
	
					// Return final computed hash
					return new WordArray.init(hashWords, outputLengthBytes);
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
	
					var state = clone._state = this._state.slice(0);
					for (var i = 0; i < 25; i++) {
						state[i] = state[i].clone();
					}
	
					return clone;
				}
			});
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.SHA3('message');
	   *     var hash = CryptoJS.SHA3(wordArray);
	   */
			C.SHA3 = Hasher._createHelper(SHA3);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacSHA3(message, key);
	   */
			C.HmacSHA3 = Hasher._createHmacHelper(SHA3);
		})(Math);
	
		return CryptoJS.SHA3;
	});

/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/** @preserve
	 (c) 2012 by Cédric Mesnil. All rights reserved.
	 	Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
	 	    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
	     - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
	 	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	 */
	
		(function (Math) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var Hasher = C_lib.Hasher;
			var C_algo = C.algo;
	
			// Constants table
			var _zl = WordArray.create([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13]);
			var _zr = WordArray.create([5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11]);
			var _sl = WordArray.create([11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6]);
			var _sr = WordArray.create([8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11]);
	
			var _hl = WordArray.create([0x00000000, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xA953FD4E]);
			var _hr = WordArray.create([0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0x7A6D76E9, 0x00000000]);
	
			/**
	   * RIPEMD160 hash algorithm.
	   */
			var RIPEMD160 = C_algo.RIPEMD160 = Hasher.extend({
				_doReset: function _doReset() {
					this._hash = WordArray.create([0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]);
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
	
					// Swap endian
					for (var i = 0; i < 16; i++) {
						// Shortcuts
						var offset_i = offset + i;
						var M_offset_i = M[offset_i];
	
						// Swap
						M[offset_i] = (M_offset_i << 8 | M_offset_i >>> 24) & 0x00ff00ff | (M_offset_i << 24 | M_offset_i >>> 8) & 0xff00ff00;
					}
					// Shortcut
					var H = this._hash.words;
					var hl = _hl.words;
					var hr = _hr.words;
					var zl = _zl.words;
					var zr = _zr.words;
					var sl = _sl.words;
					var sr = _sr.words;
	
					// Working variables
					var al, bl, cl, dl, el;
					var ar, br, cr, dr, er;
	
					ar = al = H[0];
					br = bl = H[1];
					cr = cl = H[2];
					dr = dl = H[3];
					er = el = H[4];
					// Computation
					var t;
					for (var i = 0; i < 80; i += 1) {
						t = al + M[offset + zl[i]] | 0;
						if (i < 16) {
							t += f1(bl, cl, dl) + hl[0];
						} else if (i < 32) {
							t += f2(bl, cl, dl) + hl[1];
						} else if (i < 48) {
							t += f3(bl, cl, dl) + hl[2];
						} else if (i < 64) {
							t += f4(bl, cl, dl) + hl[3];
						} else {
							// if (i<80) {
							t += f5(bl, cl, dl) + hl[4];
						}
						t = t | 0;
						t = rotl(t, sl[i]);
						t = t + el | 0;
						al = el;
						el = dl;
						dl = rotl(cl, 10);
						cl = bl;
						bl = t;
	
						t = ar + M[offset + zr[i]] | 0;
						if (i < 16) {
							t += f5(br, cr, dr) + hr[0];
						} else if (i < 32) {
							t += f4(br, cr, dr) + hr[1];
						} else if (i < 48) {
							t += f3(br, cr, dr) + hr[2];
						} else if (i < 64) {
							t += f2(br, cr, dr) + hr[3];
						} else {
							// if (i<80) {
							t += f1(br, cr, dr) + hr[4];
						}
						t = t | 0;
						t = rotl(t, sr[i]);
						t = t + er | 0;
						ar = er;
						er = dr;
						dr = rotl(cr, 10);
						cr = br;
						br = t;
					}
					// Intermediate hash value
					t = H[1] + cl + dr | 0;
					H[1] = H[2] + dl + er | 0;
					H[2] = H[3] + el + ar | 0;
					H[3] = H[4] + al + br | 0;
					H[4] = H[0] + bl + cr | 0;
					H[0] = t;
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcuts
					var data = this._data;
					var dataWords = data.words;
	
					var nBitsTotal = this._nDataBytes * 8;
					var nBitsLeft = data.sigBytes * 8;
	
					// Add padding
					dataWords[nBitsLeft >>> 5] |= 0x80 << 24 - nBitsLeft % 32;
					dataWords[(nBitsLeft + 64 >>> 9 << 4) + 14] = (nBitsTotal << 8 | nBitsTotal >>> 24) & 0x00ff00ff | (nBitsTotal << 24 | nBitsTotal >>> 8) & 0xff00ff00;
					data.sigBytes = (dataWords.length + 1) * 4;
	
					// Hash final blocks
					this._process();
	
					// Shortcuts
					var hash = this._hash;
					var H = hash.words;
	
					// Swap endian
					for (var i = 0; i < 5; i++) {
						// Shortcut
						var H_i = H[i];
	
						// Swap
						H[i] = (H_i << 8 | H_i >>> 24) & 0x00ff00ff | (H_i << 24 | H_i >>> 8) & 0xff00ff00;
					}
	
					// Return final computed hash
					return hash;
				},
	
				clone: function clone() {
					var clone = Hasher.clone.call(this);
					clone._hash = this._hash.clone();
	
					return clone;
				}
			});
	
			function f1(x, y, z) {
				return x ^ y ^ z;
			}
	
			function f2(x, y, z) {
				return x & y | ~x & z;
			}
	
			function f3(x, y, z) {
				return (x | ~y) ^ z;
			}
	
			function f4(x, y, z) {
				return x & z | y & ~z;
			}
	
			function f5(x, y, z) {
				return x ^ (y | ~z);
			}
	
			function rotl(x, n) {
				return x << n | x >>> 32 - n;
			}
	
			/**
	   * Shortcut function to the hasher's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   *
	   * @return {WordArray} The hash.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hash = CryptoJS.RIPEMD160('message');
	   *     var hash = CryptoJS.RIPEMD160(wordArray);
	   */
			C.RIPEMD160 = Hasher._createHelper(RIPEMD160);
	
			/**
	   * Shortcut function to the HMAC's object interface.
	   *
	   * @param {WordArray|string} message The message to hash.
	   * @param {WordArray|string} key The secret key.
	   *
	   * @return {WordArray} The HMAC.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var hmac = CryptoJS.HmacRIPEMD160(message, key);
	   */
			C.HmacRIPEMD160 = Hasher._createHmacHelper(RIPEMD160);
		})(Math);
	
		return CryptoJS.RIPEMD160;
	});

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Base = C_lib.Base;
			var C_enc = C.enc;
			var Utf8 = C_enc.Utf8;
			var C_algo = C.algo;
	
			/**
	   * HMAC algorithm.
	   */
			var HMAC = C_algo.HMAC = Base.extend({
				/**
	    * Initializes a newly created HMAC.
	    *
	    * @param {Hasher} hasher The hash algorithm to use.
	    * @param {WordArray|string} key The secret key.
	    *
	    * @example
	    *
	    *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);
	    */
				init: function init(hasher, key) {
					// Init hasher
					hasher = this._hasher = new hasher.init();
	
					// Convert string to WordArray, else assume WordArray already
					if (typeof key == 'string') {
						key = Utf8.parse(key);
					}
	
					// Shortcuts
					var hasherBlockSize = hasher.blockSize;
					var hasherBlockSizeBytes = hasherBlockSize * 4;
	
					// Allow arbitrary length keys
					if (key.sigBytes > hasherBlockSizeBytes) {
						key = hasher.finalize(key);
					}
	
					// Clamp excess bits
					key.clamp();
	
					// Clone key for inner and outer pads
					var oKey = this._oKey = key.clone();
					var iKey = this._iKey = key.clone();
	
					// Shortcuts
					var oKeyWords = oKey.words;
					var iKeyWords = iKey.words;
	
					// XOR keys with pad constants
					for (var i = 0; i < hasherBlockSize; i++) {
						oKeyWords[i] ^= 0x5c5c5c5c;
						iKeyWords[i] ^= 0x36363636;
					}
					oKey.sigBytes = iKey.sigBytes = hasherBlockSizeBytes;
	
					// Set initial values
					this.reset();
				},
	
				/**
	    * Resets this HMAC to its initial state.
	    *
	    * @example
	    *
	    *     hmacHasher.reset();
	    */
				reset: function reset() {
					// Shortcut
					var hasher = this._hasher;
	
					// Reset
					hasher.reset();
					hasher.update(this._iKey);
				},
	
				/**
	    * Updates this HMAC with a message.
	    *
	    * @param {WordArray|string} messageUpdate The message to append.
	    *
	    * @return {HMAC} This HMAC instance.
	    *
	    * @example
	    *
	    *     hmacHasher.update('message');
	    *     hmacHasher.update(wordArray);
	    */
				update: function update(messageUpdate) {
					this._hasher.update(messageUpdate);
	
					// Chainable
					return this;
				},
	
				/**
	    * Finalizes the HMAC computation.
	    * Note that the finalize operation is effectively a destructive, read-once operation.
	    *
	    * @param {WordArray|string} messageUpdate (Optional) A final message update.
	    *
	    * @return {WordArray} The HMAC.
	    *
	    * @example
	    *
	    *     var hmac = hmacHasher.finalize();
	    *     var hmac = hmacHasher.finalize('message');
	    *     var hmac = hmacHasher.finalize(wordArray);
	    */
				finalize: function finalize(messageUpdate) {
					// Shortcut
					var hasher = this._hasher;
	
					// Compute HMAC
					var innerHash = hasher.finalize(messageUpdate);
					hasher.reset();
					var hmac = hasher.finalize(this._oKey.clone().concat(innerHash));
	
					return hmac;
				}
			});
		})();
	});

/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(21), __webpack_require__(28));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(21), __webpack_require__(28)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Base = C_lib.Base;
			var WordArray = C_lib.WordArray;
			var C_algo = C.algo;
			var SHA1 = C_algo.SHA1;
			var HMAC = C_algo.HMAC;
	
			/**
	   * Password-Based Key Derivation Function 2 algorithm.
	   */
			var PBKDF2 = C_algo.PBKDF2 = Base.extend({
				/**
	    * Configuration options.
	    *
	    * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
	    * @property {Hasher} hasher The hasher to use. Default: SHA1
	    * @property {number} iterations The number of iterations to perform. Default: 1
	    */
				cfg: Base.extend({
					keySize: 128 / 32,
					hasher: SHA1,
					iterations: 1
				}),
	
				/**
	    * Initializes a newly created key derivation function.
	    *
	    * @param {Object} cfg (Optional) The configuration options to use for the derivation.
	    *
	    * @example
	    *
	    *     var kdf = CryptoJS.algo.PBKDF2.create();
	    *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });
	    *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });
	    */
				init: function init(cfg) {
					this.cfg = this.cfg.extend(cfg);
				},
	
				/**
	    * Computes the Password-Based Key Derivation Function 2.
	    *
	    * @param {WordArray|string} password The password.
	    * @param {WordArray|string} salt A salt.
	    *
	    * @return {WordArray} The derived key.
	    *
	    * @example
	    *
	    *     var key = kdf.compute(password, salt);
	    */
				compute: function compute(password, salt) {
					// Shortcut
					var cfg = this.cfg;
	
					// Init HMAC
					var hmac = HMAC.create(cfg.hasher, password);
	
					// Initial values
					var derivedKey = WordArray.create();
					var blockIndex = WordArray.create([0x00000001]);
	
					// Shortcuts
					var derivedKeyWords = derivedKey.words;
					var blockIndexWords = blockIndex.words;
					var keySize = cfg.keySize;
					var iterations = cfg.iterations;
	
					// Generate key
					while (derivedKeyWords.length < keySize) {
						var block = hmac.update(salt).finalize(blockIndex);
						hmac.reset();
	
						// Shortcuts
						var blockWords = block.words;
						var blockWordsLength = blockWords.length;
	
						// Iterations
						var intermediate = block;
						for (var i = 1; i < iterations; i++) {
							intermediate = hmac.finalize(intermediate);
							hmac.reset();
	
							// Shortcut
							var intermediateWords = intermediate.words;
	
							// XOR intermediate with block
							for (var j = 0; j < blockWordsLength; j++) {
								blockWords[j] ^= intermediateWords[j];
							}
						}
	
						derivedKey.concat(block);
						blockIndexWords[0]++;
					}
					derivedKey.sigBytes = keySize * 4;
	
					return derivedKey;
				}
			});
	
			/**
	   * Computes the Password-Based Key Derivation Function 2.
	   *
	   * @param {WordArray|string} password The password.
	   * @param {WordArray|string} salt A salt.
	   * @param {Object} cfg (Optional) The configuration options to use for this computation.
	   *
	   * @return {WordArray} The derived key.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var key = CryptoJS.PBKDF2(password, salt);
	   *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8 });
	   *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8, iterations: 1000 });
	   */
			C.PBKDF2 = function (password, salt, cfg) {
				return PBKDF2.create(cfg).compute(password, salt);
			};
		})();
	
		return CryptoJS.PBKDF2;
	});

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(21), __webpack_require__(28));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(21), __webpack_require__(28)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Base = C_lib.Base;
			var WordArray = C_lib.WordArray;
			var C_algo = C.algo;
			var MD5 = C_algo.MD5;
	
			/**
	   * This key derivation function is meant to conform with EVP_BytesToKey.
	   * www.openssl.org/docs/crypto/EVP_BytesToKey.html
	   */
			var EvpKDF = C_algo.EvpKDF = Base.extend({
				/**
	    * Configuration options.
	    *
	    * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
	    * @property {Hasher} hasher The hash algorithm to use. Default: MD5
	    * @property {number} iterations The number of iterations to perform. Default: 1
	    */
				cfg: Base.extend({
					keySize: 128 / 32,
					hasher: MD5,
					iterations: 1
				}),
	
				/**
	    * Initializes a newly created key derivation function.
	    *
	    * @param {Object} cfg (Optional) The configuration options to use for the derivation.
	    *
	    * @example
	    *
	    *     var kdf = CryptoJS.algo.EvpKDF.create();
	    *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });
	    *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });
	    */
				init: function init(cfg) {
					this.cfg = this.cfg.extend(cfg);
				},
	
				/**
	    * Derives a key from a password.
	    *
	    * @param {WordArray|string} password The password.
	    * @param {WordArray|string} salt A salt.
	    *
	    * @return {WordArray} The derived key.
	    *
	    * @example
	    *
	    *     var key = kdf.compute(password, salt);
	    */
				compute: function compute(password, salt) {
					// Shortcut
					var cfg = this.cfg;
	
					// Init hasher
					var hasher = cfg.hasher.create();
	
					// Initial values
					var derivedKey = WordArray.create();
	
					// Shortcuts
					var derivedKeyWords = derivedKey.words;
					var keySize = cfg.keySize;
					var iterations = cfg.iterations;
	
					// Generate key
					while (derivedKeyWords.length < keySize) {
						if (block) {
							hasher.update(block);
						}
						var block = hasher.update(password).finalize(salt);
						hasher.reset();
	
						// Iterations
						for (var i = 1; i < iterations; i++) {
							block = hasher.finalize(block);
							hasher.reset();
						}
	
						derivedKey.concat(block);
					}
					derivedKey.sigBytes = keySize * 4;
	
					return derivedKey;
				}
			});
	
			/**
	   * Derives a key from a password.
	   *
	   * @param {WordArray|string} password The password.
	   * @param {WordArray|string} salt A salt.
	   * @param {Object} cfg (Optional) The configuration options to use for this computation.
	   *
	   * @return {WordArray} The derived key.
	   *
	   * @static
	   *
	   * @example
	   *
	   *     var key = CryptoJS.EvpKDF(password, salt);
	   *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8 });
	   *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8, iterations: 1000 });
	   */
			C.EvpKDF = function (password, salt, cfg) {
				return EvpKDF.create(cfg).compute(password, salt);
			};
		})();
	
		return CryptoJS.EvpKDF;
	});

/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(30));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(30)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Cipher core components.
	  */
		CryptoJS.lib.Cipher || function (undefined) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var Base = C_lib.Base;
			var WordArray = C_lib.WordArray;
			var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm;
			var C_enc = C.enc;
			var Utf8 = C_enc.Utf8;
			var Base64 = C_enc.Base64;
			var C_algo = C.algo;
			var EvpKDF = C_algo.EvpKDF;
	
			/**
	   * Abstract base cipher template.
	   *
	   * @property {number} keySize This cipher's key size. Default: 4 (128 bits)
	   * @property {number} ivSize This cipher's IV size. Default: 4 (128 bits)
	   * @property {number} _ENC_XFORM_MODE A constant representing encryption mode.
	   * @property {number} _DEC_XFORM_MODE A constant representing decryption mode.
	   */
			var Cipher = C_lib.Cipher = BufferedBlockAlgorithm.extend({
				/**
	    * Configuration options.
	    *
	    * @property {WordArray} iv The IV to use for this operation.
	    */
				cfg: Base.extend(),
	
				/**
	    * Creates this cipher in encryption mode.
	    *
	    * @param {WordArray} key The key.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {Cipher} A cipher instance.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });
	    */
				createEncryptor: function createEncryptor(key, cfg) {
					return this.create(this._ENC_XFORM_MODE, key, cfg);
				},
	
				/**
	    * Creates this cipher in decryption mode.
	    *
	    * @param {WordArray} key The key.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {Cipher} A cipher instance.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });
	    */
				createDecryptor: function createDecryptor(key, cfg) {
					return this.create(this._DEC_XFORM_MODE, key, cfg);
				},
	
				/**
	    * Initializes a newly created cipher.
	    *
	    * @param {number} xformMode Either the encryption or decryption transormation mode constant.
	    * @param {WordArray} key The key.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @example
	    *
	    *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });
	    */
				init: function init(xformMode, key, cfg) {
					// Apply config defaults
					this.cfg = this.cfg.extend(cfg);
	
					// Store transform mode and key
					this._xformMode = xformMode;
					this._key = key;
	
					// Set initial values
					this.reset();
				},
	
				/**
	    * Resets this cipher to its initial state.
	    *
	    * @example
	    *
	    *     cipher.reset();
	    */
				reset: function reset() {
					// Reset data buffer
					BufferedBlockAlgorithm.reset.call(this);
	
					// Perform concrete-cipher logic
					this._doReset();
				},
	
				/**
	    * Adds data to be encrypted or decrypted.
	    *
	    * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.
	    *
	    * @return {WordArray} The data after processing.
	    *
	    * @example
	    *
	    *     var encrypted = cipher.process('data');
	    *     var encrypted = cipher.process(wordArray);
	    */
				process: function process(dataUpdate) {
					// Append
					this._append(dataUpdate);
	
					// Process available blocks
					return this._process();
				},
	
				/**
	    * Finalizes the encryption or decryption process.
	    * Note that the finalize operation is effectively a destructive, read-once operation.
	    *
	    * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.
	    *
	    * @return {WordArray} The data after final processing.
	    *
	    * @example
	    *
	    *     var encrypted = cipher.finalize();
	    *     var encrypted = cipher.finalize('data');
	    *     var encrypted = cipher.finalize(wordArray);
	    */
				finalize: function finalize(dataUpdate) {
					// Final data update
					if (dataUpdate) {
						this._append(dataUpdate);
					}
	
					// Perform concrete-cipher logic
					var finalProcessedData = this._doFinalize();
	
					return finalProcessedData;
				},
	
				keySize: 128 / 32,
	
				ivSize: 128 / 32,
	
				_ENC_XFORM_MODE: 1,
	
				_DEC_XFORM_MODE: 2,
	
				/**
	    * Creates shortcut functions to a cipher's object interface.
	    *
	    * @param {Cipher} cipher The cipher to create a helper for.
	    *
	    * @return {Object} An object with encrypt and decrypt shortcut functions.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);
	    */
				_createHelper: function () {
					function selectCipherStrategy(key) {
						if (typeof key == 'string') {
							return PasswordBasedCipher;
						} else {
							return SerializableCipher;
						}
					}
	
					return function (cipher) {
						return {
							encrypt: function encrypt(message, key, cfg) {
								return selectCipherStrategy(key).encrypt(cipher, message, key, cfg);
							},
	
							decrypt: function decrypt(ciphertext, key, cfg) {
								return selectCipherStrategy(key).decrypt(cipher, ciphertext, key, cfg);
							}
						};
					};
				}()
			});
	
			/**
	   * Abstract base stream cipher template.
	   *
	   * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 1 (32 bits)
	   */
			var StreamCipher = C_lib.StreamCipher = Cipher.extend({
				_doFinalize: function _doFinalize() {
					// Process partial blocks
					var finalProcessedBlocks = this._process(!!'flush');
	
					return finalProcessedBlocks;
				},
	
				blockSize: 1
			});
	
			/**
	   * Mode namespace.
	   */
			var C_mode = C.mode = {};
	
			/**
	   * Abstract base block cipher mode template.
	   */
			var BlockCipherMode = C_lib.BlockCipherMode = Base.extend({
				/**
	    * Creates this mode for encryption.
	    *
	    * @param {Cipher} cipher A block cipher instance.
	    * @param {Array} iv The IV words.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);
	    */
				createEncryptor: function createEncryptor(cipher, iv) {
					return this.Encryptor.create(cipher, iv);
				},
	
				/**
	    * Creates this mode for decryption.
	    *
	    * @param {Cipher} cipher A block cipher instance.
	    * @param {Array} iv The IV words.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);
	    */
				createDecryptor: function createDecryptor(cipher, iv) {
					return this.Decryptor.create(cipher, iv);
				},
	
				/**
	    * Initializes a newly created mode.
	    *
	    * @param {Cipher} cipher A block cipher instance.
	    * @param {Array} iv The IV words.
	    *
	    * @example
	    *
	    *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);
	    */
				init: function init(cipher, iv) {
					this._cipher = cipher;
					this._iv = iv;
				}
			});
	
			/**
	   * Cipher Block Chaining mode.
	   */
			var CBC = C_mode.CBC = function () {
				/**
	    * Abstract base CBC mode.
	    */
				var CBC = BlockCipherMode.extend();
	
				/**
	    * CBC encryptor.
	    */
				CBC.Encryptor = CBC.extend({
					/**
	     * Processes the data block at offset.
	     *
	     * @param {Array} words The data words to operate on.
	     * @param {number} offset The offset where the block starts.
	     *
	     * @example
	     *
	     *     mode.processBlock(data.words, offset);
	     */
					processBlock: function processBlock(words, offset) {
						// Shortcuts
						var cipher = this._cipher;
						var blockSize = cipher.blockSize;
	
						// XOR and encrypt
						xorBlock.call(this, words, offset, blockSize);
						cipher.encryptBlock(words, offset);
	
						// Remember this block to use with next block
						this._prevBlock = words.slice(offset, offset + blockSize);
					}
				});
	
				/**
	    * CBC decryptor.
	    */
				CBC.Decryptor = CBC.extend({
					/**
	     * Processes the data block at offset.
	     *
	     * @param {Array} words The data words to operate on.
	     * @param {number} offset The offset where the block starts.
	     *
	     * @example
	     *
	     *     mode.processBlock(data.words, offset);
	     */
					processBlock: function processBlock(words, offset) {
						// Shortcuts
						var cipher = this._cipher;
						var blockSize = cipher.blockSize;
	
						// Remember this block to use with next block
						var thisBlock = words.slice(offset, offset + blockSize);
	
						// Decrypt and XOR
						cipher.decryptBlock(words, offset);
						xorBlock.call(this, words, offset, blockSize);
	
						// This block becomes the previous block
						this._prevBlock = thisBlock;
					}
				});
	
				function xorBlock(words, offset, blockSize) {
					// Shortcut
					var iv = this._iv;
	
					// Choose mixing block
					if (iv) {
						var block = iv;
	
						// Remove IV for subsequent blocks
						this._iv = undefined;
					} else {
						var block = this._prevBlock;
					}
	
					// XOR blocks
					for (var i = 0; i < blockSize; i++) {
						words[offset + i] ^= block[i];
					}
				}
	
				return CBC;
			}();
	
			/**
	   * Padding namespace.
	   */
			var C_pad = C.pad = {};
	
			/**
	   * PKCS #5/7 padding strategy.
	   */
			var Pkcs7 = C_pad.Pkcs7 = {
				/**
	    * Pads data using the algorithm defined in PKCS #5/7.
	    *
	    * @param {WordArray} data The data to pad.
	    * @param {number} blockSize The multiple that the data should be padded to.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);
	    */
				pad: function pad(data, blockSize) {
					// Shortcut
					var blockSizeBytes = blockSize * 4;
	
					// Count padding bytes
					var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;
	
					// Create padding word
					var paddingWord = nPaddingBytes << 24 | nPaddingBytes << 16 | nPaddingBytes << 8 | nPaddingBytes;
	
					// Create padding
					var paddingWords = [];
					for (var i = 0; i < nPaddingBytes; i += 4) {
						paddingWords.push(paddingWord);
					}
					var padding = WordArray.create(paddingWords, nPaddingBytes);
	
					// Add padding
					data.concat(padding);
				},
	
				/**
	    * Unpads data that had been padded using the algorithm defined in PKCS #5/7.
	    *
	    * @param {WordArray} data The data to unpad.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     CryptoJS.pad.Pkcs7.unpad(wordArray);
	    */
				unpad: function unpad(data) {
					// Get number of padding bytes from last byte
					var nPaddingBytes = data.words[data.sigBytes - 1 >>> 2] & 0xff;
	
					// Remove padding
					data.sigBytes -= nPaddingBytes;
				}
			};
	
			/**
	   * Abstract base block cipher template.
	   *
	   * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 4 (128 bits)
	   */
			var BlockCipher = C_lib.BlockCipher = Cipher.extend({
				/**
	    * Configuration options.
	    *
	    * @property {Mode} mode The block mode to use. Default: CBC
	    * @property {Padding} padding The padding strategy to use. Default: Pkcs7
	    */
				cfg: Cipher.cfg.extend({
					mode: CBC,
					padding: Pkcs7
				}),
	
				reset: function reset() {
					// Reset cipher
					Cipher.reset.call(this);
	
					// Shortcuts
					var cfg = this.cfg;
					var iv = cfg.iv;
					var mode = cfg.mode;
	
					// Reset block mode
					if (this._xformMode == this._ENC_XFORM_MODE) {
						var modeCreator = mode.createEncryptor;
					} else /* if (this._xformMode == this._DEC_XFORM_MODE) */{
							var modeCreator = mode.createDecryptor;
							// Keep at least one block in the buffer for unpadding
							this._minBufferSize = 1;
						}
	
					if (this._mode && this._mode.__creator == modeCreator) {
						this._mode.init(this, iv && iv.words);
					} else {
						this._mode = modeCreator.call(mode, this, iv && iv.words);
						this._mode.__creator = modeCreator;
					}
				},
	
				_doProcessBlock: function _doProcessBlock(words, offset) {
					this._mode.processBlock(words, offset);
				},
	
				_doFinalize: function _doFinalize() {
					// Shortcut
					var padding = this.cfg.padding;
	
					// Finalize
					if (this._xformMode == this._ENC_XFORM_MODE) {
						// Pad data
						padding.pad(this._data, this.blockSize);
	
						// Process final blocks
						var finalProcessedBlocks = this._process(!!'flush');
					} else /* if (this._xformMode == this._DEC_XFORM_MODE) */{
							// Process final blocks
							var finalProcessedBlocks = this._process(!!'flush');
	
							// Unpad data
							padding.unpad(finalProcessedBlocks);
						}
	
					return finalProcessedBlocks;
				},
	
				blockSize: 128 / 32
			});
	
			/**
	   * A collection of cipher parameters.
	   *
	   * @property {WordArray} ciphertext The raw ciphertext.
	   * @property {WordArray} key The key to this ciphertext.
	   * @property {WordArray} iv The IV used in the ciphering operation.
	   * @property {WordArray} salt The salt used with a key derivation function.
	   * @property {Cipher} algorithm The cipher algorithm.
	   * @property {Mode} mode The block mode used in the ciphering operation.
	   * @property {Padding} padding The padding scheme used in the ciphering operation.
	   * @property {number} blockSize The block size of the cipher.
	   * @property {Format} formatter The default formatting strategy to convert this cipher params object to a string.
	   */
			var CipherParams = C_lib.CipherParams = Base.extend({
				/**
	    * Initializes a newly created cipher params object.
	    *
	    * @param {Object} cipherParams An object with any of the possible cipher parameters.
	    *
	    * @example
	    *
	    *     var cipherParams = CryptoJS.lib.CipherParams.create({
	    *         ciphertext: ciphertextWordArray,
	    *         key: keyWordArray,
	    *         iv: ivWordArray,
	    *         salt: saltWordArray,
	    *         algorithm: CryptoJS.algo.AES,
	    *         mode: CryptoJS.mode.CBC,
	    *         padding: CryptoJS.pad.PKCS7,
	    *         blockSize: 4,
	    *         formatter: CryptoJS.format.OpenSSL
	    *     });
	    */
				init: function init(cipherParams) {
					this.mixIn(cipherParams);
				},
	
				/**
	    * Converts this cipher params object to a string.
	    *
	    * @param {Format} formatter (Optional) The formatting strategy to use.
	    *
	    * @return {string} The stringified cipher params.
	    *
	    * @throws Error If neither the formatter nor the default formatter is set.
	    *
	    * @example
	    *
	    *     var string = cipherParams + '';
	    *     var string = cipherParams.toString();
	    *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);
	    */
				toString: function toString(formatter) {
					return (formatter || this.formatter).stringify(this);
				}
			});
	
			/**
	   * Format namespace.
	   */
			var C_format = C.format = {};
	
			/**
	   * OpenSSL formatting strategy.
	   */
			var OpenSSLFormatter = C_format.OpenSSL = {
				/**
	    * Converts a cipher params object to an OpenSSL-compatible string.
	    *
	    * @param {CipherParams} cipherParams The cipher params object.
	    *
	    * @return {string} The OpenSSL-compatible string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);
	    */
				stringify: function stringify(cipherParams) {
					// Shortcuts
					var ciphertext = cipherParams.ciphertext;
					var salt = cipherParams.salt;
	
					// Format
					if (salt) {
						var wordArray = WordArray.create([0x53616c74, 0x65645f5f]).concat(salt).concat(ciphertext);
					} else {
						var wordArray = ciphertext;
					}
	
					return wordArray.toString(Base64);
				},
	
				/**
	    * Converts an OpenSSL-compatible string to a cipher params object.
	    *
	    * @param {string} openSSLStr The OpenSSL-compatible string.
	    *
	    * @return {CipherParams} The cipher params object.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);
	    */
				parse: function parse(openSSLStr) {
					// Parse base64
					var ciphertext = Base64.parse(openSSLStr);
	
					// Shortcut
					var ciphertextWords = ciphertext.words;
	
					// Test for salt
					if (ciphertextWords[0] == 0x53616c74 && ciphertextWords[1] == 0x65645f5f) {
						// Extract salt
						var salt = WordArray.create(ciphertextWords.slice(2, 4));
	
						// Remove salt from ciphertext
						ciphertextWords.splice(0, 4);
						ciphertext.sigBytes -= 16;
					}
	
					return CipherParams.create({ ciphertext: ciphertext, salt: salt });
				}
			};
	
			/**
	   * A cipher wrapper that returns ciphertext as a serializable cipher params object.
	   */
			var SerializableCipher = C_lib.SerializableCipher = Base.extend({
				/**
	    * Configuration options.
	    *
	    * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL
	    */
				cfg: Base.extend({
					format: OpenSSLFormatter
				}),
	
				/**
	    * Encrypts a message.
	    *
	    * @param {Cipher} cipher The cipher algorithm to use.
	    * @param {WordArray|string} message The message to encrypt.
	    * @param {WordArray} key The key.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {CipherParams} A cipher params object.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
	    *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
	    *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	    */
				encrypt: function encrypt(cipher, message, key, cfg) {
					// Apply config defaults
					cfg = this.cfg.extend(cfg);
	
					// Encrypt
					var encryptor = cipher.createEncryptor(key, cfg);
					var ciphertext = encryptor.finalize(message);
	
					// Shortcut
					var cipherCfg = encryptor.cfg;
	
					// Create and return serializable cipher params
					return CipherParams.create({
						ciphertext: ciphertext,
						key: key,
						iv: cipherCfg.iv,
						algorithm: cipher,
						mode: cipherCfg.mode,
						padding: cipherCfg.padding,
						blockSize: cipher.blockSize,
						formatter: cfg.format
					});
				},
	
				/**
	    * Decrypts serialized ciphertext.
	    *
	    * @param {Cipher} cipher The cipher algorithm to use.
	    * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
	    * @param {WordArray} key The key.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {WordArray} The plaintext.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	    *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	    */
				decrypt: function decrypt(cipher, ciphertext, key, cfg) {
					// Apply config defaults
					cfg = this.cfg.extend(cfg);
	
					// Convert string to CipherParams
					ciphertext = this._parse(ciphertext, cfg.format);
	
					// Decrypt
					var plaintext = cipher.createDecryptor(key, cfg).finalize(ciphertext.ciphertext);
	
					return plaintext;
				},
	
				/**
	    * Converts serialized ciphertext to CipherParams,
	    * else assumed CipherParams already and returns ciphertext unchanged.
	    *
	    * @param {CipherParams|string} ciphertext The ciphertext.
	    * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.
	    *
	    * @return {CipherParams} The unserialized ciphertext.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
	    */
				_parse: function _parse(ciphertext, format) {
					if (typeof ciphertext == 'string') {
						return format.parse(ciphertext, this);
					} else {
						return ciphertext;
					}
				}
			});
	
			/**
	   * Key derivation function namespace.
	   */
			var C_kdf = C.kdf = {};
	
			/**
	   * OpenSSL key derivation function.
	   */
			var OpenSSLKdf = C_kdf.OpenSSL = {
				/**
	    * Derives a key and IV from a password.
	    *
	    * @param {string} password The password to derive from.
	    * @param {number} keySize The size in words of the key to generate.
	    * @param {number} ivSize The size in words of the IV to generate.
	    * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.
	    *
	    * @return {CipherParams} A cipher params object with the key, IV, and salt.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);
	    *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');
	    */
				execute: function execute(password, keySize, ivSize, salt) {
					// Generate random salt
					if (!salt) {
						salt = WordArray.random(64 / 8);
					}
	
					// Derive key and IV
					var key = EvpKDF.create({ keySize: keySize + ivSize }).compute(password, salt);
	
					// Separate key and IV
					var iv = WordArray.create(key.words.slice(keySize), ivSize * 4);
					key.sigBytes = keySize * 4;
	
					// Return params
					return CipherParams.create({ key: key, iv: iv, salt: salt });
				}
			};
	
			/**
	   * A serializable cipher wrapper that derives the key from a password,
	   * and returns ciphertext as a serializable cipher params object.
	   */
			var PasswordBasedCipher = C_lib.PasswordBasedCipher = SerializableCipher.extend({
				/**
	    * Configuration options.
	    *
	    * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL
	    */
				cfg: SerializableCipher.cfg.extend({
					kdf: OpenSSLKdf
				}),
	
				/**
	    * Encrypts a message using a password.
	    *
	    * @param {Cipher} cipher The cipher algorithm to use.
	    * @param {WordArray|string} message The message to encrypt.
	    * @param {string} password The password.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {CipherParams} A cipher params object.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');
	    *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });
	    */
				encrypt: function encrypt(cipher, message, password, cfg) {
					// Apply config defaults
					cfg = this.cfg.extend(cfg);
	
					// Derive key and other params
					var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize);
	
					// Add IV to config
					cfg.iv = derivedParams.iv;
	
					// Encrypt
					var ciphertext = SerializableCipher.encrypt.call(this, cipher, message, derivedParams.key, cfg);
	
					// Mix in derived params
					ciphertext.mixIn(derivedParams);
	
					return ciphertext;
				},
	
				/**
	    * Decrypts serialized ciphertext using a password.
	    *
	    * @param {Cipher} cipher The cipher algorithm to use.
	    * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
	    * @param {string} password The password.
	    * @param {Object} cfg (Optional) The configuration options to use for this operation.
	    *
	    * @return {WordArray} The plaintext.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });
	    *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });
	    */
				decrypt: function decrypt(cipher, ciphertext, password, cfg) {
					// Apply config defaults
					cfg = this.cfg.extend(cfg);
	
					// Convert string to CipherParams
					ciphertext = this._parse(ciphertext, cfg.format);
	
					// Derive key and other params
					var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize, ciphertext.salt);
	
					// Add IV to config
					cfg.iv = derivedParams.iv;
	
					// Decrypt
					var plaintext = SerializableCipher.decrypt.call(this, cipher, ciphertext, derivedParams.key, cfg);
	
					return plaintext;
				}
			});
		}();
	});

/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Cipher Feedback block mode.
	  */
		CryptoJS.mode.CFB = function () {
			var CFB = CryptoJS.lib.BlockCipherMode.extend();
	
			CFB.Encryptor = CFB.extend({
				processBlock: function processBlock(words, offset) {
					// Shortcuts
					var cipher = this._cipher;
					var blockSize = cipher.blockSize;
	
					generateKeystreamAndEncrypt.call(this, words, offset, blockSize, cipher);
	
					// Remember this block to use with next block
					this._prevBlock = words.slice(offset, offset + blockSize);
				}
			});
	
			CFB.Decryptor = CFB.extend({
				processBlock: function processBlock(words, offset) {
					// Shortcuts
					var cipher = this._cipher;
					var blockSize = cipher.blockSize;
	
					// Remember this block to use with next block
					var thisBlock = words.slice(offset, offset + blockSize);
	
					generateKeystreamAndEncrypt.call(this, words, offset, blockSize, cipher);
	
					// This block becomes the previous block
					this._prevBlock = thisBlock;
				}
			});
	
			function generateKeystreamAndEncrypt(words, offset, blockSize, cipher) {
				// Shortcut
				var iv = this._iv;
	
				// Generate keystream
				if (iv) {
					var keystream = iv.slice(0);
	
					// Remove IV for subsequent blocks
					this._iv = undefined;
				} else {
					var keystream = this._prevBlock;
				}
				cipher.encryptBlock(keystream, 0);
	
				// Encrypt
				for (var i = 0; i < blockSize; i++) {
					words[offset + i] ^= keystream[i];
				}
			}
	
			return CFB;
		}();
	
		return CryptoJS.mode.CFB;
	});

/***/ },
/* 33 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Counter block mode.
	  */
		CryptoJS.mode.CTR = function () {
			var CTR = CryptoJS.lib.BlockCipherMode.extend();
	
			var Encryptor = CTR.Encryptor = CTR.extend({
				processBlock: function processBlock(words, offset) {
					// Shortcuts
					var cipher = this._cipher;
					var blockSize = cipher.blockSize;
					var iv = this._iv;
					var counter = this._counter;
	
					// Generate keystream
					if (iv) {
						counter = this._counter = iv.slice(0);
	
						// Remove IV for subsequent blocks
						this._iv = undefined;
					}
					var keystream = counter.slice(0);
					cipher.encryptBlock(keystream, 0);
	
					// Increment counter
					counter[blockSize - 1] = counter[blockSize - 1] + 1 | 0;
	
					// Encrypt
					for (var i = 0; i < blockSize; i++) {
						words[offset + i] ^= keystream[i];
					}
				}
			});
	
			CTR.Decryptor = Encryptor;
	
			return CTR;
		}();
	
		return CryptoJS.mode.CTR;
	});

/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/** @preserve
	  * Counter block mode compatible with  Dr Brian Gladman fileenc.c
	  * derived from CryptoJS.mode.CTR
	  * Jan Hruby jhruby.web@gmail.com
	  */
		CryptoJS.mode.CTRGladman = function () {
			var CTRGladman = CryptoJS.lib.BlockCipherMode.extend();
	
			function incWord(word) {
				if ((word >> 24 & 0xff) === 0xff) {
					//overflow
					var b1 = word >> 16 & 0xff;
					var b2 = word >> 8 & 0xff;
					var b3 = word & 0xff;
	
					if (b1 === 0xff) // overflow b1
						{
							b1 = 0;
							if (b2 === 0xff) {
								b2 = 0;
								if (b3 === 0xff) {
									b3 = 0;
								} else {
									++b3;
								}
							} else {
								++b2;
							}
						} else {
						++b1;
					}
	
					word = 0;
					word += b1 << 16;
					word += b2 << 8;
					word += b3;
				} else {
					word += 0x01 << 24;
				}
				return word;
			}
	
			function incCounter(counter) {
				if ((counter[0] = incWord(counter[0])) === 0) {
					// encr_data in fileenc.c from  Dr Brian Gladman's counts only with DWORD j < 8
					counter[1] = incWord(counter[1]);
				}
				return counter;
			}
	
			var Encryptor = CTRGladman.Encryptor = CTRGladman.extend({
				processBlock: function processBlock(words, offset) {
					// Shortcuts
					var cipher = this._cipher;
					var blockSize = cipher.blockSize;
					var iv = this._iv;
					var counter = this._counter;
	
					// Generate keystream
					if (iv) {
						counter = this._counter = iv.slice(0);
	
						// Remove IV for subsequent blocks
						this._iv = undefined;
					}
	
					incCounter(counter);
	
					var keystream = counter.slice(0);
					cipher.encryptBlock(keystream, 0);
	
					// Encrypt
					for (var i = 0; i < blockSize; i++) {
						words[offset + i] ^= keystream[i];
					}
				}
			});
	
			CTRGladman.Decryptor = Encryptor;
	
			return CTRGladman;
		}();
	
		return CryptoJS.mode.CTRGladman;
	});

/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Output Feedback block mode.
	  */
		CryptoJS.mode.OFB = function () {
			var OFB = CryptoJS.lib.BlockCipherMode.extend();
	
			var Encryptor = OFB.Encryptor = OFB.extend({
				processBlock: function processBlock(words, offset) {
					// Shortcuts
					var cipher = this._cipher;
					var blockSize = cipher.blockSize;
					var iv = this._iv;
					var keystream = this._keystream;
	
					// Generate keystream
					if (iv) {
						keystream = this._keystream = iv.slice(0);
	
						// Remove IV for subsequent blocks
						this._iv = undefined;
					}
					cipher.encryptBlock(keystream, 0);
	
					// Encrypt
					for (var i = 0; i < blockSize; i++) {
						words[offset + i] ^= keystream[i];
					}
				}
			});
	
			OFB.Decryptor = Encryptor;
	
			return OFB;
		}();
	
		return CryptoJS.mode.OFB;
	});

/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Electronic Codebook block mode.
	  */
		CryptoJS.mode.ECB = function () {
			var ECB = CryptoJS.lib.BlockCipherMode.extend();
	
			ECB.Encryptor = ECB.extend({
				processBlock: function processBlock(words, offset) {
					this._cipher.encryptBlock(words, offset);
				}
			});
	
			ECB.Decryptor = ECB.extend({
				processBlock: function processBlock(words, offset) {
					this._cipher.decryptBlock(words, offset);
				}
			});
	
			return ECB;
		}();
	
		return CryptoJS.mode.ECB;
	});

/***/ },
/* 37 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * ANSI X.923 padding strategy.
	  */
		CryptoJS.pad.AnsiX923 = {
			pad: function pad(data, blockSize) {
				// Shortcuts
				var dataSigBytes = data.sigBytes;
				var blockSizeBytes = blockSize * 4;
	
				// Count padding bytes
				var nPaddingBytes = blockSizeBytes - dataSigBytes % blockSizeBytes;
	
				// Compute last byte position
				var lastBytePos = dataSigBytes + nPaddingBytes - 1;
	
				// Pad
				data.clamp();
				data.words[lastBytePos >>> 2] |= nPaddingBytes << 24 - lastBytePos % 4 * 8;
				data.sigBytes += nPaddingBytes;
			},
	
			unpad: function unpad(data) {
				// Get number of padding bytes from last byte
				var nPaddingBytes = data.words[data.sigBytes - 1 >>> 2] & 0xff;
	
				// Remove padding
				data.sigBytes -= nPaddingBytes;
			}
		};
	
		return CryptoJS.pad.Ansix923;
	});

/***/ },
/* 38 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * ISO 10126 padding strategy.
	  */
		CryptoJS.pad.Iso10126 = {
			pad: function pad(data, blockSize) {
				// Shortcut
				var blockSizeBytes = blockSize * 4;
	
				// Count padding bytes
				var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;
	
				// Pad
				data.concat(CryptoJS.lib.WordArray.random(nPaddingBytes - 1)).concat(CryptoJS.lib.WordArray.create([nPaddingBytes << 24], 1));
			},
	
			unpad: function unpad(data) {
				// Get number of padding bytes from last byte
				var nPaddingBytes = data.words[data.sigBytes - 1 >>> 2] & 0xff;
	
				// Remove padding
				data.sigBytes -= nPaddingBytes;
			}
		};
	
		return CryptoJS.pad.Iso10126;
	});

/***/ },
/* 39 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * ISO/IEC 9797-1 Padding Method 2.
	  */
		CryptoJS.pad.Iso97971 = {
			pad: function pad(data, blockSize) {
				// Add 0x80 byte
				data.concat(CryptoJS.lib.WordArray.create([0x80000000], 1));
	
				// Zero pad the rest
				CryptoJS.pad.ZeroPadding.pad(data, blockSize);
			},
	
			unpad: function unpad(data) {
				// Remove zero padding
				CryptoJS.pad.ZeroPadding.unpad(data);
	
				// Remove one more byte -- the 0x80 byte
				data.sigBytes--;
			}
		};
	
		return CryptoJS.pad.Iso97971;
	});

/***/ },
/* 40 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * Zero padding strategy.
	  */
		CryptoJS.pad.ZeroPadding = {
			pad: function pad(data, blockSize) {
				// Shortcut
				var blockSizeBytes = blockSize * 4;
	
				// Pad
				data.clamp();
				data.sigBytes += blockSizeBytes - (data.sigBytes % blockSizeBytes || blockSizeBytes);
			},
	
			unpad: function unpad(data) {
				// Shortcut
				var dataWords = data.words;
	
				// Unpad
				var i = data.sigBytes - 1;
				while (!(dataWords[i >>> 2] >>> 24 - i % 4 * 8 & 0xff)) {
					i--;
				}
				data.sigBytes = i + 1;
			}
		};
	
		return CryptoJS.pad.ZeroPadding;
	});

/***/ },
/* 41 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		/**
	  * A noop padding strategy.
	  */
		CryptoJS.pad.NoPadding = {
			pad: function pad() {},
	
			unpad: function unpad() {}
		};
	
		return CryptoJS.pad.NoPadding;
	});

/***/ },
/* 42 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function (undefined) {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var CipherParams = C_lib.CipherParams;
			var C_enc = C.enc;
			var Hex = C_enc.Hex;
			var C_format = C.format;
	
			var HexFormatter = C_format.Hex = {
				/**
	    * Converts the ciphertext of a cipher params object to a hexadecimally encoded string.
	    *
	    * @param {CipherParams} cipherParams The cipher params object.
	    *
	    * @return {string} The hexadecimally encoded string.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var hexString = CryptoJS.format.Hex.stringify(cipherParams);
	    */
				stringify: function stringify(cipherParams) {
					return cipherParams.ciphertext.toString(Hex);
				},
	
				/**
	    * Converts a hexadecimally encoded ciphertext string to a cipher params object.
	    *
	    * @param {string} input The hexadecimally encoded string.
	    *
	    * @return {CipherParams} The cipher params object.
	    *
	    * @static
	    *
	    * @example
	    *
	    *     var cipherParams = CryptoJS.format.Hex.parse(hexString);
	    */
				parse: function parse(input) {
					var ciphertext = Hex.parse(input);
					return CipherParams.create({ ciphertext: ciphertext });
				}
			};
		})();
	
		return CryptoJS.format.Hex;
	});

/***/ },
/* 43 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var BlockCipher = C_lib.BlockCipher;
			var C_algo = C.algo;
	
			// Lookup tables
			var SBOX = [];
			var INV_SBOX = [];
			var SUB_MIX_0 = [];
			var SUB_MIX_1 = [];
			var SUB_MIX_2 = [];
			var SUB_MIX_3 = [];
			var INV_SUB_MIX_0 = [];
			var INV_SUB_MIX_1 = [];
			var INV_SUB_MIX_2 = [];
			var INV_SUB_MIX_3 = [];
	
			// Compute lookup tables
			(function () {
				// Compute double table
				var d = [];
				for (var i = 0; i < 256; i++) {
					if (i < 128) {
						d[i] = i << 1;
					} else {
						d[i] = i << 1 ^ 0x11b;
					}
				}
	
				// Walk GF(2^8)
				var x = 0;
				var xi = 0;
				for (var i = 0; i < 256; i++) {
					// Compute sbox
					var sx = xi ^ xi << 1 ^ xi << 2 ^ xi << 3 ^ xi << 4;
					sx = sx >>> 8 ^ sx & 0xff ^ 0x63;
					SBOX[x] = sx;
					INV_SBOX[sx] = x;
	
					// Compute multiplication
					var x2 = d[x];
					var x4 = d[x2];
					var x8 = d[x4];
	
					// Compute sub bytes, mix columns tables
					var t = d[sx] * 0x101 ^ sx * 0x1010100;
					SUB_MIX_0[x] = t << 24 | t >>> 8;
					SUB_MIX_1[x] = t << 16 | t >>> 16;
					SUB_MIX_2[x] = t << 8 | t >>> 24;
					SUB_MIX_3[x] = t;
	
					// Compute inv sub bytes, inv mix columns tables
					var t = x8 * 0x1010101 ^ x4 * 0x10001 ^ x2 * 0x101 ^ x * 0x1010100;
					INV_SUB_MIX_0[sx] = t << 24 | t >>> 8;
					INV_SUB_MIX_1[sx] = t << 16 | t >>> 16;
					INV_SUB_MIX_2[sx] = t << 8 | t >>> 24;
					INV_SUB_MIX_3[sx] = t;
	
					// Compute next counter
					if (!x) {
						x = xi = 1;
					} else {
						x = x2 ^ d[d[d[x8 ^ x2]]];
						xi ^= d[d[xi]];
					}
				}
			})();
	
			// Precomputed Rcon lookup
			var RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];
	
			/**
	   * AES block cipher algorithm.
	   */
			var AES = C_algo.AES = BlockCipher.extend({
				_doReset: function _doReset() {
					// Skip reset of nRounds has been set before and key did not change
					if (this._nRounds && this._keyPriorReset === this._key) {
						return;
					}
	
					// Shortcuts
					var key = this._keyPriorReset = this._key;
					var keyWords = key.words;
					var keySize = key.sigBytes / 4;
	
					// Compute number of rounds
					var nRounds = this._nRounds = keySize + 6;
	
					// Compute number of key schedule rows
					var ksRows = (nRounds + 1) * 4;
	
					// Compute key schedule
					var keySchedule = this._keySchedule = [];
					for (var ksRow = 0; ksRow < ksRows; ksRow++) {
						if (ksRow < keySize) {
							keySchedule[ksRow] = keyWords[ksRow];
						} else {
							var t = keySchedule[ksRow - 1];
	
							if (!(ksRow % keySize)) {
								// Rot word
								t = t << 8 | t >>> 24;
	
								// Sub word
								t = SBOX[t >>> 24] << 24 | SBOX[t >>> 16 & 0xff] << 16 | SBOX[t >>> 8 & 0xff] << 8 | SBOX[t & 0xff];
	
								// Mix Rcon
								t ^= RCON[ksRow / keySize | 0] << 24;
							} else if (keySize > 6 && ksRow % keySize == 4) {
								// Sub word
								t = SBOX[t >>> 24] << 24 | SBOX[t >>> 16 & 0xff] << 16 | SBOX[t >>> 8 & 0xff] << 8 | SBOX[t & 0xff];
							}
	
							keySchedule[ksRow] = keySchedule[ksRow - keySize] ^ t;
						}
					}
	
					// Compute inv key schedule
					var invKeySchedule = this._invKeySchedule = [];
					for (var invKsRow = 0; invKsRow < ksRows; invKsRow++) {
						var ksRow = ksRows - invKsRow;
	
						if (invKsRow % 4) {
							var t = keySchedule[ksRow];
						} else {
							var t = keySchedule[ksRow - 4];
						}
	
						if (invKsRow < 4 || ksRow <= 4) {
							invKeySchedule[invKsRow] = t;
						} else {
							invKeySchedule[invKsRow] = INV_SUB_MIX_0[SBOX[t >>> 24]] ^ INV_SUB_MIX_1[SBOX[t >>> 16 & 0xff]] ^ INV_SUB_MIX_2[SBOX[t >>> 8 & 0xff]] ^ INV_SUB_MIX_3[SBOX[t & 0xff]];
						}
					}
				},
	
				encryptBlock: function encryptBlock(M, offset) {
					this._doCryptBlock(M, offset, this._keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX);
				},
	
				decryptBlock: function decryptBlock(M, offset) {
					// Swap 2nd and 4th rows
					var t = M[offset + 1];
					M[offset + 1] = M[offset + 3];
					M[offset + 3] = t;
	
					this._doCryptBlock(M, offset, this._invKeySchedule, INV_SUB_MIX_0, INV_SUB_MIX_1, INV_SUB_MIX_2, INV_SUB_MIX_3, INV_SBOX);
	
					// Inv swap 2nd and 4th rows
					var t = M[offset + 1];
					M[offset + 1] = M[offset + 3];
					M[offset + 3] = t;
				},
	
				_doCryptBlock: function _doCryptBlock(M, offset, keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX) {
					// Shortcut
					var nRounds = this._nRounds;
	
					// Get input, add round key
					var s0 = M[offset] ^ keySchedule[0];
					var s1 = M[offset + 1] ^ keySchedule[1];
					var s2 = M[offset + 2] ^ keySchedule[2];
					var s3 = M[offset + 3] ^ keySchedule[3];
	
					// Key schedule row counter
					var ksRow = 4;
	
					// Rounds
					for (var round = 1; round < nRounds; round++) {
						// Shift rows, sub bytes, mix columns, add round key
						var t0 = SUB_MIX_0[s0 >>> 24] ^ SUB_MIX_1[s1 >>> 16 & 0xff] ^ SUB_MIX_2[s2 >>> 8 & 0xff] ^ SUB_MIX_3[s3 & 0xff] ^ keySchedule[ksRow++];
						var t1 = SUB_MIX_0[s1 >>> 24] ^ SUB_MIX_1[s2 >>> 16 & 0xff] ^ SUB_MIX_2[s3 >>> 8 & 0xff] ^ SUB_MIX_3[s0 & 0xff] ^ keySchedule[ksRow++];
						var t2 = SUB_MIX_0[s2 >>> 24] ^ SUB_MIX_1[s3 >>> 16 & 0xff] ^ SUB_MIX_2[s0 >>> 8 & 0xff] ^ SUB_MIX_3[s1 & 0xff] ^ keySchedule[ksRow++];
						var t3 = SUB_MIX_0[s3 >>> 24] ^ SUB_MIX_1[s0 >>> 16 & 0xff] ^ SUB_MIX_2[s1 >>> 8 & 0xff] ^ SUB_MIX_3[s2 & 0xff] ^ keySchedule[ksRow++];
	
						// Update state
						s0 = t0;
						s1 = t1;
						s2 = t2;
						s3 = t3;
					}
	
					// Shift rows, sub bytes, add round key
					var t0 = (SBOX[s0 >>> 24] << 24 | SBOX[s1 >>> 16 & 0xff] << 16 | SBOX[s2 >>> 8 & 0xff] << 8 | SBOX[s3 & 0xff]) ^ keySchedule[ksRow++];
					var t1 = (SBOX[s1 >>> 24] << 24 | SBOX[s2 >>> 16 & 0xff] << 16 | SBOX[s3 >>> 8 & 0xff] << 8 | SBOX[s0 & 0xff]) ^ keySchedule[ksRow++];
					var t2 = (SBOX[s2 >>> 24] << 24 | SBOX[s3 >>> 16 & 0xff] << 16 | SBOX[s0 >>> 8 & 0xff] << 8 | SBOX[s1 & 0xff]) ^ keySchedule[ksRow++];
					var t3 = (SBOX[s3 >>> 24] << 24 | SBOX[s0 >>> 16 & 0xff] << 16 | SBOX[s1 >>> 8 & 0xff] << 8 | SBOX[s2 & 0xff]) ^ keySchedule[ksRow++];
	
					// Set output
					M[offset] = t0;
					M[offset + 1] = t1;
					M[offset + 2] = t2;
					M[offset + 3] = t3;
				},
	
				keySize: 256 / 32
			});
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.AES.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.AES.decrypt(ciphertext, key, cfg);
	   */
			C.AES = BlockCipher._createHelper(AES);
		})();
	
		return CryptoJS.AES;
	});

/***/ },
/* 44 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var WordArray = C_lib.WordArray;
			var BlockCipher = C_lib.BlockCipher;
			var C_algo = C.algo;
	
			// Permuted Choice 1 constants
			var PC1 = [57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36, 63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4];
	
			// Permuted Choice 2 constants
			var PC2 = [14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2, 41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32];
	
			// Cumulative bit shift constants
			var BIT_SHIFTS = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28];
	
			// SBOXes and round permutation constants
			var SBOX_P = [{
				0x0: 0x808200,
				0x10000000: 0x8000,
				0x20000000: 0x808002,
				0x30000000: 0x2,
				0x40000000: 0x200,
				0x50000000: 0x808202,
				0x60000000: 0x800202,
				0x70000000: 0x800000,
				0x80000000: 0x202,
				0x90000000: 0x800200,
				0xa0000000: 0x8200,
				0xb0000000: 0x808000,
				0xc0000000: 0x8002,
				0xd0000000: 0x800002,
				0xe0000000: 0x0,
				0xf0000000: 0x8202,
				0x8000000: 0x0,
				0x18000000: 0x808202,
				0x28000000: 0x8202,
				0x38000000: 0x8000,
				0x48000000: 0x808200,
				0x58000000: 0x200,
				0x68000000: 0x808002,
				0x78000000: 0x2,
				0x88000000: 0x800200,
				0x98000000: 0x8200,
				0xa8000000: 0x808000,
				0xb8000000: 0x800202,
				0xc8000000: 0x800002,
				0xd8000000: 0x8002,
				0xe8000000: 0x202,
				0xf8000000: 0x800000,
				0x1: 0x8000,
				0x10000001: 0x2,
				0x20000001: 0x808200,
				0x30000001: 0x800000,
				0x40000001: 0x808002,
				0x50000001: 0x8200,
				0x60000001: 0x200,
				0x70000001: 0x800202,
				0x80000001: 0x808202,
				0x90000001: 0x808000,
				0xa0000001: 0x800002,
				0xb0000001: 0x8202,
				0xc0000001: 0x202,
				0xd0000001: 0x800200,
				0xe0000001: 0x8002,
				0xf0000001: 0x0,
				0x8000001: 0x808202,
				0x18000001: 0x808000,
				0x28000001: 0x800000,
				0x38000001: 0x200,
				0x48000001: 0x8000,
				0x58000001: 0x800002,
				0x68000001: 0x2,
				0x78000001: 0x8202,
				0x88000001: 0x8002,
				0x98000001: 0x800202,
				0xa8000001: 0x202,
				0xb8000001: 0x808200,
				0xc8000001: 0x800200,
				0xd8000001: 0x0,
				0xe8000001: 0x8200,
				0xf8000001: 0x808002
			}, {
				0x0: 0x40084010,
				0x1000000: 0x4000,
				0x2000000: 0x80000,
				0x3000000: 0x40080010,
				0x4000000: 0x40000010,
				0x5000000: 0x40084000,
				0x6000000: 0x40004000,
				0x7000000: 0x10,
				0x8000000: 0x84000,
				0x9000000: 0x40004010,
				0xa000000: 0x40000000,
				0xb000000: 0x84010,
				0xc000000: 0x80010,
				0xd000000: 0x0,
				0xe000000: 0x4010,
				0xf000000: 0x40080000,
				0x800000: 0x40004000,
				0x1800000: 0x84010,
				0x2800000: 0x10,
				0x3800000: 0x40004010,
				0x4800000: 0x40084010,
				0x5800000: 0x40000000,
				0x6800000: 0x80000,
				0x7800000: 0x40080010,
				0x8800000: 0x80010,
				0x9800000: 0x0,
				0xa800000: 0x4000,
				0xb800000: 0x40080000,
				0xc800000: 0x40000010,
				0xd800000: 0x84000,
				0xe800000: 0x40084000,
				0xf800000: 0x4010,
				0x10000000: 0x0,
				0x11000000: 0x40080010,
				0x12000000: 0x40004010,
				0x13000000: 0x40084000,
				0x14000000: 0x40080000,
				0x15000000: 0x10,
				0x16000000: 0x84010,
				0x17000000: 0x4000,
				0x18000000: 0x4010,
				0x19000000: 0x80000,
				0x1a000000: 0x80010,
				0x1b000000: 0x40000010,
				0x1c000000: 0x84000,
				0x1d000000: 0x40004000,
				0x1e000000: 0x40000000,
				0x1f000000: 0x40084010,
				0x10800000: 0x84010,
				0x11800000: 0x80000,
				0x12800000: 0x40080000,
				0x13800000: 0x4000,
				0x14800000: 0x40004000,
				0x15800000: 0x40084010,
				0x16800000: 0x10,
				0x17800000: 0x40000000,
				0x18800000: 0x40084000,
				0x19800000: 0x40000010,
				0x1a800000: 0x40004010,
				0x1b800000: 0x80010,
				0x1c800000: 0x0,
				0x1d800000: 0x4010,
				0x1e800000: 0x40080010,
				0x1f800000: 0x84000
			}, {
				0x0: 0x104,
				0x100000: 0x0,
				0x200000: 0x4000100,
				0x300000: 0x10104,
				0x400000: 0x10004,
				0x500000: 0x4000004,
				0x600000: 0x4010104,
				0x700000: 0x4010000,
				0x800000: 0x4000000,
				0x900000: 0x4010100,
				0xa00000: 0x10100,
				0xb00000: 0x4010004,
				0xc00000: 0x4000104,
				0xd00000: 0x10000,
				0xe00000: 0x4,
				0xf00000: 0x100,
				0x80000: 0x4010100,
				0x180000: 0x4010004,
				0x280000: 0x0,
				0x380000: 0x4000100,
				0x480000: 0x4000004,
				0x580000: 0x10000,
				0x680000: 0x10004,
				0x780000: 0x104,
				0x880000: 0x4,
				0x980000: 0x100,
				0xa80000: 0x4010000,
				0xb80000: 0x10104,
				0xc80000: 0x10100,
				0xd80000: 0x4000104,
				0xe80000: 0x4010104,
				0xf80000: 0x4000000,
				0x1000000: 0x4010100,
				0x1100000: 0x10004,
				0x1200000: 0x10000,
				0x1300000: 0x4000100,
				0x1400000: 0x100,
				0x1500000: 0x4010104,
				0x1600000: 0x4000004,
				0x1700000: 0x0,
				0x1800000: 0x4000104,
				0x1900000: 0x4000000,
				0x1a00000: 0x4,
				0x1b00000: 0x10100,
				0x1c00000: 0x4010000,
				0x1d00000: 0x104,
				0x1e00000: 0x10104,
				0x1f00000: 0x4010004,
				0x1080000: 0x4000000,
				0x1180000: 0x104,
				0x1280000: 0x4010100,
				0x1380000: 0x0,
				0x1480000: 0x10004,
				0x1580000: 0x4000100,
				0x1680000: 0x100,
				0x1780000: 0x4010004,
				0x1880000: 0x10000,
				0x1980000: 0x4010104,
				0x1a80000: 0x10104,
				0x1b80000: 0x4000004,
				0x1c80000: 0x4000104,
				0x1d80000: 0x4010000,
				0x1e80000: 0x4,
				0x1f80000: 0x10100
			}, {
				0x0: 0x80401000,
				0x10000: 0x80001040,
				0x20000: 0x401040,
				0x30000: 0x80400000,
				0x40000: 0x0,
				0x50000: 0x401000,
				0x60000: 0x80000040,
				0x70000: 0x400040,
				0x80000: 0x80000000,
				0x90000: 0x400000,
				0xa0000: 0x40,
				0xb0000: 0x80001000,
				0xc0000: 0x80400040,
				0xd0000: 0x1040,
				0xe0000: 0x1000,
				0xf0000: 0x80401040,
				0x8000: 0x80001040,
				0x18000: 0x40,
				0x28000: 0x80400040,
				0x38000: 0x80001000,
				0x48000: 0x401000,
				0x58000: 0x80401040,
				0x68000: 0x0,
				0x78000: 0x80400000,
				0x88000: 0x1000,
				0x98000: 0x80401000,
				0xa8000: 0x400000,
				0xb8000: 0x1040,
				0xc8000: 0x80000000,
				0xd8000: 0x400040,
				0xe8000: 0x401040,
				0xf8000: 0x80000040,
				0x100000: 0x400040,
				0x110000: 0x401000,
				0x120000: 0x80000040,
				0x130000: 0x0,
				0x140000: 0x1040,
				0x150000: 0x80400040,
				0x160000: 0x80401000,
				0x170000: 0x80001040,
				0x180000: 0x80401040,
				0x190000: 0x80000000,
				0x1a0000: 0x80400000,
				0x1b0000: 0x401040,
				0x1c0000: 0x80001000,
				0x1d0000: 0x400000,
				0x1e0000: 0x40,
				0x1f0000: 0x1000,
				0x108000: 0x80400000,
				0x118000: 0x80401040,
				0x128000: 0x0,
				0x138000: 0x401000,
				0x148000: 0x400040,
				0x158000: 0x80000000,
				0x168000: 0x80001040,
				0x178000: 0x40,
				0x188000: 0x80000040,
				0x198000: 0x1000,
				0x1a8000: 0x80001000,
				0x1b8000: 0x80400040,
				0x1c8000: 0x1040,
				0x1d8000: 0x80401000,
				0x1e8000: 0x400000,
				0x1f8000: 0x401040
			}, {
				0x0: 0x80,
				0x1000: 0x1040000,
				0x2000: 0x40000,
				0x3000: 0x20000000,
				0x4000: 0x20040080,
				0x5000: 0x1000080,
				0x6000: 0x21000080,
				0x7000: 0x40080,
				0x8000: 0x1000000,
				0x9000: 0x20040000,
				0xa000: 0x20000080,
				0xb000: 0x21040080,
				0xc000: 0x21040000,
				0xd000: 0x0,
				0xe000: 0x1040080,
				0xf000: 0x21000000,
				0x800: 0x1040080,
				0x1800: 0x21000080,
				0x2800: 0x80,
				0x3800: 0x1040000,
				0x4800: 0x40000,
				0x5800: 0x20040080,
				0x6800: 0x21040000,
				0x7800: 0x20000000,
				0x8800: 0x20040000,
				0x9800: 0x0,
				0xa800: 0x21040080,
				0xb800: 0x1000080,
				0xc800: 0x20000080,
				0xd800: 0x21000000,
				0xe800: 0x1000000,
				0xf800: 0x40080,
				0x10000: 0x40000,
				0x11000: 0x80,
				0x12000: 0x20000000,
				0x13000: 0x21000080,
				0x14000: 0x1000080,
				0x15000: 0x21040000,
				0x16000: 0x20040080,
				0x17000: 0x1000000,
				0x18000: 0x21040080,
				0x19000: 0x21000000,
				0x1a000: 0x1040000,
				0x1b000: 0x20040000,
				0x1c000: 0x40080,
				0x1d000: 0x20000080,
				0x1e000: 0x0,
				0x1f000: 0x1040080,
				0x10800: 0x21000080,
				0x11800: 0x1000000,
				0x12800: 0x1040000,
				0x13800: 0x20040080,
				0x14800: 0x20000000,
				0x15800: 0x1040080,
				0x16800: 0x80,
				0x17800: 0x21040000,
				0x18800: 0x40080,
				0x19800: 0x21040080,
				0x1a800: 0x0,
				0x1b800: 0x21000000,
				0x1c800: 0x1000080,
				0x1d800: 0x40000,
				0x1e800: 0x20040000,
				0x1f800: 0x20000080
			}, {
				0x0: 0x10000008,
				0x100: 0x2000,
				0x200: 0x10200000,
				0x300: 0x10202008,
				0x400: 0x10002000,
				0x500: 0x200000,
				0x600: 0x200008,
				0x700: 0x10000000,
				0x800: 0x0,
				0x900: 0x10002008,
				0xa00: 0x202000,
				0xb00: 0x8,
				0xc00: 0x10200008,
				0xd00: 0x202008,
				0xe00: 0x2008,
				0xf00: 0x10202000,
				0x80: 0x10200000,
				0x180: 0x10202008,
				0x280: 0x8,
				0x380: 0x200000,
				0x480: 0x202008,
				0x580: 0x10000008,
				0x680: 0x10002000,
				0x780: 0x2008,
				0x880: 0x200008,
				0x980: 0x2000,
				0xa80: 0x10002008,
				0xb80: 0x10200008,
				0xc80: 0x0,
				0xd80: 0x10202000,
				0xe80: 0x202000,
				0xf80: 0x10000000,
				0x1000: 0x10002000,
				0x1100: 0x10200008,
				0x1200: 0x10202008,
				0x1300: 0x2008,
				0x1400: 0x200000,
				0x1500: 0x10000000,
				0x1600: 0x10000008,
				0x1700: 0x202000,
				0x1800: 0x202008,
				0x1900: 0x0,
				0x1a00: 0x8,
				0x1b00: 0x10200000,
				0x1c00: 0x2000,
				0x1d00: 0x10002008,
				0x1e00: 0x10202000,
				0x1f00: 0x200008,
				0x1080: 0x8,
				0x1180: 0x202000,
				0x1280: 0x200000,
				0x1380: 0x10000008,
				0x1480: 0x10002000,
				0x1580: 0x2008,
				0x1680: 0x10202008,
				0x1780: 0x10200000,
				0x1880: 0x10202000,
				0x1980: 0x10200008,
				0x1a80: 0x2000,
				0x1b80: 0x202008,
				0x1c80: 0x200008,
				0x1d80: 0x0,
				0x1e80: 0x10000000,
				0x1f80: 0x10002008
			}, {
				0x0: 0x100000,
				0x10: 0x2000401,
				0x20: 0x400,
				0x30: 0x100401,
				0x40: 0x2100401,
				0x50: 0x0,
				0x60: 0x1,
				0x70: 0x2100001,
				0x80: 0x2000400,
				0x90: 0x100001,
				0xa0: 0x2000001,
				0xb0: 0x2100400,
				0xc0: 0x2100000,
				0xd0: 0x401,
				0xe0: 0x100400,
				0xf0: 0x2000000,
				0x8: 0x2100001,
				0x18: 0x0,
				0x28: 0x2000401,
				0x38: 0x2100400,
				0x48: 0x100000,
				0x58: 0x2000001,
				0x68: 0x2000000,
				0x78: 0x401,
				0x88: 0x100401,
				0x98: 0x2000400,
				0xa8: 0x2100000,
				0xb8: 0x100001,
				0xc8: 0x400,
				0xd8: 0x2100401,
				0xe8: 0x1,
				0xf8: 0x100400,
				0x100: 0x2000000,
				0x110: 0x100000,
				0x120: 0x2000401,
				0x130: 0x2100001,
				0x140: 0x100001,
				0x150: 0x2000400,
				0x160: 0x2100400,
				0x170: 0x100401,
				0x180: 0x401,
				0x190: 0x2100401,
				0x1a0: 0x100400,
				0x1b0: 0x1,
				0x1c0: 0x0,
				0x1d0: 0x2100000,
				0x1e0: 0x2000001,
				0x1f0: 0x400,
				0x108: 0x100400,
				0x118: 0x2000401,
				0x128: 0x2100001,
				0x138: 0x1,
				0x148: 0x2000000,
				0x158: 0x100000,
				0x168: 0x401,
				0x178: 0x2100400,
				0x188: 0x2000001,
				0x198: 0x2100000,
				0x1a8: 0x0,
				0x1b8: 0x2100401,
				0x1c8: 0x100401,
				0x1d8: 0x400,
				0x1e8: 0x2000400,
				0x1f8: 0x100001
			}, {
				0x0: 0x8000820,
				0x1: 0x20000,
				0x2: 0x8000000,
				0x3: 0x20,
				0x4: 0x20020,
				0x5: 0x8020820,
				0x6: 0x8020800,
				0x7: 0x800,
				0x8: 0x8020000,
				0x9: 0x8000800,
				0xa: 0x20800,
				0xb: 0x8020020,
				0xc: 0x820,
				0xd: 0x0,
				0xe: 0x8000020,
				0xf: 0x20820,
				0x80000000: 0x800,
				0x80000001: 0x8020820,
				0x80000002: 0x8000820,
				0x80000003: 0x8000000,
				0x80000004: 0x8020000,
				0x80000005: 0x20800,
				0x80000006: 0x20820,
				0x80000007: 0x20,
				0x80000008: 0x8000020,
				0x80000009: 0x820,
				0x8000000a: 0x20020,
				0x8000000b: 0x8020800,
				0x8000000c: 0x0,
				0x8000000d: 0x8020020,
				0x8000000e: 0x8000800,
				0x8000000f: 0x20000,
				0x10: 0x20820,
				0x11: 0x8020800,
				0x12: 0x20,
				0x13: 0x800,
				0x14: 0x8000800,
				0x15: 0x8000020,
				0x16: 0x8020020,
				0x17: 0x20000,
				0x18: 0x0,
				0x19: 0x20020,
				0x1a: 0x8020000,
				0x1b: 0x8000820,
				0x1c: 0x8020820,
				0x1d: 0x20800,
				0x1e: 0x820,
				0x1f: 0x8000000,
				0x80000010: 0x20000,
				0x80000011: 0x800,
				0x80000012: 0x8020020,
				0x80000013: 0x20820,
				0x80000014: 0x20,
				0x80000015: 0x8020000,
				0x80000016: 0x8000000,
				0x80000017: 0x8000820,
				0x80000018: 0x8020820,
				0x80000019: 0x8000020,
				0x8000001a: 0x8000800,
				0x8000001b: 0x0,
				0x8000001c: 0x20800,
				0x8000001d: 0x820,
				0x8000001e: 0x20020,
				0x8000001f: 0x8020800
			}];
	
			// Masks that select the SBOX input
			var SBOX_MASK = [0xf8000001, 0x1f800000, 0x01f80000, 0x001f8000, 0x0001f800, 0x00001f80, 0x000001f8, 0x8000001f];
	
			/**
	   * DES block cipher algorithm.
	   */
			var DES = C_algo.DES = BlockCipher.extend({
				_doReset: function _doReset() {
					// Shortcuts
					var key = this._key;
					var keyWords = key.words;
	
					// Select 56 bits according to PC1
					var keyBits = [];
					for (var i = 0; i < 56; i++) {
						var keyBitPos = PC1[i] - 1;
						keyBits[i] = keyWords[keyBitPos >>> 5] >>> 31 - keyBitPos % 32 & 1;
					}
	
					// Assemble 16 subkeys
					var subKeys = this._subKeys = [];
					for (var nSubKey = 0; nSubKey < 16; nSubKey++) {
						// Create subkey
						var subKey = subKeys[nSubKey] = [];
	
						// Shortcut
						var bitShift = BIT_SHIFTS[nSubKey];
	
						// Select 48 bits according to PC2
						for (var i = 0; i < 24; i++) {
							// Select from the left 28 key bits
							subKey[i / 6 | 0] |= keyBits[(PC2[i] - 1 + bitShift) % 28] << 31 - i % 6;
	
							// Select from the right 28 key bits
							subKey[4 + (i / 6 | 0)] |= keyBits[28 + (PC2[i + 24] - 1 + bitShift) % 28] << 31 - i % 6;
						}
	
						// Since each subkey is applied to an expanded 32-bit input,
						// the subkey can be broken into 8 values scaled to 32-bits,
						// which allows the key to be used without expansion
						subKey[0] = subKey[0] << 1 | subKey[0] >>> 31;
						for (var i = 1; i < 7; i++) {
							subKey[i] = subKey[i] >>> (i - 1) * 4 + 3;
						}
						subKey[7] = subKey[7] << 5 | subKey[7] >>> 27;
					}
	
					// Compute inverse subkeys
					var invSubKeys = this._invSubKeys = [];
					for (var i = 0; i < 16; i++) {
						invSubKeys[i] = subKeys[15 - i];
					}
				},
	
				encryptBlock: function encryptBlock(M, offset) {
					this._doCryptBlock(M, offset, this._subKeys);
				},
	
				decryptBlock: function decryptBlock(M, offset) {
					this._doCryptBlock(M, offset, this._invSubKeys);
				},
	
				_doCryptBlock: function _doCryptBlock(M, offset, subKeys) {
					// Get input
					this._lBlock = M[offset];
					this._rBlock = M[offset + 1];
	
					// Initial permutation
					exchangeLR.call(this, 4, 0x0f0f0f0f);
					exchangeLR.call(this, 16, 0x0000ffff);
					exchangeRL.call(this, 2, 0x33333333);
					exchangeRL.call(this, 8, 0x00ff00ff);
					exchangeLR.call(this, 1, 0x55555555);
	
					// Rounds
					for (var round = 0; round < 16; round++) {
						// Shortcuts
						var subKey = subKeys[round];
						var lBlock = this._lBlock;
						var rBlock = this._rBlock;
	
						// Feistel function
						var f = 0;
						for (var i = 0; i < 8; i++) {
							f |= SBOX_P[i][((rBlock ^ subKey[i]) & SBOX_MASK[i]) >>> 0];
						}
						this._lBlock = rBlock;
						this._rBlock = lBlock ^ f;
					}
	
					// Undo swap from last round
					var t = this._lBlock;
					this._lBlock = this._rBlock;
					this._rBlock = t;
	
					// Final permutation
					exchangeLR.call(this, 1, 0x55555555);
					exchangeRL.call(this, 8, 0x00ff00ff);
					exchangeRL.call(this, 2, 0x33333333);
					exchangeLR.call(this, 16, 0x0000ffff);
					exchangeLR.call(this, 4, 0x0f0f0f0f);
	
					// Set output
					M[offset] = this._lBlock;
					M[offset + 1] = this._rBlock;
				},
	
				keySize: 64 / 32,
	
				ivSize: 64 / 32,
	
				blockSize: 64 / 32
			});
	
			// Swap bits across the left and right words
			function exchangeLR(offset, mask) {
				var t = (this._lBlock >>> offset ^ this._rBlock) & mask;
				this._rBlock ^= t;
				this._lBlock ^= t << offset;
			}
	
			function exchangeRL(offset, mask) {
				var t = (this._rBlock >>> offset ^ this._lBlock) & mask;
				this._lBlock ^= t;
				this._rBlock ^= t << offset;
			}
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.DES.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.DES.decrypt(ciphertext, key, cfg);
	   */
			C.DES = BlockCipher._createHelper(DES);
	
			/**
	   * Triple-DES block cipher algorithm.
	   */
			var TripleDES = C_algo.TripleDES = BlockCipher.extend({
				_doReset: function _doReset() {
					// Shortcuts
					var key = this._key;
					var keyWords = key.words;
	
					// Create DES instances
					this._des1 = DES.createEncryptor(WordArray.create(keyWords.slice(0, 2)));
					this._des2 = DES.createEncryptor(WordArray.create(keyWords.slice(2, 4)));
					this._des3 = DES.createEncryptor(WordArray.create(keyWords.slice(4, 6)));
				},
	
				encryptBlock: function encryptBlock(M, offset) {
					this._des1.encryptBlock(M, offset);
					this._des2.decryptBlock(M, offset);
					this._des3.encryptBlock(M, offset);
				},
	
				decryptBlock: function decryptBlock(M, offset) {
					this._des3.decryptBlock(M, offset);
					this._des2.encryptBlock(M, offset);
					this._des1.decryptBlock(M, offset);
				},
	
				keySize: 192 / 32,
	
				ivSize: 64 / 32,
	
				blockSize: 64 / 32
			});
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.TripleDES.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.TripleDES.decrypt(ciphertext, key, cfg);
	   */
			C.TripleDES = BlockCipher._createHelper(TripleDES);
		})();
	
		return CryptoJS.TripleDES;
	});

/***/ },
/* 45 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var StreamCipher = C_lib.StreamCipher;
			var C_algo = C.algo;
	
			/**
	   * RC4 stream cipher algorithm.
	   */
			var RC4 = C_algo.RC4 = StreamCipher.extend({
				_doReset: function _doReset() {
					// Shortcuts
					var key = this._key;
					var keyWords = key.words;
					var keySigBytes = key.sigBytes;
	
					// Init sbox
					var S = this._S = [];
					for (var i = 0; i < 256; i++) {
						S[i] = i;
					}
	
					// Key setup
					for (var i = 0, j = 0; i < 256; i++) {
						var keyByteIndex = i % keySigBytes;
						var keyByte = keyWords[keyByteIndex >>> 2] >>> 24 - keyByteIndex % 4 * 8 & 0xff;
	
						j = (j + S[i] + keyByte) % 256;
	
						// Swap
						var t = S[i];
						S[i] = S[j];
						S[j] = t;
					}
	
					// Counters
					this._i = this._j = 0;
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					M[offset] ^= generateKeystreamWord.call(this);
				},
	
				keySize: 256 / 32,
	
				ivSize: 0
			});
	
			function generateKeystreamWord() {
				// Shortcuts
				var S = this._S;
				var i = this._i;
				var j = this._j;
	
				// Generate keystream word
				var keystreamWord = 0;
				for (var n = 0; n < 4; n++) {
					i = (i + 1) % 256;
					j = (j + S[i]) % 256;
	
					// Swap
					var t = S[i];
					S[i] = S[j];
					S[j] = t;
	
					keystreamWord |= S[(S[i] + S[j]) % 256] << 24 - n * 8;
				}
	
				// Update counters
				this._i = i;
				this._j = j;
	
				return keystreamWord;
			}
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.RC4.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.RC4.decrypt(ciphertext, key, cfg);
	   */
			C.RC4 = StreamCipher._createHelper(RC4);
	
			/**
	   * Modified RC4 stream cipher algorithm.
	   */
			var RC4Drop = C_algo.RC4Drop = RC4.extend({
				/**
	    * Configuration options.
	    *
	    * @property {number} drop The number of keystream words to drop. Default 192
	    */
				cfg: RC4.cfg.extend({
					drop: 192
				}),
	
				_doReset: function _doReset() {
					RC4._doReset.call(this);
	
					// Drop
					for (var i = this.cfg.drop; i > 0; i--) {
						generateKeystreamWord.call(this);
					}
				}
			});
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.RC4Drop.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.RC4Drop.decrypt(ciphertext, key, cfg);
	   */
			C.RC4Drop = StreamCipher._createHelper(RC4Drop);
		})();
	
		return CryptoJS.RC4;
	});

/***/ },
/* 46 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var StreamCipher = C_lib.StreamCipher;
			var C_algo = C.algo;
	
			// Reusable objects
			var S = [];
			var C_ = [];
			var G = [];
	
			/**
	   * Rabbit stream cipher algorithm
	   */
			var Rabbit = C_algo.Rabbit = StreamCipher.extend({
				_doReset: function _doReset() {
					// Shortcuts
					var K = this._key.words;
					var iv = this.cfg.iv;
	
					// Swap endian
					for (var i = 0; i < 4; i++) {
						K[i] = (K[i] << 8 | K[i] >>> 24) & 0x00ff00ff | (K[i] << 24 | K[i] >>> 8) & 0xff00ff00;
					}
	
					// Generate initial state values
					var X = this._X = [K[0], K[3] << 16 | K[2] >>> 16, K[1], K[0] << 16 | K[3] >>> 16, K[2], K[1] << 16 | K[0] >>> 16, K[3], K[2] << 16 | K[1] >>> 16];
	
					// Generate initial counter values
					var C = this._C = [K[2] << 16 | K[2] >>> 16, K[0] & 0xffff0000 | K[1] & 0x0000ffff, K[3] << 16 | K[3] >>> 16, K[1] & 0xffff0000 | K[2] & 0x0000ffff, K[0] << 16 | K[0] >>> 16, K[2] & 0xffff0000 | K[3] & 0x0000ffff, K[1] << 16 | K[1] >>> 16, K[3] & 0xffff0000 | K[0] & 0x0000ffff];
	
					// Carry bit
					this._b = 0;
	
					// Iterate the system four times
					for (var i = 0; i < 4; i++) {
						nextState.call(this);
					}
	
					// Modify the counters
					for (var i = 0; i < 8; i++) {
						C[i] ^= X[i + 4 & 7];
					}
	
					// IV setup
					if (iv) {
						// Shortcuts
						var IV = iv.words;
						var IV_0 = IV[0];
						var IV_1 = IV[1];
	
						// Generate four subvectors
						var i0 = (IV_0 << 8 | IV_0 >>> 24) & 0x00ff00ff | (IV_0 << 24 | IV_0 >>> 8) & 0xff00ff00;
						var i2 = (IV_1 << 8 | IV_1 >>> 24) & 0x00ff00ff | (IV_1 << 24 | IV_1 >>> 8) & 0xff00ff00;
						var i1 = i0 >>> 16 | i2 & 0xffff0000;
						var i3 = i2 << 16 | i0 & 0x0000ffff;
	
						// Modify counter values
						C[0] ^= i0;
						C[1] ^= i1;
						C[2] ^= i2;
						C[3] ^= i3;
						C[4] ^= i0;
						C[5] ^= i1;
						C[6] ^= i2;
						C[7] ^= i3;
	
						// Iterate the system four times
						for (var i = 0; i < 4; i++) {
							nextState.call(this);
						}
					}
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcut
					var X = this._X;
	
					// Iterate the system
					nextState.call(this);
	
					// Generate four keystream words
					S[0] = X[0] ^ X[5] >>> 16 ^ X[3] << 16;
					S[1] = X[2] ^ X[7] >>> 16 ^ X[5] << 16;
					S[2] = X[4] ^ X[1] >>> 16 ^ X[7] << 16;
					S[3] = X[6] ^ X[3] >>> 16 ^ X[1] << 16;
	
					for (var i = 0; i < 4; i++) {
						// Swap endian
						S[i] = (S[i] << 8 | S[i] >>> 24) & 0x00ff00ff | (S[i] << 24 | S[i] >>> 8) & 0xff00ff00;
	
						// Encrypt
						M[offset + i] ^= S[i];
					}
				},
	
				blockSize: 128 / 32,
	
				ivSize: 64 / 32
			});
	
			function nextState() {
				// Shortcuts
				var X = this._X;
				var C = this._C;
	
				// Save old counter values
				for (var i = 0; i < 8; i++) {
					C_[i] = C[i];
				}
	
				// Calculate new counter values
				C[0] = C[0] + 0x4d34d34d + this._b | 0;
				C[1] = C[1] + 0xd34d34d3 + (C[0] >>> 0 < C_[0] >>> 0 ? 1 : 0) | 0;
				C[2] = C[2] + 0x34d34d34 + (C[1] >>> 0 < C_[1] >>> 0 ? 1 : 0) | 0;
				C[3] = C[3] + 0x4d34d34d + (C[2] >>> 0 < C_[2] >>> 0 ? 1 : 0) | 0;
				C[4] = C[4] + 0xd34d34d3 + (C[3] >>> 0 < C_[3] >>> 0 ? 1 : 0) | 0;
				C[5] = C[5] + 0x34d34d34 + (C[4] >>> 0 < C_[4] >>> 0 ? 1 : 0) | 0;
				C[6] = C[6] + 0x4d34d34d + (C[5] >>> 0 < C_[5] >>> 0 ? 1 : 0) | 0;
				C[7] = C[7] + 0xd34d34d3 + (C[6] >>> 0 < C_[6] >>> 0 ? 1 : 0) | 0;
				this._b = C[7] >>> 0 < C_[7] >>> 0 ? 1 : 0;
	
				// Calculate the g-values
				for (var i = 0; i < 8; i++) {
					var gx = X[i] + C[i];
	
					// Construct high and low argument for squaring
					var ga = gx & 0xffff;
					var gb = gx >>> 16;
	
					// Calculate high and low result of squaring
					var gh = ((ga * ga >>> 17) + ga * gb >>> 15) + gb * gb;
					var gl = ((gx & 0xffff0000) * gx | 0) + ((gx & 0x0000ffff) * gx | 0);
	
					// High XOR low
					G[i] = gh ^ gl;
				}
	
				// Calculate new state values
				X[0] = G[0] + (G[7] << 16 | G[7] >>> 16) + (G[6] << 16 | G[6] >>> 16) | 0;
				X[1] = G[1] + (G[0] << 8 | G[0] >>> 24) + G[7] | 0;
				X[2] = G[2] + (G[1] << 16 | G[1] >>> 16) + (G[0] << 16 | G[0] >>> 16) | 0;
				X[3] = G[3] + (G[2] << 8 | G[2] >>> 24) + G[1] | 0;
				X[4] = G[4] + (G[3] << 16 | G[3] >>> 16) + (G[2] << 16 | G[2] >>> 16) | 0;
				X[5] = G[5] + (G[4] << 8 | G[4] >>> 24) + G[3] | 0;
				X[6] = G[6] + (G[5] << 16 | G[5] >>> 16) + (G[4] << 16 | G[4] >>> 16) | 0;
				X[7] = G[7] + (G[6] << 8 | G[6] >>> 24) + G[5] | 0;
			}
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.Rabbit.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.Rabbit.decrypt(ciphertext, key, cfg);
	   */
			C.Rabbit = StreamCipher._createHelper(Rabbit);
		})();
	
		return CryptoJS.Rabbit;
	});

/***/ },
/* 47 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;"use strict";
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
	
	;(function (root, factory, undef) {
		if (( false ? "undefined" : _typeof(exports)) === "object") {
			// CommonJS
			module.exports = exports = factory(__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31));
		} else if (true) {
			// AMD
			!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(15), __webpack_require__(19), __webpack_require__(20), __webpack_require__(30), __webpack_require__(31)], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			// Global (browser)
			factory(root.CryptoJS);
		}
	})(undefined, function (CryptoJS) {
	
		(function () {
			// Shortcuts
			var C = CryptoJS;
			var C_lib = C.lib;
			var StreamCipher = C_lib.StreamCipher;
			var C_algo = C.algo;
	
			// Reusable objects
			var S = [];
			var C_ = [];
			var G = [];
	
			/**
	   * Rabbit stream cipher algorithm.
	   *
	   * This is a legacy version that neglected to convert the key to little-endian.
	   * This error doesn't affect the cipher's security,
	   * but it does affect its compatibility with other implementations.
	   */
			var RabbitLegacy = C_algo.RabbitLegacy = StreamCipher.extend({
				_doReset: function _doReset() {
					// Shortcuts
					var K = this._key.words;
					var iv = this.cfg.iv;
	
					// Generate initial state values
					var X = this._X = [K[0], K[3] << 16 | K[2] >>> 16, K[1], K[0] << 16 | K[3] >>> 16, K[2], K[1] << 16 | K[0] >>> 16, K[3], K[2] << 16 | K[1] >>> 16];
	
					// Generate initial counter values
					var C = this._C = [K[2] << 16 | K[2] >>> 16, K[0] & 0xffff0000 | K[1] & 0x0000ffff, K[3] << 16 | K[3] >>> 16, K[1] & 0xffff0000 | K[2] & 0x0000ffff, K[0] << 16 | K[0] >>> 16, K[2] & 0xffff0000 | K[3] & 0x0000ffff, K[1] << 16 | K[1] >>> 16, K[3] & 0xffff0000 | K[0] & 0x0000ffff];
	
					// Carry bit
					this._b = 0;
	
					// Iterate the system four times
					for (var i = 0; i < 4; i++) {
						nextState.call(this);
					}
	
					// Modify the counters
					for (var i = 0; i < 8; i++) {
						C[i] ^= X[i + 4 & 7];
					}
	
					// IV setup
					if (iv) {
						// Shortcuts
						var IV = iv.words;
						var IV_0 = IV[0];
						var IV_1 = IV[1];
	
						// Generate four subvectors
						var i0 = (IV_0 << 8 | IV_0 >>> 24) & 0x00ff00ff | (IV_0 << 24 | IV_0 >>> 8) & 0xff00ff00;
						var i2 = (IV_1 << 8 | IV_1 >>> 24) & 0x00ff00ff | (IV_1 << 24 | IV_1 >>> 8) & 0xff00ff00;
						var i1 = i0 >>> 16 | i2 & 0xffff0000;
						var i3 = i2 << 16 | i0 & 0x0000ffff;
	
						// Modify counter values
						C[0] ^= i0;
						C[1] ^= i1;
						C[2] ^= i2;
						C[3] ^= i3;
						C[4] ^= i0;
						C[5] ^= i1;
						C[6] ^= i2;
						C[7] ^= i3;
	
						// Iterate the system four times
						for (var i = 0; i < 4; i++) {
							nextState.call(this);
						}
					}
				},
	
				_doProcessBlock: function _doProcessBlock(M, offset) {
					// Shortcut
					var X = this._X;
	
					// Iterate the system
					nextState.call(this);
	
					// Generate four keystream words
					S[0] = X[0] ^ X[5] >>> 16 ^ X[3] << 16;
					S[1] = X[2] ^ X[7] >>> 16 ^ X[5] << 16;
					S[2] = X[4] ^ X[1] >>> 16 ^ X[7] << 16;
					S[3] = X[6] ^ X[3] >>> 16 ^ X[1] << 16;
	
					for (var i = 0; i < 4; i++) {
						// Swap endian
						S[i] = (S[i] << 8 | S[i] >>> 24) & 0x00ff00ff | (S[i] << 24 | S[i] >>> 8) & 0xff00ff00;
	
						// Encrypt
						M[offset + i] ^= S[i];
					}
				},
	
				blockSize: 128 / 32,
	
				ivSize: 64 / 32
			});
	
			function nextState() {
				// Shortcuts
				var X = this._X;
				var C = this._C;
	
				// Save old counter values
				for (var i = 0; i < 8; i++) {
					C_[i] = C[i];
				}
	
				// Calculate new counter values
				C[0] = C[0] + 0x4d34d34d + this._b | 0;
				C[1] = C[1] + 0xd34d34d3 + (C[0] >>> 0 < C_[0] >>> 0 ? 1 : 0) | 0;
				C[2] = C[2] + 0x34d34d34 + (C[1] >>> 0 < C_[1] >>> 0 ? 1 : 0) | 0;
				C[3] = C[3] + 0x4d34d34d + (C[2] >>> 0 < C_[2] >>> 0 ? 1 : 0) | 0;
				C[4] = C[4] + 0xd34d34d3 + (C[3] >>> 0 < C_[3] >>> 0 ? 1 : 0) | 0;
				C[5] = C[5] + 0x34d34d34 + (C[4] >>> 0 < C_[4] >>> 0 ? 1 : 0) | 0;
				C[6] = C[6] + 0x4d34d34d + (C[5] >>> 0 < C_[5] >>> 0 ? 1 : 0) | 0;
				C[7] = C[7] + 0xd34d34d3 + (C[6] >>> 0 < C_[6] >>> 0 ? 1 : 0) | 0;
				this._b = C[7] >>> 0 < C_[7] >>> 0 ? 1 : 0;
	
				// Calculate the g-values
				for (var i = 0; i < 8; i++) {
					var gx = X[i] + C[i];
	
					// Construct high and low argument for squaring
					var ga = gx & 0xffff;
					var gb = gx >>> 16;
	
					// Calculate high and low result of squaring
					var gh = ((ga * ga >>> 17) + ga * gb >>> 15) + gb * gb;
					var gl = ((gx & 0xffff0000) * gx | 0) + ((gx & 0x0000ffff) * gx | 0);
	
					// High XOR low
					G[i] = gh ^ gl;
				}
	
				// Calculate new state values
				X[0] = G[0] + (G[7] << 16 | G[7] >>> 16) + (G[6] << 16 | G[6] >>> 16) | 0;
				X[1] = G[1] + (G[0] << 8 | G[0] >>> 24) + G[7] | 0;
				X[2] = G[2] + (G[1] << 16 | G[1] >>> 16) + (G[0] << 16 | G[0] >>> 16) | 0;
				X[3] = G[3] + (G[2] << 8 | G[2] >>> 24) + G[1] | 0;
				X[4] = G[4] + (G[3] << 16 | G[3] >>> 16) + (G[2] << 16 | G[2] >>> 16) | 0;
				X[5] = G[5] + (G[4] << 8 | G[4] >>> 24) + G[3] | 0;
				X[6] = G[6] + (G[5] << 16 | G[5] >>> 16) + (G[4] << 16 | G[4] >>> 16) | 0;
				X[7] = G[7] + (G[6] << 8 | G[6] >>> 24) + G[5] | 0;
			}
	
			/**
	   * Shortcut functions to the cipher's object interface.
	   *
	   * @example
	   *
	   *     var ciphertext = CryptoJS.RabbitLegacy.encrypt(message, key, cfg);
	   *     var plaintext  = CryptoJS.RabbitLegacy.decrypt(ciphertext, key, cfg);
	   */
			C.RabbitLegacy = StreamCipher._createHelper(RabbitLegacy);
		})();
	
		return CryptoJS.RabbitLegacy;
	});

/***/ }
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMjFjODYzZDY3ODI3MzZlYzM1Yzg/ZmIyOSIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaG9tZS5taXg/ZTBkNCIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaG9tZS5taXg/Mjk5OSIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaG9tZS5taXg/NGYyNiIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaG9tZS5taXgiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvY29yZS5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy94NjQtY29yZS5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9saWItdHlwZWRhcnJheXMuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvZW5jLXV0ZjE2LmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL2VuYy1iYXNlNjQuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvbWQ1LmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3NoYTEuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvc2hhMjU2LmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3NoYTIyNC5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9zaGE1MTIuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvc2hhMzg0LmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3NoYTMuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvcmlwZW1kMTYwLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL2htYWMuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvcGJrZGYyLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL2V2cGtkZi5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9jaXBoZXItY29yZS5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9tb2RlLWNmYi5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9tb2RlLWN0ci5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9tb2RlLWN0ci1nbGFkbWFuLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL21vZGUtb2ZiLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL21vZGUtZWNiLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3BhZC1hbnNpeDkyMy5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9wYWQtaXNvMTAxMjYuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvcGFkLWlzbzk3OTcxLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3BhZC16ZXJvcGFkZGluZy5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9wYWQtbm9wYWRkaW5nLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL2Zvcm1hdC1oZXguanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvYWVzLmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3RyaXBsZWRlcy5qcyIsIndlYnBhY2s6Ly8vLi9+L2NyeXB0by1qcy9yYzQuanMiLCJ3ZWJwYWNrOi8vLy4vfi9jcnlwdG8tanMvcmFiYml0LmpzIiwid2VicGFjazovLy8uL34vY3J5cHRvLWpzL3JhYmJpdC1sZWdhY3kuanMiXSwibmFtZXMiOlsicm9vdCIsImZhY3RvcnkiLCJ1bmRlZiIsImV4cG9ydHMiLCJtb2R1bGUiLCJyZXF1aXJlIiwiZGVmaW5lIiwiQ3J5cHRvSlMiLCJNYXRoIiwidW5kZWZpbmVkIiwiY3JlYXRlIiwiT2JqZWN0IiwiRiIsIm9iaiIsInN1YnR5cGUiLCJwcm90b3R5cGUiLCJDIiwiQ19saWIiLCJsaWIiLCJCYXNlIiwiZXh0ZW5kIiwib3ZlcnJpZGVzIiwibWl4SW4iLCJoYXNPd25Qcm9wZXJ0eSIsImluaXQiLCIkc3VwZXIiLCJhcHBseSIsImFyZ3VtZW50cyIsImluc3RhbmNlIiwicHJvcGVydGllcyIsInByb3BlcnR5TmFtZSIsInRvU3RyaW5nIiwiY2xvbmUiLCJXb3JkQXJyYXkiLCJ3b3JkcyIsInNpZ0J5dGVzIiwibGVuZ3RoIiwiZW5jb2RlciIsIkhleCIsInN0cmluZ2lmeSIsImNvbmNhdCIsIndvcmRBcnJheSIsInRoaXNXb3JkcyIsInRoYXRXb3JkcyIsInRoaXNTaWdCeXRlcyIsInRoYXRTaWdCeXRlcyIsImNsYW1wIiwiaSIsInRoYXRCeXRlIiwiY2VpbCIsImNhbGwiLCJzbGljZSIsInJhbmRvbSIsIm5CeXRlcyIsInIiLCJtX3ciLCJtX3oiLCJtYXNrIiwicmVzdWx0IiwicmNhY2hlIiwiX3IiLCJwdXNoIiwiQ19lbmMiLCJlbmMiLCJoZXhDaGFycyIsImJpdGUiLCJqb2luIiwicGFyc2UiLCJoZXhTdHIiLCJoZXhTdHJMZW5ndGgiLCJwYXJzZUludCIsInN1YnN0ciIsIkxhdGluMSIsImxhdGluMUNoYXJzIiwiU3RyaW5nIiwiZnJvbUNoYXJDb2RlIiwibGF0aW4xU3RyIiwibGF0aW4xU3RyTGVuZ3RoIiwiY2hhckNvZGVBdCIsIlV0ZjgiLCJkZWNvZGVVUklDb21wb25lbnQiLCJlc2NhcGUiLCJlIiwiRXJyb3IiLCJ1dGY4U3RyIiwidW5lc2NhcGUiLCJlbmNvZGVVUklDb21wb25lbnQiLCJCdWZmZXJlZEJsb2NrQWxnb3JpdGhtIiwicmVzZXQiLCJfZGF0YSIsIl9uRGF0YUJ5dGVzIiwiX2FwcGVuZCIsImRhdGEiLCJfcHJvY2VzcyIsImRvRmx1c2giLCJkYXRhV29yZHMiLCJkYXRhU2lnQnl0ZXMiLCJibG9ja1NpemUiLCJibG9ja1NpemVCeXRlcyIsIm5CbG9ja3NSZWFkeSIsIm1heCIsIl9taW5CdWZmZXJTaXplIiwibldvcmRzUmVhZHkiLCJuQnl0ZXNSZWFkeSIsIm1pbiIsIm9mZnNldCIsIl9kb1Byb2Nlc3NCbG9jayIsInByb2Nlc3NlZFdvcmRzIiwic3BsaWNlIiwiSGFzaGVyIiwiY2ZnIiwiX2RvUmVzZXQiLCJ1cGRhdGUiLCJtZXNzYWdlVXBkYXRlIiwiZmluYWxpemUiLCJoYXNoIiwiX2RvRmluYWxpemUiLCJfY3JlYXRlSGVscGVyIiwiaGFzaGVyIiwibWVzc2FnZSIsIl9jcmVhdGVIbWFjSGVscGVyIiwia2V5IiwiQ19hbGdvIiwiSE1BQyIsImFsZ28iLCJYMzJXb3JkQXJyYXkiLCJDX3g2NCIsIng2NCIsIlg2NFdvcmQiLCJXb3JkIiwiaGlnaCIsImxvdyIsIlg2NFdvcmRBcnJheSIsInRvWDMyIiwieDY0V29yZHMiLCJ4NjRXb3Jkc0xlbmd0aCIsIngzMldvcmRzIiwieDY0V29yZCIsIndvcmRzTGVuZ3RoIiwiQXJyYXlCdWZmZXIiLCJzdXBlckluaXQiLCJzdWJJbml0IiwidHlwZWRBcnJheSIsIlVpbnQ4QXJyYXkiLCJJbnQ4QXJyYXkiLCJVaW50OENsYW1wZWRBcnJheSIsIkludDE2QXJyYXkiLCJVaW50MTZBcnJheSIsIkludDMyQXJyYXkiLCJVaW50MzJBcnJheSIsIkZsb2F0MzJBcnJheSIsIkZsb2F0NjRBcnJheSIsImJ1ZmZlciIsImJ5dGVPZmZzZXQiLCJieXRlTGVuZ3RoIiwidHlwZWRBcnJheUJ5dGVMZW5ndGgiLCJVdGYxNkJFIiwiVXRmMTYiLCJ1dGYxNkNoYXJzIiwiY29kZVBvaW50IiwidXRmMTZTdHIiLCJ1dGYxNlN0ckxlbmd0aCIsIlV0ZjE2TEUiLCJzd2FwRW5kaWFuIiwid29yZCIsIkJhc2U2NCIsIm1hcCIsIl9tYXAiLCJiYXNlNjRDaGFycyIsImJ5dGUxIiwiYnl0ZTIiLCJieXRlMyIsInRyaXBsZXQiLCJqIiwiY2hhckF0IiwicGFkZGluZ0NoYXIiLCJiYXNlNjRTdHIiLCJiYXNlNjRTdHJMZW5ndGgiLCJyZXZlcnNlTWFwIiwiX3JldmVyc2VNYXAiLCJwYWRkaW5nSW5kZXgiLCJpbmRleE9mIiwicGFyc2VMb29wIiwiYml0czEiLCJiaXRzMiIsIlQiLCJhYnMiLCJzaW4iLCJNRDUiLCJfaGFzaCIsIk0iLCJvZmZzZXRfaSIsIk1fb2Zmc2V0X2kiLCJIIiwiTV9vZmZzZXRfMCIsIk1fb2Zmc2V0XzEiLCJNX29mZnNldF8yIiwiTV9vZmZzZXRfMyIsIk1fb2Zmc2V0XzQiLCJNX29mZnNldF81IiwiTV9vZmZzZXRfNiIsIk1fb2Zmc2V0XzciLCJNX29mZnNldF84IiwiTV9vZmZzZXRfOSIsIk1fb2Zmc2V0XzEwIiwiTV9vZmZzZXRfMTEiLCJNX29mZnNldF8xMiIsIk1fb2Zmc2V0XzEzIiwiTV9vZmZzZXRfMTQiLCJNX29mZnNldF8xNSIsImEiLCJiIiwiYyIsImQiLCJGRiIsIkdHIiwiSEgiLCJJSSIsIm5CaXRzVG90YWwiLCJuQml0c0xlZnQiLCJuQml0c1RvdGFsSCIsImZsb29yIiwibkJpdHNUb3RhbEwiLCJIX2kiLCJ4IiwicyIsInQiLCJuIiwiSG1hY01ENSIsIlciLCJTSEExIiwiSG1hY1NIQTEiLCJLIiwiaXNQcmltZSIsInNxcnROIiwic3FydCIsImZhY3RvciIsImdldEZyYWN0aW9uYWxCaXRzIiwiblByaW1lIiwicG93IiwiU0hBMjU2IiwiZiIsImciLCJoIiwiZ2FtbWEweCIsImdhbW1hMCIsImdhbW1hMXgiLCJnYW1tYTEiLCJjaCIsIm1haiIsInNpZ21hMCIsInNpZ21hMSIsInQxIiwidDIiLCJIbWFjU0hBMjU2IiwiU0hBMjI0IiwiSG1hY1NIQTIyNCIsIlg2NFdvcmRfY3JlYXRlIiwiU0hBNTEyIiwiSDAiLCJIMSIsIkgyIiwiSDMiLCJINCIsIkg1IiwiSDYiLCJINyIsIkgwaCIsIkgwbCIsIkgxaCIsIkgxbCIsIkgyaCIsIkgybCIsIkgzaCIsIkgzbCIsIkg0aCIsIkg0bCIsIkg1aCIsIkg1bCIsIkg2aCIsIkg2bCIsIkg3aCIsIkg3bCIsImFoIiwiYWwiLCJiaCIsImJsIiwiY2wiLCJkaCIsImRsIiwiZWgiLCJlbCIsImZoIiwiZmwiLCJnaCIsImdsIiwiaGgiLCJobCIsIldpIiwiV2loIiwiV2lsIiwiZ2FtbWEweGgiLCJnYW1tYTB4bCIsImdhbW1hMGgiLCJnYW1tYTBsIiwiZ2FtbWExeGgiLCJnYW1tYTF4bCIsImdhbW1hMWgiLCJnYW1tYTFsIiwiV2k3IiwiV2k3aCIsIldpN2wiLCJXaTE2IiwiV2kxNmgiLCJXaTE2bCIsImNoaCIsImNobCIsIm1hamgiLCJtYWpsIiwic2lnbWEwaCIsInNpZ21hMGwiLCJzaWdtYTFoIiwic2lnbWExbCIsIktpIiwiS2loIiwiS2lsIiwidDFsIiwidDFoIiwidDJsIiwidDJoIiwiSG1hY1NIQTUxMiIsIlNIQTM4NCIsIkhtYWNTSEEzODQiLCJSSE9fT0ZGU0VUUyIsIlBJX0lOREVYRVMiLCJST1VORF9DT05TVEFOVFMiLCJ5IiwibmV3WCIsIm5ld1kiLCJMRlNSIiwicm91bmRDb25zdGFudE1zdyIsInJvdW5kQ29uc3RhbnRMc3ciLCJiaXRQb3NpdGlvbiIsIlNIQTMiLCJvdXRwdXRMZW5ndGgiLCJzdGF0ZSIsIl9zdGF0ZSIsIm5CbG9ja1NpemVMYW5lcyIsIk0yaSIsIk0yaTEiLCJsYW5lIiwicm91bmQiLCJ0TXN3IiwidExzdyIsIlR4IiwiVHg0IiwiVHgxIiwiVHgxTXN3IiwiVHgxTHN3IiwibGFuZUluZGV4IiwibGFuZU1zdyIsImxhbmVMc3ciLCJyaG9PZmZzZXQiLCJUUGlMYW5lIiwiVDAiLCJzdGF0ZTAiLCJUTGFuZSIsIlR4MUxhbmUiLCJUeDJMYW5lIiwicm91bmRDb25zdGFudCIsImJsb2NrU2l6ZUJpdHMiLCJvdXRwdXRMZW5ndGhCeXRlcyIsIm91dHB1dExlbmd0aExhbmVzIiwiaGFzaFdvcmRzIiwiSG1hY1NIQTMiLCJfemwiLCJfenIiLCJfc2wiLCJfc3IiLCJfaGwiLCJfaHIiLCJSSVBFTUQxNjAiLCJociIsInpsIiwienIiLCJzbCIsInNyIiwiYXIiLCJiciIsImNyIiwiZHIiLCJlciIsImYxIiwiZjIiLCJmMyIsImY0IiwiZjUiLCJyb3RsIiwieiIsIkhtYWNSSVBFTUQxNjAiLCJfaGFzaGVyIiwiaGFzaGVyQmxvY2tTaXplIiwiaGFzaGVyQmxvY2tTaXplQnl0ZXMiLCJvS2V5IiwiX29LZXkiLCJpS2V5IiwiX2lLZXkiLCJvS2V5V29yZHMiLCJpS2V5V29yZHMiLCJpbm5lckhhc2giLCJobWFjIiwiUEJLREYyIiwia2V5U2l6ZSIsIml0ZXJhdGlvbnMiLCJjb21wdXRlIiwicGFzc3dvcmQiLCJzYWx0IiwiZGVyaXZlZEtleSIsImJsb2NrSW5kZXgiLCJkZXJpdmVkS2V5V29yZHMiLCJibG9ja0luZGV4V29yZHMiLCJibG9jayIsImJsb2NrV29yZHMiLCJibG9ja1dvcmRzTGVuZ3RoIiwiaW50ZXJtZWRpYXRlIiwiaW50ZXJtZWRpYXRlV29yZHMiLCJFdnBLREYiLCJDaXBoZXIiLCJjcmVhdGVFbmNyeXB0b3IiLCJfRU5DX1hGT1JNX01PREUiLCJjcmVhdGVEZWNyeXB0b3IiLCJfREVDX1hGT1JNX01PREUiLCJ4Zm9ybU1vZGUiLCJfeGZvcm1Nb2RlIiwiX2tleSIsInByb2Nlc3MiLCJkYXRhVXBkYXRlIiwiZmluYWxQcm9jZXNzZWREYXRhIiwiaXZTaXplIiwic2VsZWN0Q2lwaGVyU3RyYXRlZ3kiLCJQYXNzd29yZEJhc2VkQ2lwaGVyIiwiU2VyaWFsaXphYmxlQ2lwaGVyIiwiY2lwaGVyIiwiZW5jcnlwdCIsImRlY3J5cHQiLCJjaXBoZXJ0ZXh0IiwiU3RyZWFtQ2lwaGVyIiwiZmluYWxQcm9jZXNzZWRCbG9ja3MiLCJDX21vZGUiLCJtb2RlIiwiQmxvY2tDaXBoZXJNb2RlIiwiaXYiLCJFbmNyeXB0b3IiLCJEZWNyeXB0b3IiLCJfY2lwaGVyIiwiX2l2IiwiQ0JDIiwicHJvY2Vzc0Jsb2NrIiwieG9yQmxvY2siLCJlbmNyeXB0QmxvY2siLCJfcHJldkJsb2NrIiwidGhpc0Jsb2NrIiwiZGVjcnlwdEJsb2NrIiwiQ19wYWQiLCJwYWQiLCJQa2NzNyIsIm5QYWRkaW5nQnl0ZXMiLCJwYWRkaW5nV29yZCIsInBhZGRpbmdXb3JkcyIsInBhZGRpbmciLCJ1bnBhZCIsIkJsb2NrQ2lwaGVyIiwibW9kZUNyZWF0b3IiLCJfbW9kZSIsIl9fY3JlYXRvciIsIkNpcGhlclBhcmFtcyIsImNpcGhlclBhcmFtcyIsImZvcm1hdHRlciIsIkNfZm9ybWF0IiwiZm9ybWF0IiwiT3BlblNTTEZvcm1hdHRlciIsIk9wZW5TU0wiLCJvcGVuU1NMU3RyIiwiY2lwaGVydGV4dFdvcmRzIiwiZW5jcnlwdG9yIiwiY2lwaGVyQ2ZnIiwiYWxnb3JpdGhtIiwiX3BhcnNlIiwicGxhaW50ZXh0IiwiQ19rZGYiLCJrZGYiLCJPcGVuU1NMS2RmIiwiZXhlY3V0ZSIsImRlcml2ZWRQYXJhbXMiLCJDRkIiLCJnZW5lcmF0ZUtleXN0cmVhbUFuZEVuY3J5cHQiLCJrZXlzdHJlYW0iLCJDVFIiLCJjb3VudGVyIiwiX2NvdW50ZXIiLCJDVFJHbGFkbWFuIiwiaW5jV29yZCIsImIxIiwiYjIiLCJiMyIsImluY0NvdW50ZXIiLCJPRkIiLCJfa2V5c3RyZWFtIiwiRUNCIiwiQW5zaVg5MjMiLCJsYXN0Qnl0ZVBvcyIsIkFuc2l4OTIzIiwiSXNvMTAxMjYiLCJJc285Nzk3MSIsIlplcm9QYWRkaW5nIiwiTm9QYWRkaW5nIiwiSGV4Rm9ybWF0dGVyIiwiaW5wdXQiLCJTQk9YIiwiSU5WX1NCT1giLCJTVUJfTUlYXzAiLCJTVUJfTUlYXzEiLCJTVUJfTUlYXzIiLCJTVUJfTUlYXzMiLCJJTlZfU1VCX01JWF8wIiwiSU5WX1NVQl9NSVhfMSIsIklOVl9TVUJfTUlYXzIiLCJJTlZfU1VCX01JWF8zIiwieGkiLCJzeCIsIngyIiwieDQiLCJ4OCIsIlJDT04iLCJBRVMiLCJfblJvdW5kcyIsIl9rZXlQcmlvclJlc2V0Iiwia2V5V29yZHMiLCJuUm91bmRzIiwia3NSb3dzIiwia2V5U2NoZWR1bGUiLCJfa2V5U2NoZWR1bGUiLCJrc1JvdyIsImludktleVNjaGVkdWxlIiwiX2ludktleVNjaGVkdWxlIiwiaW52S3NSb3ciLCJfZG9DcnlwdEJsb2NrIiwiczAiLCJzMSIsInMyIiwiczMiLCJ0MCIsInQzIiwiUEMxIiwiUEMyIiwiQklUX1NISUZUUyIsIlNCT1hfUCIsIlNCT1hfTUFTSyIsIkRFUyIsImtleUJpdHMiLCJrZXlCaXRQb3MiLCJzdWJLZXlzIiwiX3N1YktleXMiLCJuU3ViS2V5Iiwic3ViS2V5IiwiYml0U2hpZnQiLCJpbnZTdWJLZXlzIiwiX2ludlN1YktleXMiLCJfbEJsb2NrIiwiX3JCbG9jayIsImV4Y2hhbmdlTFIiLCJleGNoYW5nZVJMIiwibEJsb2NrIiwickJsb2NrIiwiVHJpcGxlREVTIiwiX2RlczEiLCJfZGVzMiIsIl9kZXMzIiwiUkM0Iiwia2V5U2lnQnl0ZXMiLCJTIiwiX1MiLCJrZXlCeXRlSW5kZXgiLCJrZXlCeXRlIiwiX2kiLCJfaiIsImdlbmVyYXRlS2V5c3RyZWFtV29yZCIsImtleXN0cmVhbVdvcmQiLCJSQzREcm9wIiwiZHJvcCIsIkNfIiwiRyIsIlJhYmJpdCIsIlgiLCJfWCIsIl9DIiwiX2IiLCJuZXh0U3RhdGUiLCJJViIsIklWXzAiLCJJVl8xIiwiaTAiLCJpMiIsImkxIiwiaTMiLCJneCIsImdhIiwiZ2IiLCJSYWJiaXRMZWdhY3kiXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1QkFBZTtBQUNmO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7O0FDdENBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBQzs7QUFFRCw0Q0FBMkMsMEJBQTBCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNkckU7QUFDQTtBQUNBLGFBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7QUNTQSxvQ0FFQTs7OztXQUdBO1dBQ0E7VUFFQTtBQUpBOztBQUtBOzs0QkFDQTtvQkFDQTtxRkFDQTtRQUVBO0FBQ0E7dUNBQ0E7WUFDQTtBQUNBOzJCQUNBO29CQUNBO0FBQ0E7QUFsQkEsSTs7Ozs7Ozs7OztBQ3pDQSxFQUFFLFdBQVVBLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsRUFBa0QsbUJBQUFBLENBQVEsRUFBUixDQUFsRCxFQUFnRixtQkFBQUEsQ0FBUSxFQUFSLENBQWhGLEVBQXdHLG1CQUFBQSxDQUFRLEVBQVIsQ0FBeEcsRUFBaUksbUJBQUFBLENBQVEsRUFBUixDQUFqSSxFQUFtSixtQkFBQUEsQ0FBUSxFQUFSLENBQW5KLEVBQXNLLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdEssRUFBMkwsbUJBQUFBLENBQVEsRUFBUixDQUEzTCxFQUFnTixtQkFBQUEsQ0FBUSxFQUFSLENBQWhOLEVBQXFPLG1CQUFBQSxDQUFRLEVBQVIsQ0FBck8sRUFBMFAsbUJBQUFBLENBQVEsRUFBUixDQUExUCxFQUE2USxtQkFBQUEsQ0FBUSxFQUFSLENBQTdRLEVBQXFTLG1CQUFBQSxDQUFRLEVBQVIsQ0FBclMsRUFBd1QsbUJBQUFBLENBQVEsRUFBUixDQUF4VCxFQUE2VSxtQkFBQUEsQ0FBUSxFQUFSLENBQTdVLEVBQWtXLG1CQUFBQSxDQUFRLEVBQVIsQ0FBbFcsRUFBNFgsbUJBQUFBLENBQVEsRUFBUixDQUE1WCxFQUFtWixtQkFBQUEsQ0FBUSxFQUFSLENBQW5aLEVBQTBhLG1CQUFBQSxDQUFRLEVBQVIsQ0FBMWEsRUFBeWMsbUJBQUFBLENBQVEsRUFBUixDQUF6YyxFQUFnZSxtQkFBQUEsQ0FBUSxFQUFSLENBQWhlLEVBQXVmLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdmYsRUFBa2hCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBbGhCLEVBQTZpQixtQkFBQUEsQ0FBUSxFQUFSLENBQTdpQixFQUF3a0IsbUJBQUFBLENBQVEsRUFBUixDQUF4a0IsRUFBc21CLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdG1CLEVBQWtvQixtQkFBQUEsQ0FBUSxFQUFSLENBQWxvQixFQUEycEIsbUJBQUFBLENBQVEsRUFBUixDQUEzcEIsRUFBNnFCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBN3FCLEVBQXFzQixtQkFBQUEsQ0FBUSxFQUFSLENBQXJzQixFQUF1dEIsbUJBQUFBLENBQVEsRUFBUixDQUF2dEIsRUFBNHVCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBNXVCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxFQUF5Qix1QkFBekIsRUFBOEMsdUJBQTlDLEVBQTZELHVCQUE3RCxFQUE2RSx1QkFBN0UsRUFBc0YsdUJBQXRGLEVBQWdHLHVCQUFoRyxFQUE0Ryx1QkFBNUcsRUFBd0gsdUJBQXhILEVBQW9JLHVCQUFwSSxFQUFnSix1QkFBaEosRUFBMEosdUJBQTFKLEVBQXlLLHVCQUF6SyxFQUFtTCx1QkFBbkwsRUFBK0wsdUJBQS9MLEVBQTJNLHVCQUEzTSxFQUE0Tix1QkFBNU4sRUFBME8sdUJBQTFPLEVBQXdQLHVCQUF4UCxFQUE4USx1QkFBOVEsRUFBNFIsdUJBQTVSLEVBQTBTLHVCQUExUyxFQUE0VCx1QkFBNVQsRUFBOFUsdUJBQTlVLEVBQWdXLHVCQUFoVyxFQUFxWCx1QkFBclgsRUFBd1ksdUJBQXhZLEVBQXdaLHVCQUF4WixFQUFpYSx1QkFBamEsRUFBZ2IsdUJBQWhiLEVBQXliLHVCQUF6YixFQUFxYyx1QkFBcmMsQ0FBUCxvQ0FBZ2VMLE9BQWhlO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUQsUUFBS08sUUFBTCxHQUFnQk4sUUFBUUQsS0FBS08sUUFBYixDQUFoQjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTNCLFNBQU9BLFFBQVA7QUFFQSxFQWpCQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVVQLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCO0FBQzFCLE1BQUksZ0NBQU9FLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsU0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FLLEdBQUEsaUNBQU8sRUFBUCxvQ0FBV0wsT0FBWDtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FELFFBQUtPLFFBQUwsR0FBZ0JOLFNBQWhCO0FBQ0E7QUFDRCxFQWJDLGFBYU0sWUFBWTs7QUFFbkI7OztBQUdBLE1BQUlNLFdBQVdBLFlBQWEsVUFBVUMsSUFBVixFQUFnQkMsU0FBaEIsRUFBMkI7QUFDbkQ7OztBQUdBLE9BQUlDLFNBQVNDLE9BQU9ELE1BQVAsSUFBa0IsWUFBWTtBQUN2QyxhQUFTRSxDQUFULEdBQWEsQ0FBRTs7QUFFZixXQUFPLFVBQVVDLEdBQVYsRUFBZTtBQUNsQixTQUFJQyxPQUFKOztBQUVBRixPQUFFRyxTQUFGLEdBQWNGLEdBQWQ7O0FBRUFDLGVBQVUsSUFBSUYsQ0FBSixFQUFWOztBQUVBQSxPQUFFRyxTQUFGLEdBQWMsSUFBZDs7QUFFQSxZQUFPRCxPQUFQO0FBQ0gsS0FWRDtBQVdILElBZDhCLEVBQS9COztBQWdCQTs7O0FBR0EsT0FBSUUsSUFBSSxFQUFSOztBQUVBOzs7QUFHQSxPQUFJQyxRQUFRRCxFQUFFRSxHQUFGLEdBQVEsRUFBcEI7O0FBRUE7OztBQUdBLE9BQUlDLE9BQU9GLE1BQU1FLElBQU4sR0FBYyxZQUFZOztBQUdqQyxXQUFPO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQUMsYUFBUSxnQkFBVUMsU0FBVixFQUFxQjtBQUN6QjtBQUNBLFVBQUlQLFVBQVVKLE9BQU8sSUFBUCxDQUFkOztBQUVBO0FBQ0EsVUFBSVcsU0FBSixFQUFlO0FBQ1hQLGVBQVFRLEtBQVIsQ0FBY0QsU0FBZDtBQUNIOztBQUVEO0FBQ0EsVUFBSSxDQUFDUCxRQUFRUyxjQUFSLENBQXVCLE1BQXZCLENBQUQsSUFBbUMsS0FBS0MsSUFBTCxLQUFjVixRQUFRVSxJQUE3RCxFQUFtRTtBQUMvRFYsZUFBUVUsSUFBUixHQUFlLFlBQVk7QUFDdkJWLGdCQUFRVyxNQUFSLENBQWVELElBQWYsQ0FBb0JFLEtBQXBCLENBQTBCLElBQTFCLEVBQWdDQyxTQUFoQztBQUNILFFBRkQ7QUFHSDs7QUFFRDtBQUNBYixjQUFRVSxJQUFSLENBQWFULFNBQWIsR0FBeUJELE9BQXpCOztBQUVBO0FBQ0FBLGNBQVFXLE1BQVIsR0FBaUIsSUFBakI7O0FBRUEsYUFBT1gsT0FBUDtBQUNILE1BMUNFOztBQTRDSDs7Ozs7Ozs7Ozs7O0FBWUFKLGFBQVEsa0JBQVk7QUFDaEIsVUFBSWtCLFdBQVcsS0FBS1IsTUFBTCxFQUFmO0FBQ0FRLGVBQVNKLElBQVQsQ0FBY0UsS0FBZCxDQUFvQkUsUUFBcEIsRUFBOEJELFNBQTlCOztBQUVBLGFBQU9DLFFBQVA7QUFDSCxNQTdERTs7QUErREg7Ozs7Ozs7Ozs7OztBQVlBSixXQUFNLGdCQUFZLENBQ2pCLENBNUVFOztBQThFSDs7Ozs7Ozs7Ozs7QUFXQUYsWUFBTyxlQUFVTyxVQUFWLEVBQXNCO0FBQ3pCLFdBQUssSUFBSUMsWUFBVCxJQUF5QkQsVUFBekIsRUFBcUM7QUFDakMsV0FBSUEsV0FBV04sY0FBWCxDQUEwQk8sWUFBMUIsQ0FBSixFQUE2QztBQUN6QyxhQUFLQSxZQUFMLElBQXFCRCxXQUFXQyxZQUFYLENBQXJCO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFVBQUlELFdBQVdOLGNBQVgsQ0FBMEIsVUFBMUIsQ0FBSixFQUEyQztBQUN2QyxZQUFLUSxRQUFMLEdBQWdCRixXQUFXRSxRQUEzQjtBQUNIO0FBQ0osTUFwR0U7O0FBc0dIOzs7Ozs7Ozs7QUFTQUMsWUFBTyxpQkFBWTtBQUNmLGFBQU8sS0FBS1IsSUFBTCxDQUFVVCxTQUFWLENBQW9CSyxNQUFwQixDQUEyQixJQUEzQixDQUFQO0FBQ0g7QUFqSEUsS0FBUDtBQW1ISCxJQXRId0IsRUFBekI7O0FBd0hBOzs7Ozs7QUFNQSxPQUFJYSxZQUFZaEIsTUFBTWdCLFNBQU4sR0FBa0JkLEtBQUtDLE1BQUwsQ0FBWTtBQUMxQzs7Ozs7Ozs7Ozs7O0FBWUFJLFVBQU0sY0FBVVUsS0FBVixFQUFpQkMsUUFBakIsRUFBMkI7QUFDN0JELGFBQVEsS0FBS0EsS0FBTCxHQUFhQSxTQUFTLEVBQTlCOztBQUVBLFNBQUlDLFlBQVkxQixTQUFoQixFQUEyQjtBQUN2QixXQUFLMEIsUUFBTCxHQUFnQkEsUUFBaEI7QUFDSCxNQUZELE1BRU87QUFDSCxXQUFLQSxRQUFMLEdBQWdCRCxNQUFNRSxNQUFOLEdBQWUsQ0FBL0I7QUFDSDtBQUNKLEtBckJ5Qzs7QUF1QjFDOzs7Ozs7Ozs7Ozs7O0FBYUFMLGNBQVUsa0JBQVVNLE9BQVYsRUFBbUI7QUFDekIsWUFBTyxDQUFDQSxXQUFXQyxHQUFaLEVBQWlCQyxTQUFqQixDQUEyQixJQUEzQixDQUFQO0FBQ0gsS0F0Q3lDOztBQXdDMUM7Ozs7Ozs7Ozs7O0FBV0FDLFlBQVEsZ0JBQVVDLFNBQVYsRUFBcUI7QUFDekI7QUFDQSxTQUFJQyxZQUFZLEtBQUtSLEtBQXJCO0FBQ0EsU0FBSVMsWUFBWUYsVUFBVVAsS0FBMUI7QUFDQSxTQUFJVSxlQUFlLEtBQUtULFFBQXhCO0FBQ0EsU0FBSVUsZUFBZUosVUFBVU4sUUFBN0I7O0FBRUE7QUFDQSxVQUFLVyxLQUFMOztBQUVBO0FBQ0EsU0FBSUYsZUFBZSxDQUFuQixFQUFzQjtBQUNsQjtBQUNBLFdBQUssSUFBSUcsSUFBSSxDQUFiLEVBQWdCQSxJQUFJRixZQUFwQixFQUFrQ0UsR0FBbEMsRUFBdUM7QUFDbkMsV0FBSUMsV0FBWUwsVUFBVUksTUFBTSxDQUFoQixNQUF3QixLQUFNQSxJQUFJLENBQUwsR0FBVSxDQUF4QyxHQUE4QyxJQUE3RDtBQUNBTCxpQkFBV0UsZUFBZUcsQ0FBaEIsS0FBdUIsQ0FBakMsS0FBdUNDLFlBQWEsS0FBTSxDQUFDSixlQUFlRyxDQUFoQixJQUFxQixDQUF0QixHQUEyQixDQUFwRjtBQUNIO0FBQ0osTUFORCxNQU1PO0FBQ0g7QUFDQSxXQUFLLElBQUlBLElBQUksQ0FBYixFQUFnQkEsSUFBSUYsWUFBcEIsRUFBa0NFLEtBQUssQ0FBdkMsRUFBMEM7QUFDdENMLGlCQUFXRSxlQUFlRyxDQUFoQixLQUF1QixDQUFqQyxJQUFzQ0osVUFBVUksTUFBTSxDQUFoQixDQUF0QztBQUNIO0FBQ0o7QUFDRCxVQUFLWixRQUFMLElBQWlCVSxZQUFqQjs7QUFFQTtBQUNBLFlBQU8sSUFBUDtBQUNILEtBOUV5Qzs7QUFnRjFDOzs7Ozs7O0FBT0FDLFdBQU8saUJBQVk7QUFDZjtBQUNBLFNBQUlaLFFBQVEsS0FBS0EsS0FBakI7QUFDQSxTQUFJQyxXQUFXLEtBQUtBLFFBQXBCOztBQUVBO0FBQ0FELFdBQU1DLGFBQWEsQ0FBbkIsS0FBeUIsY0FBZSxLQUFNQSxXQUFXLENBQVosR0FBaUIsQ0FBOUQ7QUFDQUQsV0FBTUUsTUFBTixHQUFlNUIsS0FBS3lDLElBQUwsQ0FBVWQsV0FBVyxDQUFyQixDQUFmO0FBQ0gsS0EvRnlDOztBQWlHMUM7Ozs7Ozs7OztBQVNBSCxXQUFPLGlCQUFZO0FBQ2YsU0FBSUEsUUFBUWIsS0FBS2EsS0FBTCxDQUFXa0IsSUFBWCxDQUFnQixJQUFoQixDQUFaO0FBQ0FsQixXQUFNRSxLQUFOLEdBQWMsS0FBS0EsS0FBTCxDQUFXaUIsS0FBWCxDQUFpQixDQUFqQixDQUFkOztBQUVBLFlBQU9uQixLQUFQO0FBQ0gsS0EvR3lDOztBQWlIMUM7Ozs7Ozs7Ozs7Ozs7QUFhQW9CLFlBQVEsZ0JBQVVDLE1BQVYsRUFBa0I7QUFDdEIsU0FBSW5CLFFBQVEsRUFBWjs7QUFFQSxTQUFJb0IsSUFBSyxTQUFMQSxDQUFLLENBQVVDLEdBQVYsRUFBZTtBQUNwQixVQUFJQSxNQUFNQSxHQUFWO0FBQ0EsVUFBSUMsTUFBTSxVQUFWO0FBQ0EsVUFBSUMsT0FBTyxVQUFYOztBQUVBLGFBQU8sWUFBWTtBQUNmRCxhQUFPLFVBQVVBLE1BQU0sTUFBaEIsS0FBMkJBLE9BQU8sSUFBbEMsQ0FBRCxHQUE0Q0MsSUFBbEQ7QUFDQUYsYUFBTyxVQUFVQSxNQUFNLE1BQWhCLEtBQTJCQSxPQUFPLElBQWxDLENBQUQsR0FBNENFLElBQWxEO0FBQ0EsV0FBSUMsU0FBVSxDQUFDRixPQUFPLElBQVIsSUFBZ0JELEdBQWpCLEdBQXdCRSxJQUFyQztBQUNBQyxpQkFBVSxXQUFWO0FBQ0FBLGlCQUFVLEdBQVY7QUFDQSxjQUFPQSxVQUFVbEQsS0FBSzRDLE1BQUwsS0FBZ0IsRUFBaEIsR0FBcUIsQ0FBckIsR0FBeUIsQ0FBQyxDQUFwQyxDQUFQO0FBQ0gsT0FQRDtBQVFILE1BYkQ7O0FBZUEsVUFBSyxJQUFJTCxJQUFJLENBQVIsRUFBV1ksTUFBaEIsRUFBd0JaLElBQUlNLE1BQTVCLEVBQW9DTixLQUFLLENBQXpDLEVBQTRDO0FBQ3hDLFVBQUlhLEtBQUtOLEVBQUUsQ0FBQ0ssVUFBVW5ELEtBQUs0QyxNQUFMLEVBQVgsSUFBNEIsV0FBOUIsQ0FBVDs7QUFFQU8sZUFBU0MsT0FBTyxVQUFoQjtBQUNBMUIsWUFBTTJCLElBQU4sQ0FBWUQsT0FBTyxXQUFSLEdBQXVCLENBQWxDO0FBQ0g7O0FBRUQsWUFBTyxJQUFJM0IsVUFBVVQsSUFBZCxDQUFtQlUsS0FBbkIsRUFBMEJtQixNQUExQixDQUFQO0FBQ0g7QUF4SnlDLElBQVosQ0FBbEM7O0FBMkpBOzs7QUFHQSxPQUFJUyxRQUFROUMsRUFBRStDLEdBQUYsR0FBUSxFQUFwQjs7QUFFQTs7O0FBR0EsT0FBSXpCLE1BQU13QixNQUFNeEIsR0FBTixHQUFZO0FBQ2xCOzs7Ozs7Ozs7Ozs7O0FBYUFDLGVBQVcsbUJBQVVFLFNBQVYsRUFBcUI7QUFDNUI7QUFDQSxTQUFJUCxRQUFRTyxVQUFVUCxLQUF0QjtBQUNBLFNBQUlDLFdBQVdNLFVBQVVOLFFBQXpCOztBQUVBO0FBQ0EsU0FBSTZCLFdBQVcsRUFBZjtBQUNBLFVBQUssSUFBSWpCLElBQUksQ0FBYixFQUFnQkEsSUFBSVosUUFBcEIsRUFBOEJZLEdBQTlCLEVBQW1DO0FBQy9CLFVBQUlrQixPQUFRL0IsTUFBTWEsTUFBTSxDQUFaLE1BQW9CLEtBQU1BLElBQUksQ0FBTCxHQUFVLENBQXBDLEdBQTBDLElBQXJEO0FBQ0FpQixlQUFTSCxJQUFULENBQWMsQ0FBQ0ksU0FBUyxDQUFWLEVBQWFsQyxRQUFiLENBQXNCLEVBQXRCLENBQWQ7QUFDQWlDLGVBQVNILElBQVQsQ0FBYyxDQUFDSSxPQUFPLElBQVIsRUFBY2xDLFFBQWQsQ0FBdUIsRUFBdkIsQ0FBZDtBQUNIOztBQUVELFlBQU9pQyxTQUFTRSxJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0gsS0E1QmlCOztBQThCbEI7Ozs7Ozs7Ozs7Ozs7QUFhQUMsV0FBTyxlQUFVQyxNQUFWLEVBQWtCO0FBQ3JCO0FBQ0EsU0FBSUMsZUFBZUQsT0FBT2hDLE1BQTFCOztBQUVBO0FBQ0EsU0FBSUYsUUFBUSxFQUFaO0FBQ0EsVUFBSyxJQUFJYSxJQUFJLENBQWIsRUFBZ0JBLElBQUlzQixZQUFwQixFQUFrQ3RCLEtBQUssQ0FBdkMsRUFBMEM7QUFDdENiLFlBQU1hLE1BQU0sQ0FBWixLQUFrQnVCLFNBQVNGLE9BQU9HLE1BQVAsQ0FBY3hCLENBQWQsRUFBaUIsQ0FBakIsQ0FBVCxFQUE4QixFQUE5QixLQUFzQyxLQUFNQSxJQUFJLENBQUwsR0FBVSxDQUF2RTtBQUNIOztBQUVELFlBQU8sSUFBSWQsVUFBVVQsSUFBZCxDQUFtQlUsS0FBbkIsRUFBMEJtQyxlQUFlLENBQXpDLENBQVA7QUFDSDtBQXREaUIsSUFBdEI7O0FBeURBOzs7QUFHQSxPQUFJRyxTQUFTVixNQUFNVSxNQUFOLEdBQWU7QUFDeEI7Ozs7Ozs7Ozs7Ozs7QUFhQWpDLGVBQVcsbUJBQVVFLFNBQVYsRUFBcUI7QUFDNUI7QUFDQSxTQUFJUCxRQUFRTyxVQUFVUCxLQUF0QjtBQUNBLFNBQUlDLFdBQVdNLFVBQVVOLFFBQXpCOztBQUVBO0FBQ0EsU0FBSXNDLGNBQWMsRUFBbEI7QUFDQSxVQUFLLElBQUkxQixJQUFJLENBQWIsRUFBZ0JBLElBQUlaLFFBQXBCLEVBQThCWSxHQUE5QixFQUFtQztBQUMvQixVQUFJa0IsT0FBUS9CLE1BQU1hLE1BQU0sQ0FBWixNQUFvQixLQUFNQSxJQUFJLENBQUwsR0FBVSxDQUFwQyxHQUEwQyxJQUFyRDtBQUNBMEIsa0JBQVlaLElBQVosQ0FBaUJhLE9BQU9DLFlBQVAsQ0FBb0JWLElBQXBCLENBQWpCO0FBQ0g7O0FBRUQsWUFBT1EsWUFBWVAsSUFBWixDQUFpQixFQUFqQixDQUFQO0FBQ0gsS0EzQnVCOztBQTZCeEI7Ozs7Ozs7Ozs7Ozs7QUFhQUMsV0FBTyxlQUFVUyxTQUFWLEVBQXFCO0FBQ3hCO0FBQ0EsU0FBSUMsa0JBQWtCRCxVQUFVeEMsTUFBaEM7O0FBRUE7QUFDQSxTQUFJRixRQUFRLEVBQVo7QUFDQSxVQUFLLElBQUlhLElBQUksQ0FBYixFQUFnQkEsSUFBSThCLGVBQXBCLEVBQXFDOUIsR0FBckMsRUFBMEM7QUFDdENiLFlBQU1hLE1BQU0sQ0FBWixLQUFrQixDQUFDNkIsVUFBVUUsVUFBVixDQUFxQi9CLENBQXJCLElBQTBCLElBQTNCLEtBQXFDLEtBQU1BLElBQUksQ0FBTCxHQUFVLENBQXRFO0FBQ0g7O0FBRUQsWUFBTyxJQUFJZCxVQUFVVCxJQUFkLENBQW1CVSxLQUFuQixFQUEwQjJDLGVBQTFCLENBQVA7QUFDSDtBQXJEdUIsSUFBNUI7O0FBd0RBOzs7QUFHQSxPQUFJRSxPQUFPakIsTUFBTWlCLElBQU4sR0FBYTtBQUNwQjs7Ozs7Ozs7Ozs7OztBQWFBeEMsZUFBVyxtQkFBVUUsU0FBVixFQUFxQjtBQUM1QixTQUFJO0FBQ0EsYUFBT3VDLG1CQUFtQkMsT0FBT1QsT0FBT2pDLFNBQVAsQ0FBaUJFLFNBQWpCLENBQVAsQ0FBbkIsQ0FBUDtBQUNILE1BRkQsQ0FFRSxPQUFPeUMsQ0FBUCxFQUFVO0FBQ1IsWUFBTSxJQUFJQyxLQUFKLENBQVUsc0JBQVYsQ0FBTjtBQUNIO0FBQ0osS0FwQm1COztBQXNCcEI7Ozs7Ozs7Ozs7Ozs7QUFhQWhCLFdBQU8sZUFBVWlCLE9BQVYsRUFBbUI7QUFDdEIsWUFBT1osT0FBT0wsS0FBUCxDQUFha0IsU0FBU0MsbUJBQW1CRixPQUFuQixDQUFULENBQWIsQ0FBUDtBQUNIO0FBckNtQixJQUF4Qjs7QUF3Q0E7Ozs7Ozs7QUFPQSxPQUFJRyx5QkFBeUJ0RSxNQUFNc0Usc0JBQU4sR0FBK0JwRSxLQUFLQyxNQUFMLENBQVk7QUFDcEU7Ozs7Ozs7QUFPQW9FLFdBQU8saUJBQVk7QUFDZjtBQUNBLFVBQUtDLEtBQUwsR0FBYSxJQUFJeEQsVUFBVVQsSUFBZCxFQUFiO0FBQ0EsVUFBS2tFLFdBQUwsR0FBbUIsQ0FBbkI7QUFDSCxLQVptRTs7QUFjcEU7Ozs7Ozs7Ozs7QUFVQUMsYUFBUyxpQkFBVUMsSUFBVixFQUFnQjtBQUNyQjtBQUNBLFNBQUksT0FBT0EsSUFBUCxJQUFlLFFBQW5CLEVBQTZCO0FBQ3pCQSxhQUFPYixLQUFLWixLQUFMLENBQVd5QixJQUFYLENBQVA7QUFDSDs7QUFFRDtBQUNBLFVBQUtILEtBQUwsQ0FBV2pELE1BQVgsQ0FBa0JvRCxJQUFsQjtBQUNBLFVBQUtGLFdBQUwsSUFBb0JFLEtBQUt6RCxRQUF6QjtBQUNILEtBakNtRTs7QUFtQ3BFOzs7Ozs7Ozs7Ozs7OztBQWNBMEQsY0FBVSxrQkFBVUMsT0FBVixFQUFtQjtBQUN6QjtBQUNBLFNBQUlGLE9BQU8sS0FBS0gsS0FBaEI7QUFDQSxTQUFJTSxZQUFZSCxLQUFLMUQsS0FBckI7QUFDQSxTQUFJOEQsZUFBZUosS0FBS3pELFFBQXhCO0FBQ0EsU0FBSThELFlBQVksS0FBS0EsU0FBckI7QUFDQSxTQUFJQyxpQkFBaUJELFlBQVksQ0FBakM7O0FBRUE7QUFDQSxTQUFJRSxlQUFlSCxlQUFlRSxjQUFsQztBQUNBLFNBQUlKLE9BQUosRUFBYTtBQUNUO0FBQ0FLLHFCQUFlM0YsS0FBS3lDLElBQUwsQ0FBVWtELFlBQVYsQ0FBZjtBQUNILE1BSEQsTUFHTztBQUNIO0FBQ0E7QUFDQUEscUJBQWUzRixLQUFLNEYsR0FBTCxDQUFTLENBQUNELGVBQWUsQ0FBaEIsSUFBcUIsS0FBS0UsY0FBbkMsRUFBbUQsQ0FBbkQsQ0FBZjtBQUNIOztBQUVEO0FBQ0EsU0FBSUMsY0FBY0gsZUFBZUYsU0FBakM7O0FBRUE7QUFDQSxTQUFJTSxjQUFjL0YsS0FBS2dHLEdBQUwsQ0FBU0YsY0FBYyxDQUF2QixFQUEwQk4sWUFBMUIsQ0FBbEI7O0FBRUE7QUFDQSxTQUFJTSxXQUFKLEVBQWlCO0FBQ2IsV0FBSyxJQUFJRyxTQUFTLENBQWxCLEVBQXFCQSxTQUFTSCxXQUE5QixFQUEyQ0csVUFBVVIsU0FBckQsRUFBZ0U7QUFDNUQ7QUFDQSxZQUFLUyxlQUFMLENBQXFCWCxTQUFyQixFQUFnQ1UsTUFBaEM7QUFDSDs7QUFFRDtBQUNBLFVBQUlFLGlCQUFpQlosVUFBVWEsTUFBVixDQUFpQixDQUFqQixFQUFvQk4sV0FBcEIsQ0FBckI7QUFDQVYsV0FBS3pELFFBQUwsSUFBaUJvRSxXQUFqQjtBQUNIOztBQUVEO0FBQ0EsWUFBTyxJQUFJdEUsVUFBVVQsSUFBZCxDQUFtQm1GLGNBQW5CLEVBQW1DSixXQUFuQyxDQUFQO0FBQ0gsS0F4Rm1FOztBQTBGcEU7Ozs7Ozs7OztBQVNBdkUsV0FBTyxpQkFBWTtBQUNmLFNBQUlBLFFBQVFiLEtBQUthLEtBQUwsQ0FBV2tCLElBQVgsQ0FBZ0IsSUFBaEIsQ0FBWjtBQUNBbEIsV0FBTXlELEtBQU4sR0FBYyxLQUFLQSxLQUFMLENBQVd6RCxLQUFYLEVBQWQ7O0FBRUEsWUFBT0EsS0FBUDtBQUNILEtBeEdtRTs7QUEwR3BFcUUsb0JBQWdCO0FBMUdvRCxJQUFaLENBQTVEOztBQTZHQTs7Ozs7QUFLQSxPQUFJUSxTQUFTNUYsTUFBTTRGLE1BQU4sR0FBZXRCLHVCQUF1Qm5FLE1BQXZCLENBQThCO0FBQ3REOzs7QUFHQTBGLFNBQUszRixLQUFLQyxNQUFMLEVBSmlEOztBQU10RDs7Ozs7Ozs7O0FBU0FJLFVBQU0sY0FBVXNGLEdBQVYsRUFBZTtBQUNqQjtBQUNBLFVBQUtBLEdBQUwsR0FBVyxLQUFLQSxHQUFMLENBQVMxRixNQUFULENBQWdCMEYsR0FBaEIsQ0FBWDs7QUFFQTtBQUNBLFVBQUt0QixLQUFMO0FBQ0gsS0FyQnFEOztBQXVCdEQ7Ozs7Ozs7QUFPQUEsV0FBTyxpQkFBWTtBQUNmO0FBQ0FELDRCQUF1QkMsS0FBdkIsQ0FBNkJ0QyxJQUE3QixDQUFrQyxJQUFsQzs7QUFFQTtBQUNBLFVBQUs2RCxRQUFMO0FBQ0gsS0FwQ3FEOztBQXNDdEQ7Ozs7Ozs7Ozs7OztBQVlBQyxZQUFRLGdCQUFVQyxhQUFWLEVBQXlCO0FBQzdCO0FBQ0EsVUFBS3RCLE9BQUwsQ0FBYXNCLGFBQWI7O0FBRUE7QUFDQSxVQUFLcEIsUUFBTDs7QUFFQTtBQUNBLFlBQU8sSUFBUDtBQUNILEtBM0RxRDs7QUE2RHREOzs7Ozs7Ozs7Ozs7OztBQWNBcUIsY0FBVSxrQkFBVUQsYUFBVixFQUF5QjtBQUMvQjtBQUNBLFNBQUlBLGFBQUosRUFBbUI7QUFDZixXQUFLdEIsT0FBTCxDQUFhc0IsYUFBYjtBQUNIOztBQUVEO0FBQ0EsU0FBSUUsT0FBTyxLQUFLQyxXQUFMLEVBQVg7O0FBRUEsWUFBT0QsSUFBUDtBQUNILEtBckZxRDs7QUF1RnREbEIsZUFBVyxNQUFJLEVBdkZ1Qzs7QUF5RnREOzs7Ozs7Ozs7Ozs7O0FBYUFvQixtQkFBZSx1QkFBVUMsTUFBVixFQUFrQjtBQUM3QixZQUFPLFVBQVVDLE9BQVYsRUFBbUJULEdBQW5CLEVBQXdCO0FBQzNCLGFBQU8sSUFBSVEsT0FBTzlGLElBQVgsQ0FBZ0JzRixHQUFoQixFQUFxQkksUUFBckIsQ0FBOEJLLE9BQTlCLENBQVA7QUFDSCxNQUZEO0FBR0gsS0ExR3FEOztBQTRHdEQ7Ozs7Ozs7Ozs7Ozs7QUFhQUMsdUJBQW1CLDJCQUFVRixNQUFWLEVBQWtCO0FBQ2pDLFlBQU8sVUFBVUMsT0FBVixFQUFtQkUsR0FBbkIsRUFBd0I7QUFDM0IsYUFBTyxJQUFJQyxPQUFPQyxJQUFQLENBQVluRyxJQUFoQixDQUFxQjhGLE1BQXJCLEVBQTZCRyxHQUE3QixFQUFrQ1AsUUFBbEMsQ0FBMkNLLE9BQTNDLENBQVA7QUFDSCxNQUZEO0FBR0g7QUE3SHFELElBQTlCLENBQTVCOztBQWdJQTs7O0FBR0EsT0FBSUcsU0FBUzFHLEVBQUU0RyxJQUFGLEdBQVMsRUFBdEI7O0FBRUEsVUFBTzVHLENBQVA7QUFDSCxHQWh1QjJCLENBZ3VCMUJSLElBaHVCMEIsQ0FBNUI7O0FBbXVCQSxTQUFPRCxRQUFQO0FBRUEsRUF2dkJDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVVAsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUI7QUFDMUIsTUFBSSxnQ0FBT0UsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELENBQVAsb0NBQW1CTCxPQUFuQjtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixhQUFVRSxTQUFWLEVBQXFCO0FBQ2xCO0FBQ0EsT0FBSU8sSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJQyxPQUFPRixNQUFNRSxJQUFqQjtBQUNBLE9BQUkwRyxlQUFlNUcsTUFBTWdCLFNBQXpCOztBQUVBOzs7QUFHQSxPQUFJNkYsUUFBUTlHLEVBQUUrRyxHQUFGLEdBQVEsRUFBcEI7O0FBRUE7OztBQUdBLE9BQUlDLFVBQVVGLE1BQU1HLElBQU4sR0FBYTlHLEtBQUtDLE1BQUwsQ0FBWTtBQUNuQzs7Ozs7Ozs7OztBQVVBSSxVQUFNLGNBQVUwRyxJQUFWLEVBQWdCQyxHQUFoQixFQUFxQjtBQUN2QixVQUFLRCxJQUFMLEdBQVlBLElBQVo7QUFDQSxVQUFLQyxHQUFMLEdBQVdBLEdBQVg7QUFDSDs7QUFFRDs7Ozs7Ozs7O0FBU0E7QUFDSTtBQUNBOztBQUVBO0FBQ0o7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDSTtBQUNBOztBQUVBO0FBQ0o7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDSTtBQUNBOztBQUVBO0FBQ0o7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDSTtBQUNBOztBQUVBO0FBQ0o7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDSTtBQUNJO0FBQ0E7QUFDSjtBQUNJO0FBQ0E7QUFDSjs7QUFFQTtBQUNKOztBQUVBOzs7Ozs7Ozs7OztBQVdBO0FBQ0k7QUFDSTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0o7O0FBRUE7QUFDSjs7QUFFQTs7Ozs7Ozs7Ozs7QUFXQTtBQUNJO0FBQ0o7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDSTtBQUNKOztBQUVBOzs7Ozs7Ozs7OztBQVdBO0FBQ0k7QUFDQTtBQUNBOztBQUVBO0FBQ0o7QUFuTG1DLElBQVosQ0FBM0I7O0FBc0xBOzs7Ozs7QUFNQSxPQUFJQyxlQUFlTixNQUFNN0YsU0FBTixHQUFrQmQsS0FBS0MsTUFBTCxDQUFZO0FBQzdDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CQUksVUFBTSxjQUFVVSxLQUFWLEVBQWlCQyxRQUFqQixFQUEyQjtBQUM3QkQsYUFBUSxLQUFLQSxLQUFMLEdBQWFBLFNBQVMsRUFBOUI7O0FBRUEsU0FBSUMsWUFBWTFCLFNBQWhCLEVBQTJCO0FBQ3ZCLFdBQUswQixRQUFMLEdBQWdCQSxRQUFoQjtBQUNILE1BRkQsTUFFTztBQUNILFdBQUtBLFFBQUwsR0FBZ0JELE1BQU1FLE1BQU4sR0FBZSxDQUEvQjtBQUNIO0FBQ0osS0E3QjRDOztBQStCN0M7Ozs7Ozs7OztBQVNBaUcsV0FBTyxpQkFBWTtBQUNmO0FBQ0EsU0FBSUMsV0FBVyxLQUFLcEcsS0FBcEI7QUFDQSxTQUFJcUcsaUJBQWlCRCxTQUFTbEcsTUFBOUI7O0FBRUE7QUFDQSxTQUFJb0csV0FBVyxFQUFmO0FBQ0EsVUFBSyxJQUFJekYsSUFBSSxDQUFiLEVBQWdCQSxJQUFJd0YsY0FBcEIsRUFBb0N4RixHQUFwQyxFQUF5QztBQUNyQyxVQUFJMEYsVUFBVUgsU0FBU3ZGLENBQVQsQ0FBZDtBQUNBeUYsZUFBUzNFLElBQVQsQ0FBYzRFLFFBQVFQLElBQXRCO0FBQ0FNLGVBQVMzRSxJQUFULENBQWM0RSxRQUFRTixHQUF0QjtBQUNIOztBQUVELFlBQU9OLGFBQWFuSCxNQUFiLENBQW9COEgsUUFBcEIsRUFBOEIsS0FBS3JHLFFBQW5DLENBQVA7QUFDSCxLQXRENEM7O0FBd0Q3Qzs7Ozs7Ozs7O0FBU0FILFdBQU8saUJBQVk7QUFDZixTQUFJQSxRQUFRYixLQUFLYSxLQUFMLENBQVdrQixJQUFYLENBQWdCLElBQWhCLENBQVo7O0FBRUE7QUFDQSxTQUFJaEIsUUFBUUYsTUFBTUUsS0FBTixHQUFjLEtBQUtBLEtBQUwsQ0FBV2lCLEtBQVgsQ0FBaUIsQ0FBakIsQ0FBMUI7O0FBRUE7QUFDQSxTQUFJdUYsY0FBY3hHLE1BQU1FLE1BQXhCO0FBQ0EsVUFBSyxJQUFJVyxJQUFJLENBQWIsRUFBZ0JBLElBQUkyRixXQUFwQixFQUFpQzNGLEdBQWpDLEVBQXNDO0FBQ2xDYixZQUFNYSxDQUFOLElBQVdiLE1BQU1hLENBQU4sRUFBU2YsS0FBVCxFQUFYO0FBQ0g7O0FBRUQsWUFBT0EsS0FBUDtBQUNIO0FBOUU0QyxJQUFaLENBQXJDO0FBZ0ZILEdBM1JBLEdBQUQ7O0FBOFJBLFNBQU96QixRQUFQO0FBRUEsRUEvU0MsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVUCxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QjtBQUMxQixNQUFJLGdDQUFPRSxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsQ0FBUCxvQ0FBbUJMLE9BQW5CO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUksT0FBT29JLFdBQVAsSUFBc0IsVUFBMUIsRUFBc0M7QUFDbEM7QUFDSDs7QUFFRDtBQUNBLE9BQUkzSCxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7O0FBRUE7QUFDQSxPQUFJMkcsWUFBWTNHLFVBQVVULElBQTFCOztBQUVBO0FBQ0EsT0FBSXFILFVBQVU1RyxVQUFVVCxJQUFWLEdBQWlCLFVBQVVzSCxVQUFWLEVBQXNCO0FBQ2pEO0FBQ0EsUUFBSUEsc0JBQXNCSCxXQUExQixFQUF1QztBQUNuQ0csa0JBQWEsSUFBSUMsVUFBSixDQUFlRCxVQUFmLENBQWI7QUFDSDs7QUFFRDtBQUNBLFFBQ0lBLHNCQUFzQkUsU0FBdEIsSUFDQyxPQUFPQyxpQkFBUCxLQUE2QixXQUE3QixJQUE0Q0gsc0JBQXNCRyxpQkFEbkUsSUFFQUgsc0JBQXNCSSxVQUZ0QixJQUdBSixzQkFBc0JLLFdBSHRCLElBSUFMLHNCQUFzQk0sVUFKdEIsSUFLQU4sc0JBQXNCTyxXQUx0QixJQU1BUCxzQkFBc0JRLFlBTnRCLElBT0FSLHNCQUFzQlMsWUFSMUIsRUFTRTtBQUNFVCxrQkFBYSxJQUFJQyxVQUFKLENBQWVELFdBQVdVLE1BQTFCLEVBQWtDVixXQUFXVyxVQUE3QyxFQUF5RFgsV0FBV1ksVUFBcEUsQ0FBYjtBQUNIOztBQUVEO0FBQ0EsUUFBSVosc0JBQXNCQyxVQUExQixFQUFzQztBQUNsQztBQUNBLFNBQUlZLHVCQUF1QmIsV0FBV1ksVUFBdEM7O0FBRUE7QUFDQSxTQUFJeEgsUUFBUSxFQUFaO0FBQ0EsVUFBSyxJQUFJYSxJQUFJLENBQWIsRUFBZ0JBLElBQUk0RyxvQkFBcEIsRUFBMEM1RyxHQUExQyxFQUErQztBQUMzQ2IsWUFBTWEsTUFBTSxDQUFaLEtBQWtCK0YsV0FBVy9GLENBQVgsS0FBa0IsS0FBTUEsSUFBSSxDQUFMLEdBQVUsQ0FBbkQ7QUFDSDs7QUFFRDtBQUNBNkYsZUFBVTFGLElBQVYsQ0FBZSxJQUFmLEVBQXFCaEIsS0FBckIsRUFBNEJ5SCxvQkFBNUI7QUFDSCxLQVpELE1BWU87QUFDSDtBQUNBZixlQUFVbEgsS0FBVixDQUFnQixJQUFoQixFQUFzQkMsU0FBdEI7QUFDSDtBQUNKLElBckNEOztBQXVDQWtILFdBQVE5SCxTQUFSLEdBQW9Ca0IsU0FBcEI7QUFDSCxHQXZEQSxHQUFEOztBQTBEQSxTQUFPMUIsU0FBU1csR0FBVCxDQUFhZSxTQUFwQjtBQUVBLEVBM0VDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVWpDLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCO0FBQzFCLE1BQUksZ0NBQU9FLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxDQUFQLG9DQUFtQkwsT0FBbkI7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFMUIsZUFBWTtBQUNUO0FBQ0EsT0FBSVMsSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJZSxZQUFZaEIsTUFBTWdCLFNBQXRCO0FBQ0EsT0FBSTZCLFFBQVE5QyxFQUFFK0MsR0FBZDs7QUFFQTs7O0FBR0EsT0FBSTZGLFVBQVU5RixNQUFNK0YsS0FBTixHQUFjL0YsTUFBTThGLE9BQU4sR0FBZ0I7QUFDeEM7Ozs7Ozs7Ozs7Ozs7QUFhQXJILGVBQVcsbUJBQVVFLFNBQVYsRUFBcUI7QUFDNUI7QUFDQSxTQUFJUCxRQUFRTyxVQUFVUCxLQUF0QjtBQUNBLFNBQUlDLFdBQVdNLFVBQVVOLFFBQXpCOztBQUVBO0FBQ0EsU0FBSTJILGFBQWEsRUFBakI7QUFDQSxVQUFLLElBQUkvRyxJQUFJLENBQWIsRUFBZ0JBLElBQUlaLFFBQXBCLEVBQThCWSxLQUFLLENBQW5DLEVBQXNDO0FBQ2xDLFVBQUlnSCxZQUFhN0gsTUFBTWEsTUFBTSxDQUFaLE1BQW9CLEtBQU1BLElBQUksQ0FBTCxHQUFVLENBQXBDLEdBQTBDLE1BQTFEO0FBQ0ErRyxpQkFBV2pHLElBQVgsQ0FBZ0JhLE9BQU9DLFlBQVAsQ0FBb0JvRixTQUFwQixDQUFoQjtBQUNIOztBQUVELFlBQU9ELFdBQVc1RixJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDSCxLQTNCdUM7O0FBNkJ4Qzs7Ozs7Ozs7Ozs7OztBQWFBQyxXQUFPLGVBQVU2RixRQUFWLEVBQW9CO0FBQ3ZCO0FBQ0EsU0FBSUMsaUJBQWlCRCxTQUFTNUgsTUFBOUI7O0FBRUE7QUFDQSxTQUFJRixRQUFRLEVBQVo7QUFDQSxVQUFLLElBQUlhLElBQUksQ0FBYixFQUFnQkEsSUFBSWtILGNBQXBCLEVBQW9DbEgsR0FBcEMsRUFBeUM7QUFDckNiLFlBQU1hLE1BQU0sQ0FBWixLQUFrQmlILFNBQVNsRixVQUFULENBQW9CL0IsQ0FBcEIsS0FBMkIsS0FBTUEsSUFBSSxDQUFMLEdBQVUsRUFBNUQ7QUFDSDs7QUFFRCxZQUFPZCxVQUFVdkIsTUFBVixDQUFpQndCLEtBQWpCLEVBQXdCK0gsaUJBQWlCLENBQXpDLENBQVA7QUFDSDtBQXJEdUMsSUFBNUM7O0FBd0RBOzs7QUFHQW5HLFNBQU1vRyxPQUFOLEdBQWdCO0FBQ1o7Ozs7Ozs7Ozs7Ozs7QUFhQTNILGVBQVcsbUJBQVVFLFNBQVYsRUFBcUI7QUFDNUI7QUFDQSxTQUFJUCxRQUFRTyxVQUFVUCxLQUF0QjtBQUNBLFNBQUlDLFdBQVdNLFVBQVVOLFFBQXpCOztBQUVBO0FBQ0EsU0FBSTJILGFBQWEsRUFBakI7QUFDQSxVQUFLLElBQUkvRyxJQUFJLENBQWIsRUFBZ0JBLElBQUlaLFFBQXBCLEVBQThCWSxLQUFLLENBQW5DLEVBQXNDO0FBQ2xDLFVBQUlnSCxZQUFZSSxXQUFZakksTUFBTWEsTUFBTSxDQUFaLE1BQW9CLEtBQU1BLElBQUksQ0FBTCxHQUFVLENBQXBDLEdBQTBDLE1BQXJELENBQWhCO0FBQ0ErRyxpQkFBV2pHLElBQVgsQ0FBZ0JhLE9BQU9DLFlBQVAsQ0FBb0JvRixTQUFwQixDQUFoQjtBQUNIOztBQUVELFlBQU9ELFdBQVc1RixJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDSCxLQTNCVzs7QUE2Qlo7Ozs7Ozs7Ozs7Ozs7QUFhQUMsV0FBTyxlQUFVNkYsUUFBVixFQUFvQjtBQUN2QjtBQUNBLFNBQUlDLGlCQUFpQkQsU0FBUzVILE1BQTlCOztBQUVBO0FBQ0EsU0FBSUYsUUFBUSxFQUFaO0FBQ0EsVUFBSyxJQUFJYSxJQUFJLENBQWIsRUFBZ0JBLElBQUlrSCxjQUFwQixFQUFvQ2xILEdBQXBDLEVBQXlDO0FBQ3JDYixZQUFNYSxNQUFNLENBQVosS0FBa0JvSCxXQUFXSCxTQUFTbEYsVUFBVCxDQUFvQi9CLENBQXBCLEtBQTJCLEtBQU1BLElBQUksQ0FBTCxHQUFVLEVBQXJELENBQWxCO0FBQ0g7O0FBRUQsWUFBT2QsVUFBVXZCLE1BQVYsQ0FBaUJ3QixLQUFqQixFQUF3QitILGlCQUFpQixDQUF6QyxDQUFQO0FBQ0g7QUFyRFcsSUFBaEI7O0FBd0RBLFlBQVNFLFVBQVQsQ0FBb0JDLElBQXBCLEVBQTBCO0FBQ3RCLFdBQVNBLFFBQVEsQ0FBVCxHQUFjLFVBQWYsR0FBK0JBLFNBQVMsQ0FBVixHQUFlLFVBQXBEO0FBQ0g7QUFDSixHQWhJQSxHQUFEOztBQW1JQSxTQUFPN0osU0FBU3dELEdBQVQsQ0FBYThGLEtBQXBCO0FBRUEsRUFwSkMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVN0osSUFBVixFQUFnQkMsT0FBaEIsRUFBeUI7QUFDMUIsTUFBSSxnQ0FBT0UsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELENBQVAsb0NBQW1CTCxPQUFuQjtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixlQUFZO0FBQ1Q7QUFDQSxPQUFJUyxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJNkIsUUFBUTlDLEVBQUUrQyxHQUFkOztBQUVBOzs7QUFHQSxPQUFJc0csU0FBU3ZHLE1BQU11RyxNQUFOLEdBQWU7QUFDeEI7Ozs7Ozs7Ozs7Ozs7QUFhQTlILGVBQVcsbUJBQVVFLFNBQVYsRUFBcUI7QUFDNUI7QUFDQSxTQUFJUCxRQUFRTyxVQUFVUCxLQUF0QjtBQUNBLFNBQUlDLFdBQVdNLFVBQVVOLFFBQXpCO0FBQ0EsU0FBSW1JLE1BQU0sS0FBS0MsSUFBZjs7QUFFQTtBQUNBOUgsZUFBVUssS0FBVjs7QUFFQTtBQUNBLFNBQUkwSCxjQUFjLEVBQWxCO0FBQ0EsVUFBSyxJQUFJekgsSUFBSSxDQUFiLEVBQWdCQSxJQUFJWixRQUFwQixFQUE4QlksS0FBSyxDQUFuQyxFQUFzQztBQUNsQyxVQUFJMEgsUUFBU3ZJLE1BQU1hLE1BQU0sQ0FBWixNQUEwQixLQUFNQSxJQUFJLENBQUwsR0FBVSxDQUExQyxHQUFzRCxJQUFsRTtBQUNBLFVBQUkySCxRQUFTeEksTUFBT2EsSUFBSSxDQUFMLEtBQVksQ0FBbEIsTUFBMEIsS0FBTSxDQUFDQSxJQUFJLENBQUwsSUFBVSxDQUFYLEdBQWdCLENBQWhELEdBQXNELElBQWxFO0FBQ0EsVUFBSTRILFFBQVN6SSxNQUFPYSxJQUFJLENBQUwsS0FBWSxDQUFsQixNQUEwQixLQUFNLENBQUNBLElBQUksQ0FBTCxJQUFVLENBQVgsR0FBZ0IsQ0FBaEQsR0FBc0QsSUFBbEU7O0FBRUEsVUFBSTZILFVBQVdILFNBQVMsRUFBVixHQUFpQkMsU0FBUyxDQUExQixHQUErQkMsS0FBN0M7O0FBRUEsV0FBSyxJQUFJRSxJQUFJLENBQWIsRUFBaUJBLElBQUksQ0FBTCxJQUFZOUgsSUFBSThILElBQUksSUFBUixHQUFlMUksUUFBM0MsRUFBc0QwSSxHQUF0RCxFQUEyRDtBQUN2REwsbUJBQVkzRyxJQUFaLENBQWlCeUcsSUFBSVEsTUFBSixDQUFZRixZQUFhLEtBQUssSUFBSUMsQ0FBVCxDQUFkLEdBQThCLElBQXpDLENBQWpCO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFNBQUlFLGNBQWNULElBQUlRLE1BQUosQ0FBVyxFQUFYLENBQWxCO0FBQ0EsU0FBSUMsV0FBSixFQUFpQjtBQUNiLGFBQU9QLFlBQVlwSSxNQUFaLEdBQXFCLENBQTVCLEVBQStCO0FBQzNCb0ksbUJBQVkzRyxJQUFaLENBQWlCa0gsV0FBakI7QUFDSDtBQUNKOztBQUVELFlBQU9QLFlBQVl0RyxJQUFaLENBQWlCLEVBQWpCLENBQVA7QUFDSCxLQTlDdUI7O0FBZ0R4Qjs7Ozs7Ozs7Ozs7OztBQWFBQyxXQUFPLGVBQVU2RyxTQUFWLEVBQXFCO0FBQ3hCO0FBQ0EsU0FBSUMsa0JBQWtCRCxVQUFVNUksTUFBaEM7QUFDQSxTQUFJa0ksTUFBTSxLQUFLQyxJQUFmO0FBQ0EsU0FBSVcsYUFBYSxLQUFLQyxXQUF0Qjs7QUFFQSxTQUFJLENBQUNELFVBQUwsRUFBaUI7QUFDVEEsbUJBQWEsS0FBS0MsV0FBTCxHQUFtQixFQUFoQztBQUNBLFdBQUssSUFBSU4sSUFBSSxDQUFiLEVBQWdCQSxJQUFJUCxJQUFJbEksTUFBeEIsRUFBZ0N5SSxHQUFoQyxFQUFxQztBQUNqQ0ssa0JBQVdaLElBQUl4RixVQUFKLENBQWUrRixDQUFmLENBQVgsSUFBZ0NBLENBQWhDO0FBQ0g7QUFDUjs7QUFFRDtBQUNBLFNBQUlFLGNBQWNULElBQUlRLE1BQUosQ0FBVyxFQUFYLENBQWxCO0FBQ0EsU0FBSUMsV0FBSixFQUFpQjtBQUNiLFVBQUlLLGVBQWVKLFVBQVVLLE9BQVYsQ0FBa0JOLFdBQWxCLENBQW5CO0FBQ0EsVUFBSUssaUJBQWlCLENBQUMsQ0FBdEIsRUFBeUI7QUFDckJILHlCQUFrQkcsWUFBbEI7QUFDSDtBQUNKOztBQUVEO0FBQ0EsWUFBT0UsVUFBVU4sU0FBVixFQUFxQkMsZUFBckIsRUFBc0NDLFVBQXRDLENBQVA7QUFFSCxLQXRGdUI7O0FBd0Z4QlgsVUFBTTtBQXhGa0IsSUFBNUI7O0FBMkZBLFlBQVNlLFNBQVQsQ0FBbUJOLFNBQW5CLEVBQThCQyxlQUE5QixFQUErQ0MsVUFBL0MsRUFBMkQ7QUFDekQsUUFBSWhKLFFBQVEsRUFBWjtBQUNBLFFBQUltQixTQUFTLENBQWI7QUFDQSxTQUFLLElBQUlOLElBQUksQ0FBYixFQUFnQkEsSUFBSWtJLGVBQXBCLEVBQXFDbEksR0FBckMsRUFBMEM7QUFDdEMsU0FBSUEsSUFBSSxDQUFSLEVBQVc7QUFDUCxVQUFJd0ksUUFBUUwsV0FBV0YsVUFBVWxHLFVBQVYsQ0FBcUIvQixJQUFJLENBQXpCLENBQVgsS0FBNkNBLElBQUksQ0FBTCxHQUFVLENBQWxFO0FBQ0EsVUFBSXlJLFFBQVFOLFdBQVdGLFVBQVVsRyxVQUFWLENBQXFCL0IsQ0FBckIsQ0FBWCxNQUF5QyxJQUFLQSxJQUFJLENBQUwsR0FBVSxDQUFuRTtBQUNBYixZQUFNbUIsV0FBVyxDQUFqQixLQUF1QixDQUFDa0ksUUFBUUMsS0FBVCxLQUFvQixLQUFNbkksU0FBUyxDQUFWLEdBQWUsQ0FBL0Q7QUFDQUE7QUFDSDtBQUNKO0FBQ0QsV0FBT3BCLFVBQVV2QixNQUFWLENBQWlCd0IsS0FBakIsRUFBd0JtQixNQUF4QixDQUFQO0FBQ0Q7QUFDSixHQWxIQSxHQUFEOztBQXFIQSxTQUFPOUMsU0FBU3dELEdBQVQsQ0FBYXNHLE1BQXBCO0FBRUEsRUF0SUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVckssSUFBVixFQUFnQkMsT0FBaEIsRUFBeUI7QUFDMUIsTUFBSSxnQ0FBT0UsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELENBQVAsb0NBQW1CTCxPQUFuQjtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixhQUFVQyxJQUFWLEVBQWdCO0FBQ2I7QUFDQSxPQUFJUSxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJNEUsU0FBUzVGLE1BQU00RixNQUFuQjtBQUNBLE9BQUlhLFNBQVMxRyxFQUFFNEcsSUFBZjs7QUFFQTtBQUNBLE9BQUk2RCxJQUFJLEVBQVI7O0FBRUE7QUFDQyxnQkFBWTtBQUNULFNBQUssSUFBSTFJLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekIwSSxPQUFFMUksQ0FBRixJQUFRdkMsS0FBS2tMLEdBQUwsQ0FBU2xMLEtBQUttTCxHQUFMLENBQVM1SSxJQUFJLENBQWIsQ0FBVCxJQUE0QixXQUE3QixHQUE0QyxDQUFuRDtBQUNIO0FBQ0osSUFKQSxHQUFEOztBQU1BOzs7QUFHQSxPQUFJNkksTUFBTWxFLE9BQU9rRSxHQUFQLEdBQWEvRSxPQUFPekYsTUFBUCxDQUFjO0FBQ2pDMkYsY0FBVSxvQkFBWTtBQUNsQixVQUFLOEUsS0FBTCxHQUFhLElBQUk1SixVQUFVVCxJQUFkLENBQW1CLENBQzVCLFVBRDRCLEVBQ2hCLFVBRGdCLEVBRTVCLFVBRjRCLEVBRWhCLFVBRmdCLENBQW5CLENBQWI7QUFJSCxLQU5nQzs7QUFRakNrRixxQkFBaUIseUJBQVVvRixDQUFWLEVBQWFyRixNQUFiLEVBQXFCO0FBQ2xDO0FBQ0EsVUFBSyxJQUFJMUQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEVBQXBCLEVBQXdCQSxHQUF4QixFQUE2QjtBQUN6QjtBQUNBLFVBQUlnSixXQUFXdEYsU0FBUzFELENBQXhCO0FBQ0EsVUFBSWlKLGFBQWFGLEVBQUVDLFFBQUYsQ0FBakI7O0FBRUFELFFBQUVDLFFBQUYsSUFDSyxDQUFFQyxjQUFjLENBQWYsR0FBc0JBLGVBQWUsRUFBdEMsSUFBNkMsVUFBOUMsR0FDQyxDQUFFQSxjQUFjLEVBQWYsR0FBc0JBLGVBQWUsQ0FBdEMsSUFBNkMsVUFGbEQ7QUFJSDs7QUFFRDtBQUNBLFNBQUlDLElBQUksS0FBS0osS0FBTCxDQUFXM0osS0FBbkI7O0FBRUEsU0FBSWdLLGFBQWNKLEVBQUVyRixTQUFTLENBQVgsQ0FBbEI7QUFDQSxTQUFJMEYsYUFBY0wsRUFBRXJGLFNBQVMsQ0FBWCxDQUFsQjtBQUNBLFNBQUkyRixhQUFjTixFQUFFckYsU0FBUyxDQUFYLENBQWxCO0FBQ0EsU0FBSTRGLGFBQWNQLEVBQUVyRixTQUFTLENBQVgsQ0FBbEI7QUFDQSxTQUFJNkYsYUFBY1IsRUFBRXJGLFNBQVMsQ0FBWCxDQUFsQjtBQUNBLFNBQUk4RixhQUFjVCxFQUFFckYsU0FBUyxDQUFYLENBQWxCO0FBQ0EsU0FBSStGLGFBQWNWLEVBQUVyRixTQUFTLENBQVgsQ0FBbEI7QUFDQSxTQUFJZ0csYUFBY1gsRUFBRXJGLFNBQVMsQ0FBWCxDQUFsQjtBQUNBLFNBQUlpRyxhQUFjWixFQUFFckYsU0FBUyxDQUFYLENBQWxCO0FBQ0EsU0FBSWtHLGFBQWNiLEVBQUVyRixTQUFTLENBQVgsQ0FBbEI7QUFDQSxTQUFJbUcsY0FBY2QsRUFBRXJGLFNBQVMsRUFBWCxDQUFsQjtBQUNBLFNBQUlvRyxjQUFjZixFQUFFckYsU0FBUyxFQUFYLENBQWxCO0FBQ0EsU0FBSXFHLGNBQWNoQixFQUFFckYsU0FBUyxFQUFYLENBQWxCO0FBQ0EsU0FBSXNHLGNBQWNqQixFQUFFckYsU0FBUyxFQUFYLENBQWxCO0FBQ0EsU0FBSXVHLGNBQWNsQixFQUFFckYsU0FBUyxFQUFYLENBQWxCO0FBQ0EsU0FBSXdHLGNBQWNuQixFQUFFckYsU0FBUyxFQUFYLENBQWxCOztBQUVBO0FBQ0EsU0FBSXlHLElBQUlqQixFQUFFLENBQUYsQ0FBUjtBQUNBLFNBQUlrQixJQUFJbEIsRUFBRSxDQUFGLENBQVI7QUFDQSxTQUFJbUIsSUFBSW5CLEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSW9CLElBQUlwQixFQUFFLENBQUYsQ0FBUjs7QUFFQTtBQUNBaUIsU0FBSUksR0FBR0osQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlbkIsVUFBZixFQUE0QixDQUE1QixFQUFnQ1QsRUFBRSxDQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlDLEdBQUdELENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZWpCLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NWLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJRSxHQUFHRixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVmLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NYLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJRyxHQUFHSCxDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWViLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NaLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0F5QixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVmLFVBQWYsRUFBNEIsQ0FBNUIsRUFBZ0NiLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJQyxHQUFHRCxDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWViLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NkLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJRSxHQUFHRixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVYLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NmLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJRyxHQUFHSCxDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWVULFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NoQixFQUFFLENBQUYsQ0FBaEMsQ0FBSjtBQUNBeUIsU0FBSUksR0FBR0osQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlWCxVQUFmLEVBQTRCLENBQTVCLEVBQWdDakIsRUFBRSxDQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlDLEdBQUdELENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZVQsVUFBZixFQUE0QixFQUE1QixFQUFnQ2xCLEVBQUUsQ0FBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJRSxHQUFHRixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVQLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0NuQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSUcsR0FBR0gsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlTCxXQUFmLEVBQTRCLEVBQTVCLEVBQWdDcEIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQXlCLFNBQUlJLEdBQUdKLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZVAsV0FBZixFQUE0QixDQUE1QixFQUFnQ3JCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJQyxHQUFHRCxDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVMLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0N0QixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMkIsU0FBSUUsR0FBR0YsQ0FBSCxFQUFNQyxDQUFOLEVBQVNILENBQVQsRUFBWUMsQ0FBWixFQUFlSCxXQUFmLEVBQTRCLEVBQTVCLEVBQWdDdkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTBCLFNBQUlHLEdBQUdILENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlILENBQVosRUFBZUQsV0FBZixFQUE0QixFQUE1QixFQUFnQ3hCLEVBQUUsRUFBRixDQUFoQyxDQUFKOztBQUVBeUIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlbEIsVUFBZixFQUE0QixDQUE1QixFQUFnQ1YsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlFLEdBQUdGLENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZVosVUFBZixFQUE0QixDQUE1QixFQUFnQ2YsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTJCLFNBQUlHLEdBQUdILENBQUgsRUFBTUMsQ0FBTixFQUFTSCxDQUFULEVBQVlDLENBQVosRUFBZU4sV0FBZixFQUE0QixFQUE1QixFQUFnQ3BCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWVoQixVQUFmLEVBQTRCLEVBQTVCLEVBQWdDVCxFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBeUIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlZCxVQUFmLEVBQTRCLENBQTVCLEVBQWdDZCxFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBNEIsU0FBSUUsR0FBR0YsQ0FBSCxFQUFNSCxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlUixXQUFmLEVBQTRCLENBQTVCLEVBQWdDbkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTJCLFNBQUlHLEdBQUdILENBQUgsRUFBTUMsQ0FBTixFQUFTSCxDQUFULEVBQVlDLENBQVosRUFBZUYsV0FBZixFQUE0QixFQUE1QixFQUFnQ3hCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWVaLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NiLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0F5QixTQUFJSyxHQUFHTCxDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVWLFVBQWYsRUFBNEIsQ0FBNUIsRUFBZ0NsQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBNEIsU0FBSUUsR0FBR0YsQ0FBSCxFQUFNSCxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlSixXQUFmLEVBQTRCLENBQTVCLEVBQWdDdkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTJCLFNBQUlHLEdBQUdILENBQUgsRUFBTUMsQ0FBTixFQUFTSCxDQUFULEVBQVlDLENBQVosRUFBZWQsVUFBZixFQUE0QixFQUE1QixFQUFnQ1osRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTBCLFNBQUlJLEdBQUdKLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlILENBQVosRUFBZVIsVUFBZixFQUE0QixFQUE1QixFQUFnQ2pCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0F5QixTQUFJSyxHQUFHTCxDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVOLFdBQWYsRUFBNEIsQ0FBNUIsRUFBZ0N0QixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBNEIsU0FBSUUsR0FBR0YsQ0FBSCxFQUFNSCxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlaEIsVUFBZixFQUE0QixDQUE1QixFQUFnQ1gsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTJCLFNBQUlHLEdBQUdILENBQUgsRUFBTUMsQ0FBTixFQUFTSCxDQUFULEVBQVlDLENBQVosRUFBZVYsVUFBZixFQUE0QixFQUE1QixFQUFnQ2hCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWVKLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0NyQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjs7QUFFQXlCLFNBQUlNLEdBQUdOLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZWQsVUFBZixFQUE0QixDQUE1QixFQUFnQ2QsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlHLEdBQUdILENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZVYsVUFBZixFQUE0QixFQUE1QixFQUFnQ2pCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVOLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0NwQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlRixXQUFmLEVBQTRCLEVBQTVCLEVBQWdDdkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQXlCLFNBQUlNLEdBQUdOLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZWxCLFVBQWYsRUFBNEIsQ0FBNUIsRUFBZ0NWLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJRyxHQUFHSCxDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVkLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NiLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVWLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NoQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlTixXQUFmLEVBQTRCLEVBQTVCLEVBQWdDbkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQXlCLFNBQUlNLEdBQUdOLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZU4sV0FBZixFQUE0QixDQUE1QixFQUFnQ3RCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJRyxHQUFHSCxDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVsQixVQUFmLEVBQTRCLEVBQTVCLEVBQWdDVCxFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMkIsU0FBSUksR0FBR0osQ0FBSCxFQUFNQyxDQUFOLEVBQVNILENBQVQsRUFBWUMsQ0FBWixFQUFlZCxVQUFmLEVBQTRCLEVBQTVCLEVBQWdDWixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlVixVQUFmLEVBQTRCLEVBQTVCLEVBQWdDZixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBeUIsU0FBSU0sR0FBR04sQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlVixVQUFmLEVBQTRCLENBQTVCLEVBQWdDbEIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlHLEdBQUdILENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZU4sV0FBZixFQUE0QixFQUE1QixFQUFnQ3JCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJSSxHQUFHSixDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVGLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0N4QixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlZCxVQUFmLEVBQTRCLEVBQTVCLEVBQWdDWCxFQUFFLEVBQUYsQ0FBaEMsQ0FBSjs7QUFFQXlCLFNBQUlPLEdBQUdQLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZW5CLFVBQWYsRUFBNEIsQ0FBNUIsRUFBZ0NULEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJSSxHQUFHSixDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVYLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NoQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMkIsU0FBSUssR0FBR0wsQ0FBSCxFQUFNQyxDQUFOLEVBQVNILENBQVQsRUFBWUMsQ0FBWixFQUFlSCxXQUFmLEVBQTRCLEVBQTVCLEVBQWdDdkIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTBCLFNBQUlNLEdBQUdOLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlILENBQVosRUFBZVgsVUFBZixFQUE0QixFQUE1QixFQUFnQ2QsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQXlCLFNBQUlPLEdBQUdQLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZVAsV0FBZixFQUE0QixDQUE1QixFQUFnQ3JCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0E0QixTQUFJSSxHQUFHSixDQUFILEVBQU1ILENBQU4sRUFBU0MsQ0FBVCxFQUFZQyxDQUFaLEVBQWVmLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NaLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJSyxHQUFHTCxDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVQLFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0NuQixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBMEIsU0FBSU0sR0FBR04sQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUgsQ0FBWixFQUFlZixVQUFmLEVBQTRCLEVBQTVCLEVBQWdDVixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBeUIsU0FBSU8sR0FBR1AsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlWCxVQUFmLEVBQTRCLENBQTVCLEVBQWdDakIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTRCLFNBQUlJLEdBQUdKLENBQUgsRUFBTUgsQ0FBTixFQUFTQyxDQUFULEVBQVlDLENBQVosRUFBZUgsV0FBZixFQUE0QixFQUE1QixFQUFnQ3hCLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EyQixTQUFJSyxHQUFHTCxDQUFILEVBQU1DLENBQU4sRUFBU0gsQ0FBVCxFQUFZQyxDQUFaLEVBQWVYLFVBQWYsRUFBNEIsRUFBNUIsRUFBZ0NmLEVBQUUsRUFBRixDQUFoQyxDQUFKO0FBQ0EwQixTQUFJTSxHQUFHTixDQUFILEVBQU1DLENBQU4sRUFBU0MsQ0FBVCxFQUFZSCxDQUFaLEVBQWVILFdBQWYsRUFBNEIsRUFBNUIsRUFBZ0N0QixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBeUIsU0FBSU8sR0FBR1AsQ0FBSCxFQUFNQyxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlZixVQUFmLEVBQTRCLENBQTVCLEVBQWdDYixFQUFFLEVBQUYsQ0FBaEMsQ0FBSjtBQUNBNEIsU0FBSUksR0FBR0osQ0FBSCxFQUFNSCxDQUFOLEVBQVNDLENBQVQsRUFBWUMsQ0FBWixFQUFlUCxXQUFmLEVBQTRCLEVBQTVCLEVBQWdDcEIsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTJCLFNBQUlLLEdBQUdMLENBQUgsRUFBTUMsQ0FBTixFQUFTSCxDQUFULEVBQVlDLENBQVosRUFBZWYsVUFBZixFQUE0QixFQUE1QixFQUFnQ1gsRUFBRSxFQUFGLENBQWhDLENBQUo7QUFDQTBCLFNBQUlNLEdBQUdOLENBQUgsRUFBTUMsQ0FBTixFQUFTQyxDQUFULEVBQVlILENBQVosRUFBZVAsVUFBZixFQUE0QixFQUE1QixFQUFnQ2xCLEVBQUUsRUFBRixDQUFoQyxDQUFKOztBQUVBO0FBQ0FRLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBT2lCLENBQVIsR0FBYSxDQUFwQjtBQUNBakIsT0FBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPa0IsQ0FBUixHQUFhLENBQXBCO0FBQ0FsQixPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9tQixDQUFSLEdBQWEsQ0FBcEI7QUFDQW5CLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBT29CLENBQVIsR0FBYSxDQUFwQjtBQUNILEtBekhnQzs7QUEySGpDakcsaUJBQWEsdUJBQVk7QUFDckI7QUFDQSxTQUFJeEIsT0FBTyxLQUFLSCxLQUFoQjtBQUNBLFNBQUlNLFlBQVlILEtBQUsxRCxLQUFyQjs7QUFFQSxTQUFJd0wsYUFBYSxLQUFLaEksV0FBTCxHQUFtQixDQUFwQztBQUNBLFNBQUlpSSxZQUFZL0gsS0FBS3pELFFBQUwsR0FBZ0IsQ0FBaEM7O0FBRUE7QUFDQTRELGVBQVU0SCxjQUFjLENBQXhCLEtBQThCLFFBQVMsS0FBS0EsWUFBWSxFQUF4RDs7QUFFQSxTQUFJQyxjQUFjcE4sS0FBS3FOLEtBQUwsQ0FBV0gsYUFBYSxXQUF4QixDQUFsQjtBQUNBLFNBQUlJLGNBQWNKLFVBQWxCO0FBQ0EzSCxlQUFVLENBQUc0SCxZQUFZLEVBQWIsS0FBcUIsQ0FBdEIsSUFBNEIsQ0FBN0IsSUFBa0MsRUFBNUMsSUFDSyxDQUFFQyxlQUFlLENBQWhCLEdBQXVCQSxnQkFBZ0IsRUFBeEMsSUFBK0MsVUFBaEQsR0FDQyxDQUFFQSxlQUFlLEVBQWhCLEdBQXVCQSxnQkFBZ0IsQ0FBeEMsSUFBK0MsVUFGcEQ7QUFJQTdILGVBQVUsQ0FBRzRILFlBQVksRUFBYixLQUFxQixDQUF0QixJQUE0QixDQUE3QixJQUFrQyxFQUE1QyxJQUNLLENBQUVHLGVBQWUsQ0FBaEIsR0FBdUJBLGdCQUFnQixFQUF4QyxJQUErQyxVQUFoRCxHQUNDLENBQUVBLGVBQWUsRUFBaEIsR0FBdUJBLGdCQUFnQixDQUF4QyxJQUErQyxVQUZwRDs7QUFLQWxJLFVBQUt6RCxRQUFMLEdBQWdCLENBQUM0RCxVQUFVM0QsTUFBVixHQUFtQixDQUFwQixJQUF5QixDQUF6Qzs7QUFFQTtBQUNBLFVBQUt5RCxRQUFMOztBQUVBO0FBQ0EsU0FBSXNCLE9BQU8sS0FBSzBFLEtBQWhCO0FBQ0EsU0FBSUksSUFBSTlFLEtBQUtqRixLQUFiOztBQUVBO0FBQ0EsVUFBSyxJQUFJYSxJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCO0FBQ0EsVUFBSWdMLE1BQU05QixFQUFFbEosQ0FBRixDQUFWOztBQUVBa0osUUFBRWxKLENBQUYsSUFBUSxDQUFFZ0wsT0FBTyxDQUFSLEdBQWVBLFFBQVEsRUFBeEIsSUFBK0IsVUFBaEMsR0FDQyxDQUFFQSxPQUFPLEVBQVIsR0FBZUEsUUFBUSxDQUF4QixJQUErQixVQUR2QztBQUVIOztBQUVEO0FBQ0EsWUFBTzVHLElBQVA7QUFDSCxLQXJLZ0M7O0FBdUtqQ25GLFdBQU8saUJBQVk7QUFDZixTQUFJQSxRQUFRNkUsT0FBTzdFLEtBQVAsQ0FBYWtCLElBQWIsQ0FBa0IsSUFBbEIsQ0FBWjtBQUNBbEIsV0FBTTZKLEtBQU4sR0FBYyxLQUFLQSxLQUFMLENBQVc3SixLQUFYLEVBQWQ7O0FBRUEsWUFBT0EsS0FBUDtBQUNIO0FBNUtnQyxJQUFkLENBQXZCOztBQStLQSxZQUFTc0wsRUFBVCxDQUFZSixDQUFaLEVBQWVDLENBQWYsRUFBa0JDLENBQWxCLEVBQXFCQyxDQUFyQixFQUF3QlcsQ0FBeEIsRUFBMkJDLENBQTNCLEVBQThCQyxDQUE5QixFQUFpQztBQUM3QixRQUFJQyxJQUFJakIsS0FBTUMsSUFBSUMsQ0FBTCxHQUFXLENBQUNELENBQUQsR0FBS0UsQ0FBckIsSUFBMkJXLENBQTNCLEdBQStCRSxDQUF2QztBQUNBLFdBQU8sQ0FBRUMsS0FBS0YsQ0FBTixHQUFZRSxNQUFPLEtBQUtGLENBQXpCLElBQWdDZCxDQUF2QztBQUNIOztBQUVELFlBQVNJLEVBQVQsQ0FBWUwsQ0FBWixFQUFlQyxDQUFmLEVBQWtCQyxDQUFsQixFQUFxQkMsQ0FBckIsRUFBd0JXLENBQXhCLEVBQTJCQyxDQUEzQixFQUE4QkMsQ0FBOUIsRUFBaUM7QUFDN0IsUUFBSUMsSUFBSWpCLEtBQU1DLElBQUlFLENBQUwsR0FBV0QsSUFBSSxDQUFDQyxDQUFyQixJQUEyQlcsQ0FBM0IsR0FBK0JFLENBQXZDO0FBQ0EsV0FBTyxDQUFFQyxLQUFLRixDQUFOLEdBQVlFLE1BQU8sS0FBS0YsQ0FBekIsSUFBZ0NkLENBQXZDO0FBQ0g7O0FBRUQsWUFBU0ssRUFBVCxDQUFZTixDQUFaLEVBQWVDLENBQWYsRUFBa0JDLENBQWxCLEVBQXFCQyxDQUFyQixFQUF3QlcsQ0FBeEIsRUFBMkJDLENBQTNCLEVBQThCQyxDQUE5QixFQUFpQztBQUM3QixRQUFJQyxJQUFJakIsS0FBS0MsSUFBSUMsQ0FBSixHQUFRQyxDQUFiLElBQWtCVyxDQUFsQixHQUFzQkUsQ0FBOUI7QUFDQSxXQUFPLENBQUVDLEtBQUtGLENBQU4sR0FBWUUsTUFBTyxLQUFLRixDQUF6QixJQUFnQ2QsQ0FBdkM7QUFDSDs7QUFFRCxZQUFTTSxFQUFULENBQVlQLENBQVosRUFBZUMsQ0FBZixFQUFrQkMsQ0FBbEIsRUFBcUJDLENBQXJCLEVBQXdCVyxDQUF4QixFQUEyQkMsQ0FBM0IsRUFBOEJDLENBQTlCLEVBQWlDO0FBQzdCLFFBQUlDLElBQUlqQixLQUFLRSxLQUFLRCxJQUFJLENBQUNFLENBQVYsQ0FBTCxJQUFxQlcsQ0FBckIsR0FBeUJFLENBQWpDO0FBQ0EsV0FBTyxDQUFFQyxLQUFLRixDQUFOLEdBQVlFLE1BQU8sS0FBS0YsQ0FBekIsSUFBZ0NkLENBQXZDO0FBQ0g7O0FBRUQ7Ozs7Ozs7Ozs7Ozs7O0FBY0FuTSxLQUFFNEssR0FBRixHQUFRL0UsT0FBT1EsYUFBUCxDQUFxQnVFLEdBQXJCLENBQVI7O0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FBY0E1SyxLQUFFb04sT0FBRixHQUFZdkgsT0FBT1csaUJBQVAsQ0FBeUJvRSxHQUF6QixDQUFaO0FBQ0gsR0F2UEEsRUF1UENwTCxJQXZQRCxDQUFEOztBQTBQQSxTQUFPRCxTQUFTcUwsR0FBaEI7QUFFQSxFQTNRQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVU1TCxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QjtBQUMxQixNQUFJLGdDQUFPRSxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsQ0FBUCxvQ0FBbUJMLE9BQW5CO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSWUsWUFBWWhCLE1BQU1nQixTQUF0QjtBQUNBLE9BQUk0RSxTQUFTNUYsTUFBTTRGLE1BQW5CO0FBQ0EsT0FBSWEsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBO0FBQ0EsT0FBSXlHLElBQUksRUFBUjs7QUFFQTs7O0FBR0EsT0FBSUMsT0FBTzVHLE9BQU80RyxJQUFQLEdBQWN6SCxPQUFPekYsTUFBUCxDQUFjO0FBQ25DMkYsY0FBVSxvQkFBWTtBQUNsQixVQUFLOEUsS0FBTCxHQUFhLElBQUk1SixVQUFVVCxJQUFkLENBQW1CLENBQzVCLFVBRDRCLEVBQ2hCLFVBRGdCLEVBRTVCLFVBRjRCLEVBRWhCLFVBRmdCLEVBRzVCLFVBSDRCLENBQW5CLENBQWI7QUFLSCxLQVBrQzs7QUFTbkNrRixxQkFBaUIseUJBQVVvRixDQUFWLEVBQWFyRixNQUFiLEVBQXFCO0FBQ2xDO0FBQ0EsU0FBSXdGLElBQUksS0FBS0osS0FBTCxDQUFXM0osS0FBbkI7O0FBRUE7QUFDQSxTQUFJZ0wsSUFBSWpCLEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSWtCLElBQUlsQixFQUFFLENBQUYsQ0FBUjtBQUNBLFNBQUltQixJQUFJbkIsRUFBRSxDQUFGLENBQVI7QUFDQSxTQUFJb0IsSUFBSXBCLEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSS9HLElBQUkrRyxFQUFFLENBQUYsQ0FBUjs7QUFFQTtBQUNBLFVBQUssSUFBSWxKLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekIsVUFBSUEsSUFBSSxFQUFSLEVBQVk7QUFDUnNMLFNBQUV0TCxDQUFGLElBQU8rSSxFQUFFckYsU0FBUzFELENBQVgsSUFBZ0IsQ0FBdkI7QUFDSCxPQUZELE1BRU87QUFDSCxXQUFJb0wsSUFBSUUsRUFBRXRMLElBQUksQ0FBTixJQUFXc0wsRUFBRXRMLElBQUksQ0FBTixDQUFYLEdBQXNCc0wsRUFBRXRMLElBQUksRUFBTixDQUF0QixHQUFrQ3NMLEVBQUV0TCxJQUFJLEVBQU4sQ0FBMUM7QUFDQXNMLFNBQUV0TCxDQUFGLElBQVFvTCxLQUFLLENBQU4sR0FBWUEsTUFBTSxFQUF6QjtBQUNIOztBQUVELFVBQUlELElBQUksQ0FBRWhCLEtBQUssQ0FBTixHQUFZQSxNQUFNLEVBQW5CLElBQTBCaEksQ0FBMUIsR0FBOEJtSixFQUFFdEwsQ0FBRixDQUF0QztBQUNBLFVBQUlBLElBQUksRUFBUixFQUFZO0FBQ1JtTCxZQUFLLENBQUVmLElBQUlDLENBQUwsR0FBVyxDQUFDRCxDQUFELEdBQUtFLENBQWpCLElBQXVCLFVBQTVCO0FBQ0gsT0FGRCxNQUVPLElBQUl0SyxJQUFJLEVBQVIsRUFBWTtBQUNmbUwsWUFBSyxDQUFDZixJQUFJQyxDQUFKLEdBQVFDLENBQVQsSUFBYyxVQUFuQjtBQUNILE9BRk0sTUFFQSxJQUFJdEssSUFBSSxFQUFSLEVBQVk7QUFDZm1MLFlBQUssQ0FBRWYsSUFBSUMsQ0FBTCxHQUFXRCxJQUFJRSxDQUFmLEdBQXFCRCxJQUFJQyxDQUExQixJQUFnQyxVQUFyQztBQUNILE9BRk0sTUFFQSxpQkFBa0I7QUFDckJhLGFBQUssQ0FBQ2YsSUFBSUMsQ0FBSixHQUFRQyxDQUFULElBQWMsVUFBbkI7QUFDSDs7QUFFRG5JLFVBQUltSSxDQUFKO0FBQ0FBLFVBQUlELENBQUo7QUFDQUEsVUFBS0QsS0FBSyxFQUFOLEdBQWFBLE1BQU0sQ0FBdkI7QUFDQUEsVUFBSUQsQ0FBSjtBQUNBQSxVQUFJZ0IsQ0FBSjtBQUNIOztBQUVEO0FBQ0FqQyxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9pQixDQUFSLEdBQWEsQ0FBcEI7QUFDQWpCLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBT2tCLENBQVIsR0FBYSxDQUFwQjtBQUNBbEIsT0FBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPbUIsQ0FBUixHQUFhLENBQXBCO0FBQ0FuQixPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9vQixDQUFSLEdBQWEsQ0FBcEI7QUFDQXBCLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTy9HLENBQVIsR0FBYSxDQUFwQjtBQUNILEtBckRrQzs7QUF1RG5Da0MsaUJBQWEsdUJBQVk7QUFDckI7QUFDQSxTQUFJeEIsT0FBTyxLQUFLSCxLQUFoQjtBQUNBLFNBQUlNLFlBQVlILEtBQUsxRCxLQUFyQjs7QUFFQSxTQUFJd0wsYUFBYSxLQUFLaEksV0FBTCxHQUFtQixDQUFwQztBQUNBLFNBQUlpSSxZQUFZL0gsS0FBS3pELFFBQUwsR0FBZ0IsQ0FBaEM7O0FBRUE7QUFDQTRELGVBQVU0SCxjQUFjLENBQXhCLEtBQThCLFFBQVMsS0FBS0EsWUFBWSxFQUF4RDtBQUNBNUgsZUFBVSxDQUFHNEgsWUFBWSxFQUFiLEtBQXFCLENBQXRCLElBQTRCLENBQTdCLElBQWtDLEVBQTVDLElBQWtEbk4sS0FBS3FOLEtBQUwsQ0FBV0gsYUFBYSxXQUF4QixDQUFsRDtBQUNBM0gsZUFBVSxDQUFHNEgsWUFBWSxFQUFiLEtBQXFCLENBQXRCLElBQTRCLENBQTdCLElBQWtDLEVBQTVDLElBQWtERCxVQUFsRDtBQUNBOUgsVUFBS3pELFFBQUwsR0FBZ0I0RCxVQUFVM0QsTUFBVixHQUFtQixDQUFuQzs7QUFFQTtBQUNBLFVBQUt5RCxRQUFMOztBQUVBO0FBQ0EsWUFBTyxLQUFLZ0csS0FBWjtBQUNILEtBMUVrQzs7QUE0RW5DN0osV0FBTyxpQkFBWTtBQUNmLFNBQUlBLFFBQVE2RSxPQUFPN0UsS0FBUCxDQUFha0IsSUFBYixDQUFrQixJQUFsQixDQUFaO0FBQ0FsQixXQUFNNkosS0FBTixHQUFjLEtBQUtBLEtBQUwsQ0FBVzdKLEtBQVgsRUFBZDs7QUFFQSxZQUFPQSxLQUFQO0FBQ0g7QUFqRmtDLElBQWQsQ0FBekI7O0FBb0ZBOzs7Ozs7Ozs7Ozs7OztBQWNBaEIsS0FBRXNOLElBQUYsR0FBU3pILE9BQU9RLGFBQVAsQ0FBcUJpSCxJQUFyQixDQUFUOztBQUVBOzs7Ozs7Ozs7Ozs7OztBQWNBdE4sS0FBRXVOLFFBQUYsR0FBYTFILE9BQU9XLGlCQUFQLENBQXlCOEcsSUFBekIsQ0FBYjtBQUNILEdBaklBLEdBQUQ7O0FBb0lBLFNBQU8vTixTQUFTK04sSUFBaEI7QUFFQSxFQXJKQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVV0TyxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QjtBQUMxQixNQUFJLGdDQUFPRSxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsQ0FBUCxvQ0FBbUJMLE9BQW5CO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGFBQVVDLElBQVYsRUFBZ0I7QUFDYjtBQUNBLE9BQUlRLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSWUsWUFBWWhCLE1BQU1nQixTQUF0QjtBQUNBLE9BQUk0RSxTQUFTNUYsTUFBTTRGLE1BQW5CO0FBQ0EsT0FBSWEsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBO0FBQ0EsT0FBSXFFLElBQUksRUFBUjtBQUNBLE9BQUl1QyxJQUFJLEVBQVI7O0FBRUE7QUFDQyxnQkFBWTtBQUNULGFBQVNDLE9BQVQsQ0FBaUJOLENBQWpCLEVBQW9CO0FBQ2hCLFNBQUlPLFFBQVFsTyxLQUFLbU8sSUFBTCxDQUFVUixDQUFWLENBQVo7QUFDQSxVQUFLLElBQUlTLFNBQVMsQ0FBbEIsRUFBcUJBLFVBQVVGLEtBQS9CLEVBQXNDRSxRQUF0QyxFQUFnRDtBQUM1QyxVQUFJLEVBQUVULElBQUlTLE1BQU4sQ0FBSixFQUFtQjtBQUNmLGNBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBRUQsWUFBTyxJQUFQO0FBQ0g7O0FBRUQsYUFBU0MsaUJBQVQsQ0FBMkJWLENBQTNCLEVBQThCO0FBQzFCLFlBQVEsQ0FBQ0EsS0FBS0EsSUFBSSxDQUFULENBQUQsSUFBZ0IsV0FBakIsR0FBZ0MsQ0FBdkM7QUFDSDs7QUFFRCxRQUFJQSxJQUFJLENBQVI7QUFDQSxRQUFJVyxTQUFTLENBQWI7QUFDQSxXQUFPQSxTQUFTLEVBQWhCLEVBQW9CO0FBQ2hCLFNBQUlMLFFBQVFOLENBQVIsQ0FBSixFQUFnQjtBQUNaLFVBQUlXLFNBQVMsQ0FBYixFQUFnQjtBQUNaN0MsU0FBRTZDLE1BQUYsSUFBWUQsa0JBQWtCck8sS0FBS3VPLEdBQUwsQ0FBU1osQ0FBVCxFQUFZLElBQUksQ0FBaEIsQ0FBbEIsQ0FBWjtBQUNIO0FBQ0RLLFFBQUVNLE1BQUYsSUFBWUQsa0JBQWtCck8sS0FBS3VPLEdBQUwsQ0FBU1osQ0FBVCxFQUFZLElBQUksQ0FBaEIsQ0FBbEIsQ0FBWjs7QUFFQVc7QUFDSDs7QUFFRFg7QUFDSDtBQUNKLElBOUJBLEdBQUQ7O0FBZ0NBO0FBQ0EsT0FBSUUsSUFBSSxFQUFSOztBQUVBOzs7QUFHQSxPQUFJVyxTQUFTdEgsT0FBT3NILE1BQVAsR0FBZ0JuSSxPQUFPekYsTUFBUCxDQUFjO0FBQ3ZDMkYsY0FBVSxvQkFBWTtBQUNsQixVQUFLOEUsS0FBTCxHQUFhLElBQUk1SixVQUFVVCxJQUFkLENBQW1CeUssRUFBRTlJLEtBQUYsQ0FBUSxDQUFSLENBQW5CLENBQWI7QUFDSCxLQUhzQzs7QUFLdkN1RCxxQkFBaUIseUJBQVVvRixDQUFWLEVBQWFyRixNQUFiLEVBQXFCO0FBQ2xDO0FBQ0EsU0FBSXdGLElBQUksS0FBS0osS0FBTCxDQUFXM0osS0FBbkI7O0FBRUE7QUFDQSxTQUFJZ0wsSUFBSWpCLEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSWtCLElBQUlsQixFQUFFLENBQUYsQ0FBUjtBQUNBLFNBQUltQixJQUFJbkIsRUFBRSxDQUFGLENBQVI7QUFDQSxTQUFJb0IsSUFBSXBCLEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSS9HLElBQUkrRyxFQUFFLENBQUYsQ0FBUjtBQUNBLFNBQUlnRCxJQUFJaEQsRUFBRSxDQUFGLENBQVI7QUFDQSxTQUFJaUQsSUFBSWpELEVBQUUsQ0FBRixDQUFSO0FBQ0EsU0FBSWtELElBQUlsRCxFQUFFLENBQUYsQ0FBUjs7QUFFQTtBQUNBLFVBQUssSUFBSWxKLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekIsVUFBSUEsSUFBSSxFQUFSLEVBQVk7QUFDUnNMLFNBQUV0TCxDQUFGLElBQU8rSSxFQUFFckYsU0FBUzFELENBQVgsSUFBZ0IsQ0FBdkI7QUFDSCxPQUZELE1BRU87QUFDSCxXQUFJcU0sVUFBVWYsRUFBRXRMLElBQUksRUFBTixDQUFkO0FBQ0EsV0FBSXNNLFNBQVUsQ0FBRUQsV0FBVyxFQUFaLEdBQW1CQSxZQUFZLENBQWhDLEtBQ0VBLFdBQVcsRUFBWixHQUFtQkEsWUFBWSxFQURoQyxJQUVFQSxZQUFZLENBRjVCOztBQUlBLFdBQUlFLFVBQVVqQixFQUFFdEwsSUFBSSxDQUFOLENBQWQ7QUFDQSxXQUFJd00sU0FBVSxDQUFFRCxXQUFXLEVBQVosR0FBbUJBLFlBQVksRUFBaEMsS0FDRUEsV0FBVyxFQUFaLEdBQW1CQSxZQUFZLEVBRGhDLElBRUVBLFlBQVksRUFGNUI7O0FBSUFqQixTQUFFdEwsQ0FBRixJQUFPc00sU0FBU2hCLEVBQUV0TCxJQUFJLENBQU4sQ0FBVCxHQUFvQndNLE1BQXBCLEdBQTZCbEIsRUFBRXRMLElBQUksRUFBTixDQUFwQztBQUNIOztBQUVELFVBQUl5TSxLQUFPdEssSUFBSStKLENBQUwsR0FBVyxDQUFDL0osQ0FBRCxHQUFLZ0ssQ0FBMUI7QUFDQSxVQUFJTyxNQUFPdkMsSUFBSUMsQ0FBTCxHQUFXRCxJQUFJRSxDQUFmLEdBQXFCRCxJQUFJQyxDQUFuQzs7QUFFQSxVQUFJc0MsU0FBUyxDQUFFeEMsS0FBSyxFQUFOLEdBQWFBLE1BQU0sQ0FBcEIsS0FBNEJBLEtBQUssRUFBTixHQUFhQSxNQUFNLEVBQTlDLEtBQXVEQSxLQUFLLEVBQU4sR0FBYUEsTUFBTSxFQUF6RSxDQUFiO0FBQ0EsVUFBSXlDLFNBQVMsQ0FBRXpLLEtBQUssRUFBTixHQUFhQSxNQUFNLENBQXBCLEtBQTRCQSxLQUFLLEVBQU4sR0FBYUEsTUFBTSxFQUE5QyxLQUF1REEsS0FBSyxDQUFOLEdBQWFBLE1BQU0sRUFBekUsQ0FBYjs7QUFFQSxVQUFJMEssS0FBS1QsSUFBSVEsTUFBSixHQUFhSCxFQUFiLEdBQWtCaEIsRUFBRXpMLENBQUYsQ0FBbEIsR0FBeUJzTCxFQUFFdEwsQ0FBRixDQUFsQztBQUNBLFVBQUk4TSxLQUFLSCxTQUFTRCxHQUFsQjs7QUFFQU4sVUFBSUQsQ0FBSjtBQUNBQSxVQUFJRCxDQUFKO0FBQ0FBLFVBQUkvSixDQUFKO0FBQ0FBLFVBQUttSSxJQUFJdUMsRUFBTCxHQUFXLENBQWY7QUFDQXZDLFVBQUlELENBQUo7QUFDQUEsVUFBSUQsQ0FBSjtBQUNBQSxVQUFJRCxDQUFKO0FBQ0FBLFVBQUswQyxLQUFLQyxFQUFOLEdBQVksQ0FBaEI7QUFDSDs7QUFFRDtBQUNBNUQsT0FBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPaUIsQ0FBUixHQUFhLENBQXBCO0FBQ0FqQixPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9rQixDQUFSLEdBQWEsQ0FBcEI7QUFDQWxCLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBT21CLENBQVIsR0FBYSxDQUFwQjtBQUNBbkIsT0FBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPb0IsQ0FBUixHQUFhLENBQXBCO0FBQ0FwQixPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8vRyxDQUFSLEdBQWEsQ0FBcEI7QUFDQStHLE9BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBT2dELENBQVIsR0FBYSxDQUFwQjtBQUNBaEQsT0FBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPaUQsQ0FBUixHQUFhLENBQXBCO0FBQ0FqRCxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9rRCxDQUFSLEdBQWEsQ0FBcEI7QUFDSCxLQWpFc0M7O0FBbUV2Qy9ILGlCQUFhLHVCQUFZO0FBQ3JCO0FBQ0EsU0FBSXhCLE9BQU8sS0FBS0gsS0FBaEI7QUFDQSxTQUFJTSxZQUFZSCxLQUFLMUQsS0FBckI7O0FBRUEsU0FBSXdMLGFBQWEsS0FBS2hJLFdBQUwsR0FBbUIsQ0FBcEM7QUFDQSxTQUFJaUksWUFBWS9ILEtBQUt6RCxRQUFMLEdBQWdCLENBQWhDOztBQUVBO0FBQ0E0RCxlQUFVNEgsY0FBYyxDQUF4QixLQUE4QixRQUFTLEtBQUtBLFlBQVksRUFBeEQ7QUFDQTVILGVBQVUsQ0FBRzRILFlBQVksRUFBYixLQUFxQixDQUF0QixJQUE0QixDQUE3QixJQUFrQyxFQUE1QyxJQUFrRG5OLEtBQUtxTixLQUFMLENBQVdILGFBQWEsV0FBeEIsQ0FBbEQ7QUFDQTNILGVBQVUsQ0FBRzRILFlBQVksRUFBYixLQUFxQixDQUF0QixJQUE0QixDQUE3QixJQUFrQyxFQUE1QyxJQUFrREQsVUFBbEQ7QUFDQTlILFVBQUt6RCxRQUFMLEdBQWdCNEQsVUFBVTNELE1BQVYsR0FBbUIsQ0FBbkM7O0FBRUE7QUFDQSxVQUFLeUQsUUFBTDs7QUFFQTtBQUNBLFlBQU8sS0FBS2dHLEtBQVo7QUFDSCxLQXRGc0M7O0FBd0Z2QzdKLFdBQU8saUJBQVk7QUFDZixTQUFJQSxRQUFRNkUsT0FBTzdFLEtBQVAsQ0FBYWtCLElBQWIsQ0FBa0IsSUFBbEIsQ0FBWjtBQUNBbEIsV0FBTTZKLEtBQU4sR0FBYyxLQUFLQSxLQUFMLENBQVc3SixLQUFYLEVBQWQ7O0FBRUEsWUFBT0EsS0FBUDtBQUNIO0FBN0ZzQyxJQUFkLENBQTdCOztBQWdHQTs7Ozs7Ozs7Ozs7Ozs7QUFjQWhCLEtBQUVnTyxNQUFGLEdBQVduSSxPQUFPUSxhQUFQLENBQXFCMkgsTUFBckIsQ0FBWDs7QUFFQTs7Ozs7Ozs7Ozs7Ozs7QUFjQWhPLEtBQUU4TyxVQUFGLEdBQWVqSixPQUFPVyxpQkFBUCxDQUF5QndILE1BQXpCLENBQWY7QUFDSCxHQWxMQSxFQWtMQ3hPLElBbExELENBQUQ7O0FBcUxBLFNBQU9ELFNBQVN5TyxNQUFoQjtBQUVBLEVBdE1DLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVWhQLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLENBQVAsb0NBQStCTCxPQUEvQjtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixlQUFZO0FBQ1Q7QUFDQSxPQUFJUyxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJeUYsU0FBUzFHLEVBQUU0RyxJQUFmO0FBQ0EsT0FBSW9ILFNBQVN0SCxPQUFPc0gsTUFBcEI7O0FBRUE7OztBQUdBLE9BQUllLFNBQVNySSxPQUFPcUksTUFBUCxHQUFnQmYsT0FBTzVOLE1BQVAsQ0FBYztBQUN2QzJGLGNBQVUsb0JBQVk7QUFDbEIsVUFBSzhFLEtBQUwsR0FBYSxJQUFJNUosVUFBVVQsSUFBZCxDQUFtQixDQUM1QixVQUQ0QixFQUNoQixVQURnQixFQUNKLFVBREksRUFDUSxVQURSLEVBRTVCLFVBRjRCLEVBRWhCLFVBRmdCLEVBRUosVUFGSSxFQUVRLFVBRlIsQ0FBbkIsQ0FBYjtBQUlILEtBTnNDOztBQVF2QzRGLGlCQUFhLHVCQUFZO0FBQ3JCLFNBQUlELE9BQU82SCxPQUFPNUgsV0FBUCxDQUFtQmxFLElBQW5CLENBQXdCLElBQXhCLENBQVg7O0FBRUFpRSxVQUFLaEYsUUFBTCxJQUFpQixDQUFqQjs7QUFFQSxZQUFPZ0YsSUFBUDtBQUNIO0FBZHNDLElBQWQsQ0FBN0I7O0FBaUJBOzs7Ozs7Ozs7Ozs7OztBQWNBbkcsS0FBRStPLE1BQUYsR0FBV2YsT0FBTzNILGFBQVAsQ0FBcUIwSSxNQUFyQixDQUFYOztBQUVBOzs7Ozs7Ozs7Ozs7OztBQWNBL08sS0FBRWdQLFVBQUYsR0FBZWhCLE9BQU94SCxpQkFBUCxDQUF5QnVJLE1BQXpCLENBQWY7QUFDSCxHQTNEQSxHQUFEOztBQThEQSxTQUFPeFAsU0FBU3dQLE1BQWhCO0FBRUEsRUEvRUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVL1AsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsQ0FBUCxvQ0FBaUNMLE9BQWpDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSTJGLFNBQVM1RixNQUFNNEYsTUFBbkI7QUFDQSxPQUFJaUIsUUFBUTlHLEVBQUUrRyxHQUFkO0FBQ0EsT0FBSUMsVUFBVUYsTUFBTUcsSUFBcEI7QUFDQSxPQUFJRyxlQUFlTixNQUFNN0YsU0FBekI7QUFDQSxPQUFJeUYsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBLFlBQVNxSSxjQUFULEdBQTBCO0FBQ3RCLFdBQU9qSSxRQUFRdEgsTUFBUixDQUFlZ0IsS0FBZixDQUFxQnNHLE9BQXJCLEVBQThCckcsU0FBOUIsQ0FBUDtBQUNIOztBQUVEO0FBQ0EsT0FBSTZNLElBQUksQ0FDSnlCLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQURJLEVBQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FEcEMsRUFFSkEsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBRkksRUFFb0NBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQUZwQyxFQUdKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FISSxFQUdvQ0EsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBSHBDLEVBSUpBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQUpJLEVBSW9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FKcEMsRUFLSkEsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBTEksRUFLb0NBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQUxwQyxFQU1KQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FOSSxFQU1vQ0EsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBTnBDLEVBT0pBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQVBJLEVBT29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FQcEMsRUFRSkEsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBUkksRUFRb0NBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQVJwQyxFQVNKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FUSSxFQVNvQ0EsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBVHBDLEVBVUpBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQVZJLEVBVW9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FWcEMsRUFXSkEsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBWEksRUFXb0NBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQVhwQyxFQVlKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FaSSxFQVlvQ0EsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBWnBDLEVBYUpBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQWJJLEVBYW9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FicEMsRUFjSkEsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBZEksRUFjb0NBLGVBQWUsVUFBZixFQUEyQixVQUEzQixDQWRwQyxFQWVKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FmSSxFQWVvQ0EsZUFBZSxVQUFmLEVBQTJCLFVBQTNCLENBZnBDLEVBZ0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FoQkksRUFnQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FoQnBDLEVBaUJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FqQkksRUFpQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FqQnBDLEVBa0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FsQkksRUFrQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FsQnBDLEVBbUJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FuQkksRUFtQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FuQnBDLEVBb0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FwQkksRUFvQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FwQnBDLEVBcUJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FyQkksRUFxQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FyQnBDLEVBc0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F0QkksRUFzQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F0QnBDLEVBdUJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F2QkksRUF1Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F2QnBDLEVBd0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F4QkksRUF3Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F4QnBDLEVBeUJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F6QkksRUF5Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F6QnBDLEVBMEJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0ExQkksRUEwQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0ExQnBDLEVBMkJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0EzQkksRUEyQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0EzQnBDLEVBNEJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E1QkksRUE0Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E1QnBDLEVBNkJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E3QkksRUE2Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E3QnBDLEVBOEJKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E5QkksRUE4Qm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0E5QnBDLEVBK0JKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0EvQkksRUErQm9DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0EvQnBDLEVBZ0NKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FoQ0ksRUFnQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FoQ3BDLEVBaUNKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FqQ0ksRUFpQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FqQ3BDLEVBa0NKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FsQ0ksRUFrQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FsQ3BDLEVBbUNKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FuQ0ksRUFtQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FuQ3BDLEVBb0NKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FwQ0ksRUFvQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FwQ3BDLEVBcUNKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FyQ0ksRUFxQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0FyQ3BDLEVBc0NKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F0Q0ksRUFzQ29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F0Q3BDLEVBdUNKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F2Q0ksRUF1Q29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F2Q3BDLEVBd0NKQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F4Q0ksRUF3Q29DQSxlQUFlLFVBQWYsRUFBMkIsVUFBM0IsQ0F4Q3BDLENBQVI7O0FBMkNBO0FBQ0EsT0FBSTVCLElBQUksRUFBUjtBQUNDLGdCQUFZO0FBQ1QsU0FBSyxJQUFJdEwsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEVBQXBCLEVBQXdCQSxHQUF4QixFQUE2QjtBQUN6QnNMLE9BQUV0TCxDQUFGLElBQU9rTixnQkFBUDtBQUNIO0FBQ0osSUFKQSxHQUFEOztBQU1BOzs7QUFHQSxPQUFJQyxTQUFTeEksT0FBT3dJLE1BQVAsR0FBZ0JySixPQUFPekYsTUFBUCxDQUFjO0FBQ3ZDMkYsY0FBVSxvQkFBWTtBQUNsQixVQUFLOEUsS0FBTCxHQUFhLElBQUl6RCxhQUFhNUcsSUFBakIsQ0FBc0IsQ0FDL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRCtCLEVBQ1csSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRFgsRUFFL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRitCLEVBRVcsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRlgsRUFHL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSCtCLEVBR1csSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSFgsRUFJL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSitCLEVBSVcsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSlgsQ0FBdEIsQ0FBYjtBQU1ILEtBUnNDOztBQVV2Q2tGLHFCQUFpQix5QkFBVW9GLENBQVYsRUFBYXJGLE1BQWIsRUFBcUI7QUFDbEM7QUFDQSxTQUFJd0YsSUFBSSxLQUFLSixLQUFMLENBQVczSixLQUFuQjs7QUFFQSxTQUFJaU8sS0FBS2xFLEVBQUUsQ0FBRixDQUFUO0FBQ0EsU0FBSW1FLEtBQUtuRSxFQUFFLENBQUYsQ0FBVDtBQUNBLFNBQUlvRSxLQUFLcEUsRUFBRSxDQUFGLENBQVQ7QUFDQSxTQUFJcUUsS0FBS3JFLEVBQUUsQ0FBRixDQUFUO0FBQ0EsU0FBSXNFLEtBQUt0RSxFQUFFLENBQUYsQ0FBVDtBQUNBLFNBQUl1RSxLQUFLdkUsRUFBRSxDQUFGLENBQVQ7QUFDQSxTQUFJd0UsS0FBS3hFLEVBQUUsQ0FBRixDQUFUO0FBQ0EsU0FBSXlFLEtBQUt6RSxFQUFFLENBQUYsQ0FBVDs7QUFFQSxTQUFJMEUsTUFBTVIsR0FBR2pJLElBQWI7QUFDQSxTQUFJMEksTUFBTVQsR0FBR2hJLEdBQWI7QUFDQSxTQUFJMEksTUFBTVQsR0FBR2xJLElBQWI7QUFDQSxTQUFJNEksTUFBTVYsR0FBR2pJLEdBQWI7QUFDQSxTQUFJNEksTUFBTVYsR0FBR25JLElBQWI7QUFDQSxTQUFJOEksTUFBTVgsR0FBR2xJLEdBQWI7QUFDQSxTQUFJOEksTUFBTVgsR0FBR3BJLElBQWI7QUFDQSxTQUFJZ0osTUFBTVosR0FBR25JLEdBQWI7QUFDQSxTQUFJZ0osTUFBTVosR0FBR3JJLElBQWI7QUFDQSxTQUFJa0osTUFBTWIsR0FBR3BJLEdBQWI7QUFDQSxTQUFJa0osTUFBTWIsR0FBR3RJLElBQWI7QUFDQSxTQUFJb0osTUFBTWQsR0FBR3JJLEdBQWI7QUFDQSxTQUFJb0osTUFBTWQsR0FBR3ZJLElBQWI7QUFDQSxTQUFJc0osTUFBTWYsR0FBR3RJLEdBQWI7QUFDQSxTQUFJc0osTUFBTWYsR0FBR3hJLElBQWI7QUFDQSxTQUFJd0osTUFBTWhCLEdBQUd2SSxHQUFiOztBQUVBO0FBQ0EsU0FBSXdKLEtBQUtoQixHQUFUO0FBQ0EsU0FBSWlCLEtBQUtoQixHQUFUO0FBQ0EsU0FBSWlCLEtBQUtoQixHQUFUO0FBQ0EsU0FBSWlCLEtBQUtoQixHQUFUO0FBQ0EsU0FBSXRCLEtBQUt1QixHQUFUO0FBQ0EsU0FBSWdCLEtBQUtmLEdBQVQ7QUFDQSxTQUFJZ0IsS0FBS2YsR0FBVDtBQUNBLFNBQUlnQixLQUFLZixHQUFUO0FBQ0EsU0FBSWdCLEtBQUtmLEdBQVQ7QUFDQSxTQUFJZ0IsS0FBS2YsR0FBVDtBQUNBLFNBQUlnQixLQUFLZixHQUFUO0FBQ0EsU0FBSWdCLEtBQUtmLEdBQVQ7QUFDQSxTQUFJZ0IsS0FBS2YsR0FBVDtBQUNBLFNBQUlnQixLQUFLZixHQUFUO0FBQ0EsU0FBSWdCLEtBQUtmLEdBQVQ7QUFDQSxTQUFJZ0IsS0FBS2YsR0FBVDs7QUFFQTtBQUNBLFVBQUssSUFBSTNPLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekI7QUFDQSxVQUFJMlAsS0FBS3JFLEVBQUV0TCxDQUFGLENBQVQ7O0FBRUE7QUFDQSxVQUFJQSxJQUFJLEVBQVIsRUFBWTtBQUNSLFdBQUk0UCxNQUFNRCxHQUFHeEssSUFBSCxHQUFVNEQsRUFBRXJGLFNBQVMxRCxJQUFJLENBQWYsSUFBd0IsQ0FBNUM7QUFDQSxXQUFJNlAsTUFBTUYsR0FBR3ZLLEdBQUgsR0FBVTJELEVBQUVyRixTQUFTMUQsSUFBSSxDQUFiLEdBQWlCLENBQW5CLElBQXdCLENBQTVDO0FBQ0gsT0FIRCxNQUdPO0FBQ0g7QUFDQSxXQUFJcU0sVUFBV2YsRUFBRXRMLElBQUksRUFBTixDQUFmO0FBQ0EsV0FBSThQLFdBQVd6RCxRQUFRbEgsSUFBdkI7QUFDQSxXQUFJNEssV0FBVzFELFFBQVFqSCxHQUF2QjtBQUNBLFdBQUk0SyxVQUFXLENBQUVGLGFBQWEsQ0FBZCxHQUFvQkMsWUFBWSxFQUFqQyxLQUEwQ0QsYUFBYSxDQUFkLEdBQW9CQyxZQUFZLEVBQXpFLElBQWlGRCxhQUFhLENBQTdHO0FBQ0EsV0FBSUcsVUFBVyxDQUFFRixhQUFhLENBQWQsR0FBb0JELFlBQVksRUFBakMsS0FBMENDLGFBQWEsQ0FBZCxHQUFvQkQsWUFBWSxFQUF6RSxLQUFrRkMsYUFBYSxDQUFkLEdBQW9CRCxZQUFZLEVBQWpILENBQWY7O0FBRUE7QUFDQSxXQUFJdkQsVUFBV2pCLEVBQUV0TCxJQUFJLENBQU4sQ0FBZjtBQUNBLFdBQUlrUSxXQUFXM0QsUUFBUXBILElBQXZCO0FBQ0EsV0FBSWdMLFdBQVc1RCxRQUFRbkgsR0FBdkI7QUFDQSxXQUFJZ0wsVUFBVyxDQUFFRixhQUFhLEVBQWQsR0FBcUJDLFlBQVksRUFBbEMsS0FBMkNELFlBQVksQ0FBYixHQUFtQkMsYUFBYSxFQUExRSxJQUFrRkQsYUFBYSxDQUE5RztBQUNBLFdBQUlHLFVBQVcsQ0FBRUYsYUFBYSxFQUFkLEdBQXFCRCxZQUFZLEVBQWxDLEtBQTJDQyxZQUFZLENBQWIsR0FBbUJELGFBQWEsRUFBMUUsS0FBbUZDLGFBQWEsQ0FBZCxHQUFvQkQsWUFBWSxFQUFsSCxDQUFmOztBQUVBO0FBQ0EsV0FBSUksTUFBT2hGLEVBQUV0TCxJQUFJLENBQU4sQ0FBWDtBQUNBLFdBQUl1USxPQUFPRCxJQUFJbkwsSUFBZjtBQUNBLFdBQUlxTCxPQUFPRixJQUFJbEwsR0FBZjs7QUFFQSxXQUFJcUwsT0FBUW5GLEVBQUV0TCxJQUFJLEVBQU4sQ0FBWjtBQUNBLFdBQUkwUSxRQUFRRCxLQUFLdEwsSUFBakI7QUFDQSxXQUFJd0wsUUFBUUYsS0FBS3JMLEdBQWpCOztBQUVBLFdBQUl5SyxNQUFNSSxVQUFVTyxJQUFwQjtBQUNBLFdBQUlaLE1BQU1JLFVBQVVPLElBQVYsSUFBbUJWLFFBQVEsQ0FBVCxHQUFlSSxZQUFZLENBQTNCLEdBQWdDLENBQWhDLEdBQW9DLENBQXRELENBQVY7QUFDQSxXQUFJSixNQUFNQSxNQUFNUSxPQUFoQjtBQUNBLFdBQUlULE1BQU1BLE1BQU1RLE9BQU4sSUFBa0JQLFFBQVEsQ0FBVCxHQUFlUSxZQUFZLENBQTNCLEdBQWdDLENBQWhDLEdBQW9DLENBQXJELENBQVY7QUFDQSxXQUFJUixNQUFNQSxNQUFNYyxLQUFoQjtBQUNBLFdBQUlmLE1BQU1BLE1BQU1jLEtBQU4sSUFBZ0JiLFFBQVEsQ0FBVCxHQUFlYyxVQUFVLENBQXpCLEdBQThCLENBQTlCLEdBQWtDLENBQWpELENBQVY7O0FBRUFoQixVQUFHeEssSUFBSCxHQUFVeUssR0FBVjtBQUNBRCxVQUFHdkssR0FBSCxHQUFVeUssR0FBVjtBQUNIOztBQUVELFVBQUllLE1BQVF6QixLQUFLRSxFQUFOLEdBQWEsQ0FBQ0YsRUFBRCxHQUFNSSxFQUE5QjtBQUNBLFVBQUlzQixNQUFRekIsS0FBS0UsRUFBTixHQUFhLENBQUNGLEVBQUQsR0FBTUksRUFBOUI7QUFDQSxVQUFJc0IsT0FBUWxDLEtBQUtFLEVBQU4sR0FBYUYsS0FBS25DLEVBQWxCLEdBQXlCcUMsS0FBS3JDLEVBQXpDO0FBQ0EsVUFBSXNFLE9BQVFsQyxLQUFLRSxFQUFOLEdBQWFGLEtBQUtHLEVBQWxCLEdBQXlCRCxLQUFLQyxFQUF6Qzs7QUFFQSxVQUFJZ0MsVUFBVSxDQUFFcEMsT0FBTyxFQUFSLEdBQWVDLE1BQU0sQ0FBdEIsS0FBK0JELE1BQU0sRUFBUCxHQUFlQyxPQUFPLENBQXBELEtBQTRERCxNQUFNLEVBQVAsR0FBY0MsT0FBTyxDQUFoRixDQUFkO0FBQ0EsVUFBSW9DLFVBQVUsQ0FBRXBDLE9BQU8sRUFBUixHQUFlRCxNQUFNLENBQXRCLEtBQStCQyxNQUFNLEVBQVAsR0FBZUQsT0FBTyxDQUFwRCxLQUE0REMsTUFBTSxFQUFQLEdBQWNELE9BQU8sQ0FBaEYsQ0FBZDtBQUNBLFVBQUlzQyxVQUFVLENBQUUvQixPQUFPLEVBQVIsR0FBZUMsTUFBTSxFQUF0QixLQUErQkQsT0FBTyxFQUFSLEdBQWVDLE1BQU0sRUFBbkQsS0FBNERELE1BQU0sRUFBUCxHQUFjQyxPQUFPLENBQWhGLENBQWQ7QUFDQSxVQUFJK0IsVUFBVSxDQUFFL0IsT0FBTyxFQUFSLEdBQWVELE1BQU0sRUFBdEIsS0FBK0JDLE9BQU8sRUFBUixHQUFlRCxNQUFNLEVBQW5ELEtBQTREQyxNQUFNLEVBQVAsR0FBY0QsT0FBTyxDQUFoRixDQUFkOztBQUVBO0FBQ0EsVUFBSWlDLEtBQU0zRixFQUFFekwsQ0FBRixDQUFWO0FBQ0EsVUFBSXFSLE1BQU1ELEdBQUdqTSxJQUFiO0FBQ0EsVUFBSW1NLE1BQU1GLEdBQUdoTSxHQUFiOztBQUVBLFVBQUltTSxNQUFNN0IsS0FBS3lCLE9BQWY7QUFDQSxVQUFJSyxNQUFNL0IsS0FBS3lCLE9BQUwsSUFBaUJLLFFBQVEsQ0FBVCxHQUFlN0IsT0FBTyxDQUF0QixHQUEyQixDQUEzQixHQUErQixDQUEvQyxDQUFWO0FBQ0EsVUFBSTZCLE1BQU1BLE1BQU1WLEdBQWhCO0FBQ0EsVUFBSVcsTUFBTUEsTUFBTVosR0FBTixJQUFjVyxRQUFRLENBQVQsR0FBZVYsUUFBUSxDQUF2QixHQUE0QixDQUE1QixHQUFnQyxDQUE3QyxDQUFWO0FBQ0EsVUFBSVUsTUFBTUEsTUFBTUQsR0FBaEI7QUFDQSxVQUFJRSxNQUFNQSxNQUFNSCxHQUFOLElBQWNFLFFBQVEsQ0FBVCxHQUFlRCxRQUFRLENBQXZCLEdBQTRCLENBQTVCLEdBQWdDLENBQTdDLENBQVY7QUFDQSxVQUFJQyxNQUFNQSxNQUFNMUIsR0FBaEI7QUFDQSxVQUFJMkIsTUFBTUEsTUFBTTVCLEdBQU4sSUFBYzJCLFFBQVEsQ0FBVCxHQUFlMUIsUUFBUSxDQUF2QixHQUE0QixDQUE1QixHQUFnQyxDQUE3QyxDQUFWOztBQUVBO0FBQ0EsVUFBSTRCLE1BQU1SLFVBQVVGLElBQXBCO0FBQ0EsVUFBSVcsTUFBTVYsVUFBVUYsSUFBVixJQUFtQlcsUUFBUSxDQUFULEdBQWVSLFlBQVksQ0FBM0IsR0FBZ0MsQ0FBaEMsR0FBb0MsQ0FBdEQsQ0FBVjs7QUFFQTtBQUNBeEIsV0FBS0YsRUFBTDtBQUNBRyxXQUFLRixFQUFMO0FBQ0FELFdBQUtGLEVBQUw7QUFDQUcsV0FBS0YsRUFBTDtBQUNBRCxXQUFLRixFQUFMO0FBQ0FHLFdBQUtGLEVBQUw7QUFDQUEsV0FBTUYsS0FBS3FDLEdBQU4sR0FBYSxDQUFsQjtBQUNBcEMsV0FBTUYsS0FBS3VDLEdBQUwsSUFBYXBDLE9BQU8sQ0FBUixHQUFjRixPQUFPLENBQXJCLEdBQTBCLENBQTFCLEdBQThCLENBQTFDLENBQUQsR0FBaUQsQ0FBdEQ7QUFDQUQsV0FBS3hDLEVBQUw7QUFDQXlDLFdBQUtGLEVBQUw7QUFDQXZDLFdBQUtxQyxFQUFMO0FBQ0FFLFdBQUtELEVBQUw7QUFDQUQsV0FBS0YsRUFBTDtBQUNBRyxXQUFLRixFQUFMO0FBQ0FBLFdBQU0wQyxNQUFNRSxHQUFQLEdBQWMsQ0FBbkI7QUFDQTdDLFdBQU00QyxNQUFNRSxHQUFOLElBQWM3QyxPQUFPLENBQVIsR0FBYzBDLFFBQVEsQ0FBdEIsR0FBMkIsQ0FBM0IsR0FBK0IsQ0FBNUMsQ0FBRCxHQUFtRCxDQUF4RDtBQUNIOztBQUVEO0FBQ0ExRCxXQUFNVCxHQUFHaEksR0FBSCxHQUFXeUksTUFBTWdCLEVBQXZCO0FBQ0F6QixRQUFHakksSUFBSCxHQUFXeUksTUFBTWdCLEVBQU4sSUFBYWYsUUFBUSxDQUFULEdBQWVnQixPQUFPLENBQXRCLEdBQTJCLENBQTNCLEdBQStCLENBQTNDLENBQVg7QUFDQWQsV0FBTVYsR0FBR2pJLEdBQUgsR0FBVzJJLE1BQU1nQixFQUF2QjtBQUNBMUIsUUFBR2xJLElBQUgsR0FBVzJJLE1BQU1nQixFQUFOLElBQWFmLFFBQVEsQ0FBVCxHQUFlZ0IsT0FBTyxDQUF0QixHQUEyQixDQUEzQixHQUErQixDQUEzQyxDQUFYO0FBQ0FkLFdBQU1YLEdBQUdsSSxHQUFILEdBQVc2SSxNQUFNZSxFQUF2QjtBQUNBMUIsUUFBR25JLElBQUgsR0FBVzZJLE1BQU12QixFQUFOLElBQWF3QixRQUFRLENBQVQsR0FBZWUsT0FBTyxDQUF0QixHQUEyQixDQUEzQixHQUErQixDQUEzQyxDQUFYO0FBQ0FiLFdBQU1aLEdBQUduSSxHQUFILEdBQVcrSSxNQUFNZSxFQUF2QjtBQUNBM0IsUUFBR3BJLElBQUgsR0FBVytJLE1BQU1lLEVBQU4sSUFBYWQsUUFBUSxDQUFULEdBQWVlLE9BQU8sQ0FBdEIsR0FBMkIsQ0FBM0IsR0FBK0IsQ0FBM0MsQ0FBWDtBQUNBYixXQUFNYixHQUFHcEksR0FBSCxHQUFXaUosTUFBTWUsRUFBdkI7QUFDQTVCLFFBQUdySSxJQUFILEdBQVdpSixNQUFNZSxFQUFOLElBQWFkLFFBQVEsQ0FBVCxHQUFlZSxPQUFPLENBQXRCLEdBQTJCLENBQTNCLEdBQStCLENBQTNDLENBQVg7QUFDQWIsV0FBTWQsR0FBR3JJLEdBQUgsR0FBV21KLE1BQU1lLEVBQXZCO0FBQ0E3QixRQUFHdEksSUFBSCxHQUFXbUosTUFBTWUsRUFBTixJQUFhZCxRQUFRLENBQVQsR0FBZWUsT0FBTyxDQUF0QixHQUEyQixDQUEzQixHQUErQixDQUEzQyxDQUFYO0FBQ0FiLFdBQU1mLEdBQUd0SSxHQUFILEdBQVdxSixNQUFNZSxFQUF2QjtBQUNBOUIsUUFBR3ZJLElBQUgsR0FBV3FKLE1BQU1lLEVBQU4sSUFBYWQsUUFBUSxDQUFULEdBQWVlLE9BQU8sQ0FBdEIsR0FBMkIsQ0FBM0IsR0FBK0IsQ0FBM0MsQ0FBWDtBQUNBYixXQUFNaEIsR0FBR3ZJLEdBQUgsR0FBV3VKLE1BQU1lLEVBQXZCO0FBQ0EvQixRQUFHeEksSUFBSCxHQUFXdUosTUFBTWUsRUFBTixJQUFhZCxRQUFRLENBQVQsR0FBZWUsT0FBTyxDQUF0QixHQUEyQixDQUEzQixHQUErQixDQUEzQyxDQUFYO0FBQ0gsS0F0S3NDOztBQXdLdkNyTCxpQkFBYSx1QkFBWTtBQUNyQjtBQUNBLFNBQUl4QixPQUFPLEtBQUtILEtBQWhCO0FBQ0EsU0FBSU0sWUFBWUgsS0FBSzFELEtBQXJCOztBQUVBLFNBQUl3TCxhQUFhLEtBQUtoSSxXQUFMLEdBQW1CLENBQXBDO0FBQ0EsU0FBSWlJLFlBQVkvSCxLQUFLekQsUUFBTCxHQUFnQixDQUFoQzs7QUFFQTtBQUNBNEQsZUFBVTRILGNBQWMsQ0FBeEIsS0FBOEIsUUFBUyxLQUFLQSxZQUFZLEVBQXhEO0FBQ0E1SCxlQUFVLENBQUc0SCxZQUFZLEdBQWIsS0FBc0IsRUFBdkIsSUFBOEIsQ0FBL0IsSUFBb0MsRUFBOUMsSUFBb0RuTixLQUFLcU4sS0FBTCxDQUFXSCxhQUFhLFdBQXhCLENBQXBEO0FBQ0EzSCxlQUFVLENBQUc0SCxZQUFZLEdBQWIsS0FBc0IsRUFBdkIsSUFBOEIsQ0FBL0IsSUFBb0MsRUFBOUMsSUFBb0RELFVBQXBEO0FBQ0E5SCxVQUFLekQsUUFBTCxHQUFnQjRELFVBQVUzRCxNQUFWLEdBQW1CLENBQW5DOztBQUVBO0FBQ0EsVUFBS3lELFFBQUw7O0FBRUE7QUFDQSxTQUFJc0IsT0FBTyxLQUFLMEUsS0FBTCxDQUFXeEQsS0FBWCxFQUFYOztBQUVBO0FBQ0EsWUFBT2xCLElBQVA7QUFDSCxLQTlMc0M7O0FBZ012Q25GLFdBQU8saUJBQVk7QUFDZixTQUFJQSxRQUFRNkUsT0FBTzdFLEtBQVAsQ0FBYWtCLElBQWIsQ0FBa0IsSUFBbEIsQ0FBWjtBQUNBbEIsV0FBTTZKLEtBQU4sR0FBYyxLQUFLQSxLQUFMLENBQVc3SixLQUFYLEVBQWQ7O0FBRUEsWUFBT0EsS0FBUDtBQUNILEtBck1zQzs7QUF1TXZDaUUsZUFBVyxPQUFLO0FBdk11QixJQUFkLENBQTdCOztBQTBNQTs7Ozs7Ozs7Ozs7Ozs7QUFjQWpGLEtBQUVrUCxNQUFGLEdBQVdySixPQUFPUSxhQUFQLENBQXFCNkksTUFBckIsQ0FBWDs7QUFFQTs7Ozs7Ozs7Ozs7Ozs7QUFjQWxQLEtBQUUwVCxVQUFGLEdBQWU3TixPQUFPVyxpQkFBUCxDQUF5QjBJLE1BQXpCLENBQWY7QUFDSCxHQTlTQSxHQUFEOztBQWlUQSxTQUFPM1AsU0FBUzJQLE1BQWhCO0FBRUEsRUFsVUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVbFEsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixFQUFrRCxtQkFBQUEsQ0FBUSxFQUFSLENBQWxELENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxFQUF5Qix1QkFBekIsQ0FBUCxvQ0FBNkNMLE9BQTdDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJdUgsUUFBUTlHLEVBQUUrRyxHQUFkO0FBQ0EsT0FBSUMsVUFBVUYsTUFBTUcsSUFBcEI7QUFDQSxPQUFJRyxlQUFlTixNQUFNN0YsU0FBekI7QUFDQSxPQUFJeUYsU0FBUzFHLEVBQUU0RyxJQUFmO0FBQ0EsT0FBSXNJLFNBQVN4SSxPQUFPd0ksTUFBcEI7O0FBRUE7OztBQUdBLE9BQUl5RSxTQUFTak4sT0FBT2lOLE1BQVAsR0FBZ0J6RSxPQUFPOU8sTUFBUCxDQUFjO0FBQ3ZDMkYsY0FBVSxvQkFBWTtBQUNsQixVQUFLOEUsS0FBTCxHQUFhLElBQUl6RCxhQUFhNUcsSUFBakIsQ0FBc0IsQ0FDL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRCtCLEVBQ1csSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRFgsRUFFL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRitCLEVBRVcsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBRlgsRUFHL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSCtCLEVBR1csSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSFgsRUFJL0IsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSitCLEVBSVcsSUFBSXdHLFFBQVF4RyxJQUFaLENBQWlCLFVBQWpCLEVBQTZCLFVBQTdCLENBSlgsQ0FBdEIsQ0FBYjtBQU1ILEtBUnNDOztBQVV2QzRGLGlCQUFhLHVCQUFZO0FBQ3JCLFNBQUlELE9BQU8rSSxPQUFPOUksV0FBUCxDQUFtQmxFLElBQW5CLENBQXdCLElBQXhCLENBQVg7O0FBRUFpRSxVQUFLaEYsUUFBTCxJQUFpQixFQUFqQjs7QUFFQSxZQUFPZ0YsSUFBUDtBQUNIO0FBaEJzQyxJQUFkLENBQTdCOztBQW1CQTs7Ozs7Ozs7Ozs7Ozs7QUFjQW5HLEtBQUUyVCxNQUFGLEdBQVd6RSxPQUFPN0ksYUFBUCxDQUFxQnNOLE1BQXJCLENBQVg7O0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FBY0EzVCxLQUFFNFQsVUFBRixHQUFlMUUsT0FBTzFJLGlCQUFQLENBQXlCbU4sTUFBekIsQ0FBZjtBQUNILEdBOURBLEdBQUQ7O0FBaUVBLFNBQU9wVSxTQUFTb1UsTUFBaEI7QUFFQSxFQWxGQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVUzVSxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUFpQ0wsT0FBakM7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFMUIsYUFBVUMsSUFBVixFQUFnQjtBQUNiO0FBQ0EsT0FBSVEsSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJZSxZQUFZaEIsTUFBTWdCLFNBQXRCO0FBQ0EsT0FBSTRFLFNBQVM1RixNQUFNNEYsTUFBbkI7QUFDQSxPQUFJaUIsUUFBUTlHLEVBQUUrRyxHQUFkO0FBQ0EsT0FBSUMsVUFBVUYsTUFBTUcsSUFBcEI7QUFDQSxPQUFJUCxTQUFTMUcsRUFBRTRHLElBQWY7O0FBRUE7QUFDQSxPQUFJaU4sY0FBYyxFQUFsQjtBQUNBLE9BQUlDLGFBQWMsRUFBbEI7QUFDQSxPQUFJQyxrQkFBa0IsRUFBdEI7O0FBRUE7QUFDQyxnQkFBWTtBQUNUO0FBQ0EsUUFBSS9HLElBQUksQ0FBUjtBQUFBLFFBQVdnSCxJQUFJLENBQWY7QUFDQSxTQUFLLElBQUk5RyxJQUFJLENBQWIsRUFBZ0JBLElBQUksRUFBcEIsRUFBd0JBLEdBQXhCLEVBQTZCO0FBQ3pCMkcsaUJBQVk3RyxJQUFJLElBQUlnSCxDQUFwQixJQUEwQixDQUFDOUcsSUFBSSxDQUFMLEtBQVdBLElBQUksQ0FBZixJQUFvQixDQUFyQixHQUEwQixFQUFuRDs7QUFFQSxTQUFJK0csT0FBT0QsSUFBSSxDQUFmO0FBQ0EsU0FBSUUsT0FBTyxDQUFDLElBQUlsSCxDQUFKLEdBQVEsSUFBSWdILENBQWIsSUFBa0IsQ0FBN0I7QUFDQWhILFNBQUlpSCxJQUFKO0FBQ0FELFNBQUlFLElBQUo7QUFDSDs7QUFFRDtBQUNBLFNBQUssSUFBSWxILElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEIsVUFBSyxJQUFJZ0gsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QkYsaUJBQVc5RyxJQUFJLElBQUlnSCxDQUFuQixJQUF3QkEsSUFBSyxDQUFDLElBQUloSCxDQUFKLEdBQVEsSUFBSWdILENBQWIsSUFBa0IsQ0FBbkIsR0FBd0IsQ0FBcEQ7QUFDSDtBQUNKOztBQUVEO0FBQ0EsUUFBSUcsT0FBTyxJQUFYO0FBQ0EsU0FBSyxJQUFJcFMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEVBQXBCLEVBQXdCQSxHQUF4QixFQUE2QjtBQUN6QixTQUFJcVMsbUJBQW1CLENBQXZCO0FBQ0EsU0FBSUMsbUJBQW1CLENBQXZCOztBQUVBLFVBQUssSUFBSXhLLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEIsVUFBSXNLLE9BQU8sSUFBWCxFQUFpQjtBQUNiLFdBQUlHLGNBQWMsQ0FBQyxLQUFLekssQ0FBTixJQUFXLENBQTdCO0FBQ0EsV0FBSXlLLGNBQWMsRUFBbEIsRUFBc0I7QUFDbEJELDRCQUFvQixLQUFLQyxXQUF6QjtBQUNILFFBRkQsTUFFTyw0QkFBNkI7QUFDaENGLDZCQUFvQixLQUFNRSxjQUFjLEVBQXhDO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFVBQUlILE9BQU8sSUFBWCxFQUFpQjtBQUNiO0FBQ0FBLGNBQVFBLFFBQVEsQ0FBVCxHQUFjLElBQXJCO0FBQ0gsT0FIRCxNQUdPO0FBQ0hBLGdCQUFTLENBQVQ7QUFDSDtBQUNKOztBQUVESixxQkFBZ0JoUyxDQUFoQixJQUFxQmlGLFFBQVF0SCxNQUFSLENBQWUwVSxnQkFBZixFQUFpQ0MsZ0JBQWpDLENBQXJCO0FBQ0g7QUFDSixJQTlDQSxHQUFEOztBQWdEQTtBQUNBLE9BQUk1SixJQUFJLEVBQVI7QUFDQyxnQkFBWTtBQUNULFNBQUssSUFBSTFJLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekIwSSxPQUFFMUksQ0FBRixJQUFPaUYsUUFBUXRILE1BQVIsRUFBUDtBQUNIO0FBQ0osSUFKQSxHQUFEOztBQU1BOzs7QUFHQSxPQUFJNlUsT0FBTzdOLE9BQU82TixJQUFQLEdBQWMxTyxPQUFPekYsTUFBUCxDQUFjO0FBQ25DOzs7Ozs7OztBQVFBMEYsU0FBS0QsT0FBT0MsR0FBUCxDQUFXMUYsTUFBWCxDQUFrQjtBQUNuQm9VLG1CQUFjO0FBREssS0FBbEIsQ0FUOEI7O0FBYW5Dek8sY0FBVSxvQkFBWTtBQUNsQixTQUFJME8sUUFBUSxLQUFLQyxNQUFMLEdBQWMsRUFBMUI7QUFDQSxVQUFLLElBQUkzUyxJQUFJLENBQWIsRUFBZ0JBLElBQUksRUFBcEIsRUFBd0JBLEdBQXhCLEVBQTZCO0FBQ3pCMFMsWUFBTTFTLENBQU4sSUFBVyxJQUFJaUYsUUFBUXhHLElBQVosRUFBWDtBQUNIOztBQUVELFVBQUt5RSxTQUFMLEdBQWlCLENBQUMsT0FBTyxJQUFJLEtBQUthLEdBQUwsQ0FBUzBPLFlBQXJCLElBQXFDLEVBQXREO0FBQ0gsS0FwQmtDOztBQXNCbkM5TyxxQkFBaUIseUJBQVVvRixDQUFWLEVBQWFyRixNQUFiLEVBQXFCO0FBQ2xDO0FBQ0EsU0FBSWdQLFFBQVEsS0FBS0MsTUFBakI7QUFDQSxTQUFJQyxrQkFBa0IsS0FBSzFQLFNBQUwsR0FBaUIsQ0FBdkM7O0FBRUE7QUFDQSxVQUFLLElBQUlsRCxJQUFJLENBQWIsRUFBZ0JBLElBQUk0UyxlQUFwQixFQUFxQzVTLEdBQXJDLEVBQTBDO0FBQ3RDO0FBQ0EsVUFBSTZTLE1BQU85SixFQUFFckYsU0FBUyxJQUFJMUQsQ0FBZixDQUFYO0FBQ0EsVUFBSThTLE9BQU8vSixFQUFFckYsU0FBUyxJQUFJMUQsQ0FBYixHQUFpQixDQUFuQixDQUFYOztBQUVBO0FBQ0E2UyxZQUNLLENBQUVBLE9BQU8sQ0FBUixHQUFlQSxRQUFRLEVBQXhCLElBQStCLFVBQWhDLEdBQ0MsQ0FBRUEsT0FBTyxFQUFSLEdBQWVBLFFBQVEsQ0FBeEIsSUFBK0IsVUFGcEM7QUFJQUMsYUFDSyxDQUFFQSxRQUFRLENBQVQsR0FBZ0JBLFNBQVMsRUFBMUIsSUFBaUMsVUFBbEMsR0FDQyxDQUFFQSxRQUFRLEVBQVQsR0FBZ0JBLFNBQVMsQ0FBMUIsSUFBaUMsVUFGdEM7O0FBS0E7QUFDQSxVQUFJQyxPQUFPTCxNQUFNMVMsQ0FBTixDQUFYO0FBQ0ErUyxXQUFLNU4sSUFBTCxJQUFhMk4sSUFBYjtBQUNBQyxXQUFLM04sR0FBTCxJQUFheU4sR0FBYjtBQUNIOztBQUVEO0FBQ0EsVUFBSyxJQUFJRyxRQUFRLENBQWpCLEVBQW9CQSxRQUFRLEVBQTVCLEVBQWdDQSxPQUFoQyxFQUF5QztBQUNyQztBQUNBLFdBQUssSUFBSS9ILElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEI7QUFDQSxXQUFJZ0ksT0FBTyxDQUFYO0FBQUEsV0FBY0MsT0FBTyxDQUFyQjtBQUNBLFlBQUssSUFBSWpCLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEIsWUFBSWMsT0FBT0wsTUFBTXpILElBQUksSUFBSWdILENBQWQsQ0FBWDtBQUNBZ0IsZ0JBQVFGLEtBQUs1TixJQUFiO0FBQ0ErTixnQkFBUUgsS0FBSzNOLEdBQWI7QUFDSDs7QUFFRDtBQUNBLFdBQUkrTixLQUFLekssRUFBRXVDLENBQUYsQ0FBVDtBQUNBa0ksVUFBR2hPLElBQUgsR0FBVThOLElBQVY7QUFDQUUsVUFBRy9OLEdBQUgsR0FBVThOLElBQVY7QUFDSDtBQUNELFdBQUssSUFBSWpJLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEI7QUFDQSxXQUFJbUksTUFBTTFLLEVBQUUsQ0FBQ3VDLElBQUksQ0FBTCxJQUFVLENBQVosQ0FBVjtBQUNBLFdBQUlvSSxNQUFNM0ssRUFBRSxDQUFDdUMsSUFBSSxDQUFMLElBQVUsQ0FBWixDQUFWO0FBQ0EsV0FBSXFJLFNBQVNELElBQUlsTyxJQUFqQjtBQUNBLFdBQUlvTyxTQUFTRixJQUFJak8sR0FBakI7O0FBRUE7QUFDQSxXQUFJNk4sT0FBT0csSUFBSWpPLElBQUosSUFBYW1PLFVBQVUsQ0FBWCxHQUFpQkMsV0FBVyxFQUF4QyxDQUFYO0FBQ0EsV0FBSUwsT0FBT0UsSUFBSWhPLEdBQUosSUFBYW1PLFVBQVUsQ0FBWCxHQUFpQkQsV0FBVyxFQUF4QyxDQUFYO0FBQ0EsWUFBSyxJQUFJckIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QixZQUFJYyxPQUFPTCxNQUFNekgsSUFBSSxJQUFJZ0gsQ0FBZCxDQUFYO0FBQ0FjLGFBQUs1TixJQUFMLElBQWE4TixJQUFiO0FBQ0FGLGFBQUszTixHQUFMLElBQWE4TixJQUFiO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFdBQUssSUFBSU0sWUFBWSxDQUFyQixFQUF3QkEsWUFBWSxFQUFwQyxFQUF3Q0EsV0FBeEMsRUFBcUQ7QUFDakQ7QUFDQSxXQUFJVCxPQUFPTCxNQUFNYyxTQUFOLENBQVg7QUFDQSxXQUFJQyxVQUFVVixLQUFLNU4sSUFBbkI7QUFDQSxXQUFJdU8sVUFBVVgsS0FBSzNOLEdBQW5CO0FBQ0EsV0FBSXVPLFlBQVk3QixZQUFZMEIsU0FBWixDQUFoQjs7QUFFQTtBQUNBLFdBQUlHLFlBQVksRUFBaEIsRUFBb0I7QUFDaEIsWUFBSVYsT0FBUVEsV0FBV0UsU0FBWixHQUEwQkQsWUFBYSxLQUFLQyxTQUF2RDtBQUNBLFlBQUlULE9BQVFRLFdBQVdDLFNBQVosR0FBMEJGLFlBQWEsS0FBS0UsU0FBdkQ7QUFDSCxRQUhELE1BR08sMEJBQTJCO0FBQzlCLGFBQUlWLE9BQVFTLFdBQVlDLFlBQVksRUFBekIsR0FBaUNGLFlBQWEsS0FBS0UsU0FBOUQ7QUFDQSxhQUFJVCxPQUFRTyxXQUFZRSxZQUFZLEVBQXpCLEdBQWlDRCxZQUFhLEtBQUtDLFNBQTlEO0FBQ0g7O0FBRUQ7QUFDQSxXQUFJQyxVQUFVbEwsRUFBRXFKLFdBQVd5QixTQUFYLENBQUYsQ0FBZDtBQUNBSSxlQUFRek8sSUFBUixHQUFlOE4sSUFBZjtBQUNBVyxlQUFReE8sR0FBUixHQUFlOE4sSUFBZjtBQUNIOztBQUVEO0FBQ0EsVUFBSVcsS0FBS25MLEVBQUUsQ0FBRixDQUFUO0FBQ0EsVUFBSW9MLFNBQVNwQixNQUFNLENBQU4sQ0FBYjtBQUNBbUIsU0FBRzFPLElBQUgsR0FBVTJPLE9BQU8zTyxJQUFqQjtBQUNBME8sU0FBR3pPLEdBQUgsR0FBVTBPLE9BQU8xTyxHQUFqQjs7QUFFQTtBQUNBLFdBQUssSUFBSTZGLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEIsWUFBSyxJQUFJZ0gsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QjtBQUNBLFlBQUl1QixZQUFZdkksSUFBSSxJQUFJZ0gsQ0FBeEI7QUFDQSxZQUFJYyxPQUFPTCxNQUFNYyxTQUFOLENBQVg7QUFDQSxZQUFJTyxRQUFRckwsRUFBRThLLFNBQUYsQ0FBWjtBQUNBLFlBQUlRLFVBQVV0TCxFQUFHLENBQUN1QyxJQUFJLENBQUwsSUFBVSxDQUFYLEdBQWdCLElBQUlnSCxDQUF0QixDQUFkO0FBQ0EsWUFBSWdDLFVBQVV2TCxFQUFHLENBQUN1QyxJQUFJLENBQUwsSUFBVSxDQUFYLEdBQWdCLElBQUlnSCxDQUF0QixDQUFkOztBQUVBO0FBQ0FjLGFBQUs1TixJQUFMLEdBQVk0TyxNQUFNNU8sSUFBTixHQUFjLENBQUM2TyxRQUFRN08sSUFBVCxHQUFnQjhPLFFBQVE5TyxJQUFsRDtBQUNBNE4sYUFBSzNOLEdBQUwsR0FBWTJPLE1BQU0zTyxHQUFOLEdBQWMsQ0FBQzRPLFFBQVE1TyxHQUFULEdBQWdCNk8sUUFBUTdPLEdBQWxEO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFVBQUkyTixPQUFPTCxNQUFNLENBQU4sQ0FBWDtBQUNBLFVBQUl3QixnQkFBZ0JsQyxnQkFBZ0JnQixLQUFoQixDQUFwQjtBQUNBRCxXQUFLNU4sSUFBTCxJQUFhK08sY0FBYy9PLElBQTNCO0FBQ0E0TixXQUFLM04sR0FBTCxJQUFhOE8sY0FBYzlPLEdBQTNCLENBQStCO0FBQ2xDO0FBQ0osS0F0SWtDOztBQXdJbkNmLGlCQUFhLHVCQUFZO0FBQ3JCO0FBQ0EsU0FBSXhCLE9BQU8sS0FBS0gsS0FBaEI7QUFDQSxTQUFJTSxZQUFZSCxLQUFLMUQsS0FBckI7QUFDQSxTQUFJd0wsYUFBYSxLQUFLaEksV0FBTCxHQUFtQixDQUFwQztBQUNBLFNBQUlpSSxZQUFZL0gsS0FBS3pELFFBQUwsR0FBZ0IsQ0FBaEM7QUFDQSxTQUFJK1UsZ0JBQWdCLEtBQUtqUixTQUFMLEdBQWlCLEVBQXJDOztBQUVBO0FBQ0FGLGVBQVU0SCxjQUFjLENBQXhCLEtBQThCLE9BQVEsS0FBS0EsWUFBWSxFQUF2RDtBQUNBNUgsZUFBVSxDQUFFdkYsS0FBS3lDLElBQUwsQ0FBVSxDQUFDMEssWUFBWSxDQUFiLElBQWtCdUosYUFBNUIsSUFBNkNBLGFBQTlDLEtBQWlFLENBQWxFLElBQXVFLENBQWpGLEtBQXVGLElBQXZGO0FBQ0F0UixVQUFLekQsUUFBTCxHQUFnQjRELFVBQVUzRCxNQUFWLEdBQW1CLENBQW5DOztBQUVBO0FBQ0EsVUFBS3lELFFBQUw7O0FBRUE7QUFDQSxTQUFJNFAsUUFBUSxLQUFLQyxNQUFqQjtBQUNBLFNBQUl5QixvQkFBb0IsS0FBS3JRLEdBQUwsQ0FBUzBPLFlBQVQsR0FBd0IsQ0FBaEQ7QUFDQSxTQUFJNEIsb0JBQW9CRCxvQkFBb0IsQ0FBNUM7O0FBRUE7QUFDQSxTQUFJRSxZQUFZLEVBQWhCO0FBQ0EsVUFBSyxJQUFJdFUsSUFBSSxDQUFiLEVBQWdCQSxJQUFJcVUsaUJBQXBCLEVBQXVDclUsR0FBdkMsRUFBNEM7QUFDeEM7QUFDQSxVQUFJK1MsT0FBT0wsTUFBTTFTLENBQU4sQ0FBWDtBQUNBLFVBQUl5VCxVQUFVVixLQUFLNU4sSUFBbkI7QUFDQSxVQUFJdU8sVUFBVVgsS0FBSzNOLEdBQW5COztBQUVBO0FBQ0FxTyxnQkFDSyxDQUFFQSxXQUFXLENBQVosR0FBbUJBLFlBQVksRUFBaEMsSUFBdUMsVUFBeEMsR0FDQyxDQUFFQSxXQUFXLEVBQVosR0FBbUJBLFlBQVksQ0FBaEMsSUFBdUMsVUFGNUM7QUFJQUMsZ0JBQ0ssQ0FBRUEsV0FBVyxDQUFaLEdBQW1CQSxZQUFZLEVBQWhDLElBQXVDLFVBQXhDLEdBQ0MsQ0FBRUEsV0FBVyxFQUFaLEdBQW1CQSxZQUFZLENBQWhDLElBQXVDLFVBRjVDOztBQUtBO0FBQ0FZLGdCQUFVeFQsSUFBVixDQUFlNFMsT0FBZjtBQUNBWSxnQkFBVXhULElBQVYsQ0FBZTJTLE9BQWY7QUFDSDs7QUFFRDtBQUNBLFlBQU8sSUFBSXZVLFVBQVVULElBQWQsQ0FBbUI2VixTQUFuQixFQUE4QkYsaUJBQTlCLENBQVA7QUFDSCxLQXRMa0M7O0FBd0xuQ25WLFdBQU8saUJBQVk7QUFDZixTQUFJQSxRQUFRNkUsT0FBTzdFLEtBQVAsQ0FBYWtCLElBQWIsQ0FBa0IsSUFBbEIsQ0FBWjs7QUFFQSxTQUFJdVMsUUFBUXpULE1BQU0wVCxNQUFOLEdBQWUsS0FBS0EsTUFBTCxDQUFZdlMsS0FBWixDQUFrQixDQUFsQixDQUEzQjtBQUNBLFVBQUssSUFBSUosSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEVBQXBCLEVBQXdCQSxHQUF4QixFQUE2QjtBQUN6QjBTLFlBQU0xUyxDQUFOLElBQVcwUyxNQUFNMVMsQ0FBTixFQUFTZixLQUFULEVBQVg7QUFDSDs7QUFFRCxZQUFPQSxLQUFQO0FBQ0g7QUFqTWtDLElBQWQsQ0FBekI7O0FBb01BOzs7Ozs7Ozs7Ozs7OztBQWNBaEIsS0FBRXVVLElBQUYsR0FBUzFPLE9BQU9RLGFBQVAsQ0FBcUJrTyxJQUFyQixDQUFUOztBQUVBOzs7Ozs7Ozs7Ozs7OztBQWNBdlUsS0FBRXNXLFFBQUYsR0FBYXpRLE9BQU9XLGlCQUFQLENBQXlCK04sSUFBekIsQ0FBYjtBQUNILEdBOVNBLEVBOFNDL1UsSUE5U0QsQ0FBRDs7QUFpVEEsU0FBT0QsU0FBU2dWLElBQWhCO0FBRUEsRUFsVUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVdlYsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUI7QUFDMUIsTUFBSSxnQ0FBT0UsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELENBQVAsb0NBQW1CTCxPQUFuQjtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUzQjs7Ozs7Ozs7QUFXQyxhQUFVQyxJQUFWLEVBQWdCO0FBQ2I7QUFDQSxPQUFJUSxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJNEUsU0FBUzVGLE1BQU00RixNQUFuQjtBQUNBLE9BQUlhLFNBQVMxRyxFQUFFNEcsSUFBZjs7QUFFQTtBQUNBLE9BQUkyUCxNQUFNdFYsVUFBVXZCLE1BQVYsQ0FBaUIsQ0FDdkIsQ0FEdUIsRUFDbkIsQ0FEbUIsRUFDZixDQURlLEVBQ1gsQ0FEVyxFQUNQLENBRE8sRUFDSCxDQURHLEVBQ0MsQ0FERCxFQUNLLENBREwsRUFDUyxDQURULEVBQ2EsQ0FEYixFQUNnQixFQURoQixFQUNvQixFQURwQixFQUN3QixFQUR4QixFQUM0QixFQUQ1QixFQUNnQyxFQURoQyxFQUNvQyxFQURwQyxFQUV2QixDQUZ1QixFQUVuQixDQUZtQixFQUVoQixFQUZnQixFQUVYLENBRlcsRUFFUixFQUZRLEVBRUgsQ0FGRyxFQUVBLEVBRkEsRUFFSyxDQUZMLEVBRVEsRUFGUixFQUVhLENBRmIsRUFFaUIsQ0FGakIsRUFFcUIsQ0FGckIsRUFFeUIsQ0FGekIsRUFFNEIsRUFGNUIsRUFFZ0MsRUFGaEMsRUFFcUMsQ0FGckMsRUFHdkIsQ0FIdUIsRUFHcEIsRUFIb0IsRUFHaEIsRUFIZ0IsRUFHWCxDQUhXLEVBR1AsQ0FITyxFQUdKLEVBSEksRUFHQyxDQUhELEVBR0ssQ0FITCxFQUdTLENBSFQsRUFHYSxDQUhiLEVBR2lCLENBSGpCLEVBR3FCLENBSHJCLEVBR3dCLEVBSHhCLEVBRzRCLEVBSDVCLEVBR2lDLENBSGpDLEVBR29DLEVBSHBDLEVBSXZCLENBSnVCLEVBSW5CLENBSm1CLEVBSWhCLEVBSmdCLEVBSVosRUFKWSxFQUlQLENBSk8sRUFJSCxDQUpHLEVBSUEsRUFKQSxFQUlLLENBSkwsRUFJUSxFQUpSLEVBSWEsQ0FKYixFQUlpQixDQUpqQixFQUlvQixFQUpwQixFQUl3QixFQUp4QixFQUk2QixDQUo3QixFQUlpQyxDQUpqQyxFQUlxQyxDQUpyQyxFQUt2QixDQUx1QixFQUtuQixDQUxtQixFQUtmLENBTGUsRUFLWCxDQUxXLEVBS1AsQ0FMTyxFQUtKLEVBTEksRUFLQyxDQUxELEVBS0ksRUFMSixFQUtRLEVBTFIsRUFLYSxDQUxiLEVBS2lCLENBTGpCLEVBS3FCLENBTHJCLEVBS3dCLEVBTHhCLEVBSzZCLENBTDdCLEVBS2dDLEVBTGhDLEVBS29DLEVBTHBDLENBQWpCLENBQVY7QUFNQSxPQUFJOFcsTUFBTXZWLFVBQVV2QixNQUFWLENBQWlCLENBQ3ZCLENBRHVCLEVBQ3BCLEVBRG9CLEVBQ2YsQ0FEZSxFQUNYLENBRFcsRUFDUCxDQURPLEVBQ0gsQ0FERyxFQUNBLEVBREEsRUFDSyxDQURMLEVBQ1EsRUFEUixFQUNhLENBRGIsRUFDZ0IsRUFEaEIsRUFDcUIsQ0FEckIsRUFDeUIsQ0FEekIsRUFDNEIsRUFENUIsRUFDaUMsQ0FEakMsRUFDb0MsRUFEcEMsRUFFdkIsQ0FGdUIsRUFFcEIsRUFGb0IsRUFFZixDQUZlLEVBRVgsQ0FGVyxFQUVQLENBRk8sRUFFSixFQUZJLEVBRUMsQ0FGRCxFQUVJLEVBRkosRUFFUSxFQUZSLEVBRVksRUFGWixFQUVpQixDQUZqQixFQUVvQixFQUZwQixFQUV5QixDQUZ6QixFQUU2QixDQUY3QixFQUVpQyxDQUZqQyxFQUVxQyxDQUZyQyxFQUd2QixFQUh1QixFQUdsQixDQUhrQixFQUdkLENBSGMsRUFHVixDQUhVLEVBR04sQ0FITSxFQUdILEVBSEcsRUFHRSxDQUhGLEVBR00sQ0FITixFQUdTLEVBSFQsRUFHYyxDQUhkLEVBR2lCLEVBSGpCLEVBR3NCLENBSHRCLEVBR3lCLEVBSHpCLEVBRzhCLENBSDlCLEVBR2tDLENBSGxDLEVBR3FDLEVBSHJDLEVBSXZCLENBSnVCLEVBSW5CLENBSm1CLEVBSWYsQ0FKZSxFQUlYLENBSlcsRUFJUCxDQUpPLEVBSUosRUFKSSxFQUlBLEVBSkEsRUFJSyxDQUpMLEVBSVMsQ0FKVCxFQUlZLEVBSlosRUFJaUIsQ0FKakIsRUFJb0IsRUFKcEIsRUFJeUIsQ0FKekIsRUFJNkIsQ0FKN0IsRUFJZ0MsRUFKaEMsRUFJb0MsRUFKcEMsRUFLdkIsRUFMdUIsRUFLbkIsRUFMbUIsRUFLZixFQUxlLEVBS1YsQ0FMVSxFQUtOLENBTE0sRUFLRixDQUxFLEVBS0UsQ0FMRixFQUtNLENBTE4sRUFLVSxDQUxWLEVBS2MsQ0FMZCxFQUtpQixFQUxqQixFQUtxQixFQUxyQixFQUswQixDQUwxQixFQUs4QixDQUw5QixFQUtrQyxDQUxsQyxFQUtxQyxFQUxyQyxDQUFqQixDQUFWO0FBTUEsT0FBSStXLE1BQU14VixVQUFVdkIsTUFBVixDQUFpQixDQUN0QixFQURzQixFQUNsQixFQURrQixFQUNkLEVBRGMsRUFDVixFQURVLEVBQ0wsQ0FESyxFQUNELENBREMsRUFDRyxDQURILEVBQ08sQ0FEUCxFQUNVLEVBRFYsRUFDYyxFQURkLEVBQ2tCLEVBRGxCLEVBQ3NCLEVBRHRCLEVBQzJCLENBRDNCLEVBQytCLENBRC9CLEVBQ21DLENBRG5DLEVBQ3VDLENBRHZDLEVBRXZCLENBRnVCLEVBRXBCLENBRm9CLEVBRWYsQ0FGZSxFQUVaLEVBRlksRUFFUixFQUZRLEVBRUgsQ0FGRyxFQUVDLENBRkQsRUFFSSxFQUZKLEVBRVMsQ0FGVCxFQUVZLEVBRlosRUFFZ0IsRUFGaEIsRUFFcUIsQ0FGckIsRUFFd0IsRUFGeEIsRUFFNkIsQ0FGN0IsRUFFZ0MsRUFGaEMsRUFFb0MsRUFGcEMsRUFHdkIsRUFIdUIsRUFHbkIsRUFIbUIsRUFHZCxDQUhjLEVBR1YsQ0FIVSxFQUdQLEVBSE8sRUFHRixDQUhFLEVBR0MsRUFIRCxFQUdLLEVBSEwsRUFHUyxFQUhULEVBR2MsQ0FIZCxFQUdpQixFQUhqQixFQUdzQixDQUh0QixFQUcwQixDQUgxQixFQUc2QixFQUg3QixFQUdrQyxDQUhsQyxFQUdzQyxDQUh0QyxFQUlyQixFQUpxQixFQUlqQixFQUppQixFQUliLEVBSmEsRUFJVCxFQUpTLEVBSUwsRUFKSyxFQUlELEVBSkMsRUFJSSxDQUpKLEVBSVEsQ0FKUixFQUlZLENBSlosRUFJZSxFQUpmLEVBSW9CLENBSnBCLEVBSXdCLENBSnhCLEVBSTRCLENBSjVCLEVBSWdDLENBSmhDLEVBSW9DLENBSnBDLEVBSXVDLEVBSnZDLEVBS3ZCLENBTHVCLEVBS3BCLEVBTG9CLEVBS2YsQ0FMZSxFQUtaLEVBTFksRUFLUCxDQUxPLEVBS0gsQ0FMRyxFQUtBLEVBTEEsRUFLSSxFQUxKLEVBS1MsQ0FMVCxFQUtZLEVBTFosRUFLZ0IsRUFMaEIsRUFLb0IsRUFMcEIsRUFLd0IsRUFMeEIsRUFLNkIsQ0FMN0IsRUFLaUMsQ0FMakMsRUFLcUMsQ0FMckMsQ0FBakIsQ0FBVjtBQU1BLE9BQUlnWCxNQUFNelYsVUFBVXZCLE1BQVYsQ0FBaUIsQ0FDdkIsQ0FEdUIsRUFDbkIsQ0FEbUIsRUFDZixDQURlLEVBQ1osRUFEWSxFQUNSLEVBRFEsRUFDSixFQURJLEVBQ0EsRUFEQSxFQUNLLENBREwsRUFDUyxDQURULEVBQ2EsQ0FEYixFQUNpQixDQURqQixFQUNvQixFQURwQixFQUN3QixFQUR4QixFQUM0QixFQUQ1QixFQUNnQyxFQURoQyxFQUNxQyxDQURyQyxFQUV2QixDQUZ1QixFQUVwQixFQUZvQixFQUVoQixFQUZnQixFQUVYLENBRlcsRUFFUixFQUZRLEVBRUgsQ0FGRyxFQUVDLENBRkQsRUFFSSxFQUZKLEVBRVMsQ0FGVCxFQUVhLENBRmIsRUFFZ0IsRUFGaEIsRUFFcUIsQ0FGckIsRUFFeUIsQ0FGekIsRUFFNEIsRUFGNUIsRUFFZ0MsRUFGaEMsRUFFb0MsRUFGcEMsRUFHdkIsQ0FIdUIsRUFHbkIsQ0FIbUIsRUFHaEIsRUFIZ0IsRUFHWixFQUhZLEVBR1AsQ0FITyxFQUdILENBSEcsRUFHQyxDQUhELEVBR0ksRUFISixFQUdRLEVBSFIsRUFHWSxFQUhaLEVBR2lCLENBSGpCLEVBR29CLEVBSHBCLEVBR3dCLEVBSHhCLEVBRzRCLEVBSDVCLEVBR2lDLENBSGpDLEVBR3FDLENBSHJDLEVBSXZCLEVBSnVCLEVBSWxCLENBSmtCLEVBSWQsQ0FKYyxFQUlYLEVBSlcsRUFJUCxFQUpPLEVBSUgsRUFKRyxFQUlFLENBSkYsRUFJSyxFQUpMLEVBSVUsQ0FKVixFQUljLENBSmQsRUFJaUIsRUFKakIsRUFJc0IsQ0FKdEIsRUFJeUIsRUFKekIsRUFJOEIsQ0FKOUIsRUFJaUMsRUFKakMsRUFJc0MsQ0FKdEMsRUFLdkIsQ0FMdUIsRUFLbkIsQ0FMbUIsRUFLaEIsRUFMZ0IsRUFLWCxDQUxXLEVBS1IsRUFMUSxFQUtILENBTEcsRUFLQSxFQUxBLEVBS0ssQ0FMTCxFQUtTLENBTFQsRUFLWSxFQUxaLEVBS2lCLENBTGpCLEVBS3FCLENBTHJCLEVBS3dCLEVBTHhCLEVBSzRCLEVBTDVCLEVBS2dDLEVBTGhDLEVBS29DLEVBTHBDLENBQWpCLENBQVY7O0FBT0EsT0FBSWlYLE1BQU8xVixVQUFVdkIsTUFBVixDQUFpQixDQUFFLFVBQUYsRUFBYyxVQUFkLEVBQTBCLFVBQTFCLEVBQXNDLFVBQXRDLEVBQWtELFVBQWxELENBQWpCLENBQVg7QUFDQSxPQUFJa1gsTUFBTzNWLFVBQVV2QixNQUFWLENBQWlCLENBQUUsVUFBRixFQUFjLFVBQWQsRUFBMEIsVUFBMUIsRUFBc0MsVUFBdEMsRUFBa0QsVUFBbEQsQ0FBakIsQ0FBWDs7QUFFQTs7O0FBR0EsT0FBSW1YLFlBQVluUSxPQUFPbVEsU0FBUCxHQUFtQmhSLE9BQU96RixNQUFQLENBQWM7QUFDN0MyRixjQUFVLG9CQUFZO0FBQ2xCLFVBQUs4RSxLQUFMLEdBQWM1SixVQUFVdkIsTUFBVixDQUFpQixDQUFDLFVBQUQsRUFBYSxVQUFiLEVBQXlCLFVBQXpCLEVBQXFDLFVBQXJDLEVBQWlELFVBQWpELENBQWpCLENBQWQ7QUFDSCxLQUg0Qzs7QUFLN0NnRyxxQkFBaUIseUJBQVVvRixDQUFWLEVBQWFyRixNQUFiLEVBQXFCOztBQUVsQztBQUNBLFVBQUssSUFBSTFELElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekI7QUFDQSxVQUFJZ0osV0FBV3RGLFNBQVMxRCxDQUF4QjtBQUNBLFVBQUlpSixhQUFhRixFQUFFQyxRQUFGLENBQWpCOztBQUVBO0FBQ0FELFFBQUVDLFFBQUYsSUFDSyxDQUFFQyxjQUFjLENBQWYsR0FBc0JBLGVBQWUsRUFBdEMsSUFBNkMsVUFBOUMsR0FDQyxDQUFFQSxjQUFjLEVBQWYsR0FBc0JBLGVBQWUsQ0FBdEMsSUFBNkMsVUFGbEQ7QUFJSDtBQUNEO0FBQ0EsU0FBSUMsSUFBSyxLQUFLSixLQUFMLENBQVczSixLQUFwQjtBQUNBLFNBQUl1USxLQUFLa0YsSUFBSXpWLEtBQWI7QUFDQSxTQUFJNFYsS0FBS0YsSUFBSTFWLEtBQWI7QUFDQSxTQUFJNlYsS0FBS1IsSUFBSXJWLEtBQWI7QUFDQSxTQUFJOFYsS0FBS1IsSUFBSXRWLEtBQWI7QUFDQSxTQUFJK1YsS0FBS1IsSUFBSXZWLEtBQWI7QUFDQSxTQUFJZ1csS0FBS1IsSUFBSXhWLEtBQWI7O0FBRUE7QUFDQSxTQUFJMFAsRUFBSixFQUFRRSxFQUFSLEVBQVlDLEVBQVosRUFBZ0JFLEVBQWhCLEVBQW9CRSxFQUFwQjtBQUNBLFNBQUlnRyxFQUFKLEVBQVFDLEVBQVIsRUFBWUMsRUFBWixFQUFnQkMsRUFBaEIsRUFBb0JDLEVBQXBCOztBQUVBSixVQUFLdkcsS0FBSzNGLEVBQUUsQ0FBRixDQUFWO0FBQ0FtTSxVQUFLdEcsS0FBSzdGLEVBQUUsQ0FBRixDQUFWO0FBQ0FvTSxVQUFLdEcsS0FBSzlGLEVBQUUsQ0FBRixDQUFWO0FBQ0FxTSxVQUFLckcsS0FBS2hHLEVBQUUsQ0FBRixDQUFWO0FBQ0FzTSxVQUFLcEcsS0FBS2xHLEVBQUUsQ0FBRixDQUFWO0FBQ0E7QUFDQSxTQUFJaUMsQ0FBSjtBQUNBLFVBQUssSUFBSW5MLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsS0FBSyxDQUE3QixFQUFnQztBQUM1Qm1MLFVBQUswRCxLQUFNOUYsRUFBRXJGLFNBQU9zUixHQUFHaFYsQ0FBSCxDQUFULENBQVAsR0FBd0IsQ0FBNUI7QUFDQSxVQUFJQSxJQUFFLEVBQU4sRUFBUztBQUNabUwsWUFBTXNLLEdBQUcxRyxFQUFILEVBQU1DLEVBQU4sRUFBU0UsRUFBVCxJQUFlUSxHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZELE1BRU8sSUFBSTFQLElBQUUsRUFBTixFQUFVO0FBQ3BCbUwsWUFBTXVLLEdBQUczRyxFQUFILEVBQU1DLEVBQU4sRUFBU0UsRUFBVCxJQUFlUSxHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZNLE1BRUEsSUFBSTFQLElBQUUsRUFBTixFQUFVO0FBQ3BCbUwsWUFBTXdLLEdBQUc1RyxFQUFILEVBQU1DLEVBQU4sRUFBU0UsRUFBVCxJQUFlUSxHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZNLE1BRUEsSUFBSTFQLElBQUUsRUFBTixFQUFVO0FBQ3BCbUwsWUFBTXlLLEdBQUc3RyxFQUFILEVBQU1DLEVBQU4sRUFBU0UsRUFBVCxJQUFlUSxHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZNLE1BRUE7QUFBQztBQUNYdkUsWUFBTTBLLEdBQUc5RyxFQUFILEVBQU1DLEVBQU4sRUFBU0UsRUFBVCxJQUFlUSxHQUFHLENBQUgsQ0FBckI7QUFDSTtBQUNEdkUsVUFBSUEsSUFBRSxDQUFOO0FBQ0FBLFVBQUsySyxLQUFLM0ssQ0FBTCxFQUFPK0osR0FBR2xWLENBQUgsQ0FBUCxDQUFMO0FBQ0FtTCxVQUFLQSxJQUFFaUUsRUFBSCxHQUFPLENBQVg7QUFDQVAsV0FBS08sRUFBTDtBQUNBQSxXQUFLRixFQUFMO0FBQ0FBLFdBQUs0RyxLQUFLOUcsRUFBTCxFQUFTLEVBQVQsQ0FBTDtBQUNBQSxXQUFLRCxFQUFMO0FBQ0FBLFdBQUs1RCxDQUFMOztBQUVBQSxVQUFLaUssS0FBS3JNLEVBQUVyRixTQUFPdVIsR0FBR2pWLENBQUgsQ0FBVCxDQUFOLEdBQXVCLENBQTNCO0FBQ0EsVUFBSUEsSUFBRSxFQUFOLEVBQVM7QUFDWm1MLFlBQU0wSyxHQUFHUixFQUFILEVBQU1DLEVBQU4sRUFBU0MsRUFBVCxJQUFlUixHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZELE1BRU8sSUFBSS9VLElBQUUsRUFBTixFQUFVO0FBQ3BCbUwsWUFBTXlLLEdBQUdQLEVBQUgsRUFBTUMsRUFBTixFQUFTQyxFQUFULElBQWVSLEdBQUcsQ0FBSCxDQUFyQjtBQUNJLE9BRk0sTUFFQSxJQUFJL1UsSUFBRSxFQUFOLEVBQVU7QUFDcEJtTCxZQUFNd0ssR0FBR04sRUFBSCxFQUFNQyxFQUFOLEVBQVNDLEVBQVQsSUFBZVIsR0FBRyxDQUFILENBQXJCO0FBQ0ksT0FGTSxNQUVBLElBQUkvVSxJQUFFLEVBQU4sRUFBVTtBQUNwQm1MLFlBQU11SyxHQUFHTCxFQUFILEVBQU1DLEVBQU4sRUFBU0MsRUFBVCxJQUFlUixHQUFHLENBQUgsQ0FBckI7QUFDSSxPQUZNLE1BRUE7QUFBQztBQUNYNUosWUFBTXNLLEdBQUdKLEVBQUgsRUFBTUMsRUFBTixFQUFTQyxFQUFULElBQWVSLEdBQUcsQ0FBSCxDQUFyQjtBQUNJO0FBQ0Q1SixVQUFJQSxJQUFFLENBQU47QUFDQUEsVUFBSzJLLEtBQUszSyxDQUFMLEVBQU9nSyxHQUFHblYsQ0FBSCxDQUFQLENBQUw7QUFDQW1MLFVBQUtBLElBQUVxSyxFQUFILEdBQU8sQ0FBWDtBQUNBSixXQUFLSSxFQUFMO0FBQ0FBLFdBQUtELEVBQUw7QUFDQUEsV0FBS08sS0FBS1IsRUFBTCxFQUFTLEVBQVQsQ0FBTDtBQUNBQSxXQUFLRCxFQUFMO0FBQ0FBLFdBQUtsSyxDQUFMO0FBQ0g7QUFDRDtBQUNBQSxTQUFRakMsRUFBRSxDQUFGLElBQU84RixFQUFQLEdBQVl1RyxFQUFiLEdBQWlCLENBQXhCO0FBQ0FyTSxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9nRyxFQUFQLEdBQVlzRyxFQUFiLEdBQWlCLENBQXhCO0FBQ0F0TSxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU9rRyxFQUFQLEdBQVlnRyxFQUFiLEdBQWlCLENBQXhCO0FBQ0FsTSxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8yRixFQUFQLEdBQVl3RyxFQUFiLEdBQWlCLENBQXhCO0FBQ0FuTSxPQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU82RixFQUFQLEdBQVl1RyxFQUFiLEdBQWlCLENBQXhCO0FBQ0FwTSxPQUFFLENBQUYsSUFBUWlDLENBQVI7QUFDSCxLQXpGNEM7O0FBMkY3QzlHLGlCQUFhLHVCQUFZO0FBQ3JCO0FBQ0EsU0FBSXhCLE9BQU8sS0FBS0gsS0FBaEI7QUFDQSxTQUFJTSxZQUFZSCxLQUFLMUQsS0FBckI7O0FBRUEsU0FBSXdMLGFBQWEsS0FBS2hJLFdBQUwsR0FBbUIsQ0FBcEM7QUFDQSxTQUFJaUksWUFBWS9ILEtBQUt6RCxRQUFMLEdBQWdCLENBQWhDOztBQUVBO0FBQ0E0RCxlQUFVNEgsY0FBYyxDQUF4QixLQUE4QixRQUFTLEtBQUtBLFlBQVksRUFBeEQ7QUFDQTVILGVBQVUsQ0FBRzRILFlBQVksRUFBYixLQUFxQixDQUF0QixJQUE0QixDQUE3QixJQUFrQyxFQUE1QyxJQUNLLENBQUVELGNBQWMsQ0FBZixHQUFzQkEsZUFBZSxFQUF0QyxJQUE2QyxVQUE5QyxHQUNDLENBQUVBLGNBQWMsRUFBZixHQUFzQkEsZUFBZSxDQUF0QyxJQUE2QyxVQUZsRDtBQUlBOUgsVUFBS3pELFFBQUwsR0FBZ0IsQ0FBQzRELFVBQVUzRCxNQUFWLEdBQW1CLENBQXBCLElBQXlCLENBQXpDOztBQUVBO0FBQ0EsVUFBS3lELFFBQUw7O0FBRUE7QUFDQSxTQUFJc0IsT0FBTyxLQUFLMEUsS0FBaEI7QUFDQSxTQUFJSSxJQUFJOUUsS0FBS2pGLEtBQWI7O0FBRUE7QUFDQSxVQUFLLElBQUlhLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEI7QUFDQSxVQUFJZ0wsTUFBTTlCLEVBQUVsSixDQUFGLENBQVY7O0FBRUE7QUFDQWtKLFFBQUVsSixDQUFGLElBQVEsQ0FBRWdMLE9BQU8sQ0FBUixHQUFlQSxRQUFRLEVBQXhCLElBQStCLFVBQWhDLEdBQ0MsQ0FBRUEsT0FBTyxFQUFSLEdBQWVBLFFBQVEsQ0FBeEIsSUFBK0IsVUFEdkM7QUFFSDs7QUFFRDtBQUNBLFlBQU81RyxJQUFQO0FBQ0gsS0E5SDRDOztBQWdJN0NuRixXQUFPLGlCQUFZO0FBQ2YsU0FBSUEsUUFBUTZFLE9BQU83RSxLQUFQLENBQWFrQixJQUFiLENBQWtCLElBQWxCLENBQVo7QUFDQWxCLFdBQU02SixLQUFOLEdBQWMsS0FBS0EsS0FBTCxDQUFXN0osS0FBWCxFQUFkOztBQUVBLFlBQU9BLEtBQVA7QUFDSDtBQXJJNEMsSUFBZCxDQUFuQzs7QUF5SUEsWUFBU3dXLEVBQVQsQ0FBWXhLLENBQVosRUFBZWdILENBQWYsRUFBa0I4RCxDQUFsQixFQUFxQjtBQUNqQixXQUFTOUssQ0FBRCxHQUFPZ0gsQ0FBUCxHQUFhOEQsQ0FBckI7QUFFSDs7QUFFRCxZQUFTTCxFQUFULENBQVl6SyxDQUFaLEVBQWVnSCxDQUFmLEVBQWtCOEQsQ0FBbEIsRUFBcUI7QUFDakIsV0FBVTlLLENBQUQsR0FBS2dILENBQU4sR0FBYyxDQUFDaEgsQ0FBRixHQUFNOEssQ0FBM0I7QUFDSDs7QUFFRCxZQUFTSixFQUFULENBQVkxSyxDQUFaLEVBQWVnSCxDQUFmLEVBQWtCOEQsQ0FBbEIsRUFBcUI7QUFDakIsV0FBUSxDQUFFOUssQ0FBRCxHQUFPLENBQUVnSCxDQUFWLElBQWtCOEQsQ0FBMUI7QUFDSDs7QUFFRCxZQUFTSCxFQUFULENBQVkzSyxDQUFaLEVBQWVnSCxDQUFmLEVBQWtCOEQsQ0FBbEIsRUFBcUI7QUFDakIsV0FBVTlLLENBQUQsR0FBTzhLLENBQVIsR0FBZ0I5RCxDQUFELEdBQUssQ0FBRThELENBQTlCO0FBQ0g7O0FBRUQsWUFBU0YsRUFBVCxDQUFZNUssQ0FBWixFQUFlZ0gsQ0FBZixFQUFrQjhELENBQWxCLEVBQXFCO0FBQ2pCLFdBQVM5SyxDQUFELElBQVFnSCxDQUFELEdBQU0sQ0FBRThELENBQWYsQ0FBUjtBQUVIOztBQUVELFlBQVNELElBQVQsQ0FBYzdLLENBQWQsRUFBZ0JHLENBQWhCLEVBQW1CO0FBQ2YsV0FBUUgsS0FBR0csQ0FBSixHQUFVSCxNQUFLLEtBQUdHLENBQXpCO0FBQ0g7O0FBR0Q7Ozs7Ozs7Ozs7Ozs7O0FBY0FuTixLQUFFNlcsU0FBRixHQUFjaFIsT0FBT1EsYUFBUCxDQUFxQndRLFNBQXJCLENBQWQ7O0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FBY0E3VyxLQUFFK1gsYUFBRixHQUFrQmxTLE9BQU9XLGlCQUFQLENBQXlCcVEsU0FBekIsQ0FBbEI7QUFDSCxHQTNPQSxFQTJPQ3JYLElBM09ELENBQUQ7O0FBOE9BLFNBQU9ELFNBQVNzWCxTQUFoQjtBQUVBLEVBMVFDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVTdYLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCO0FBQzFCLE1BQUksZ0NBQU9FLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxDQUFQLG9DQUFtQkwsT0FBbkI7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFMUIsZUFBWTtBQUNUO0FBQ0EsT0FBSVMsSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJQyxPQUFPRixNQUFNRSxJQUFqQjtBQUNBLE9BQUkyQyxRQUFROUMsRUFBRStDLEdBQWQ7QUFDQSxPQUFJZ0IsT0FBT2pCLE1BQU1pQixJQUFqQjtBQUNBLE9BQUkyQyxTQUFTMUcsRUFBRTRHLElBQWY7O0FBRUE7OztBQUdBLE9BQUlELE9BQU9ELE9BQU9DLElBQVAsR0FBY3hHLEtBQUtDLE1BQUwsQ0FBWTtBQUNqQzs7Ozs7Ozs7OztBQVVBSSxVQUFNLGNBQVU4RixNQUFWLEVBQWtCRyxHQUFsQixFQUF1QjtBQUN6QjtBQUNBSCxjQUFTLEtBQUswUixPQUFMLEdBQWUsSUFBSTFSLE9BQU85RixJQUFYLEVBQXhCOztBQUVBO0FBQ0EsU0FBSSxPQUFPaUcsR0FBUCxJQUFjLFFBQWxCLEVBQTRCO0FBQ3hCQSxZQUFNMUMsS0FBS1osS0FBTCxDQUFXc0QsR0FBWCxDQUFOO0FBQ0g7O0FBRUQ7QUFDQSxTQUFJd1Isa0JBQWtCM1IsT0FBT3JCLFNBQTdCO0FBQ0EsU0FBSWlULHVCQUF1QkQsa0JBQWtCLENBQTdDOztBQUVBO0FBQ0EsU0FBSXhSLElBQUl0RixRQUFKLEdBQWUrVyxvQkFBbkIsRUFBeUM7QUFDckN6UixZQUFNSCxPQUFPSixRQUFQLENBQWdCTyxHQUFoQixDQUFOO0FBQ0g7O0FBRUQ7QUFDQUEsU0FBSTNFLEtBQUo7O0FBRUE7QUFDQSxTQUFJcVcsT0FBTyxLQUFLQyxLQUFMLEdBQWEzUixJQUFJekYsS0FBSixFQUF4QjtBQUNBLFNBQUlxWCxPQUFPLEtBQUtDLEtBQUwsR0FBYTdSLElBQUl6RixLQUFKLEVBQXhCOztBQUVBO0FBQ0EsU0FBSXVYLFlBQVlKLEtBQUtqWCxLQUFyQjtBQUNBLFNBQUlzWCxZQUFZSCxLQUFLblgsS0FBckI7O0FBRUE7QUFDQSxVQUFLLElBQUlhLElBQUksQ0FBYixFQUFnQkEsSUFBSWtXLGVBQXBCLEVBQXFDbFcsR0FBckMsRUFBMEM7QUFDdEN3VyxnQkFBVXhXLENBQVYsS0FBZ0IsVUFBaEI7QUFDQXlXLGdCQUFVelcsQ0FBVixLQUFnQixVQUFoQjtBQUNIO0FBQ0RvVyxVQUFLaFgsUUFBTCxHQUFnQmtYLEtBQUtsWCxRQUFMLEdBQWdCK1csb0JBQWhDOztBQUVBO0FBQ0EsVUFBSzFULEtBQUw7QUFDSCxLQWpEZ0M7O0FBbURqQzs7Ozs7OztBQU9BQSxXQUFPLGlCQUFZO0FBQ2Y7QUFDQSxTQUFJOEIsU0FBUyxLQUFLMFIsT0FBbEI7O0FBRUE7QUFDQTFSLFlBQU85QixLQUFQO0FBQ0E4QixZQUFPTixNQUFQLENBQWMsS0FBS3NTLEtBQW5CO0FBQ0gsS0FqRWdDOztBQW1FakM7Ozs7Ozs7Ozs7OztBQVlBdFMsWUFBUSxnQkFBVUMsYUFBVixFQUF5QjtBQUM3QixVQUFLK1IsT0FBTCxDQUFhaFMsTUFBYixDQUFvQkMsYUFBcEI7O0FBRUE7QUFDQSxZQUFPLElBQVA7QUFDSCxLQXBGZ0M7O0FBc0ZqQzs7Ozs7Ozs7Ozs7Ozs7QUFjQUMsY0FBVSxrQkFBVUQsYUFBVixFQUF5QjtBQUMvQjtBQUNBLFNBQUlLLFNBQVMsS0FBSzBSLE9BQWxCOztBQUVBO0FBQ0EsU0FBSVMsWUFBWW5TLE9BQU9KLFFBQVAsQ0FBZ0JELGFBQWhCLENBQWhCO0FBQ0FLLFlBQU85QixLQUFQO0FBQ0EsU0FBSWtVLE9BQU9wUyxPQUFPSixRQUFQLENBQWdCLEtBQUtrUyxLQUFMLENBQVdwWCxLQUFYLEdBQW1CUSxNQUFuQixDQUEwQmlYLFNBQTFCLENBQWhCLENBQVg7O0FBRUEsWUFBT0MsSUFBUDtBQUNIO0FBOUdnQyxJQUFaLENBQXpCO0FBZ0hILEdBNUhBLEdBQUQ7QUErSEEsRUE5SUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVMVosSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixFQUE4QyxtQkFBQUEsQ0FBUSxFQUFSLENBQTlDLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxFQUFxQix1QkFBckIsQ0FBUCxvQ0FBdUNMLE9BQXZDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSUMsT0FBT0YsTUFBTUUsSUFBakI7QUFDQSxPQUFJYyxZQUFZaEIsTUFBTWdCLFNBQXRCO0FBQ0EsT0FBSXlGLFNBQVMxRyxFQUFFNEcsSUFBZjtBQUNBLE9BQUkwRyxPQUFPNUcsT0FBTzRHLElBQWxCO0FBQ0EsT0FBSTNHLE9BQU9ELE9BQU9DLElBQWxCOztBQUVBOzs7QUFHQSxPQUFJZ1MsU0FBU2pTLE9BQU9pUyxNQUFQLEdBQWdCeFksS0FBS0MsTUFBTCxDQUFZO0FBQ3JDOzs7Ozs7O0FBT0EwRixTQUFLM0YsS0FBS0MsTUFBTCxDQUFZO0FBQ2J3WSxjQUFTLE1BQUksRUFEQTtBQUVidFMsYUFBUWdILElBRks7QUFHYnVMLGlCQUFZO0FBSEMsS0FBWixDQVJnQzs7QUFjckM7Ozs7Ozs7Ozs7O0FBV0FyWSxVQUFNLGNBQVVzRixHQUFWLEVBQWU7QUFDakIsVUFBS0EsR0FBTCxHQUFXLEtBQUtBLEdBQUwsQ0FBUzFGLE1BQVQsQ0FBZ0IwRixHQUFoQixDQUFYO0FBQ0gsS0EzQm9DOztBQTZCckM7Ozs7Ozs7Ozs7OztBQVlBZ1QsYUFBUyxpQkFBVUMsUUFBVixFQUFvQkMsSUFBcEIsRUFBMEI7QUFDL0I7QUFDQSxTQUFJbFQsTUFBTSxLQUFLQSxHQUFmOztBQUVBO0FBQ0EsU0FBSTRTLE9BQU8vUixLQUFLakgsTUFBTCxDQUFZb0csSUFBSVEsTUFBaEIsRUFBd0J5UyxRQUF4QixDQUFYOztBQUVBO0FBQ0EsU0FBSUUsYUFBYWhZLFVBQVV2QixNQUFWLEVBQWpCO0FBQ0EsU0FBSXdaLGFBQWFqWSxVQUFVdkIsTUFBVixDQUFpQixDQUFDLFVBQUQsQ0FBakIsQ0FBakI7O0FBRUE7QUFDQSxTQUFJeVosa0JBQWtCRixXQUFXL1gsS0FBakM7QUFDQSxTQUFJa1ksa0JBQWtCRixXQUFXaFksS0FBakM7QUFDQSxTQUFJMFgsVUFBVTlTLElBQUk4UyxPQUFsQjtBQUNBLFNBQUlDLGFBQWEvUyxJQUFJK1MsVUFBckI7O0FBRUE7QUFDQSxZQUFPTSxnQkFBZ0IvWCxNQUFoQixHQUF5QndYLE9BQWhDLEVBQXlDO0FBQ3JDLFVBQUlTLFFBQVFYLEtBQUsxUyxNQUFMLENBQVlnVCxJQUFaLEVBQWtCOVMsUUFBbEIsQ0FBMkJnVCxVQUEzQixDQUFaO0FBQ0FSLFdBQUtsVSxLQUFMOztBQUVBO0FBQ0EsVUFBSThVLGFBQWFELE1BQU1uWSxLQUF2QjtBQUNBLFVBQUlxWSxtQkFBbUJELFdBQVdsWSxNQUFsQzs7QUFFQTtBQUNBLFVBQUlvWSxlQUFlSCxLQUFuQjtBQUNBLFdBQUssSUFBSXRYLElBQUksQ0FBYixFQUFnQkEsSUFBSThXLFVBQXBCLEVBQWdDOVcsR0FBaEMsRUFBcUM7QUFDakN5WCxzQkFBZWQsS0FBS3hTLFFBQUwsQ0FBY3NULFlBQWQsQ0FBZjtBQUNBZCxZQUFLbFUsS0FBTDs7QUFFQTtBQUNBLFdBQUlpVixvQkFBb0JELGFBQWF0WSxLQUFyQzs7QUFFQTtBQUNBLFlBQUssSUFBSTJJLElBQUksQ0FBYixFQUFnQkEsSUFBSTBQLGdCQUFwQixFQUFzQzFQLEdBQXRDLEVBQTJDO0FBQ3ZDeVAsbUJBQVd6UCxDQUFYLEtBQWlCNFAsa0JBQWtCNVAsQ0FBbEIsQ0FBakI7QUFDSDtBQUNKOztBQUVEb1AsaUJBQVd6WCxNQUFYLENBQWtCNlgsS0FBbEI7QUFDQUQsc0JBQWdCLENBQWhCO0FBQ0g7QUFDREgsZ0JBQVc5WCxRQUFYLEdBQXNCeVgsVUFBVSxDQUFoQzs7QUFFQSxZQUFPSyxVQUFQO0FBQ0g7QUF4Rm9DLElBQVosQ0FBN0I7O0FBMkZBOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQWpaLEtBQUUyWSxNQUFGLEdBQVcsVUFBVUksUUFBVixFQUFvQkMsSUFBcEIsRUFBMEJsVCxHQUExQixFQUErQjtBQUN0QyxXQUFPNlMsT0FBT2paLE1BQVAsQ0FBY29HLEdBQWQsRUFBbUJnVCxPQUFuQixDQUEyQkMsUUFBM0IsRUFBcUNDLElBQXJDLENBQVA7QUFDSCxJQUZEO0FBR0gsR0E1SEEsR0FBRDs7QUErSEEsU0FBT3paLFNBQVNvWixNQUFoQjtBQUVBLEVBaEpDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVTNaLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsRUFBOEMsbUJBQUFBLENBQVEsRUFBUixDQUE5QyxDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsRUFBcUIsdUJBQXJCLENBQVAsb0NBQXVDTCxPQUF2QztBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixlQUFZO0FBQ1Q7QUFDQSxPQUFJUyxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUlDLE9BQU9GLE1BQU1FLElBQWpCO0FBQ0EsT0FBSWMsWUFBWWhCLE1BQU1nQixTQUF0QjtBQUNBLE9BQUl5RixTQUFTMUcsRUFBRTRHLElBQWY7QUFDQSxPQUFJZ0UsTUFBTWxFLE9BQU9rRSxHQUFqQjs7QUFFQTs7OztBQUlBLE9BQUk4TyxTQUFTaFQsT0FBT2dULE1BQVAsR0FBZ0J2WixLQUFLQyxNQUFMLENBQVk7QUFDckM7Ozs7Ozs7QUFPQTBGLFNBQUszRixLQUFLQyxNQUFMLENBQVk7QUFDYndZLGNBQVMsTUFBSSxFQURBO0FBRWJ0UyxhQUFRc0UsR0FGSztBQUdiaU8saUJBQVk7QUFIQyxLQUFaLENBUmdDOztBQWNyQzs7Ozs7Ozs7Ozs7QUFXQXJZLFVBQU0sY0FBVXNGLEdBQVYsRUFBZTtBQUNqQixVQUFLQSxHQUFMLEdBQVcsS0FBS0EsR0FBTCxDQUFTMUYsTUFBVCxDQUFnQjBGLEdBQWhCLENBQVg7QUFDSCxLQTNCb0M7O0FBNkJyQzs7Ozs7Ozs7Ozs7O0FBWUFnVCxhQUFTLGlCQUFVQyxRQUFWLEVBQW9CQyxJQUFwQixFQUEwQjtBQUMvQjtBQUNBLFNBQUlsVCxNQUFNLEtBQUtBLEdBQWY7O0FBRUE7QUFDQSxTQUFJUSxTQUFTUixJQUFJUSxNQUFKLENBQVc1RyxNQUFYLEVBQWI7O0FBRUE7QUFDQSxTQUFJdVosYUFBYWhZLFVBQVV2QixNQUFWLEVBQWpCOztBQUVBO0FBQ0EsU0FBSXlaLGtCQUFrQkYsV0FBVy9YLEtBQWpDO0FBQ0EsU0FBSTBYLFVBQVU5UyxJQUFJOFMsT0FBbEI7QUFDQSxTQUFJQyxhQUFhL1MsSUFBSStTLFVBQXJCOztBQUVBO0FBQ0EsWUFBT00sZ0JBQWdCL1gsTUFBaEIsR0FBeUJ3WCxPQUFoQyxFQUF5QztBQUNyQyxVQUFJUyxLQUFKLEVBQVc7QUFDUC9TLGNBQU9OLE1BQVAsQ0FBY3FULEtBQWQ7QUFDSDtBQUNELFVBQUlBLFFBQVEvUyxPQUFPTixNQUFQLENBQWMrUyxRQUFkLEVBQXdCN1MsUUFBeEIsQ0FBaUM4UyxJQUFqQyxDQUFaO0FBQ0ExUyxhQUFPOUIsS0FBUDs7QUFFQTtBQUNBLFdBQUssSUFBSXpDLElBQUksQ0FBYixFQUFnQkEsSUFBSThXLFVBQXBCLEVBQWdDOVcsR0FBaEMsRUFBcUM7QUFDakNzWCxlQUFRL1MsT0FBT0osUUFBUCxDQUFnQm1ULEtBQWhCLENBQVI7QUFDQS9TLGNBQU85QixLQUFQO0FBQ0g7O0FBRUR5VSxpQkFBV3pYLE1BQVgsQ0FBa0I2WCxLQUFsQjtBQUNIO0FBQ0RKLGdCQUFXOVgsUUFBWCxHQUFzQnlYLFVBQVUsQ0FBaEM7O0FBRUEsWUFBT0ssVUFBUDtBQUNIO0FBM0VvQyxJQUFaLENBQTdCOztBQThFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkFqWixLQUFFMFosTUFBRixHQUFXLFVBQVVYLFFBQVYsRUFBb0JDLElBQXBCLEVBQTBCbFQsR0FBMUIsRUFBK0I7QUFDdEMsV0FBTzRULE9BQU9oYSxNQUFQLENBQWNvRyxHQUFkLEVBQW1CZ1QsT0FBbkIsQ0FBMkJDLFFBQTNCLEVBQXFDQyxJQUFyQyxDQUFQO0FBQ0gsSUFGRDtBQUdILEdBL0dBLEdBQUQ7O0FBa0hBLFNBQU96WixTQUFTbWEsTUFBaEI7QUFFQSxFQW5JQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVUxYSxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUErQkwsT0FBL0I7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFM0I7OztBQUdBQSxXQUFTVyxHQUFULENBQWF5WixNQUFiLElBQXdCLFVBQVVsYSxTQUFWLEVBQXFCO0FBQ3pDO0FBQ0EsT0FBSU8sSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJQyxPQUFPRixNQUFNRSxJQUFqQjtBQUNBLE9BQUljLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJc0QseUJBQXlCdEUsTUFBTXNFLHNCQUFuQztBQUNBLE9BQUl6QixRQUFROUMsRUFBRStDLEdBQWQ7QUFDQSxPQUFJZ0IsT0FBT2pCLE1BQU1pQixJQUFqQjtBQUNBLE9BQUlzRixTQUFTdkcsTUFBTXVHLE1BQW5CO0FBQ0EsT0FBSTNDLFNBQVMxRyxFQUFFNEcsSUFBZjtBQUNBLE9BQUk4UyxTQUFTaFQsT0FBT2dULE1BQXBCOztBQUVBOzs7Ozs7OztBQVFBLE9BQUlDLFNBQVMxWixNQUFNMFosTUFBTixHQUFlcFYsdUJBQXVCbkUsTUFBdkIsQ0FBOEI7QUFDdEQ7Ozs7O0FBS0EwRixTQUFLM0YsS0FBS0MsTUFBTCxFQU5pRDs7QUFRdEQ7Ozs7Ozs7Ozs7Ozs7O0FBY0F3WixxQkFBaUIseUJBQVVuVCxHQUFWLEVBQWVYLEdBQWYsRUFBb0I7QUFDakMsWUFBTyxLQUFLcEcsTUFBTCxDQUFZLEtBQUttYSxlQUFqQixFQUFrQ3BULEdBQWxDLEVBQXVDWCxHQUF2QyxDQUFQO0FBQ0gsS0F4QnFEOztBQTBCdEQ7Ozs7Ozs7Ozs7Ozs7O0FBY0FnVSxxQkFBaUIseUJBQVVyVCxHQUFWLEVBQWVYLEdBQWYsRUFBb0I7QUFDakMsWUFBTyxLQUFLcEcsTUFBTCxDQUFZLEtBQUtxYSxlQUFqQixFQUFrQ3RULEdBQWxDLEVBQXVDWCxHQUF2QyxDQUFQO0FBQ0gsS0ExQ3FEOztBQTRDdEQ7Ozs7Ozs7Ozs7O0FBV0F0RixVQUFNLGNBQVV3WixTQUFWLEVBQXFCdlQsR0FBckIsRUFBMEJYLEdBQTFCLEVBQStCO0FBQ2pDO0FBQ0EsVUFBS0EsR0FBTCxHQUFXLEtBQUtBLEdBQUwsQ0FBUzFGLE1BQVQsQ0FBZ0IwRixHQUFoQixDQUFYOztBQUVBO0FBQ0EsVUFBS21VLFVBQUwsR0FBa0JELFNBQWxCO0FBQ0EsVUFBS0UsSUFBTCxHQUFZelQsR0FBWjs7QUFFQTtBQUNBLFVBQUtqQyxLQUFMO0FBQ0gsS0FqRXFEOztBQW1FdEQ7Ozs7Ozs7QUFPQUEsV0FBTyxpQkFBWTtBQUNmO0FBQ0FELDRCQUF1QkMsS0FBdkIsQ0FBNkJ0QyxJQUE3QixDQUFrQyxJQUFsQzs7QUFFQTtBQUNBLFVBQUs2RCxRQUFMO0FBQ0gsS0FoRnFEOztBQWtGdEQ7Ozs7Ozs7Ozs7OztBQVlBb1UsYUFBUyxpQkFBVUMsVUFBVixFQUFzQjtBQUMzQjtBQUNBLFVBQUt6VixPQUFMLENBQWF5VixVQUFiOztBQUVBO0FBQ0EsWUFBTyxLQUFLdlYsUUFBTCxFQUFQO0FBQ0gsS0FwR3FEOztBQXNHdEQ7Ozs7Ozs7Ozs7Ozs7O0FBY0FxQixjQUFVLGtCQUFVa1UsVUFBVixFQUFzQjtBQUM1QjtBQUNBLFNBQUlBLFVBQUosRUFBZ0I7QUFDWixXQUFLelYsT0FBTCxDQUFheVYsVUFBYjtBQUNIOztBQUVEO0FBQ0EsU0FBSUMscUJBQXFCLEtBQUtqVSxXQUFMLEVBQXpCOztBQUVBLFlBQU9pVSxrQkFBUDtBQUNILEtBOUhxRDs7QUFnSXREekIsYUFBUyxNQUFJLEVBaEl5Qzs7QUFrSXREMEIsWUFBUSxNQUFJLEVBbEkwQzs7QUFvSXREVCxxQkFBaUIsQ0FwSXFDOztBQXNJdERFLHFCQUFpQixDQXRJcUM7O0FBd0l0RDs7Ozs7Ozs7Ozs7OztBQWFBMVQsbUJBQWdCLFlBQVk7QUFDeEIsY0FBU2tVLG9CQUFULENBQThCOVQsR0FBOUIsRUFBbUM7QUFDL0IsVUFBSSxPQUFPQSxHQUFQLElBQWMsUUFBbEIsRUFBNEI7QUFDeEIsY0FBTytULG1CQUFQO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsY0FBT0Msa0JBQVA7QUFDSDtBQUNKOztBQUVELFlBQU8sVUFBVUMsTUFBVixFQUFrQjtBQUNyQixhQUFPO0FBQ0hDLGdCQUFTLGlCQUFVcFUsT0FBVixFQUFtQkUsR0FBbkIsRUFBd0JYLEdBQXhCLEVBQTZCO0FBQ2xDLGVBQU95VSxxQkFBcUI5VCxHQUFyQixFQUEwQmtVLE9BQTFCLENBQWtDRCxNQUFsQyxFQUEwQ25VLE9BQTFDLEVBQW1ERSxHQUFuRCxFQUF3RFgsR0FBeEQsQ0FBUDtBQUNILFFBSEU7O0FBS0g4VSxnQkFBUyxpQkFBVUMsVUFBVixFQUFzQnBVLEdBQXRCLEVBQTJCWCxHQUEzQixFQUFnQztBQUNyQyxlQUFPeVUscUJBQXFCOVQsR0FBckIsRUFBMEJtVSxPQUExQixDQUFrQ0YsTUFBbEMsRUFBMENHLFVBQTFDLEVBQXNEcFUsR0FBdEQsRUFBMkRYLEdBQTNELENBQVA7QUFDSDtBQVBFLE9BQVA7QUFTSCxNQVZEO0FBV0gsS0FwQmU7QUFySnNDLElBQTlCLENBQTVCOztBQTRLQTs7Ozs7QUFLQSxPQUFJZ1YsZUFBZTdhLE1BQU02YSxZQUFOLEdBQXFCbkIsT0FBT3ZaLE1BQVAsQ0FBYztBQUNsRGdHLGlCQUFhLHVCQUFZO0FBQ3JCO0FBQ0EsU0FBSTJVLHVCQUF1QixLQUFLbFcsUUFBTCxDQUFjLENBQUMsQ0FBQyxPQUFoQixDQUEzQjs7QUFFQSxZQUFPa1csb0JBQVA7QUFDSCxLQU5pRDs7QUFRbEQ5VixlQUFXO0FBUnVDLElBQWQsQ0FBeEM7O0FBV0E7OztBQUdBLE9BQUkrVixTQUFTaGIsRUFBRWliLElBQUYsR0FBUyxFQUF0Qjs7QUFFQTs7O0FBR0EsT0FBSUMsa0JBQWtCamIsTUFBTWliLGVBQU4sR0FBd0IvYSxLQUFLQyxNQUFMLENBQVk7QUFDdEQ7Ozs7Ozs7Ozs7OztBQVlBd1oscUJBQWlCLHlCQUFVYyxNQUFWLEVBQWtCUyxFQUFsQixFQUFzQjtBQUNuQyxZQUFPLEtBQUtDLFNBQUwsQ0FBZTFiLE1BQWYsQ0FBc0JnYixNQUF0QixFQUE4QlMsRUFBOUIsQ0FBUDtBQUNILEtBZnFEOztBQWlCdEQ7Ozs7Ozs7Ozs7OztBQVlBckIscUJBQWlCLHlCQUFVWSxNQUFWLEVBQWtCUyxFQUFsQixFQUFzQjtBQUNuQyxZQUFPLEtBQUtFLFNBQUwsQ0FBZTNiLE1BQWYsQ0FBc0JnYixNQUF0QixFQUE4QlMsRUFBOUIsQ0FBUDtBQUNILEtBL0JxRDs7QUFpQ3REOzs7Ozs7Ozs7O0FBVUEzYSxVQUFNLGNBQVVrYSxNQUFWLEVBQWtCUyxFQUFsQixFQUFzQjtBQUN4QixVQUFLRyxPQUFMLEdBQWVaLE1BQWY7QUFDQSxVQUFLYSxHQUFMLEdBQVdKLEVBQVg7QUFDSDtBQTlDcUQsSUFBWixDQUE5Qzs7QUFpREE7OztBQUdBLE9BQUlLLE1BQU1SLE9BQU9RLEdBQVAsR0FBYyxZQUFZO0FBQ2hDOzs7QUFHQSxRQUFJQSxNQUFNTixnQkFBZ0I5YSxNQUFoQixFQUFWOztBQUVBOzs7QUFHQW9iLFFBQUlKLFNBQUosR0FBZ0JJLElBQUlwYixNQUFKLENBQVc7QUFDdkI7Ozs7Ozs7Ozs7QUFVQXFiLG1CQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsVUFBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxVQUFJclcsWUFBWXlWLE9BQU96VixTQUF2Qjs7QUFFQTtBQUNBeVcsZUFBU3haLElBQVQsQ0FBYyxJQUFkLEVBQW9CaEIsS0FBcEIsRUFBMkJ1RSxNQUEzQixFQUFtQ1IsU0FBbkM7QUFDQXlWLGFBQU9pQixZQUFQLENBQW9CemEsS0FBcEIsRUFBMkJ1RSxNQUEzQjs7QUFFQTtBQUNBLFdBQUttVyxVQUFMLEdBQWtCMWEsTUFBTWlCLEtBQU4sQ0FBWXNELE1BQVosRUFBb0JBLFNBQVNSLFNBQTdCLENBQWxCO0FBQ0g7QUF0QnNCLEtBQVgsQ0FBaEI7O0FBeUJBOzs7QUFHQXVXLFFBQUlILFNBQUosR0FBZ0JHLElBQUlwYixNQUFKLENBQVc7QUFDdkI7Ozs7Ozs7Ozs7QUFVQXFiLG1CQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsVUFBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxVQUFJclcsWUFBWXlWLE9BQU96VixTQUF2Qjs7QUFFQTtBQUNBLFVBQUk0VyxZQUFZM2EsTUFBTWlCLEtBQU4sQ0FBWXNELE1BQVosRUFBb0JBLFNBQVNSLFNBQTdCLENBQWhCOztBQUVBO0FBQ0F5VixhQUFPb0IsWUFBUCxDQUFvQjVhLEtBQXBCLEVBQTJCdUUsTUFBM0I7QUFDQWlXLGVBQVN4WixJQUFULENBQWMsSUFBZCxFQUFvQmhCLEtBQXBCLEVBQTJCdUUsTUFBM0IsRUFBbUNSLFNBQW5DOztBQUVBO0FBQ0EsV0FBSzJXLFVBQUwsR0FBa0JDLFNBQWxCO0FBQ0g7QUF6QnNCLEtBQVgsQ0FBaEI7O0FBNEJBLGFBQVNILFFBQVQsQ0FBa0J4YSxLQUFsQixFQUF5QnVFLE1BQXpCLEVBQWlDUixTQUFqQyxFQUE0QztBQUN4QztBQUNBLFNBQUlrVyxLQUFLLEtBQUtJLEdBQWQ7O0FBRUE7QUFDQSxTQUFJSixFQUFKLEVBQVE7QUFDSixVQUFJOUIsUUFBUThCLEVBQVo7O0FBRUE7QUFDQSxXQUFLSSxHQUFMLEdBQVc5YixTQUFYO0FBQ0gsTUFMRCxNQUtPO0FBQ0gsVUFBSTRaLFFBQVEsS0FBS3VDLFVBQWpCO0FBQ0g7O0FBRUQ7QUFDQSxVQUFLLElBQUk3WixJQUFJLENBQWIsRUFBZ0JBLElBQUlrRCxTQUFwQixFQUErQmxELEdBQS9CLEVBQW9DO0FBQ2hDYixZQUFNdUUsU0FBUzFELENBQWYsS0FBcUJzWCxNQUFNdFgsQ0FBTixDQUFyQjtBQUNIO0FBQ0o7O0FBRUQsV0FBT3laLEdBQVA7QUFDSCxJQXRGdUIsRUFBeEI7O0FBd0ZBOzs7QUFHQSxPQUFJTyxRQUFRL2IsRUFBRWdjLEdBQUYsR0FBUSxFQUFwQjs7QUFFQTs7O0FBR0EsT0FBSUMsUUFBUUYsTUFBTUUsS0FBTixHQUFjO0FBQ3RCOzs7Ozs7Ozs7Ozs7QUFZQUQsU0FBSyxhQUFVcFgsSUFBVixFQUFnQkssU0FBaEIsRUFBMkI7QUFDNUI7QUFDQSxTQUFJQyxpQkFBaUJELFlBQVksQ0FBakM7O0FBRUE7QUFDQSxTQUFJaVgsZ0JBQWdCaFgsaUJBQWlCTixLQUFLekQsUUFBTCxHQUFnQitELGNBQXJEOztBQUVBO0FBQ0EsU0FBSWlYLGNBQWVELGlCQUFpQixFQUFsQixHQUF5QkEsaUJBQWlCLEVBQTFDLEdBQWlEQSxpQkFBaUIsQ0FBbEUsR0FBdUVBLGFBQXpGOztBQUVBO0FBQ0EsU0FBSUUsZUFBZSxFQUFuQjtBQUNBLFVBQUssSUFBSXJhLElBQUksQ0FBYixFQUFnQkEsSUFBSW1hLGFBQXBCLEVBQW1DbmEsS0FBSyxDQUF4QyxFQUEyQztBQUN2Q3FhLG1CQUFhdlosSUFBYixDQUFrQnNaLFdBQWxCO0FBQ0g7QUFDRCxTQUFJRSxVQUFVcGIsVUFBVXZCLE1BQVYsQ0FBaUIwYyxZQUFqQixFQUErQkYsYUFBL0IsQ0FBZDs7QUFFQTtBQUNBdFgsVUFBS3BELE1BQUwsQ0FBWTZhLE9BQVo7QUFDSCxLQWhDcUI7O0FBa0N0Qjs7Ozs7Ozs7Ozs7QUFXQUMsV0FBTyxlQUFVMVgsSUFBVixFQUFnQjtBQUNuQjtBQUNBLFNBQUlzWCxnQkFBZ0J0WCxLQUFLMUQsS0FBTCxDQUFZMEQsS0FBS3pELFFBQUwsR0FBZ0IsQ0FBakIsS0FBd0IsQ0FBbkMsSUFBd0MsSUFBNUQ7O0FBRUE7QUFDQXlELFVBQUt6RCxRQUFMLElBQWlCK2EsYUFBakI7QUFDSDtBQW5EcUIsSUFBMUI7O0FBc0RBOzs7OztBQUtBLE9BQUlLLGNBQWN0YyxNQUFNc2MsV0FBTixHQUFvQjVDLE9BQU92WixNQUFQLENBQWM7QUFDaEQ7Ozs7OztBQU1BMEYsU0FBSzZULE9BQU83VCxHQUFQLENBQVcxRixNQUFYLENBQWtCO0FBQ25CNmEsV0FBTU8sR0FEYTtBQUVuQmEsY0FBU0o7QUFGVSxLQUFsQixDQVAyQzs7QUFZaER6WCxXQUFPLGlCQUFZO0FBQ2Y7QUFDQW1WLFlBQU9uVixLQUFQLENBQWF0QyxJQUFiLENBQWtCLElBQWxCOztBQUVBO0FBQ0EsU0FBSTRELE1BQU0sS0FBS0EsR0FBZjtBQUNBLFNBQUlxVixLQUFLclYsSUFBSXFWLEVBQWI7QUFDQSxTQUFJRixPQUFPblYsSUFBSW1WLElBQWY7O0FBRUE7QUFDQSxTQUFJLEtBQUtoQixVQUFMLElBQW1CLEtBQUtKLGVBQTVCLEVBQTZDO0FBQ3pDLFVBQUkyQyxjQUFjdkIsS0FBS3JCLGVBQXZCO0FBQ0gsTUFGRCxNQUVPLGtEQUFtRDtBQUN0RCxXQUFJNEMsY0FBY3ZCLEtBQUtuQixlQUF2QjtBQUNBO0FBQ0EsWUFBS3pVLGNBQUwsR0FBc0IsQ0FBdEI7QUFDSDs7QUFFRCxTQUFJLEtBQUtvWCxLQUFMLElBQWMsS0FBS0EsS0FBTCxDQUFXQyxTQUFYLElBQXdCRixXQUExQyxFQUF1RDtBQUNuRCxXQUFLQyxLQUFMLENBQVdqYyxJQUFYLENBQWdCLElBQWhCLEVBQXNCMmEsTUFBTUEsR0FBR2phLEtBQS9CO0FBQ0gsTUFGRCxNQUVPO0FBQ0gsV0FBS3ViLEtBQUwsR0FBYUQsWUFBWXRhLElBQVosQ0FBaUIrWSxJQUFqQixFQUF1QixJQUF2QixFQUE2QkUsTUFBTUEsR0FBR2phLEtBQXRDLENBQWI7QUFDQSxXQUFLdWIsS0FBTCxDQUFXQyxTQUFYLEdBQXVCRixXQUF2QjtBQUNIO0FBQ0osS0FwQytDOztBQXNDaEQ5VyxxQkFBaUIseUJBQVV4RSxLQUFWLEVBQWlCdUUsTUFBakIsRUFBeUI7QUFDdEMsVUFBS2dYLEtBQUwsQ0FBV2hCLFlBQVgsQ0FBd0J2YSxLQUF4QixFQUErQnVFLE1BQS9CO0FBQ0gsS0F4QytDOztBQTBDaERXLGlCQUFhLHVCQUFZO0FBQ3JCO0FBQ0EsU0FBSWlXLFVBQVUsS0FBS3ZXLEdBQUwsQ0FBU3VXLE9BQXZCOztBQUVBO0FBQ0EsU0FBSSxLQUFLcEMsVUFBTCxJQUFtQixLQUFLSixlQUE1QixFQUE2QztBQUN6QztBQUNBd0MsY0FBUUwsR0FBUixDQUFZLEtBQUt2WCxLQUFqQixFQUF3QixLQUFLUSxTQUE3Qjs7QUFFQTtBQUNBLFVBQUk4Vix1QkFBdUIsS0FBS2xXLFFBQUwsQ0FBYyxDQUFDLENBQUMsT0FBaEIsQ0FBM0I7QUFDSCxNQU5ELE1BTU8sa0RBQW1EO0FBQ3REO0FBQ0EsV0FBSWtXLHVCQUF1QixLQUFLbFcsUUFBTCxDQUFjLENBQUMsQ0FBQyxPQUFoQixDQUEzQjs7QUFFQTtBQUNBd1gsZUFBUUMsS0FBUixDQUFjdkIsb0JBQWQ7QUFDSDs7QUFFRCxZQUFPQSxvQkFBUDtBQUNILEtBOUQrQzs7QUFnRWhEOVYsZUFBVyxNQUFJO0FBaEVpQyxJQUFkLENBQXRDOztBQW1FQTs7Ozs7Ozs7Ozs7OztBQWFBLE9BQUkwWCxlQUFlMWMsTUFBTTBjLFlBQU4sR0FBcUJ4YyxLQUFLQyxNQUFMLENBQVk7QUFDaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkFJLFVBQU0sY0FBVW9jLFlBQVYsRUFBd0I7QUFDMUIsVUFBS3RjLEtBQUwsQ0FBV3NjLFlBQVg7QUFDSCxLQXRCK0M7O0FBd0JoRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUE3YixjQUFVLGtCQUFVOGIsU0FBVixFQUFxQjtBQUMzQixZQUFPLENBQUNBLGFBQWEsS0FBS0EsU0FBbkIsRUFBOEJ0YixTQUE5QixDQUF3QyxJQUF4QyxDQUFQO0FBQ0g7QUF6QytDLElBQVosQ0FBeEM7O0FBNENBOzs7QUFHQSxPQUFJdWIsV0FBVzljLEVBQUUrYyxNQUFGLEdBQVcsRUFBMUI7O0FBRUE7OztBQUdBLE9BQUlDLG1CQUFtQkYsU0FBU0csT0FBVCxHQUFtQjtBQUN0Qzs7Ozs7Ozs7Ozs7OztBQWFBMWIsZUFBVyxtQkFBVXFiLFlBQVYsRUFBd0I7QUFDL0I7QUFDQSxTQUFJL0IsYUFBYStCLGFBQWEvQixVQUE5QjtBQUNBLFNBQUk3QixPQUFPNEQsYUFBYTVELElBQXhCOztBQUVBO0FBQ0EsU0FBSUEsSUFBSixFQUFVO0FBQ04sVUFBSXZYLFlBQVlSLFVBQVV2QixNQUFWLENBQWlCLENBQUMsVUFBRCxFQUFhLFVBQWIsQ0FBakIsRUFBMkM4QixNQUEzQyxDQUFrRHdYLElBQWxELEVBQXdEeFgsTUFBeEQsQ0FBK0RxWixVQUEvRCxDQUFoQjtBQUNILE1BRkQsTUFFTztBQUNILFVBQUlwWixZQUFZb1osVUFBaEI7QUFDSDs7QUFFRCxZQUFPcFosVUFBVVYsUUFBVixDQUFtQnNJLE1BQW5CLENBQVA7QUFDSCxLQTNCcUM7O0FBNkJ0Qzs7Ozs7Ozs7Ozs7OztBQWFBbEcsV0FBTyxlQUFVK1osVUFBVixFQUFzQjtBQUN6QjtBQUNBLFNBQUlyQyxhQUFheFIsT0FBT2xHLEtBQVAsQ0FBYStaLFVBQWIsQ0FBakI7O0FBRUE7QUFDQSxTQUFJQyxrQkFBa0J0QyxXQUFXM1osS0FBakM7O0FBRUE7QUFDQSxTQUFJaWMsZ0JBQWdCLENBQWhCLEtBQXNCLFVBQXRCLElBQW9DQSxnQkFBZ0IsQ0FBaEIsS0FBc0IsVUFBOUQsRUFBMEU7QUFDdEU7QUFDQSxVQUFJbkUsT0FBTy9YLFVBQVV2QixNQUFWLENBQWlCeWQsZ0JBQWdCaGIsS0FBaEIsQ0FBc0IsQ0FBdEIsRUFBeUIsQ0FBekIsQ0FBakIsQ0FBWDs7QUFFQTtBQUNBZ2Isc0JBQWdCdlgsTUFBaEIsQ0FBdUIsQ0FBdkIsRUFBMEIsQ0FBMUI7QUFDQWlWLGlCQUFXMVosUUFBWCxJQUF1QixFQUF2QjtBQUNIOztBQUVELFlBQU93YixhQUFhamQsTUFBYixDQUFvQixFQUFFbWIsWUFBWUEsVUFBZCxFQUEwQjdCLE1BQU1BLElBQWhDLEVBQXBCLENBQVA7QUFDSDtBQTVEcUMsSUFBMUM7O0FBK0RBOzs7QUFHQSxPQUFJeUIscUJBQXFCeGEsTUFBTXdhLGtCQUFOLEdBQTJCdGEsS0FBS0MsTUFBTCxDQUFZO0FBQzVEOzs7OztBQUtBMEYsU0FBSzNGLEtBQUtDLE1BQUwsQ0FBWTtBQUNiMmMsYUFBUUM7QUFESyxLQUFaLENBTnVEOztBQVU1RDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBckMsYUFBUyxpQkFBVUQsTUFBVixFQUFrQm5VLE9BQWxCLEVBQTJCRSxHQUEzQixFQUFnQ1gsR0FBaEMsRUFBcUM7QUFDMUM7QUFDQUEsV0FBTSxLQUFLQSxHQUFMLENBQVMxRixNQUFULENBQWdCMEYsR0FBaEIsQ0FBTjs7QUFFQTtBQUNBLFNBQUlzWCxZQUFZMUMsT0FBT2QsZUFBUCxDQUF1Qm5ULEdBQXZCLEVBQTRCWCxHQUE1QixDQUFoQjtBQUNBLFNBQUkrVSxhQUFhdUMsVUFBVWxYLFFBQVYsQ0FBbUJLLE9BQW5CLENBQWpCOztBQUVBO0FBQ0EsU0FBSThXLFlBQVlELFVBQVV0WCxHQUExQjs7QUFFQTtBQUNBLFlBQU82VyxhQUFhamQsTUFBYixDQUFvQjtBQUN2Qm1iLGtCQUFZQSxVQURXO0FBRXZCcFUsV0FBS0EsR0FGa0I7QUFHdkIwVSxVQUFJa0MsVUFBVWxDLEVBSFM7QUFJdkJtQyxpQkFBVzVDLE1BSlk7QUFLdkJPLFlBQU1vQyxVQUFVcEMsSUFMTztBQU12Qm9CLGVBQVNnQixVQUFVaEIsT0FOSTtBQU92QnBYLGlCQUFXeVYsT0FBT3pWLFNBUEs7QUFRdkI0WCxpQkFBVy9XLElBQUlpWDtBQVJRLE1BQXBCLENBQVA7QUFVSCxLQWxEMkQ7O0FBb0Q1RDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkFuQyxhQUFTLGlCQUFVRixNQUFWLEVBQWtCRyxVQUFsQixFQUE4QnBVLEdBQTlCLEVBQW1DWCxHQUFuQyxFQUF3QztBQUM3QztBQUNBQSxXQUFNLEtBQUtBLEdBQUwsQ0FBUzFGLE1BQVQsQ0FBZ0IwRixHQUFoQixDQUFOOztBQUVBO0FBQ0ErVSxrQkFBYSxLQUFLMEMsTUFBTCxDQUFZMUMsVUFBWixFQUF3Qi9VLElBQUlpWCxNQUE1QixDQUFiOztBQUVBO0FBQ0EsU0FBSVMsWUFBWTlDLE9BQU9aLGVBQVAsQ0FBdUJyVCxHQUF2QixFQUE0QlgsR0FBNUIsRUFBaUNJLFFBQWpDLENBQTBDMlUsV0FBV0EsVUFBckQsQ0FBaEI7O0FBRUEsWUFBTzJDLFNBQVA7QUFDSCxLQWhGMkQ7O0FBa0Y1RDs7Ozs7Ozs7Ozs7Ozs7O0FBZUFELFlBQVEsZ0JBQVUxQyxVQUFWLEVBQXNCa0MsTUFBdEIsRUFBOEI7QUFDbEMsU0FBSSxPQUFPbEMsVUFBUCxJQUFxQixRQUF6QixFQUFtQztBQUMvQixhQUFPa0MsT0FBTzVaLEtBQVAsQ0FBYTBYLFVBQWIsRUFBeUIsSUFBekIsQ0FBUDtBQUNILE1BRkQsTUFFTztBQUNILGFBQU9BLFVBQVA7QUFDSDtBQUNKO0FBdkcyRCxJQUFaLENBQXBEOztBQTBHQTs7O0FBR0EsT0FBSTRDLFFBQVF6ZCxFQUFFMGQsR0FBRixHQUFRLEVBQXBCOztBQUVBOzs7QUFHQSxPQUFJQyxhQUFhRixNQUFNUixPQUFOLEdBQWdCO0FBQzdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQVcsYUFBUyxpQkFBVTdFLFFBQVYsRUFBb0JILE9BQXBCLEVBQTZCMEIsTUFBN0IsRUFBcUN0QixJQUFyQyxFQUEyQztBQUNoRDtBQUNBLFNBQUksQ0FBQ0EsSUFBTCxFQUFXO0FBQ1BBLGFBQU8vWCxVQUFVbUIsTUFBVixDQUFpQixLQUFHLENBQXBCLENBQVA7QUFDSDs7QUFFRDtBQUNBLFNBQUlxRSxNQUFNaVQsT0FBT2hhLE1BQVAsQ0FBYyxFQUFFa1osU0FBU0EsVUFBVTBCLE1BQXJCLEVBQWQsRUFBNkN4QixPQUE3QyxDQUFxREMsUUFBckQsRUFBK0RDLElBQS9ELENBQVY7O0FBRUE7QUFDQSxTQUFJbUMsS0FBS2xhLFVBQVV2QixNQUFWLENBQWlCK0csSUFBSXZGLEtBQUosQ0FBVWlCLEtBQVYsQ0FBZ0J5VyxPQUFoQixDQUFqQixFQUEyQzBCLFNBQVMsQ0FBcEQsQ0FBVDtBQUNBN1QsU0FBSXRGLFFBQUosR0FBZXlYLFVBQVUsQ0FBekI7O0FBRUE7QUFDQSxZQUFPK0QsYUFBYWpkLE1BQWIsQ0FBb0IsRUFBRStHLEtBQUtBLEdBQVAsRUFBWTBVLElBQUlBLEVBQWhCLEVBQW9CbkMsTUFBTUEsSUFBMUIsRUFBcEIsQ0FBUDtBQUNIO0FBakM0QixJQUFqQzs7QUFvQ0E7Ozs7QUFJQSxPQUFJd0Isc0JBQXNCdmEsTUFBTXVhLG1CQUFOLEdBQTRCQyxtQkFBbUJyYSxNQUFuQixDQUEwQjtBQUM1RTs7Ozs7QUFLQTBGLFNBQUsyVSxtQkFBbUIzVSxHQUFuQixDQUF1QjFGLE1BQXZCLENBQThCO0FBQy9Cc2QsVUFBS0M7QUFEMEIsS0FBOUIsQ0FOdUU7O0FBVTVFOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQWhELGFBQVMsaUJBQVVELE1BQVYsRUFBa0JuVSxPQUFsQixFQUEyQndTLFFBQTNCLEVBQXFDalQsR0FBckMsRUFBMEM7QUFDL0M7QUFDQUEsV0FBTSxLQUFLQSxHQUFMLENBQVMxRixNQUFULENBQWdCMEYsR0FBaEIsQ0FBTjs7QUFFQTtBQUNBLFNBQUkrWCxnQkFBZ0IvWCxJQUFJNFgsR0FBSixDQUFRRSxPQUFSLENBQWdCN0UsUUFBaEIsRUFBMEIyQixPQUFPOUIsT0FBakMsRUFBMEM4QixPQUFPSixNQUFqRCxDQUFwQjs7QUFFQTtBQUNBeFUsU0FBSXFWLEVBQUosR0FBUzBDLGNBQWMxQyxFQUF2Qjs7QUFFQTtBQUNBLFNBQUlOLGFBQWFKLG1CQUFtQkUsT0FBbkIsQ0FBMkJ6WSxJQUEzQixDQUFnQyxJQUFoQyxFQUFzQ3dZLE1BQXRDLEVBQThDblUsT0FBOUMsRUFBdURzWCxjQUFjcFgsR0FBckUsRUFBMEVYLEdBQTFFLENBQWpCOztBQUVBO0FBQ0ErVSxnQkFBV3ZhLEtBQVgsQ0FBaUJ1ZCxhQUFqQjs7QUFFQSxZQUFPaEQsVUFBUDtBQUNILEtBNUMyRTs7QUE4QzVFOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQUQsYUFBUyxpQkFBVUYsTUFBVixFQUFrQkcsVUFBbEIsRUFBOEI5QixRQUE5QixFQUF3Q2pULEdBQXhDLEVBQTZDO0FBQ2xEO0FBQ0FBLFdBQU0sS0FBS0EsR0FBTCxDQUFTMUYsTUFBVCxDQUFnQjBGLEdBQWhCLENBQU47O0FBRUE7QUFDQStVLGtCQUFhLEtBQUswQyxNQUFMLENBQVkxQyxVQUFaLEVBQXdCL1UsSUFBSWlYLE1BQTVCLENBQWI7O0FBRUE7QUFDQSxTQUFJYyxnQkFBZ0IvWCxJQUFJNFgsR0FBSixDQUFRRSxPQUFSLENBQWdCN0UsUUFBaEIsRUFBMEIyQixPQUFPOUIsT0FBakMsRUFBMEM4QixPQUFPSixNQUFqRCxFQUF5RE8sV0FBVzdCLElBQXBFLENBQXBCOztBQUVBO0FBQ0FsVCxTQUFJcVYsRUFBSixHQUFTMEMsY0FBYzFDLEVBQXZCOztBQUVBO0FBQ0EsU0FBSXFDLFlBQVkvQyxtQkFBbUJHLE9BQW5CLENBQTJCMVksSUFBM0IsQ0FBZ0MsSUFBaEMsRUFBc0N3WSxNQUF0QyxFQUE4Q0csVUFBOUMsRUFBMERnRCxjQUFjcFgsR0FBeEUsRUFBNkVYLEdBQTdFLENBQWhCOztBQUVBLFlBQU8wWCxTQUFQO0FBQ0g7QUFoRjJFLElBQTFCLENBQXREO0FBa0ZILEdBMTFCdUIsRUFBeEI7QUE2MUJBLEVBLzJCQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVV4ZSxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUFvQ0wsT0FBcEM7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFM0I7OztBQUdBQSxXQUFTMGIsSUFBVCxDQUFjNkMsR0FBZCxHQUFxQixZQUFZO0FBQzdCLE9BQUlBLE1BQU12ZSxTQUFTVyxHQUFULENBQWFnYixlQUFiLENBQTZCOWEsTUFBN0IsRUFBVjs7QUFFQTBkLE9BQUkxQyxTQUFKLEdBQWdCMEMsSUFBSTFkLE1BQUosQ0FBVztBQUN2QnFiLGtCQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsU0FBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxTQUFJclcsWUFBWXlWLE9BQU96VixTQUF2Qjs7QUFFQThZLGlDQUE0QjdiLElBQTVCLENBQWlDLElBQWpDLEVBQXVDaEIsS0FBdkMsRUFBOEN1RSxNQUE5QyxFQUFzRFIsU0FBdEQsRUFBaUV5VixNQUFqRTs7QUFFQTtBQUNBLFVBQUtrQixVQUFMLEdBQWtCMWEsTUFBTWlCLEtBQU4sQ0FBWXNELE1BQVosRUFBb0JBLFNBQVNSLFNBQTdCLENBQWxCO0FBQ0g7QUFWc0IsSUFBWCxDQUFoQjs7QUFhQTZZLE9BQUl6QyxTQUFKLEdBQWdCeUMsSUFBSTFkLE1BQUosQ0FBVztBQUN2QnFiLGtCQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsU0FBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxTQUFJclcsWUFBWXlWLE9BQU96VixTQUF2Qjs7QUFFQTtBQUNBLFNBQUk0VyxZQUFZM2EsTUFBTWlCLEtBQU4sQ0FBWXNELE1BQVosRUFBb0JBLFNBQVNSLFNBQTdCLENBQWhCOztBQUVBOFksaUNBQTRCN2IsSUFBNUIsQ0FBaUMsSUFBakMsRUFBdUNoQixLQUF2QyxFQUE4Q3VFLE1BQTlDLEVBQXNEUixTQUF0RCxFQUFpRXlWLE1BQWpFOztBQUVBO0FBQ0EsVUFBS2tCLFVBQUwsR0FBa0JDLFNBQWxCO0FBQ0g7QUFic0IsSUFBWCxDQUFoQjs7QUFnQkEsWUFBU2tDLDJCQUFULENBQXFDN2MsS0FBckMsRUFBNEN1RSxNQUE1QyxFQUFvRFIsU0FBcEQsRUFBK0R5VixNQUEvRCxFQUF1RTtBQUNuRTtBQUNBLFFBQUlTLEtBQUssS0FBS0ksR0FBZDs7QUFFQTtBQUNBLFFBQUlKLEVBQUosRUFBUTtBQUNKLFNBQUk2QyxZQUFZN0MsR0FBR2haLEtBQUgsQ0FBUyxDQUFULENBQWhCOztBQUVBO0FBQ0EsVUFBS29aLEdBQUwsR0FBVzliLFNBQVg7QUFDSCxLQUxELE1BS087QUFDSCxTQUFJdWUsWUFBWSxLQUFLcEMsVUFBckI7QUFDSDtBQUNEbEIsV0FBT2lCLFlBQVAsQ0FBb0JxQyxTQUFwQixFQUErQixDQUEvQjs7QUFFQTtBQUNBLFNBQUssSUFBSWpjLElBQUksQ0FBYixFQUFnQkEsSUFBSWtELFNBQXBCLEVBQStCbEQsR0FBL0IsRUFBb0M7QUFDaENiLFdBQU11RSxTQUFTMUQsQ0FBZixLQUFxQmljLFVBQVVqYyxDQUFWLENBQXJCO0FBQ0g7QUFDSjs7QUFFRCxVQUFPK2IsR0FBUDtBQUNILEdBdERvQixFQUFyQjs7QUF5REEsU0FBT3ZlLFNBQVMwYixJQUFULENBQWM2QyxHQUFyQjtBQUVBLEVBN0VDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVTllLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLENBQVAsb0NBQW9DTCxPQUFwQztBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUzQjs7O0FBR0FBLFdBQVMwYixJQUFULENBQWNnRCxHQUFkLEdBQXFCLFlBQVk7QUFDN0IsT0FBSUEsTUFBTTFlLFNBQVNXLEdBQVQsQ0FBYWdiLGVBQWIsQ0FBNkI5YSxNQUE3QixFQUFWOztBQUVBLE9BQUlnYixZQUFZNkMsSUFBSTdDLFNBQUosR0FBZ0I2QyxJQUFJN2QsTUFBSixDQUFXO0FBQ3ZDcWIsa0JBQWMsc0JBQVV2YSxLQUFWLEVBQWlCdUUsTUFBakIsRUFBeUI7QUFDbkM7QUFDQSxTQUFJaVYsU0FBUyxLQUFLWSxPQUFsQjtBQUNBLFNBQUlyVyxZQUFZeVYsT0FBT3pWLFNBQXZCO0FBQ0EsU0FBSWtXLEtBQUssS0FBS0ksR0FBZDtBQUNBLFNBQUkyQyxVQUFVLEtBQUtDLFFBQW5COztBQUVBO0FBQ0EsU0FBSWhELEVBQUosRUFBUTtBQUNKK0MsZ0JBQVUsS0FBS0MsUUFBTCxHQUFnQmhELEdBQUdoWixLQUFILENBQVMsQ0FBVCxDQUExQjs7QUFFQTtBQUNBLFdBQUtvWixHQUFMLEdBQVc5YixTQUFYO0FBQ0g7QUFDRCxTQUFJdWUsWUFBWUUsUUFBUS9iLEtBQVIsQ0FBYyxDQUFkLENBQWhCO0FBQ0F1WSxZQUFPaUIsWUFBUCxDQUFvQnFDLFNBQXBCLEVBQStCLENBQS9COztBQUVBO0FBQ0FFLGFBQVFqWixZQUFZLENBQXBCLElBQTBCaVosUUFBUWpaLFlBQVksQ0FBcEIsSUFBeUIsQ0FBMUIsR0FBK0IsQ0FBeEQ7O0FBRUE7QUFDQSxVQUFLLElBQUlsRCxJQUFJLENBQWIsRUFBZ0JBLElBQUlrRCxTQUFwQixFQUErQmxELEdBQS9CLEVBQW9DO0FBQ2hDYixZQUFNdUUsU0FBUzFELENBQWYsS0FBcUJpYyxVQUFVamMsQ0FBVixDQUFyQjtBQUNIO0FBQ0o7QUF6QnNDLElBQVgsQ0FBaEM7O0FBNEJBa2MsT0FBSTVDLFNBQUosR0FBZ0JELFNBQWhCOztBQUVBLFVBQU82QyxHQUFQO0FBQ0gsR0FsQ29CLEVBQXJCOztBQXFDQSxTQUFPMWUsU0FBUzBiLElBQVQsQ0FBY2dELEdBQXJCO0FBRUEsRUF6REMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVamYsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsQ0FBUCxvQ0FBb0NMLE9BQXBDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTNCOzs7OztBQUtBQSxXQUFTMGIsSUFBVCxDQUFjbUQsVUFBZCxHQUE0QixZQUFZO0FBQ3BDLE9BQUlBLGFBQWE3ZSxTQUFTVyxHQUFULENBQWFnYixlQUFiLENBQTZCOWEsTUFBN0IsRUFBakI7O0FBRUgsWUFBU2llLE9BQVQsQ0FBaUJqVixJQUFqQixFQUNBO0FBQ0MsUUFBSSxDQUFFQSxRQUFRLEVBQVQsR0FBZSxJQUFoQixNQUEwQixJQUE5QixFQUFvQztBQUFFO0FBQ3RDLFNBQUlrVixLQUFNbFYsUUFBUSxFQUFULEdBQWEsSUFBdEI7QUFDQSxTQUFJbVYsS0FBTW5WLFFBQVEsQ0FBVCxHQUFZLElBQXJCO0FBQ0EsU0FBSW9WLEtBQUtwVixPQUFPLElBQWhCOztBQUVBLFNBQUlrVixPQUFPLElBQVgsRUFBaUI7QUFDakI7QUFDQUEsWUFBSyxDQUFMO0FBQ0EsV0FBSUMsT0FBTyxJQUFYLEVBQ0E7QUFDQ0EsYUFBSyxDQUFMO0FBQ0EsWUFBSUMsT0FBTyxJQUFYLEVBQ0E7QUFDQ0EsY0FBSyxDQUFMO0FBQ0EsU0FIRCxNQUtBO0FBQ0MsV0FBRUEsRUFBRjtBQUNBO0FBQ0QsUUFYRCxNQWFBO0FBQ0MsVUFBRUQsRUFBRjtBQUNBO0FBQ0EsT0FuQkQsTUFxQkE7QUFDQSxRQUFFRCxFQUFGO0FBQ0M7O0FBRURsVixZQUFPLENBQVA7QUFDQUEsYUFBU2tWLE1BQU0sRUFBZjtBQUNBbFYsYUFBU21WLE1BQU0sQ0FBZjtBQUNBblYsYUFBUW9WLEVBQVI7QUFDQyxLQWxDRCxNQW9DQTtBQUNBcFYsYUFBUyxRQUFRLEVBQWpCO0FBQ0M7QUFDRCxXQUFPQSxJQUFQO0FBQ0E7O0FBRUQsWUFBU3FWLFVBQVQsQ0FBb0JQLE9BQXBCLEVBQ0E7QUFDQyxRQUFJLENBQUNBLFFBQVEsQ0FBUixJQUFhRyxRQUFRSCxRQUFRLENBQVIsQ0FBUixDQUFkLE1BQXVDLENBQTNDLEVBQ0E7QUFDQztBQUNBQSxhQUFRLENBQVIsSUFBYUcsUUFBUUgsUUFBUSxDQUFSLENBQVIsQ0FBYjtBQUNBO0FBQ0QsV0FBT0EsT0FBUDtBQUNBOztBQUVFLE9BQUk5QyxZQUFZZ0QsV0FBV2hELFNBQVgsR0FBdUJnRCxXQUFXaGUsTUFBWCxDQUFrQjtBQUNyRHFiLGtCQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsU0FBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxTQUFJclcsWUFBWXlWLE9BQU96VixTQUF2QjtBQUNBLFNBQUlrVyxLQUFLLEtBQUtJLEdBQWQ7QUFDQSxTQUFJMkMsVUFBVSxLQUFLQyxRQUFuQjs7QUFFQTtBQUNBLFNBQUloRCxFQUFKLEVBQVE7QUFDSitDLGdCQUFVLEtBQUtDLFFBQUwsR0FBZ0JoRCxHQUFHaFosS0FBSCxDQUFTLENBQVQsQ0FBMUI7O0FBRUE7QUFDQSxXQUFLb1osR0FBTCxHQUFXOWIsU0FBWDtBQUNIOztBQUVWZ2YsZ0JBQVdQLE9BQVg7O0FBRUEsU0FBSUYsWUFBWUUsUUFBUS9iLEtBQVIsQ0FBYyxDQUFkLENBQWhCO0FBQ1N1WSxZQUFPaUIsWUFBUCxDQUFvQnFDLFNBQXBCLEVBQStCLENBQS9COztBQUVBO0FBQ0EsVUFBSyxJQUFJamMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJa0QsU0FBcEIsRUFBK0JsRCxHQUEvQixFQUFvQztBQUNoQ2IsWUFBTXVFLFNBQVMxRCxDQUFmLEtBQXFCaWMsVUFBVWpjLENBQVYsQ0FBckI7QUFDSDtBQUNKO0FBekJvRCxJQUFsQixDQUF2Qzs7QUE0QkFxYyxjQUFXL0MsU0FBWCxHQUF1QkQsU0FBdkI7O0FBRUEsVUFBT2dELFVBQVA7QUFDSCxHQXhGMkIsRUFBNUI7O0FBNkZBLFNBQU83ZSxTQUFTMGIsSUFBVCxDQUFjbUQsVUFBckI7QUFFQSxFQW5IQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVVwZixJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUFvQ0wsT0FBcEM7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFM0I7OztBQUdBQSxXQUFTMGIsSUFBVCxDQUFjeUQsR0FBZCxHQUFxQixZQUFZO0FBQzdCLE9BQUlBLE1BQU1uZixTQUFTVyxHQUFULENBQWFnYixlQUFiLENBQTZCOWEsTUFBN0IsRUFBVjs7QUFFQSxPQUFJZ2IsWUFBWXNELElBQUl0RCxTQUFKLEdBQWdCc0QsSUFBSXRlLE1BQUosQ0FBVztBQUN2Q3FiLGtCQUFjLHNCQUFVdmEsS0FBVixFQUFpQnVFLE1BQWpCLEVBQXlCO0FBQ25DO0FBQ0EsU0FBSWlWLFNBQVMsS0FBS1ksT0FBbEI7QUFDQSxTQUFJclcsWUFBWXlWLE9BQU96VixTQUF2QjtBQUNBLFNBQUlrVyxLQUFLLEtBQUtJLEdBQWQ7QUFDQSxTQUFJeUMsWUFBWSxLQUFLVyxVQUFyQjs7QUFFQTtBQUNBLFNBQUl4RCxFQUFKLEVBQVE7QUFDSjZDLGtCQUFZLEtBQUtXLFVBQUwsR0FBa0J4RCxHQUFHaFosS0FBSCxDQUFTLENBQVQsQ0FBOUI7O0FBRUE7QUFDQSxXQUFLb1osR0FBTCxHQUFXOWIsU0FBWDtBQUNIO0FBQ0RpYixZQUFPaUIsWUFBUCxDQUFvQnFDLFNBQXBCLEVBQStCLENBQS9COztBQUVBO0FBQ0EsVUFBSyxJQUFJamMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJa0QsU0FBcEIsRUFBK0JsRCxHQUEvQixFQUFvQztBQUNoQ2IsWUFBTXVFLFNBQVMxRCxDQUFmLEtBQXFCaWMsVUFBVWpjLENBQVYsQ0FBckI7QUFDSDtBQUNKO0FBckJzQyxJQUFYLENBQWhDOztBQXdCQTJjLE9BQUlyRCxTQUFKLEdBQWdCRCxTQUFoQjs7QUFFQSxVQUFPc0QsR0FBUDtBQUNILEdBOUJvQixFQUFyQjs7QUFpQ0EsU0FBT25mLFNBQVMwYixJQUFULENBQWN5RCxHQUFyQjtBQUVBLEVBckRDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVTFmLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLENBQVAsb0NBQW9DTCxPQUFwQztBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUzQjs7O0FBR0FBLFdBQVMwYixJQUFULENBQWMyRCxHQUFkLEdBQXFCLFlBQVk7QUFDN0IsT0FBSUEsTUFBTXJmLFNBQVNXLEdBQVQsQ0FBYWdiLGVBQWIsQ0FBNkI5YSxNQUE3QixFQUFWOztBQUVBd2UsT0FBSXhELFNBQUosR0FBZ0J3RCxJQUFJeGUsTUFBSixDQUFXO0FBQ3ZCcWIsa0JBQWMsc0JBQVV2YSxLQUFWLEVBQWlCdUUsTUFBakIsRUFBeUI7QUFDbkMsVUFBSzZWLE9BQUwsQ0FBYUssWUFBYixDQUEwQnphLEtBQTFCLEVBQWlDdUUsTUFBakM7QUFDSDtBQUhzQixJQUFYLENBQWhCOztBQU1BbVosT0FBSXZELFNBQUosR0FBZ0J1RCxJQUFJeGUsTUFBSixDQUFXO0FBQ3ZCcWIsa0JBQWMsc0JBQVV2YSxLQUFWLEVBQWlCdUUsTUFBakIsRUFBeUI7QUFDbkMsVUFBSzZWLE9BQUwsQ0FBYVEsWUFBYixDQUEwQjVhLEtBQTFCLEVBQWlDdUUsTUFBakM7QUFDSDtBQUhzQixJQUFYLENBQWhCOztBQU1BLFVBQU9tWixHQUFQO0FBQ0gsR0FoQm9CLEVBQXJCOztBQW1CQSxTQUFPcmYsU0FBUzBiLElBQVQsQ0FBYzJELEdBQXJCO0FBRUEsRUF2Q0MsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVNWYsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsQ0FBUCxvQ0FBb0NMLE9BQXBDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTNCOzs7QUFHQUEsV0FBU3ljLEdBQVQsQ0FBYTZDLFFBQWIsR0FBd0I7QUFDcEI3QyxRQUFLLGFBQVVwWCxJQUFWLEVBQWdCSyxTQUFoQixFQUEyQjtBQUM1QjtBQUNBLFFBQUlELGVBQWVKLEtBQUt6RCxRQUF4QjtBQUNBLFFBQUkrRCxpQkFBaUJELFlBQVksQ0FBakM7O0FBRUE7QUFDQSxRQUFJaVgsZ0JBQWdCaFgsaUJBQWlCRixlQUFlRSxjQUFwRDs7QUFFQTtBQUNBLFFBQUk0WixjQUFjOVosZUFBZWtYLGFBQWYsR0FBK0IsQ0FBakQ7O0FBRUE7QUFDQXRYLFNBQUs5QyxLQUFMO0FBQ0E4QyxTQUFLMUQsS0FBTCxDQUFXNGQsZ0JBQWdCLENBQTNCLEtBQWlDNUMsaUJBQWtCLEtBQU00QyxjQUFjLENBQWYsR0FBb0IsQ0FBNUU7QUFDQWxhLFNBQUt6RCxRQUFMLElBQWlCK2EsYUFBakI7QUFDSCxJQWhCbUI7O0FBa0JwQkksVUFBTyxlQUFVMVgsSUFBVixFQUFnQjtBQUNuQjtBQUNBLFFBQUlzWCxnQkFBZ0J0WCxLQUFLMUQsS0FBTCxDQUFZMEQsS0FBS3pELFFBQUwsR0FBZ0IsQ0FBakIsS0FBd0IsQ0FBbkMsSUFBd0MsSUFBNUQ7O0FBRUE7QUFDQXlELFNBQUt6RCxRQUFMLElBQWlCK2EsYUFBakI7QUFDSDtBQXhCbUIsR0FBeEI7O0FBNEJBLFNBQU8zYyxTQUFTeWMsR0FBVCxDQUFhK0MsUUFBcEI7QUFFQSxFQWhEQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVUvZixJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUFvQ0wsT0FBcEM7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFM0I7OztBQUdBQSxXQUFTeWMsR0FBVCxDQUFhZ0QsUUFBYixHQUF3QjtBQUNwQmhELFFBQUssYUFBVXBYLElBQVYsRUFBZ0JLLFNBQWhCLEVBQTJCO0FBQzVCO0FBQ0EsUUFBSUMsaUJBQWlCRCxZQUFZLENBQWpDOztBQUVBO0FBQ0EsUUFBSWlYLGdCQUFnQmhYLGlCQUFpQk4sS0FBS3pELFFBQUwsR0FBZ0IrRCxjQUFyRDs7QUFFQTtBQUNBTixTQUFLcEQsTUFBTCxDQUFZakMsU0FBU1csR0FBVCxDQUFhZSxTQUFiLENBQXVCbUIsTUFBdkIsQ0FBOEI4WixnQkFBZ0IsQ0FBOUMsQ0FBWixFQUNLMWEsTUFETCxDQUNZakMsU0FBU1csR0FBVCxDQUFhZSxTQUFiLENBQXVCdkIsTUFBdkIsQ0FBOEIsQ0FBQ3djLGlCQUFpQixFQUFsQixDQUE5QixFQUFxRCxDQUFyRCxDQURaO0FBRUgsSUFYbUI7O0FBYXBCSSxVQUFPLGVBQVUxWCxJQUFWLEVBQWdCO0FBQ25CO0FBQ0EsUUFBSXNYLGdCQUFnQnRYLEtBQUsxRCxLQUFMLENBQVkwRCxLQUFLekQsUUFBTCxHQUFnQixDQUFqQixLQUF3QixDQUFuQyxJQUF3QyxJQUE1RDs7QUFFQTtBQUNBeUQsU0FBS3pELFFBQUwsSUFBaUIrYSxhQUFqQjtBQUNIO0FBbkJtQixHQUF4Qjs7QUF1QkEsU0FBTzNjLFNBQVN5YyxHQUFULENBQWFnRCxRQUFwQjtBQUVBLEVBM0NDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVWhnQixJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxDQUFQLG9DQUFvQ0wsT0FBcEM7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFM0I7OztBQUdBQSxXQUFTeWMsR0FBVCxDQUFhaUQsUUFBYixHQUF3QjtBQUNwQmpELFFBQUssYUFBVXBYLElBQVYsRUFBZ0JLLFNBQWhCLEVBQTJCO0FBQzVCO0FBQ0FMLFNBQUtwRCxNQUFMLENBQVlqQyxTQUFTVyxHQUFULENBQWFlLFNBQWIsQ0FBdUJ2QixNQUF2QixDQUE4QixDQUFDLFVBQUQsQ0FBOUIsRUFBNEMsQ0FBNUMsQ0FBWjs7QUFFQTtBQUNBSCxhQUFTeWMsR0FBVCxDQUFha0QsV0FBYixDQUF5QmxELEdBQXpCLENBQTZCcFgsSUFBN0IsRUFBbUNLLFNBQW5DO0FBQ0gsSUFQbUI7O0FBU3BCcVgsVUFBTyxlQUFVMVgsSUFBVixFQUFnQjtBQUNuQjtBQUNBckYsYUFBU3ljLEdBQVQsQ0FBYWtELFdBQWIsQ0FBeUI1QyxLQUF6QixDQUErQjFYLElBQS9COztBQUVBO0FBQ0FBLFNBQUt6RCxRQUFMO0FBQ0g7QUFmbUIsR0FBeEI7O0FBbUJBLFNBQU81QixTQUFTeWMsR0FBVCxDQUFhaUQsUUFBcEI7QUFFQSxFQXZDQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVVqZ0IsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsQ0FBUCxvQ0FBb0NMLE9BQXBDO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTNCOzs7QUFHQUEsV0FBU3ljLEdBQVQsQ0FBYWtELFdBQWIsR0FBMkI7QUFDdkJsRCxRQUFLLGFBQVVwWCxJQUFWLEVBQWdCSyxTQUFoQixFQUEyQjtBQUM1QjtBQUNBLFFBQUlDLGlCQUFpQkQsWUFBWSxDQUFqQzs7QUFFQTtBQUNBTCxTQUFLOUMsS0FBTDtBQUNBOEMsU0FBS3pELFFBQUwsSUFBaUIrRCxrQkFBbUJOLEtBQUt6RCxRQUFMLEdBQWdCK0QsY0FBakIsSUFBb0NBLGNBQXRELENBQWpCO0FBQ0gsSUFSc0I7O0FBVXZCb1gsVUFBTyxlQUFVMVgsSUFBVixFQUFnQjtBQUNuQjtBQUNBLFFBQUlHLFlBQVlILEtBQUsxRCxLQUFyQjs7QUFFQTtBQUNBLFFBQUlhLElBQUk2QyxLQUFLekQsUUFBTCxHQUFnQixDQUF4QjtBQUNBLFdBQU8sRUFBRzRELFVBQVVoRCxNQUFNLENBQWhCLE1BQXdCLEtBQU1BLElBQUksQ0FBTCxHQUFVLENBQXhDLEdBQThDLElBQWhELENBQVAsRUFBOEQ7QUFDMURBO0FBQ0g7QUFDRDZDLFNBQUt6RCxRQUFMLEdBQWdCWSxJQUFJLENBQXBCO0FBQ0g7QUFwQnNCLEdBQTNCOztBQXdCQSxTQUFPeEMsU0FBU3ljLEdBQVQsQ0FBYWtELFdBQXBCO0FBRUEsRUE1Q0MsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVbGdCLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLENBQVAsb0NBQW9DTCxPQUFwQztBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUzQjs7O0FBR0FBLFdBQVN5YyxHQUFULENBQWFtRCxTQUFiLEdBQXlCO0FBQ3JCbkQsUUFBSyxlQUFZLENBQ2hCLENBRm9COztBQUlyQk0sVUFBTyxpQkFBWSxDQUNsQjtBQUxvQixHQUF6Qjs7QUFTQSxTQUFPL2MsU0FBU3ljLEdBQVQsQ0FBYW1ELFNBQXBCO0FBRUEsRUE3QkMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVbmdCLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLENBQVAsb0NBQW9DTCxPQUFwQztBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixhQUFVRSxTQUFWLEVBQXFCO0FBQ2xCO0FBQ0EsT0FBSU8sSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJeWMsZUFBZTFjLE1BQU0wYyxZQUF6QjtBQUNBLE9BQUk3WixRQUFROUMsRUFBRStDLEdBQWQ7QUFDQSxPQUFJekIsTUFBTXdCLE1BQU14QixHQUFoQjtBQUNBLE9BQUl3YixXQUFXOWMsRUFBRStjLE1BQWpCOztBQUVBLE9BQUlxQyxlQUFldEMsU0FBU3hiLEdBQVQsR0FBZTtBQUM5Qjs7Ozs7Ozs7Ozs7OztBQWFBQyxlQUFXLG1CQUFVcWIsWUFBVixFQUF3QjtBQUMvQixZQUFPQSxhQUFhL0IsVUFBYixDQUF3QjlaLFFBQXhCLENBQWlDTyxHQUFqQyxDQUFQO0FBQ0gsS0FoQjZCOztBQWtCOUI7Ozs7Ozs7Ozs7Ozs7QUFhQTZCLFdBQU8sZUFBVWtjLEtBQVYsRUFBaUI7QUFDcEIsU0FBSXhFLGFBQWF2WixJQUFJNkIsS0FBSixDQUFVa2MsS0FBVixDQUFqQjtBQUNBLFlBQU8xQyxhQUFhamQsTUFBYixDQUFvQixFQUFFbWIsWUFBWUEsVUFBZCxFQUFwQixDQUFQO0FBQ0g7QUFsQzZCLElBQWxDO0FBb0NILEdBN0NBLEdBQUQ7O0FBZ0RBLFNBQU90YixTQUFTd2QsTUFBVCxDQUFnQnpiLEdBQXZCO0FBRUEsRUFqRUMsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVdEMsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixFQUFvRCxtQkFBQUEsQ0FBUSxFQUFSLENBQXBELEVBQXNFLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdEUsRUFBMkYsbUJBQUFBLENBQVEsRUFBUixDQUEzRixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsRUFBMkIsdUJBQTNCLEVBQW9DLHVCQUFwQyxFQUFnRCx1QkFBaEQsQ0FBUCxvQ0FBeUVMLE9BQXpFO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSXFjLGNBQWN0YyxNQUFNc2MsV0FBeEI7QUFDQSxPQUFJN1YsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBO0FBQ0EsT0FBSTBZLE9BQU8sRUFBWDtBQUNBLE9BQUlDLFdBQVcsRUFBZjtBQUNBLE9BQUlDLFlBQVksRUFBaEI7QUFDQSxPQUFJQyxZQUFZLEVBQWhCO0FBQ0EsT0FBSUMsWUFBWSxFQUFoQjtBQUNBLE9BQUlDLFlBQVksRUFBaEI7QUFDQSxPQUFJQyxnQkFBZ0IsRUFBcEI7QUFDQSxPQUFJQyxnQkFBZ0IsRUFBcEI7QUFDQSxPQUFJQyxnQkFBZ0IsRUFBcEI7QUFDQSxPQUFJQyxnQkFBZ0IsRUFBcEI7O0FBRUE7QUFDQyxnQkFBWTtBQUNUO0FBQ0EsUUFBSTFULElBQUksRUFBUjtBQUNBLFNBQUssSUFBSXRLLElBQUksQ0FBYixFQUFnQkEsSUFBSSxHQUFwQixFQUF5QkEsR0FBekIsRUFBOEI7QUFDMUIsU0FBSUEsSUFBSSxHQUFSLEVBQWE7QUFDVHNLLFFBQUV0SyxDQUFGLElBQU9BLEtBQUssQ0FBWjtBQUNILE1BRkQsTUFFTztBQUNIc0ssUUFBRXRLLENBQUYsSUFBUUEsS0FBSyxDQUFOLEdBQVcsS0FBbEI7QUFDSDtBQUNKOztBQUVEO0FBQ0EsUUFBSWlMLElBQUksQ0FBUjtBQUNBLFFBQUlnVCxLQUFLLENBQVQ7QUFDQSxTQUFLLElBQUlqZSxJQUFJLENBQWIsRUFBZ0JBLElBQUksR0FBcEIsRUFBeUJBLEdBQXpCLEVBQThCO0FBQzFCO0FBQ0EsU0FBSWtlLEtBQUtELEtBQU1BLE1BQU0sQ0FBWixHQUFrQkEsTUFBTSxDQUF4QixHQUE4QkEsTUFBTSxDQUFwQyxHQUEwQ0EsTUFBTSxDQUF6RDtBQUNBQyxVQUFNQSxPQUFPLENBQVIsR0FBY0EsS0FBSyxJQUFuQixHQUEyQixJQUFoQztBQUNBWCxVQUFLdFMsQ0FBTCxJQUFVaVQsRUFBVjtBQUNBVixjQUFTVSxFQUFULElBQWVqVCxDQUFmOztBQUVBO0FBQ0EsU0FBSWtULEtBQUs3VCxFQUFFVyxDQUFGLENBQVQ7QUFDQSxTQUFJbVQsS0FBSzlULEVBQUU2VCxFQUFGLENBQVQ7QUFDQSxTQUFJRSxLQUFLL1QsRUFBRThULEVBQUYsQ0FBVDs7QUFFQTtBQUNBLFNBQUlqVCxJQUFLYixFQUFFNFQsRUFBRixJQUFRLEtBQVQsR0FBbUJBLEtBQUssU0FBaEM7QUFDQVQsZUFBVXhTLENBQVYsSUFBZ0JFLEtBQUssRUFBTixHQUFhQSxNQUFNLENBQWxDO0FBQ0F1UyxlQUFVelMsQ0FBVixJQUFnQkUsS0FBSyxFQUFOLEdBQWFBLE1BQU0sRUFBbEM7QUFDQXdTLGVBQVUxUyxDQUFWLElBQWdCRSxLQUFLLENBQU4sR0FBYUEsTUFBTSxFQUFsQztBQUNBeVMsZUFBVTNTLENBQVYsSUFBZUUsQ0FBZjs7QUFFQTtBQUNBLFNBQUlBLElBQUtrVCxLQUFLLFNBQU4sR0FBb0JELEtBQUssT0FBekIsR0FBcUNELEtBQUssS0FBMUMsR0FBb0RsVCxJQUFJLFNBQWhFO0FBQ0E0UyxtQkFBY0ssRUFBZCxJQUFxQi9TLEtBQUssRUFBTixHQUFhQSxNQUFNLENBQXZDO0FBQ0EyUyxtQkFBY0ksRUFBZCxJQUFxQi9TLEtBQUssRUFBTixHQUFhQSxNQUFNLEVBQXZDO0FBQ0E0UyxtQkFBY0csRUFBZCxJQUFxQi9TLEtBQUssQ0FBTixHQUFhQSxNQUFNLEVBQXZDO0FBQ0E2UyxtQkFBY0UsRUFBZCxJQUFvQi9TLENBQXBCOztBQUVBO0FBQ0EsU0FBSSxDQUFDRixDQUFMLEVBQVE7QUFDSkEsVUFBSWdULEtBQUssQ0FBVDtBQUNILE1BRkQsTUFFTztBQUNIaFQsVUFBSWtULEtBQUs3VCxFQUFFQSxFQUFFQSxFQUFFK1QsS0FBS0YsRUFBUCxDQUFGLENBQUYsQ0FBVDtBQUNBRixZQUFNM1QsRUFBRUEsRUFBRTJULEVBQUYsQ0FBRixDQUFOO0FBQ0g7QUFDSjtBQUNKLElBaERBLEdBQUQ7O0FBa0RBO0FBQ0EsT0FBSUssT0FBTyxDQUFDLElBQUQsRUFBTyxJQUFQLEVBQWEsSUFBYixFQUFtQixJQUFuQixFQUF5QixJQUF6QixFQUErQixJQUEvQixFQUFxQyxJQUFyQyxFQUEyQyxJQUEzQyxFQUFpRCxJQUFqRCxFQUF1RCxJQUF2RCxFQUE2RCxJQUE3RCxDQUFYOztBQUVBOzs7QUFHQSxPQUFJQyxNQUFNNVosT0FBTzRaLEdBQVAsR0FBYS9ELFlBQVluYyxNQUFaLENBQW1CO0FBQ3RDMkYsY0FBVSxvQkFBWTtBQUNsQjtBQUNBLFNBQUksS0FBS3dhLFFBQUwsSUFBaUIsS0FBS0MsY0FBTCxLQUF3QixLQUFLdEcsSUFBbEQsRUFBd0Q7QUFDcEQ7QUFDSDs7QUFFRDtBQUNBLFNBQUl6VCxNQUFNLEtBQUsrWixjQUFMLEdBQXNCLEtBQUt0RyxJQUFyQztBQUNBLFNBQUl1RyxXQUFXaGEsSUFBSXZGLEtBQW5CO0FBQ0EsU0FBSTBYLFVBQVVuUyxJQUFJdEYsUUFBSixHQUFlLENBQTdCOztBQUVBO0FBQ0EsU0FBSXVmLFVBQVUsS0FBS0gsUUFBTCxHQUFnQjNILFVBQVUsQ0FBeEM7O0FBRUE7QUFDQSxTQUFJK0gsU0FBUyxDQUFDRCxVQUFVLENBQVgsSUFBZ0IsQ0FBN0I7O0FBRUE7QUFDQSxTQUFJRSxjQUFjLEtBQUtDLFlBQUwsR0FBb0IsRUFBdEM7QUFDQSxVQUFLLElBQUlDLFFBQVEsQ0FBakIsRUFBb0JBLFFBQVFILE1BQTVCLEVBQW9DRyxPQUFwQyxFQUE2QztBQUN6QyxVQUFJQSxRQUFRbEksT0FBWixFQUFxQjtBQUNqQmdJLG1CQUFZRSxLQUFaLElBQXFCTCxTQUFTSyxLQUFULENBQXJCO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsV0FBSTVULElBQUkwVCxZQUFZRSxRQUFRLENBQXBCLENBQVI7O0FBRUEsV0FBSSxFQUFFQSxRQUFRbEksT0FBVixDQUFKLEVBQXdCO0FBQ3BCO0FBQ0ExTCxZQUFLQSxLQUFLLENBQU4sR0FBWUEsTUFBTSxFQUF0Qjs7QUFFQTtBQUNBQSxZQUFLb1MsS0FBS3BTLE1BQU0sRUFBWCxLQUFrQixFQUFuQixHQUEwQm9TLEtBQU1wUyxNQUFNLEVBQVAsR0FBYSxJQUFsQixLQUEyQixFQUFyRCxHQUE0RG9TLEtBQU1wUyxNQUFNLENBQVAsR0FBWSxJQUFqQixLQUEwQixDQUF0RixHQUEyRm9TLEtBQUtwUyxJQUFJLElBQVQsQ0FBL0Y7O0FBRUE7QUFDQUEsYUFBS21ULEtBQU1TLFFBQVFsSSxPQUFULEdBQW9CLENBQXpCLEtBQStCLEVBQXBDO0FBQ0gsUUFURCxNQVNPLElBQUlBLFVBQVUsQ0FBVixJQUFla0ksUUFBUWxJLE9BQVIsSUFBbUIsQ0FBdEMsRUFBeUM7QUFDNUM7QUFDQTFMLFlBQUtvUyxLQUFLcFMsTUFBTSxFQUFYLEtBQWtCLEVBQW5CLEdBQTBCb1MsS0FBTXBTLE1BQU0sRUFBUCxHQUFhLElBQWxCLEtBQTJCLEVBQXJELEdBQTREb1MsS0FBTXBTLE1BQU0sQ0FBUCxHQUFZLElBQWpCLEtBQTBCLENBQXRGLEdBQTJGb1MsS0FBS3BTLElBQUksSUFBVCxDQUEvRjtBQUNIOztBQUVEMFQsbUJBQVlFLEtBQVosSUFBcUJGLFlBQVlFLFFBQVFsSSxPQUFwQixJQUErQjFMLENBQXBEO0FBQ0g7QUFDSjs7QUFFRDtBQUNBLFNBQUk2VCxpQkFBaUIsS0FBS0MsZUFBTCxHQUF1QixFQUE1QztBQUNBLFVBQUssSUFBSUMsV0FBVyxDQUFwQixFQUF1QkEsV0FBV04sTUFBbEMsRUFBMENNLFVBQTFDLEVBQXNEO0FBQ2xELFVBQUlILFFBQVFILFNBQVNNLFFBQXJCOztBQUVBLFVBQUlBLFdBQVcsQ0FBZixFQUFrQjtBQUNkLFdBQUkvVCxJQUFJMFQsWUFBWUUsS0FBWixDQUFSO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsV0FBSTVULElBQUkwVCxZQUFZRSxRQUFRLENBQXBCLENBQVI7QUFDSDs7QUFFRCxVQUFJRyxXQUFXLENBQVgsSUFBZ0JILFNBQVMsQ0FBN0IsRUFBZ0M7QUFDNUJDLHNCQUFlRSxRQUFmLElBQTJCL1QsQ0FBM0I7QUFDSCxPQUZELE1BRU87QUFDSDZULHNCQUFlRSxRQUFmLElBQTJCckIsY0FBY04sS0FBS3BTLE1BQU0sRUFBWCxDQUFkLElBQWdDMlMsY0FBY1AsS0FBTXBTLE1BQU0sRUFBUCxHQUFhLElBQWxCLENBQWQsQ0FBaEMsR0FDQTRTLGNBQWNSLEtBQU1wUyxNQUFNLENBQVAsR0FBWSxJQUFqQixDQUFkLENBREEsR0FDd0M2UyxjQUFjVCxLQUFLcFMsSUFBSSxJQUFULENBQWQsQ0FEbkU7QUFFSDtBQUNKO0FBQ0osS0E5RHFDOztBQWdFdEN5TyxrQkFBYyxzQkFBVTdRLENBQVYsRUFBYXJGLE1BQWIsRUFBcUI7QUFDL0IsVUFBS3liLGFBQUwsQ0FBbUJwVyxDQUFuQixFQUFzQnJGLE1BQXRCLEVBQThCLEtBQUtvYixZQUFuQyxFQUFpRHJCLFNBQWpELEVBQTREQyxTQUE1RCxFQUF1RUMsU0FBdkUsRUFBa0ZDLFNBQWxGLEVBQTZGTCxJQUE3RjtBQUNILEtBbEVxQzs7QUFvRXRDeEQsa0JBQWMsc0JBQVVoUixDQUFWLEVBQWFyRixNQUFiLEVBQXFCO0FBQy9CO0FBQ0EsU0FBSXlILElBQUlwQyxFQUFFckYsU0FBUyxDQUFYLENBQVI7QUFDQXFGLE9BQUVyRixTQUFTLENBQVgsSUFBZ0JxRixFQUFFckYsU0FBUyxDQUFYLENBQWhCO0FBQ0FxRixPQUFFckYsU0FBUyxDQUFYLElBQWdCeUgsQ0FBaEI7O0FBRUEsVUFBS2dVLGFBQUwsQ0FBbUJwVyxDQUFuQixFQUFzQnJGLE1BQXRCLEVBQThCLEtBQUt1YixlQUFuQyxFQUFvRHBCLGFBQXBELEVBQW1FQyxhQUFuRSxFQUFrRkMsYUFBbEYsRUFBaUdDLGFBQWpHLEVBQWdIUixRQUFoSDs7QUFFQTtBQUNBLFNBQUlyUyxJQUFJcEMsRUFBRXJGLFNBQVMsQ0FBWCxDQUFSO0FBQ0FxRixPQUFFckYsU0FBUyxDQUFYLElBQWdCcUYsRUFBRXJGLFNBQVMsQ0FBWCxDQUFoQjtBQUNBcUYsT0FBRXJGLFNBQVMsQ0FBWCxJQUFnQnlILENBQWhCO0FBQ0gsS0FoRnFDOztBQWtGdENnVSxtQkFBZSx1QkFBVXBXLENBQVYsRUFBYXJGLE1BQWIsRUFBcUJtYixXQUFyQixFQUFrQ3BCLFNBQWxDLEVBQTZDQyxTQUE3QyxFQUF3REMsU0FBeEQsRUFBbUVDLFNBQW5FLEVBQThFTCxJQUE5RSxFQUFvRjtBQUMvRjtBQUNBLFNBQUlvQixVQUFVLEtBQUtILFFBQW5COztBQUVBO0FBQ0EsU0FBSVksS0FBS3JXLEVBQUVyRixNQUFGLElBQWdCbWIsWUFBWSxDQUFaLENBQXpCO0FBQ0EsU0FBSVEsS0FBS3RXLEVBQUVyRixTQUFTLENBQVgsSUFBZ0JtYixZQUFZLENBQVosQ0FBekI7QUFDQSxTQUFJUyxLQUFLdlcsRUFBRXJGLFNBQVMsQ0FBWCxJQUFnQm1iLFlBQVksQ0FBWixDQUF6QjtBQUNBLFNBQUlVLEtBQUt4VyxFQUFFckYsU0FBUyxDQUFYLElBQWdCbWIsWUFBWSxDQUFaLENBQXpCOztBQUVBO0FBQ0EsU0FBSUUsUUFBUSxDQUFaOztBQUVBO0FBQ0EsVUFBSyxJQUFJL0wsUUFBUSxDQUFqQixFQUFvQkEsUUFBUTJMLE9BQTVCLEVBQXFDM0wsT0FBckMsRUFBOEM7QUFDMUM7QUFDQSxVQUFJd00sS0FBSy9CLFVBQVUyQixPQUFPLEVBQWpCLElBQXVCMUIsVUFBVzJCLE9BQU8sRUFBUixHQUFjLElBQXhCLENBQXZCLEdBQXVEMUIsVUFBVzJCLE9BQU8sQ0FBUixHQUFhLElBQXZCLENBQXZELEdBQXNGMUIsVUFBVTJCLEtBQUssSUFBZixDQUF0RixHQUE2R1YsWUFBWUUsT0FBWixDQUF0SDtBQUNBLFVBQUlsUyxLQUFLNFEsVUFBVTRCLE9BQU8sRUFBakIsSUFBdUIzQixVQUFXNEIsT0FBTyxFQUFSLEdBQWMsSUFBeEIsQ0FBdkIsR0FBdUQzQixVQUFXNEIsT0FBTyxDQUFSLEdBQWEsSUFBdkIsQ0FBdkQsR0FBc0YzQixVQUFVd0IsS0FBSyxJQUFmLENBQXRGLEdBQTZHUCxZQUFZRSxPQUFaLENBQXRIO0FBQ0EsVUFBSWpTLEtBQUsyUSxVQUFVNkIsT0FBTyxFQUFqQixJQUF1QjVCLFVBQVc2QixPQUFPLEVBQVIsR0FBYyxJQUF4QixDQUF2QixHQUF1RDVCLFVBQVd5QixPQUFPLENBQVIsR0FBYSxJQUF2QixDQUF2RCxHQUFzRnhCLFVBQVV5QixLQUFLLElBQWYsQ0FBdEYsR0FBNkdSLFlBQVlFLE9BQVosQ0FBdEg7QUFDQSxVQUFJVSxLQUFLaEMsVUFBVThCLE9BQU8sRUFBakIsSUFBdUI3QixVQUFXMEIsT0FBTyxFQUFSLEdBQWMsSUFBeEIsQ0FBdkIsR0FBdUR6QixVQUFXMEIsT0FBTyxDQUFSLEdBQWEsSUFBdkIsQ0FBdkQsR0FBc0Z6QixVQUFVMEIsS0FBSyxJQUFmLENBQXRGLEdBQTZHVCxZQUFZRSxPQUFaLENBQXRIOztBQUVBO0FBQ0FLLFdBQUtJLEVBQUw7QUFDQUgsV0FBS3hTLEVBQUw7QUFDQXlTLFdBQUt4UyxFQUFMO0FBQ0F5UyxXQUFLRSxFQUFMO0FBQ0g7O0FBRUQ7QUFDQSxTQUFJRCxLQUFLLENBQUVqQyxLQUFLNkIsT0FBTyxFQUFaLEtBQW1CLEVBQXBCLEdBQTJCN0IsS0FBTThCLE9BQU8sRUFBUixHQUFjLElBQW5CLEtBQTRCLEVBQXZELEdBQThEOUIsS0FBTStCLE9BQU8sQ0FBUixHQUFhLElBQWxCLEtBQTJCLENBQXpGLEdBQThGL0IsS0FBS2dDLEtBQUssSUFBVixDQUEvRixJQUFrSFYsWUFBWUUsT0FBWixDQUEzSDtBQUNBLFNBQUlsUyxLQUFLLENBQUUwUSxLQUFLOEIsT0FBTyxFQUFaLEtBQW1CLEVBQXBCLEdBQTJCOUIsS0FBTStCLE9BQU8sRUFBUixHQUFjLElBQW5CLEtBQTRCLEVBQXZELEdBQThEL0IsS0FBTWdDLE9BQU8sQ0FBUixHQUFhLElBQWxCLEtBQTJCLENBQXpGLEdBQThGaEMsS0FBSzZCLEtBQUssSUFBVixDQUEvRixJQUFrSFAsWUFBWUUsT0FBWixDQUEzSDtBQUNBLFNBQUlqUyxLQUFLLENBQUV5USxLQUFLK0IsT0FBTyxFQUFaLEtBQW1CLEVBQXBCLEdBQTJCL0IsS0FBTWdDLE9BQU8sRUFBUixHQUFjLElBQW5CLEtBQTRCLEVBQXZELEdBQThEaEMsS0FBTTZCLE9BQU8sQ0FBUixHQUFhLElBQWxCLEtBQTJCLENBQXpGLEdBQThGN0IsS0FBSzhCLEtBQUssSUFBVixDQUEvRixJQUFrSFIsWUFBWUUsT0FBWixDQUEzSDtBQUNBLFNBQUlVLEtBQUssQ0FBRWxDLEtBQUtnQyxPQUFPLEVBQVosS0FBbUIsRUFBcEIsR0FBMkJoQyxLQUFNNkIsT0FBTyxFQUFSLEdBQWMsSUFBbkIsS0FBNEIsRUFBdkQsR0FBOEQ3QixLQUFNOEIsT0FBTyxDQUFSLEdBQWEsSUFBbEIsS0FBMkIsQ0FBekYsR0FBOEY5QixLQUFLK0IsS0FBSyxJQUFWLENBQS9GLElBQWtIVCxZQUFZRSxPQUFaLENBQTNIOztBQUVBO0FBQ0FoVyxPQUFFckYsTUFBRixJQUFnQjhiLEVBQWhCO0FBQ0F6VyxPQUFFckYsU0FBUyxDQUFYLElBQWdCbUosRUFBaEI7QUFDQTlELE9BQUVyRixTQUFTLENBQVgsSUFBZ0JvSixFQUFoQjtBQUNBL0QsT0FBRXJGLFNBQVMsQ0FBWCxJQUFnQitiLEVBQWhCO0FBQ0gsS0F6SHFDOztBQTJIdEM1SSxhQUFTLE1BQUk7QUEzSHlCLElBQW5CLENBQXZCOztBQThIQTs7Ozs7Ozs7QUFRQTVZLEtBQUVzZ0IsR0FBRixHQUFRL0QsWUFBWWxXLGFBQVosQ0FBMEJpYSxHQUExQixDQUFSO0FBQ0gsR0FuTkEsR0FBRDs7QUFzTkEsU0FBTy9nQixTQUFTK2dCLEdBQWhCO0FBRUEsRUF2T0MsQ0FBRCxDOzs7Ozs7Ozs7O0FDQUQsRUFBRSxXQUFVdGhCLElBQVYsRUFBZ0JDLE9BQWhCLEVBQXlCQyxLQUF6QixFQUFnQztBQUNqQyxNQUFJLGdDQUFPQyxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQ2hDO0FBQ0FDLFVBQU9ELE9BQVAsR0FBaUJBLFVBQVVGLFFBQVEsbUJBQUFJLENBQVEsRUFBUixDQUFSLEVBQTJCLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0IsRUFBb0QsbUJBQUFBLENBQVEsRUFBUixDQUFwRCxFQUFzRSxtQkFBQUEsQ0FBUSxFQUFSLENBQXRFLEVBQTJGLG1CQUFBQSxDQUFRLEVBQVIsQ0FBM0YsQ0FBM0I7QUFDQSxHQUhELE1BSUssSUFBSSxJQUFKLEVBQWdEO0FBQ3BEO0FBQ0FDLEdBQUEsaUNBQU8sQ0FBQyx1QkFBRCxFQUFXLHVCQUFYLEVBQTJCLHVCQUEzQixFQUFvQyx1QkFBcEMsRUFBZ0QsdUJBQWhELENBQVAsb0NBQXlFTCxPQUF6RTtBQUNBLEdBSEksTUFJQTtBQUNKO0FBQ0FBLFdBQVFELEtBQUtPLFFBQWI7QUFDQTtBQUNELEVBYkMsYUFhTSxVQUFVQSxRQUFWLEVBQW9COztBQUUxQixlQUFZO0FBQ1Q7QUFDQSxPQUFJUyxJQUFJVCxRQUFSO0FBQ0EsT0FBSVUsUUFBUUQsRUFBRUUsR0FBZDtBQUNBLE9BQUllLFlBQVloQixNQUFNZ0IsU0FBdEI7QUFDQSxPQUFJc2IsY0FBY3RjLE1BQU1zYyxXQUF4QjtBQUNBLE9BQUk3VixTQUFTMUcsRUFBRTRHLElBQWY7O0FBRUE7QUFDQSxPQUFJNmEsTUFBTSxDQUNOLEVBRE0sRUFDRixFQURFLEVBQ0UsRUFERixFQUNNLEVBRE4sRUFDVSxFQURWLEVBQ2MsRUFEZCxFQUNrQixDQURsQixFQUNzQixDQUR0QixFQUVOLEVBRk0sRUFFRixFQUZFLEVBRUUsRUFGRixFQUVNLEVBRk4sRUFFVSxFQUZWLEVBRWMsRUFGZCxFQUVrQixFQUZsQixFQUVzQixDQUZ0QixFQUdOLEVBSE0sRUFHRixFQUhFLEVBR0UsRUFIRixFQUdNLEVBSE4sRUFHVSxFQUhWLEVBR2MsRUFIZCxFQUdrQixFQUhsQixFQUdzQixDQUh0QixFQUlOLEVBSk0sRUFJRixFQUpFLEVBSUUsRUFKRixFQUlNLEVBSk4sRUFJVSxFQUpWLEVBSWMsRUFKZCxFQUlrQixFQUpsQixFQUlzQixFQUp0QixFQUtOLEVBTE0sRUFLRixFQUxFLEVBS0UsRUFMRixFQUtNLENBTE4sRUFLVSxFQUxWLEVBS2MsRUFMZCxFQUtrQixFQUxsQixFQUtzQixFQUx0QixFQU1OLEVBTk0sRUFNRixFQU5FLEVBTUUsRUFORixFQU1NLENBTk4sRUFNVSxFQU5WLEVBTWMsRUFOZCxFQU1rQixFQU5sQixFQU1zQixFQU50QixFQU9OLEVBUE0sRUFPRixFQVBFLEVBT0UsRUFQRixFQU9NLENBUE4sRUFPVSxFQVBWLEVBT2MsRUFQZCxFQU9rQixFQVBsQixFQU9zQixDQVB0QixDQUFWOztBQVVBO0FBQ0EsT0FBSUMsTUFBTSxDQUNOLEVBRE0sRUFDRixFQURFLEVBQ0UsRUFERixFQUNNLEVBRE4sRUFDVSxDQURWLEVBQ2MsQ0FEZCxFQUVOLENBRk0sRUFFRixFQUZFLEVBRUUsRUFGRixFQUVNLENBRk4sRUFFVSxFQUZWLEVBRWMsRUFGZCxFQUdOLEVBSE0sRUFHRixFQUhFLEVBR0UsRUFIRixFQUdNLENBSE4sRUFHVSxFQUhWLEVBR2MsQ0FIZCxFQUlOLEVBSk0sRUFJRixDQUpFLEVBSUUsRUFKRixFQUlNLEVBSk4sRUFJVSxFQUpWLEVBSWMsQ0FKZCxFQUtOLEVBTE0sRUFLRixFQUxFLEVBS0UsRUFMRixFQUtNLEVBTE4sRUFLVSxFQUxWLEVBS2MsRUFMZCxFQU1OLEVBTk0sRUFNRixFQU5FLEVBTUUsRUFORixFQU1NLEVBTk4sRUFNVSxFQU5WLEVBTWMsRUFOZCxFQU9OLEVBUE0sRUFPRixFQVBFLEVBT0UsRUFQRixFQU9NLEVBUE4sRUFPVSxFQVBWLEVBT2MsRUFQZCxFQVFOLEVBUk0sRUFRRixFQVJFLEVBUUUsRUFSRixFQVFNLEVBUk4sRUFRVSxFQVJWLEVBUWMsRUFSZCxDQUFWOztBQVdBO0FBQ0EsT0FBSUMsYUFBYSxDQUFDLENBQUQsRUFBSyxDQUFMLEVBQVMsQ0FBVCxFQUFhLENBQWIsRUFBaUIsQ0FBakIsRUFBcUIsRUFBckIsRUFBeUIsRUFBekIsRUFBNkIsRUFBN0IsRUFBaUMsRUFBakMsRUFBcUMsRUFBckMsRUFBeUMsRUFBekMsRUFBNkMsRUFBN0MsRUFBaUQsRUFBakQsRUFBcUQsRUFBckQsRUFBeUQsRUFBekQsRUFBNkQsRUFBN0QsQ0FBakI7O0FBRUE7QUFDQSxPQUFJQyxTQUFTLENBQ1Q7QUFDSSxTQUFLLFFBRFQ7QUFFSSxnQkFBWSxNQUZoQjtBQUdJLGdCQUFZLFFBSGhCO0FBSUksZ0JBQVksR0FKaEI7QUFLSSxnQkFBWSxLQUxoQjtBQU1JLGdCQUFZLFFBTmhCO0FBT0ksZ0JBQVksUUFQaEI7QUFRSSxnQkFBWSxRQVJoQjtBQVNJLGdCQUFZLEtBVGhCO0FBVUksZ0JBQVksUUFWaEI7QUFXSSxnQkFBWSxNQVhoQjtBQVlJLGdCQUFZLFFBWmhCO0FBYUksZ0JBQVksTUFiaEI7QUFjSSxnQkFBWSxRQWRoQjtBQWVJLGdCQUFZLEdBZmhCO0FBZ0JJLGdCQUFZLE1BaEJoQjtBQWlCSSxlQUFXLEdBakJmO0FBa0JJLGdCQUFZLFFBbEJoQjtBQW1CSSxnQkFBWSxNQW5CaEI7QUFvQkksZ0JBQVksTUFwQmhCO0FBcUJJLGdCQUFZLFFBckJoQjtBQXNCSSxnQkFBWSxLQXRCaEI7QUF1QkksZ0JBQVksUUF2QmhCO0FBd0JJLGdCQUFZLEdBeEJoQjtBQXlCSSxnQkFBWSxRQXpCaEI7QUEwQkksZ0JBQVksTUExQmhCO0FBMkJJLGdCQUFZLFFBM0JoQjtBQTRCSSxnQkFBWSxRQTVCaEI7QUE2QkksZ0JBQVksUUE3QmhCO0FBOEJJLGdCQUFZLE1BOUJoQjtBQStCSSxnQkFBWSxLQS9CaEI7QUFnQ0ksZ0JBQVksUUFoQ2hCO0FBaUNJLFNBQUssTUFqQ1Q7QUFrQ0ksZ0JBQVksR0FsQ2hCO0FBbUNJLGdCQUFZLFFBbkNoQjtBQW9DSSxnQkFBWSxRQXBDaEI7QUFxQ0ksZ0JBQVksUUFyQ2hCO0FBc0NJLGdCQUFZLE1BdENoQjtBQXVDSSxnQkFBWSxLQXZDaEI7QUF3Q0ksZ0JBQVksUUF4Q2hCO0FBeUNJLGdCQUFZLFFBekNoQjtBQTBDSSxnQkFBWSxRQTFDaEI7QUEyQ0ksZ0JBQVksUUEzQ2hCO0FBNENJLGdCQUFZLE1BNUNoQjtBQTZDSSxnQkFBWSxLQTdDaEI7QUE4Q0ksZ0JBQVksUUE5Q2hCO0FBK0NJLGdCQUFZLE1BL0NoQjtBQWdESSxnQkFBWSxHQWhEaEI7QUFpREksZUFBVyxRQWpEZjtBQWtESSxnQkFBWSxRQWxEaEI7QUFtREksZ0JBQVksUUFuRGhCO0FBb0RJLGdCQUFZLEtBcERoQjtBQXFESSxnQkFBWSxNQXJEaEI7QUFzREksZ0JBQVksUUF0RGhCO0FBdURJLGdCQUFZLEdBdkRoQjtBQXdESSxnQkFBWSxNQXhEaEI7QUF5REksZ0JBQVksTUF6RGhCO0FBMERJLGdCQUFZLFFBMURoQjtBQTJESSxnQkFBWSxLQTNEaEI7QUE0REksZ0JBQVksUUE1RGhCO0FBNkRJLGdCQUFZLFFBN0RoQjtBQThESSxnQkFBWSxHQTlEaEI7QUErREksZ0JBQVksTUEvRGhCO0FBZ0VJLGdCQUFZO0FBaEVoQixJQURTLEVBbUVUO0FBQ0ksU0FBSyxVQURUO0FBRUksZUFBVyxNQUZmO0FBR0ksZUFBVyxPQUhmO0FBSUksZUFBVyxVQUpmO0FBS0ksZUFBVyxVQUxmO0FBTUksZUFBVyxVQU5mO0FBT0ksZUFBVyxVQVBmO0FBUUksZUFBVyxJQVJmO0FBU0ksZUFBVyxPQVRmO0FBVUksZUFBVyxVQVZmO0FBV0ksZUFBVyxVQVhmO0FBWUksZUFBVyxPQVpmO0FBYUksZUFBVyxPQWJmO0FBY0ksZUFBVyxHQWRmO0FBZUksZUFBVyxNQWZmO0FBZ0JJLGVBQVcsVUFoQmY7QUFpQkksY0FBVSxVQWpCZDtBQWtCSSxlQUFXLE9BbEJmO0FBbUJJLGVBQVcsSUFuQmY7QUFvQkksZUFBVyxVQXBCZjtBQXFCSSxlQUFXLFVBckJmO0FBc0JJLGVBQVcsVUF0QmY7QUF1QkksZUFBVyxPQXZCZjtBQXdCSSxlQUFXLFVBeEJmO0FBeUJJLGVBQVcsT0F6QmY7QUEwQkksZUFBVyxHQTFCZjtBQTJCSSxlQUFXLE1BM0JmO0FBNEJJLGVBQVcsVUE1QmY7QUE2QkksZUFBVyxVQTdCZjtBQThCSSxlQUFXLE9BOUJmO0FBK0JJLGVBQVcsVUEvQmY7QUFnQ0ksZUFBVyxNQWhDZjtBQWlDSSxnQkFBWSxHQWpDaEI7QUFrQ0ksZ0JBQVksVUFsQ2hCO0FBbUNJLGdCQUFZLFVBbkNoQjtBQW9DSSxnQkFBWSxVQXBDaEI7QUFxQ0ksZ0JBQVksVUFyQ2hCO0FBc0NJLGdCQUFZLElBdENoQjtBQXVDSSxnQkFBWSxPQXZDaEI7QUF3Q0ksZ0JBQVksTUF4Q2hCO0FBeUNJLGdCQUFZLE1BekNoQjtBQTBDSSxnQkFBWSxPQTFDaEI7QUEyQ0ksZ0JBQVksT0EzQ2hCO0FBNENJLGdCQUFZLFVBNUNoQjtBQTZDSSxnQkFBWSxPQTdDaEI7QUE4Q0ksZ0JBQVksVUE5Q2hCO0FBK0NJLGdCQUFZLFVBL0NoQjtBQWdESSxnQkFBWSxVQWhEaEI7QUFpREksZ0JBQVksT0FqRGhCO0FBa0RJLGdCQUFZLE9BbERoQjtBQW1ESSxnQkFBWSxVQW5EaEI7QUFvREksZ0JBQVksTUFwRGhCO0FBcURJLGdCQUFZLFVBckRoQjtBQXNESSxnQkFBWSxVQXREaEI7QUF1REksZ0JBQVksSUF2RGhCO0FBd0RJLGdCQUFZLFVBeERoQjtBQXlESSxnQkFBWSxVQXpEaEI7QUEwREksZ0JBQVksVUExRGhCO0FBMkRJLGdCQUFZLFVBM0RoQjtBQTRESSxnQkFBWSxPQTVEaEI7QUE2REksZ0JBQVksR0E3RGhCO0FBOERJLGdCQUFZLE1BOURoQjtBQStESSxnQkFBWSxVQS9EaEI7QUFnRUksZ0JBQVk7QUFoRWhCLElBbkVTLEVBcUlUO0FBQ0ksU0FBSyxLQURUO0FBRUksY0FBVSxHQUZkO0FBR0ksY0FBVSxTQUhkO0FBSUksY0FBVSxPQUpkO0FBS0ksY0FBVSxPQUxkO0FBTUksY0FBVSxTQU5kO0FBT0ksY0FBVSxTQVBkO0FBUUksY0FBVSxTQVJkO0FBU0ksY0FBVSxTQVRkO0FBVUksY0FBVSxTQVZkO0FBV0ksY0FBVSxPQVhkO0FBWUksY0FBVSxTQVpkO0FBYUksY0FBVSxTQWJkO0FBY0ksY0FBVSxPQWRkO0FBZUksY0FBVSxHQWZkO0FBZ0JJLGNBQVUsS0FoQmQ7QUFpQkksYUFBUyxTQWpCYjtBQWtCSSxjQUFVLFNBbEJkO0FBbUJJLGNBQVUsR0FuQmQ7QUFvQkksY0FBVSxTQXBCZDtBQXFCSSxjQUFVLFNBckJkO0FBc0JJLGNBQVUsT0F0QmQ7QUF1QkksY0FBVSxPQXZCZDtBQXdCSSxjQUFVLEtBeEJkO0FBeUJJLGNBQVUsR0F6QmQ7QUEwQkksY0FBVSxLQTFCZDtBQTJCSSxjQUFVLFNBM0JkO0FBNEJJLGNBQVUsT0E1QmQ7QUE2QkksY0FBVSxPQTdCZDtBQThCSSxjQUFVLFNBOUJkO0FBK0JJLGNBQVUsU0EvQmQ7QUFnQ0ksY0FBVSxTQWhDZDtBQWlDSSxlQUFXLFNBakNmO0FBa0NJLGVBQVcsT0FsQ2Y7QUFtQ0ksZUFBVyxPQW5DZjtBQW9DSSxlQUFXLFNBcENmO0FBcUNJLGVBQVcsS0FyQ2Y7QUFzQ0ksZUFBVyxTQXRDZjtBQXVDSSxlQUFXLFNBdkNmO0FBd0NJLGVBQVcsR0F4Q2Y7QUF5Q0ksZUFBVyxTQXpDZjtBQTBDSSxlQUFXLFNBMUNmO0FBMkNJLGVBQVcsR0EzQ2Y7QUE0Q0ksZUFBVyxPQTVDZjtBQTZDSSxlQUFXLFNBN0NmO0FBOENJLGVBQVcsS0E5Q2Y7QUErQ0ksZUFBVyxPQS9DZjtBQWdESSxlQUFXLFNBaERmO0FBaURJLGVBQVcsU0FqRGY7QUFrREksZUFBVyxLQWxEZjtBQW1ESSxlQUFXLFNBbkRmO0FBb0RJLGVBQVcsR0FwRGY7QUFxREksZUFBVyxPQXJEZjtBQXNESSxlQUFXLFNBdERmO0FBdURJLGVBQVcsS0F2RGY7QUF3REksZUFBVyxTQXhEZjtBQXlESSxlQUFXLE9BekRmO0FBMERJLGVBQVcsU0ExRGY7QUEyREksZUFBVyxPQTNEZjtBQTRESSxlQUFXLFNBNURmO0FBNkRJLGVBQVcsU0E3RGY7QUE4REksZUFBVyxTQTlEZjtBQStESSxlQUFXLEdBL0RmO0FBZ0VJLGVBQVc7QUFoRWYsSUFySVMsRUF1TVQ7QUFDSSxTQUFLLFVBRFQ7QUFFSSxhQUFTLFVBRmI7QUFHSSxhQUFTLFFBSGI7QUFJSSxhQUFTLFVBSmI7QUFLSSxhQUFTLEdBTGI7QUFNSSxhQUFTLFFBTmI7QUFPSSxhQUFTLFVBUGI7QUFRSSxhQUFTLFFBUmI7QUFTSSxhQUFTLFVBVGI7QUFVSSxhQUFTLFFBVmI7QUFXSSxhQUFTLElBWGI7QUFZSSxhQUFTLFVBWmI7QUFhSSxhQUFTLFVBYmI7QUFjSSxhQUFTLE1BZGI7QUFlSSxhQUFTLE1BZmI7QUFnQkksYUFBUyxVQWhCYjtBQWlCSSxZQUFRLFVBakJaO0FBa0JJLGFBQVMsSUFsQmI7QUFtQkksYUFBUyxVQW5CYjtBQW9CSSxhQUFTLFVBcEJiO0FBcUJJLGFBQVMsUUFyQmI7QUFzQkksYUFBUyxVQXRCYjtBQXVCSSxhQUFTLEdBdkJiO0FBd0JJLGFBQVMsVUF4QmI7QUF5QkksYUFBUyxNQXpCYjtBQTBCSSxhQUFTLFVBMUJiO0FBMkJJLGFBQVMsUUEzQmI7QUE0QkksYUFBUyxNQTVCYjtBQTZCSSxhQUFTLFVBN0JiO0FBOEJJLGFBQVMsUUE5QmI7QUErQkksYUFBUyxRQS9CYjtBQWdDSSxhQUFTLFVBaENiO0FBaUNJLGNBQVUsUUFqQ2Q7QUFrQ0ksY0FBVSxRQWxDZDtBQW1DSSxjQUFVLFVBbkNkO0FBb0NJLGNBQVUsR0FwQ2Q7QUFxQ0ksY0FBVSxNQXJDZDtBQXNDSSxjQUFVLFVBdENkO0FBdUNJLGNBQVUsVUF2Q2Q7QUF3Q0ksY0FBVSxVQXhDZDtBQXlDSSxjQUFVLFVBekNkO0FBMENJLGNBQVUsVUExQ2Q7QUEyQ0ksY0FBVSxVQTNDZDtBQTRDSSxjQUFVLFFBNUNkO0FBNkNJLGNBQVUsVUE3Q2Q7QUE4Q0ksY0FBVSxRQTlDZDtBQStDSSxjQUFVLElBL0NkO0FBZ0RJLGNBQVUsTUFoRGQ7QUFpREksY0FBVSxVQWpEZDtBQWtESSxjQUFVLFVBbERkO0FBbURJLGNBQVUsR0FuRGQ7QUFvREksY0FBVSxRQXBEZDtBQXFESSxjQUFVLFFBckRkO0FBc0RJLGNBQVUsVUF0RGQ7QUF1REksY0FBVSxVQXZEZDtBQXdESSxjQUFVLElBeERkO0FBeURJLGNBQVUsVUF6RGQ7QUEwREksY0FBVSxNQTFEZDtBQTJESSxjQUFVLFVBM0RkO0FBNERJLGNBQVUsVUE1RGQ7QUE2REksY0FBVSxNQTdEZDtBQThESSxjQUFVLFVBOURkO0FBK0RJLGNBQVUsUUEvRGQ7QUFnRUksY0FBVTtBQWhFZCxJQXZNUyxFQXlRVDtBQUNJLFNBQUssSUFEVDtBQUVJLFlBQVEsU0FGWjtBQUdJLFlBQVEsT0FIWjtBQUlJLFlBQVEsVUFKWjtBQUtJLFlBQVEsVUFMWjtBQU1JLFlBQVEsU0FOWjtBQU9JLFlBQVEsVUFQWjtBQVFJLFlBQVEsT0FSWjtBQVNJLFlBQVEsU0FUWjtBQVVJLFlBQVEsVUFWWjtBQVdJLFlBQVEsVUFYWjtBQVlJLFlBQVEsVUFaWjtBQWFJLFlBQVEsVUFiWjtBQWNJLFlBQVEsR0FkWjtBQWVJLFlBQVEsU0FmWjtBQWdCSSxZQUFRLFVBaEJaO0FBaUJJLFdBQU8sU0FqQlg7QUFrQkksWUFBUSxVQWxCWjtBQW1CSSxZQUFRLElBbkJaO0FBb0JJLFlBQVEsU0FwQlo7QUFxQkksWUFBUSxPQXJCWjtBQXNCSSxZQUFRLFVBdEJaO0FBdUJJLFlBQVEsVUF2Qlo7QUF3QkksWUFBUSxVQXhCWjtBQXlCSSxZQUFRLFVBekJaO0FBMEJJLFlBQVEsR0ExQlo7QUEyQkksWUFBUSxVQTNCWjtBQTRCSSxZQUFRLFNBNUJaO0FBNkJJLFlBQVEsVUE3Qlo7QUE4QkksWUFBUSxVQTlCWjtBQStCSSxZQUFRLFNBL0JaO0FBZ0NJLFlBQVEsT0FoQ1o7QUFpQ0ksYUFBUyxPQWpDYjtBQWtDSSxhQUFTLElBbENiO0FBbUNJLGFBQVMsVUFuQ2I7QUFvQ0ksYUFBUyxVQXBDYjtBQXFDSSxhQUFTLFNBckNiO0FBc0NJLGFBQVMsVUF0Q2I7QUF1Q0ksYUFBUyxVQXZDYjtBQXdDSSxhQUFTLFNBeENiO0FBeUNJLGFBQVMsVUF6Q2I7QUEwQ0ksYUFBUyxVQTFDYjtBQTJDSSxhQUFTLFNBM0NiO0FBNENJLGFBQVMsVUE1Q2I7QUE2Q0ksYUFBUyxPQTdDYjtBQThDSSxhQUFTLFVBOUNiO0FBK0NJLGFBQVMsR0EvQ2I7QUFnREksYUFBUyxTQWhEYjtBQWlESSxhQUFTLFVBakRiO0FBa0RJLGFBQVMsU0FsRGI7QUFtREksYUFBUyxTQW5EYjtBQW9ESSxhQUFTLFVBcERiO0FBcURJLGFBQVMsVUFyRGI7QUFzREksYUFBUyxTQXREYjtBQXVESSxhQUFTLElBdkRiO0FBd0RJLGFBQVMsVUF4RGI7QUF5REksYUFBUyxPQXpEYjtBQTBESSxhQUFTLFVBMURiO0FBMkRJLGFBQVMsR0EzRGI7QUE0REksYUFBUyxVQTVEYjtBQTZESSxhQUFTLFNBN0RiO0FBOERJLGFBQVMsT0E5RGI7QUErREksYUFBUyxVQS9EYjtBQWdFSSxhQUFTO0FBaEViLElBelFTLEVBMlVUO0FBQ0ksU0FBSyxVQURUO0FBRUksV0FBTyxNQUZYO0FBR0ksV0FBTyxVQUhYO0FBSUksV0FBTyxVQUpYO0FBS0ksV0FBTyxVQUxYO0FBTUksV0FBTyxRQU5YO0FBT0ksV0FBTyxRQVBYO0FBUUksV0FBTyxVQVJYO0FBU0ksV0FBTyxHQVRYO0FBVUksV0FBTyxVQVZYO0FBV0ksV0FBTyxRQVhYO0FBWUksV0FBTyxHQVpYO0FBYUksV0FBTyxVQWJYO0FBY0ksV0FBTyxRQWRYO0FBZUksV0FBTyxNQWZYO0FBZ0JJLFdBQU8sVUFoQlg7QUFpQkksVUFBTSxVQWpCVjtBQWtCSSxXQUFPLFVBbEJYO0FBbUJJLFdBQU8sR0FuQlg7QUFvQkksV0FBTyxRQXBCWDtBQXFCSSxXQUFPLFFBckJYO0FBc0JJLFdBQU8sVUF0Qlg7QUF1QkksV0FBTyxVQXZCWDtBQXdCSSxXQUFPLE1BeEJYO0FBeUJJLFdBQU8sUUF6Qlg7QUEwQkksV0FBTyxNQTFCWDtBQTJCSSxXQUFPLFVBM0JYO0FBNEJJLFdBQU8sVUE1Qlg7QUE2QkksV0FBTyxHQTdCWDtBQThCSSxXQUFPLFVBOUJYO0FBK0JJLFdBQU8sUUEvQlg7QUFnQ0ksV0FBTyxVQWhDWDtBQWlDSSxZQUFRLFVBakNaO0FBa0NJLFlBQVEsVUFsQ1o7QUFtQ0ksWUFBUSxVQW5DWjtBQW9DSSxZQUFRLE1BcENaO0FBcUNJLFlBQVEsUUFyQ1o7QUFzQ0ksWUFBUSxVQXRDWjtBQXVDSSxZQUFRLFVBdkNaO0FBd0NJLFlBQVEsUUF4Q1o7QUF5Q0ksWUFBUSxRQXpDWjtBQTBDSSxZQUFRLEdBMUNaO0FBMkNJLFlBQVEsR0EzQ1o7QUE0Q0ksWUFBUSxVQTVDWjtBQTZDSSxZQUFRLE1BN0NaO0FBOENJLFlBQVEsVUE5Q1o7QUErQ0ksWUFBUSxVQS9DWjtBQWdESSxZQUFRLFFBaERaO0FBaURJLFlBQVEsR0FqRFo7QUFrREksWUFBUSxRQWxEWjtBQW1ESSxZQUFRLFFBbkRaO0FBb0RJLFlBQVEsVUFwRFo7QUFxREksWUFBUSxVQXJEWjtBQXNESSxZQUFRLE1BdERaO0FBdURJLFlBQVEsVUF2RFo7QUF3REksWUFBUSxVQXhEWjtBQXlESSxZQUFRLFVBekRaO0FBMERJLFlBQVEsVUExRFo7QUEyREksWUFBUSxNQTNEWjtBQTRESSxZQUFRLFFBNURaO0FBNkRJLFlBQVEsUUE3RFo7QUE4REksWUFBUSxHQTlEWjtBQStESSxZQUFRLFVBL0RaO0FBZ0VJLFlBQVE7QUFoRVosSUEzVVMsRUE2WVQ7QUFDSSxTQUFLLFFBRFQ7QUFFSSxVQUFNLFNBRlY7QUFHSSxVQUFNLEtBSFY7QUFJSSxVQUFNLFFBSlY7QUFLSSxVQUFNLFNBTFY7QUFNSSxVQUFNLEdBTlY7QUFPSSxVQUFNLEdBUFY7QUFRSSxVQUFNLFNBUlY7QUFTSSxVQUFNLFNBVFY7QUFVSSxVQUFNLFFBVlY7QUFXSSxVQUFNLFNBWFY7QUFZSSxVQUFNLFNBWlY7QUFhSSxVQUFNLFNBYlY7QUFjSSxVQUFNLEtBZFY7QUFlSSxVQUFNLFFBZlY7QUFnQkksVUFBTSxTQWhCVjtBQWlCSSxTQUFLLFNBakJUO0FBa0JJLFVBQU0sR0FsQlY7QUFtQkksVUFBTSxTQW5CVjtBQW9CSSxVQUFNLFNBcEJWO0FBcUJJLFVBQU0sUUFyQlY7QUFzQkksVUFBTSxTQXRCVjtBQXVCSSxVQUFNLFNBdkJWO0FBd0JJLFVBQU0sS0F4QlY7QUF5QkksVUFBTSxRQXpCVjtBQTBCSSxVQUFNLFNBMUJWO0FBMkJJLFVBQU0sU0EzQlY7QUE0QkksVUFBTSxRQTVCVjtBQTZCSSxVQUFNLEtBN0JWO0FBOEJJLFVBQU0sU0E5QlY7QUErQkksVUFBTSxHQS9CVjtBQWdDSSxVQUFNLFFBaENWO0FBaUNJLFdBQU8sU0FqQ1g7QUFrQ0ksV0FBTyxRQWxDWDtBQW1DSSxXQUFPLFNBbkNYO0FBb0NJLFdBQU8sU0FwQ1g7QUFxQ0ksV0FBTyxRQXJDWDtBQXNDSSxXQUFPLFNBdENYO0FBdUNJLFdBQU8sU0F2Q1g7QUF3Q0ksV0FBTyxRQXhDWDtBQXlDSSxXQUFPLEtBekNYO0FBMENJLFdBQU8sU0ExQ1g7QUEyQ0ksV0FBTyxRQTNDWDtBQTRDSSxXQUFPLEdBNUNYO0FBNkNJLFdBQU8sR0E3Q1g7QUE4Q0ksV0FBTyxTQTlDWDtBQStDSSxXQUFPLFNBL0NYO0FBZ0RJLFdBQU8sS0FoRFg7QUFpREksV0FBTyxRQWpEWDtBQWtESSxXQUFPLFNBbERYO0FBbURJLFdBQU8sU0FuRFg7QUFvREksV0FBTyxHQXBEWDtBQXFESSxXQUFPLFNBckRYO0FBc0RJLFdBQU8sUUF0RFg7QUF1REksV0FBTyxLQXZEWDtBQXdESSxXQUFPLFNBeERYO0FBeURJLFdBQU8sU0F6RFg7QUEwREksV0FBTyxTQTFEWDtBQTJESSxXQUFPLEdBM0RYO0FBNERJLFdBQU8sU0E1RFg7QUE2REksV0FBTyxRQTdEWDtBQThESSxXQUFPLEtBOURYO0FBK0RJLFdBQU8sU0EvRFg7QUFnRUksV0FBTztBQWhFWCxJQTdZUyxFQStjVDtBQUNJLFNBQUssU0FEVDtBQUVJLFNBQUssT0FGVDtBQUdJLFNBQUssU0FIVDtBQUlJLFNBQUssSUFKVDtBQUtJLFNBQUssT0FMVDtBQU1JLFNBQUssU0FOVDtBQU9JLFNBQUssU0FQVDtBQVFJLFNBQUssS0FSVDtBQVNJLFNBQUssU0FUVDtBQVVJLFNBQUssU0FWVDtBQVdJLFNBQUssT0FYVDtBQVlJLFNBQUssU0FaVDtBQWFJLFNBQUssS0FiVDtBQWNJLFNBQUssR0FkVDtBQWVJLFNBQUssU0FmVDtBQWdCSSxTQUFLLE9BaEJUO0FBaUJJLGdCQUFZLEtBakJoQjtBQWtCSSxnQkFBWSxTQWxCaEI7QUFtQkksZ0JBQVksU0FuQmhCO0FBb0JJLGdCQUFZLFNBcEJoQjtBQXFCSSxnQkFBWSxTQXJCaEI7QUFzQkksZ0JBQVksT0F0QmhCO0FBdUJJLGdCQUFZLE9BdkJoQjtBQXdCSSxnQkFBWSxJQXhCaEI7QUF5QkksZ0JBQVksU0F6QmhCO0FBMEJJLGdCQUFZLEtBMUJoQjtBQTJCSSxnQkFBWSxPQTNCaEI7QUE0QkksZ0JBQVksU0E1QmhCO0FBNkJJLGdCQUFZLEdBN0JoQjtBQThCSSxnQkFBWSxTQTlCaEI7QUErQkksZ0JBQVksU0EvQmhCO0FBZ0NJLGdCQUFZLE9BaENoQjtBQWlDSSxVQUFNLE9BakNWO0FBa0NJLFVBQU0sU0FsQ1Y7QUFtQ0ksVUFBTSxJQW5DVjtBQW9DSSxVQUFNLEtBcENWO0FBcUNJLFVBQU0sU0FyQ1Y7QUFzQ0ksVUFBTSxTQXRDVjtBQXVDSSxVQUFNLFNBdkNWO0FBd0NJLFVBQU0sT0F4Q1Y7QUF5Q0ksVUFBTSxHQXpDVjtBQTBDSSxVQUFNLE9BMUNWO0FBMkNJLFVBQU0sU0EzQ1Y7QUE0Q0ksVUFBTSxTQTVDVjtBQTZDSSxVQUFNLFNBN0NWO0FBOENJLFVBQU0sT0E5Q1Y7QUErQ0ksVUFBTSxLQS9DVjtBQWdESSxVQUFNLFNBaERWO0FBaURJLGdCQUFZLE9BakRoQjtBQWtESSxnQkFBWSxLQWxEaEI7QUFtREksZ0JBQVksU0FuRGhCO0FBb0RJLGdCQUFZLE9BcERoQjtBQXFESSxnQkFBWSxJQXJEaEI7QUFzREksZ0JBQVksU0F0RGhCO0FBdURJLGdCQUFZLFNBdkRoQjtBQXdESSxnQkFBWSxTQXhEaEI7QUF5REksZ0JBQVksU0F6RGhCO0FBMERJLGdCQUFZLFNBMURoQjtBQTJESSxnQkFBWSxTQTNEaEI7QUE0REksZ0JBQVksR0E1RGhCO0FBNkRJLGdCQUFZLE9BN0RoQjtBQThESSxnQkFBWSxLQTlEaEI7QUErREksZ0JBQVksT0EvRGhCO0FBZ0VJLGdCQUFZO0FBaEVoQixJQS9jUyxDQUFiOztBQW1oQkE7QUFDQSxPQUFJQyxZQUFZLENBQ1osVUFEWSxFQUNBLFVBREEsRUFDWSxVQURaLEVBQ3dCLFVBRHhCLEVBRVosVUFGWSxFQUVBLFVBRkEsRUFFWSxVQUZaLEVBRXdCLFVBRnhCLENBQWhCOztBQUtBOzs7QUFHQSxPQUFJQyxNQUFNcGIsT0FBT29iLEdBQVAsR0FBYXZGLFlBQVluYyxNQUFaLENBQW1CO0FBQ3RDMkYsY0FBVSxvQkFBWTtBQUNsQjtBQUNBLFNBQUlVLE1BQU0sS0FBS3lULElBQWY7QUFDQSxTQUFJdUcsV0FBV2hhLElBQUl2RixLQUFuQjs7QUFFQTtBQUNBLFNBQUk2Z0IsVUFBVSxFQUFkO0FBQ0EsVUFBSyxJQUFJaGdCLElBQUksQ0FBYixFQUFnQkEsSUFBSSxFQUFwQixFQUF3QkEsR0FBeEIsRUFBNkI7QUFDekIsVUFBSWlnQixZQUFZUCxJQUFJMWYsQ0FBSixJQUFTLENBQXpCO0FBQ0FnZ0IsY0FBUWhnQixDQUFSLElBQWMwZSxTQUFTdUIsY0FBYyxDQUF2QixNQUErQixLQUFLQSxZQUFZLEVBQWpELEdBQXdELENBQXJFO0FBQ0g7O0FBRUQ7QUFDQSxTQUFJQyxVQUFVLEtBQUtDLFFBQUwsR0FBZ0IsRUFBOUI7QUFDQSxVQUFLLElBQUlDLFVBQVUsQ0FBbkIsRUFBc0JBLFVBQVUsRUFBaEMsRUFBb0NBLFNBQXBDLEVBQStDO0FBQzNDO0FBQ0EsVUFBSUMsU0FBU0gsUUFBUUUsT0FBUixJQUFtQixFQUFoQzs7QUFFQTtBQUNBLFVBQUlFLFdBQVdWLFdBQVdRLE9BQVgsQ0FBZjs7QUFFQTtBQUNBLFdBQUssSUFBSXBnQixJQUFJLENBQWIsRUFBZ0JBLElBQUksRUFBcEIsRUFBd0JBLEdBQXhCLEVBQTZCO0FBQ3pCO0FBQ0FxZ0IsY0FBUXJnQixJQUFJLENBQUwsR0FBVSxDQUFqQixLQUF1QmdnQixRQUFRLENBQUVMLElBQUkzZixDQUFKLElBQVMsQ0FBVixHQUFlc2dCLFFBQWhCLElBQTRCLEVBQXBDLEtBQTRDLEtBQUt0Z0IsSUFBSSxDQUE1RTs7QUFFQTtBQUNBcWdCLGNBQU8sS0FBTXJnQixJQUFJLENBQUwsR0FBVSxDQUFmLENBQVAsS0FBNkJnZ0IsUUFBUSxLQUFNLENBQUVMLElBQUkzZixJQUFJLEVBQVIsSUFBYyxDQUFmLEdBQW9Cc2dCLFFBQXJCLElBQWlDLEVBQS9DLEtBQXdELEtBQUt0Z0IsSUFBSSxDQUE5RjtBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNBcWdCLGFBQU8sQ0FBUCxJQUFhQSxPQUFPLENBQVAsS0FBYSxDQUFkLEdBQW9CQSxPQUFPLENBQVAsTUFBYyxFQUE5QztBQUNBLFdBQUssSUFBSXJnQixJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCcWdCLGNBQU9yZ0IsQ0FBUCxJQUFZcWdCLE9BQU9yZ0IsQ0FBUCxNQUFlLENBQUNBLElBQUksQ0FBTCxJQUFVLENBQVYsR0FBYyxDQUF6QztBQUNIO0FBQ0RxZ0IsYUFBTyxDQUFQLElBQWFBLE9BQU8sQ0FBUCxLQUFhLENBQWQsR0FBb0JBLE9BQU8sQ0FBUCxNQUFjLEVBQTlDO0FBQ0g7O0FBRUQ7QUFDQSxTQUFJRSxhQUFhLEtBQUtDLFdBQUwsR0FBbUIsRUFBcEM7QUFDQSxVQUFLLElBQUl4Z0IsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEVBQXBCLEVBQXdCQSxHQUF4QixFQUE2QjtBQUN6QnVnQixpQkFBV3ZnQixDQUFYLElBQWdCa2dCLFFBQVEsS0FBS2xnQixDQUFiLENBQWhCO0FBQ0g7QUFDSixLQTlDcUM7O0FBZ0R0QzRaLGtCQUFjLHNCQUFVN1EsQ0FBVixFQUFhckYsTUFBYixFQUFxQjtBQUMvQixVQUFLeWIsYUFBTCxDQUFtQnBXLENBQW5CLEVBQXNCckYsTUFBdEIsRUFBOEIsS0FBS3ljLFFBQW5DO0FBQ0gsS0FsRHFDOztBQW9EdENwRyxrQkFBYyxzQkFBVWhSLENBQVYsRUFBYXJGLE1BQWIsRUFBcUI7QUFDL0IsVUFBS3liLGFBQUwsQ0FBbUJwVyxDQUFuQixFQUFzQnJGLE1BQXRCLEVBQThCLEtBQUs4YyxXQUFuQztBQUNILEtBdERxQzs7QUF3RHRDckIsbUJBQWUsdUJBQVVwVyxDQUFWLEVBQWFyRixNQUFiLEVBQXFCd2MsT0FBckIsRUFBOEI7QUFDekM7QUFDQSxVQUFLTyxPQUFMLEdBQWUxWCxFQUFFckYsTUFBRixDQUFmO0FBQ0EsVUFBS2dkLE9BQUwsR0FBZTNYLEVBQUVyRixTQUFTLENBQVgsQ0FBZjs7QUFFQTtBQUNBaWQsZ0JBQVd4Z0IsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixFQUEwQixVQUExQjtBQUNBd2dCLGdCQUFXeGdCLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsRUFBdEIsRUFBMEIsVUFBMUI7QUFDQXlnQixnQkFBV3pnQixJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEVBQTBCLFVBQTFCO0FBQ0F5Z0IsZ0JBQVd6Z0IsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixFQUEwQixVQUExQjtBQUNBd2dCLGdCQUFXeGdCLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsRUFBMEIsVUFBMUI7O0FBRUE7QUFDQSxVQUFLLElBQUk2UyxRQUFRLENBQWpCLEVBQW9CQSxRQUFRLEVBQTVCLEVBQWdDQSxPQUFoQyxFQUF5QztBQUNyQztBQUNBLFVBQUlxTixTQUFTSCxRQUFRbE4sS0FBUixDQUFiO0FBQ0EsVUFBSTZOLFNBQVMsS0FBS0osT0FBbEI7QUFDQSxVQUFJSyxTQUFTLEtBQUtKLE9BQWxCOztBQUVBO0FBQ0EsVUFBSXhVLElBQUksQ0FBUjtBQUNBLFdBQUssSUFBSWxNLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEJrTSxZQUFLMlQsT0FBTzdmLENBQVAsRUFBVSxDQUFDLENBQUM4Z0IsU0FBU1QsT0FBT3JnQixDQUFQLENBQVYsSUFBdUI4ZixVQUFVOWYsQ0FBVixDQUF4QixNQUEwQyxDQUFwRCxDQUFMO0FBQ0g7QUFDRCxXQUFLeWdCLE9BQUwsR0FBZUssTUFBZjtBQUNBLFdBQUtKLE9BQUwsR0FBZUcsU0FBUzNVLENBQXhCO0FBQ0g7O0FBRUQ7QUFDQSxTQUFJZixJQUFJLEtBQUtzVixPQUFiO0FBQ0EsVUFBS0EsT0FBTCxHQUFlLEtBQUtDLE9BQXBCO0FBQ0EsVUFBS0EsT0FBTCxHQUFldlYsQ0FBZjs7QUFFQTtBQUNBd1YsZ0JBQVd4Z0IsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixFQUEwQixVQUExQjtBQUNBeWdCLGdCQUFXemdCLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsRUFBMEIsVUFBMUI7QUFDQXlnQixnQkFBV3pnQixJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEVBQTBCLFVBQTFCO0FBQ0F3Z0IsZ0JBQVd4Z0IsSUFBWCxDQUFnQixJQUFoQixFQUFzQixFQUF0QixFQUEwQixVQUExQjtBQUNBd2dCLGdCQUFXeGdCLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsRUFBMEIsVUFBMUI7O0FBRUE7QUFDQTRJLE9BQUVyRixNQUFGLElBQVksS0FBSytjLE9BQWpCO0FBQ0ExWCxPQUFFckYsU0FBUyxDQUFYLElBQWdCLEtBQUtnZCxPQUFyQjtBQUNILEtBbkdxQzs7QUFxR3RDN0osYUFBUyxLQUFHLEVBckcwQjs7QUF1R3RDMEIsWUFBUSxLQUFHLEVBdkcyQjs7QUF5R3RDclYsZUFBVyxLQUFHO0FBekd3QixJQUFuQixDQUF2Qjs7QUE0R0E7QUFDQSxZQUFTeWQsVUFBVCxDQUFvQmpkLE1BQXBCLEVBQTRCaEQsSUFBNUIsRUFBa0M7QUFDOUIsUUFBSXlLLElBQUksQ0FBRSxLQUFLc1YsT0FBTCxLQUFpQi9jLE1BQWxCLEdBQTRCLEtBQUtnZCxPQUFsQyxJQUE2Q2hnQixJQUFyRDtBQUNBLFNBQUtnZ0IsT0FBTCxJQUFnQnZWLENBQWhCO0FBQ0EsU0FBS3NWLE9BQUwsSUFBZ0J0VixLQUFLekgsTUFBckI7QUFDSDs7QUFFRCxZQUFTa2QsVUFBVCxDQUFvQmxkLE1BQXBCLEVBQTRCaEQsSUFBNUIsRUFBa0M7QUFDOUIsUUFBSXlLLElBQUksQ0FBRSxLQUFLdVYsT0FBTCxLQUFpQmhkLE1BQWxCLEdBQTRCLEtBQUsrYyxPQUFsQyxJQUE2Qy9mLElBQXJEO0FBQ0EsU0FBSytmLE9BQUwsSUFBZ0J0VixDQUFoQjtBQUNBLFNBQUt1VixPQUFMLElBQWdCdlYsS0FBS3pILE1BQXJCO0FBQ0g7O0FBRUQ7Ozs7Ozs7O0FBUUF6RixLQUFFOGhCLEdBQUYsR0FBUXZGLFlBQVlsVyxhQUFaLENBQTBCeWIsR0FBMUIsQ0FBUjs7QUFFQTs7O0FBR0EsT0FBSWdCLFlBQVlwYyxPQUFPb2MsU0FBUCxHQUFtQnZHLFlBQVluYyxNQUFaLENBQW1CO0FBQ2xEMkYsY0FBVSxvQkFBWTtBQUNsQjtBQUNBLFNBQUlVLE1BQU0sS0FBS3lULElBQWY7QUFDQSxTQUFJdUcsV0FBV2hhLElBQUl2RixLQUFuQjs7QUFFQTtBQUNBLFVBQUs2aEIsS0FBTCxHQUFhakIsSUFBSWxJLGVBQUosQ0FBb0IzWSxVQUFVdkIsTUFBVixDQUFpQitnQixTQUFTdGUsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsQ0FBakIsQ0FBcEIsQ0FBYjtBQUNBLFVBQUs2Z0IsS0FBTCxHQUFhbEIsSUFBSWxJLGVBQUosQ0FBb0IzWSxVQUFVdkIsTUFBVixDQUFpQitnQixTQUFTdGUsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsQ0FBakIsQ0FBcEIsQ0FBYjtBQUNBLFVBQUs4Z0IsS0FBTCxHQUFhbkIsSUFBSWxJLGVBQUosQ0FBb0IzWSxVQUFVdkIsTUFBVixDQUFpQitnQixTQUFTdGUsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsQ0FBakIsQ0FBcEIsQ0FBYjtBQUNILEtBVmlEOztBQVlsRHdaLGtCQUFjLHNCQUFVN1EsQ0FBVixFQUFhckYsTUFBYixFQUFxQjtBQUMvQixVQUFLc2QsS0FBTCxDQUFXcEgsWUFBWCxDQUF3QjdRLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDQSxVQUFLdWQsS0FBTCxDQUFXbEgsWUFBWCxDQUF3QmhSLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDQSxVQUFLd2QsS0FBTCxDQUFXdEgsWUFBWCxDQUF3QjdRLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDSCxLQWhCaUQ7O0FBa0JsRHFXLGtCQUFjLHNCQUFVaFIsQ0FBVixFQUFhckYsTUFBYixFQUFxQjtBQUMvQixVQUFLd2QsS0FBTCxDQUFXbkgsWUFBWCxDQUF3QmhSLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDQSxVQUFLdWQsS0FBTCxDQUFXckgsWUFBWCxDQUF3QjdRLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDQSxVQUFLc2QsS0FBTCxDQUFXakgsWUFBWCxDQUF3QmhSLENBQXhCLEVBQTJCckYsTUFBM0I7QUFDSCxLQXRCaUQ7O0FBd0JsRG1ULGFBQVMsTUFBSSxFQXhCcUM7O0FBMEJsRDBCLFlBQVEsS0FBRyxFQTFCdUM7O0FBNEJsRHJWLGVBQVcsS0FBRztBQTVCb0MsSUFBbkIsQ0FBbkM7O0FBK0JBOzs7Ozs7OztBQVFBakYsS0FBRThpQixTQUFGLEdBQWN2RyxZQUFZbFcsYUFBWixDQUEwQnljLFNBQTFCLENBQWQ7QUFDSCxHQTd1QkEsR0FBRDs7QUFndkJBLFNBQU92akIsU0FBU3VqQixTQUFoQjtBQUVBLEVBandCQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVU5akIsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixFQUFvRCxtQkFBQUEsQ0FBUSxFQUFSLENBQXBELEVBQXNFLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdEUsRUFBMkYsbUJBQUFBLENBQVEsRUFBUixDQUEzRixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsRUFBMkIsdUJBQTNCLEVBQW9DLHVCQUFwQyxFQUFnRCx1QkFBaEQsQ0FBUCxvQ0FBeUVMLE9BQXpFO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSTRhLGVBQWU3YSxNQUFNNmEsWUFBekI7QUFDQSxPQUFJcFUsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBOzs7QUFHQSxPQUFJc2MsTUFBTXhjLE9BQU93YyxHQUFQLEdBQWFwSSxhQUFhMWEsTUFBYixDQUFvQjtBQUN2QzJGLGNBQVUsb0JBQVk7QUFDbEI7QUFDQSxTQUFJVSxNQUFNLEtBQUt5VCxJQUFmO0FBQ0EsU0FBSXVHLFdBQVdoYSxJQUFJdkYsS0FBbkI7QUFDQSxTQUFJaWlCLGNBQWMxYyxJQUFJdEYsUUFBdEI7O0FBRUE7QUFDQSxTQUFJaWlCLElBQUksS0FBS0MsRUFBTCxHQUFVLEVBQWxCO0FBQ0EsVUFBSyxJQUFJdGhCLElBQUksQ0FBYixFQUFnQkEsSUFBSSxHQUFwQixFQUF5QkEsR0FBekIsRUFBOEI7QUFDMUJxaEIsUUFBRXJoQixDQUFGLElBQU9BLENBQVA7QUFDSDs7QUFFRDtBQUNBLFVBQUssSUFBSUEsSUFBSSxDQUFSLEVBQVc4SCxJQUFJLENBQXBCLEVBQXVCOUgsSUFBSSxHQUEzQixFQUFnQ0EsR0FBaEMsRUFBcUM7QUFDakMsVUFBSXVoQixlQUFldmhCLElBQUlvaEIsV0FBdkI7QUFDQSxVQUFJSSxVQUFXOUMsU0FBUzZDLGlCQUFpQixDQUExQixNQUFrQyxLQUFNQSxlQUFlLENBQWhCLEdBQXFCLENBQTdELEdBQW1FLElBQWpGOztBQUVBelosVUFBSSxDQUFDQSxJQUFJdVosRUFBRXJoQixDQUFGLENBQUosR0FBV3doQixPQUFaLElBQXVCLEdBQTNCOztBQUVBO0FBQ0EsVUFBSXJXLElBQUlrVyxFQUFFcmhCLENBQUYsQ0FBUjtBQUNBcWhCLFFBQUVyaEIsQ0FBRixJQUFPcWhCLEVBQUV2WixDQUFGLENBQVA7QUFDQXVaLFFBQUV2WixDQUFGLElBQU9xRCxDQUFQO0FBQ0g7O0FBRUQ7QUFDQSxVQUFLc1csRUFBTCxHQUFVLEtBQUtDLEVBQUwsR0FBVSxDQUFwQjtBQUNILEtBNUJzQzs7QUE4QnZDL2QscUJBQWlCLHlCQUFVb0YsQ0FBVixFQUFhckYsTUFBYixFQUFxQjtBQUNsQ3FGLE9BQUVyRixNQUFGLEtBQWFpZSxzQkFBc0J4aEIsSUFBdEIsQ0FBMkIsSUFBM0IsQ0FBYjtBQUNILEtBaENzQzs7QUFrQ3ZDMFcsYUFBUyxNQUFJLEVBbEMwQjs7QUFvQ3ZDMEIsWUFBUTtBQXBDK0IsSUFBcEIsQ0FBdkI7O0FBdUNBLFlBQVNvSixxQkFBVCxHQUFpQztBQUM3QjtBQUNBLFFBQUlOLElBQUksS0FBS0MsRUFBYjtBQUNBLFFBQUl0aEIsSUFBSSxLQUFLeWhCLEVBQWI7QUFDQSxRQUFJM1osSUFBSSxLQUFLNFosRUFBYjs7QUFFQTtBQUNBLFFBQUlFLGdCQUFnQixDQUFwQjtBQUNBLFNBQUssSUFBSXhXLElBQUksQ0FBYixFQUFnQkEsSUFBSSxDQUFwQixFQUF1QkEsR0FBdkIsRUFBNEI7QUFDeEJwTCxTQUFJLENBQUNBLElBQUksQ0FBTCxJQUFVLEdBQWQ7QUFDQThILFNBQUksQ0FBQ0EsSUFBSXVaLEVBQUVyaEIsQ0FBRixDQUFMLElBQWEsR0FBakI7O0FBRUE7QUFDQSxTQUFJbUwsSUFBSWtXLEVBQUVyaEIsQ0FBRixDQUFSO0FBQ0FxaEIsT0FBRXJoQixDQUFGLElBQU9xaEIsRUFBRXZaLENBQUYsQ0FBUDtBQUNBdVosT0FBRXZaLENBQUYsSUFBT3FELENBQVA7O0FBRUF5VyxzQkFBaUJQLEVBQUUsQ0FBQ0EsRUFBRXJoQixDQUFGLElBQU9xaEIsRUFBRXZaLENBQUYsQ0FBUixJQUFnQixHQUFsQixLQUEyQixLQUFLc0QsSUFBSSxDQUFyRDtBQUNIOztBQUVEO0FBQ0EsU0FBS3FXLEVBQUwsR0FBVXpoQixDQUFWO0FBQ0EsU0FBSzBoQixFQUFMLEdBQVU1WixDQUFWOztBQUVBLFdBQU84WixhQUFQO0FBQ0g7O0FBRUQ7Ozs7Ozs7O0FBUUEzakIsS0FBRWtqQixHQUFGLEdBQVFwSSxhQUFhelUsYUFBYixDQUEyQjZjLEdBQTNCLENBQVI7O0FBRUE7OztBQUdBLE9BQUlVLFVBQVVsZCxPQUFPa2QsT0FBUCxHQUFpQlYsSUFBSTlpQixNQUFKLENBQVc7QUFDdEM7Ozs7O0FBS0EwRixTQUFLb2QsSUFBSXBkLEdBQUosQ0FBUTFGLE1BQVIsQ0FBZTtBQUNoQnlqQixXQUFNO0FBRFUsS0FBZixDQU5pQzs7QUFVdEM5ZCxjQUFVLG9CQUFZO0FBQ2xCbWQsU0FBSW5kLFFBQUosQ0FBYTdELElBQWIsQ0FBa0IsSUFBbEI7O0FBRUE7QUFDQSxVQUFLLElBQUlILElBQUksS0FBSytELEdBQUwsQ0FBUytkLElBQXRCLEVBQTRCOWhCLElBQUksQ0FBaEMsRUFBbUNBLEdBQW5DLEVBQXdDO0FBQ3BDMmhCLDRCQUFzQnhoQixJQUF0QixDQUEyQixJQUEzQjtBQUNIO0FBQ0o7QUFqQnFDLElBQVgsQ0FBL0I7O0FBb0JBOzs7Ozs7OztBQVFBbEMsS0FBRTRqQixPQUFGLEdBQVk5SSxhQUFhelUsYUFBYixDQUEyQnVkLE9BQTNCLENBQVo7QUFDSCxHQXRIQSxHQUFEOztBQXlIQSxTQUFPcmtCLFNBQVMyakIsR0FBaEI7QUFFQSxFQTFJQyxDQUFELEM7Ozs7Ozs7Ozs7QUNBRCxFQUFFLFdBQVVsa0IsSUFBVixFQUFnQkMsT0FBaEIsRUFBeUJDLEtBQXpCLEVBQWdDO0FBQ2pDLE1BQUksZ0NBQU9DLE9BQVAsT0FBbUIsUUFBdkIsRUFBaUM7QUFDaEM7QUFDQUMsVUFBT0QsT0FBUCxHQUFpQkEsVUFBVUYsUUFBUSxtQkFBQUksQ0FBUSxFQUFSLENBQVIsRUFBMkIsbUJBQUFBLENBQVEsRUFBUixDQUEzQixFQUFvRCxtQkFBQUEsQ0FBUSxFQUFSLENBQXBELEVBQXNFLG1CQUFBQSxDQUFRLEVBQVIsQ0FBdEUsRUFBMkYsbUJBQUFBLENBQVEsRUFBUixDQUEzRixDQUEzQjtBQUNBLEdBSEQsTUFJSyxJQUFJLElBQUosRUFBZ0Q7QUFDcEQ7QUFDQUMsR0FBQSxpQ0FBTyxDQUFDLHVCQUFELEVBQVcsdUJBQVgsRUFBMkIsdUJBQTNCLEVBQW9DLHVCQUFwQyxFQUFnRCx1QkFBaEQsQ0FBUCxvQ0FBeUVMLE9BQXpFO0FBQ0EsR0FISSxNQUlBO0FBQ0o7QUFDQUEsV0FBUUQsS0FBS08sUUFBYjtBQUNBO0FBQ0QsRUFiQyxhQWFNLFVBQVVBLFFBQVYsRUFBb0I7O0FBRTFCLGVBQVk7QUFDVDtBQUNBLE9BQUlTLElBQUlULFFBQVI7QUFDQSxPQUFJVSxRQUFRRCxFQUFFRSxHQUFkO0FBQ0EsT0FBSTRhLGVBQWU3YSxNQUFNNmEsWUFBekI7QUFDQSxPQUFJcFUsU0FBUzFHLEVBQUU0RyxJQUFmOztBQUVBO0FBQ0EsT0FBSXdjLElBQUssRUFBVDtBQUNBLE9BQUlVLEtBQUssRUFBVDtBQUNBLE9BQUlDLElBQUssRUFBVDs7QUFFQTs7O0FBR0EsT0FBSUMsU0FBU3RkLE9BQU9zZCxNQUFQLEdBQWdCbEosYUFBYTFhLE1BQWIsQ0FBb0I7QUFDN0MyRixjQUFVLG9CQUFZO0FBQ2xCO0FBQ0EsU0FBSXlILElBQUksS0FBSzBNLElBQUwsQ0FBVWhaLEtBQWxCO0FBQ0EsU0FBSWlhLEtBQUssS0FBS3JWLEdBQUwsQ0FBU3FWLEVBQWxCOztBQUVBO0FBQ0EsVUFBSyxJQUFJcFosSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QnlMLFFBQUV6TCxDQUFGLElBQVEsQ0FBRXlMLEVBQUV6TCxDQUFGLEtBQVEsQ0FBVCxHQUFnQnlMLEVBQUV6TCxDQUFGLE1BQVMsRUFBMUIsSUFBaUMsVUFBbEMsR0FDQyxDQUFFeUwsRUFBRXpMLENBQUYsS0FBUSxFQUFULEdBQWdCeUwsRUFBRXpMLENBQUYsTUFBUyxDQUExQixJQUFpQyxVQUR6QztBQUVIOztBQUVEO0FBQ0EsU0FBSWtpQixJQUFJLEtBQUtDLEVBQUwsR0FBVSxDQUNkMVcsRUFBRSxDQUFGLENBRGMsRUFDUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFEakIsRUFFZEEsRUFBRSxDQUFGLENBRmMsRUFFUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFGakIsRUFHZEEsRUFBRSxDQUFGLENBSGMsRUFHUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFIakIsRUFJZEEsRUFBRSxDQUFGLENBSmMsRUFJUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFKakIsQ0FBbEI7O0FBT0E7QUFDQSxTQUFJeE4sSUFBSSxLQUFLbWtCLEVBQUwsR0FBVSxDQUNiM1csRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFEWCxFQUNpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFEOUMsRUFFYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFGWCxFQUVpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFGOUMsRUFHYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFIWCxFQUdpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFIOUMsRUFJYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFKWCxFQUlpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFKOUMsQ0FBbEI7O0FBT0E7QUFDQSxVQUFLNFcsRUFBTCxHQUFVLENBQVY7O0FBRUE7QUFDQSxVQUFLLElBQUlyaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QnNpQixnQkFBVW5pQixJQUFWLENBQWUsSUFBZjtBQUNIOztBQUVEO0FBQ0EsVUFBSyxJQUFJSCxJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCL0IsUUFBRStCLENBQUYsS0FBUWtpQixFQUFHbGlCLElBQUksQ0FBTCxHQUFVLENBQVosQ0FBUjtBQUNIOztBQUVEO0FBQ0EsU0FBSW9aLEVBQUosRUFBUTtBQUNKO0FBQ0EsVUFBSW1KLEtBQUtuSixHQUFHamEsS0FBWjtBQUNBLFVBQUlxakIsT0FBT0QsR0FBRyxDQUFILENBQVg7QUFDQSxVQUFJRSxPQUFPRixHQUFHLENBQUgsQ0FBWDs7QUFFQTtBQUNBLFVBQUlHLEtBQU0sQ0FBRUYsUUFBUSxDQUFULEdBQWVBLFNBQVMsRUFBekIsSUFBZ0MsVUFBakMsR0FBZ0QsQ0FBRUEsUUFBUSxFQUFULEdBQWdCQSxTQUFTLENBQTFCLElBQWdDLFVBQXpGO0FBQ0EsVUFBSUcsS0FBTSxDQUFFRixRQUFRLENBQVQsR0FBZUEsU0FBUyxFQUF6QixJQUFnQyxVQUFqQyxHQUFnRCxDQUFFQSxRQUFRLEVBQVQsR0FBZ0JBLFNBQVMsQ0FBMUIsSUFBZ0MsVUFBekY7QUFDQSxVQUFJRyxLQUFNRixPQUFPLEVBQVIsR0FBZUMsS0FBSyxVQUE3QjtBQUNBLFVBQUlFLEtBQU1GLE1BQU0sRUFBUCxHQUFlRCxLQUFLLFVBQTdCOztBQUVBO0FBQ0F6a0IsUUFBRSxDQUFGLEtBQVF5a0IsRUFBUjtBQUNBemtCLFFBQUUsQ0FBRixLQUFRMmtCLEVBQVI7QUFDQTNrQixRQUFFLENBQUYsS0FBUTBrQixFQUFSO0FBQ0Exa0IsUUFBRSxDQUFGLEtBQVE0a0IsRUFBUjtBQUNBNWtCLFFBQUUsQ0FBRixLQUFReWtCLEVBQVI7QUFDQXprQixRQUFFLENBQUYsS0FBUTJrQixFQUFSO0FBQ0Eza0IsUUFBRSxDQUFGLEtBQVEwa0IsRUFBUjtBQUNBMWtCLFFBQUUsQ0FBRixLQUFRNGtCLEVBQVI7O0FBRUE7QUFDQSxXQUFLLElBQUk3aUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QnNpQixpQkFBVW5pQixJQUFWLENBQWUsSUFBZjtBQUNIO0FBQ0o7QUFDSixLQXJFNEM7O0FBdUU3Q3dELHFCQUFpQix5QkFBVW9GLENBQVYsRUFBYXJGLE1BQWIsRUFBcUI7QUFDbEM7QUFDQSxTQUFJd2UsSUFBSSxLQUFLQyxFQUFiOztBQUVBO0FBQ0FHLGVBQVVuaUIsSUFBVixDQUFlLElBQWY7O0FBRUE7QUFDQWtoQixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2Qzs7QUFFQSxVQUFLLElBQUlsaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QjtBQUNBcWhCLFFBQUVyaEIsQ0FBRixJQUFRLENBQUVxaEIsRUFBRXJoQixDQUFGLEtBQVEsQ0FBVCxHQUFnQnFoQixFQUFFcmhCLENBQUYsTUFBUyxFQUExQixJQUFpQyxVQUFsQyxHQUNDLENBQUVxaEIsRUFBRXJoQixDQUFGLEtBQVEsRUFBVCxHQUFnQnFoQixFQUFFcmhCLENBQUYsTUFBUyxDQUExQixJQUFpQyxVQUR6Qzs7QUFHQTtBQUNBK0ksUUFBRXJGLFNBQVMxRCxDQUFYLEtBQWlCcWhCLEVBQUVyaEIsQ0FBRixDQUFqQjtBQUNIO0FBQ0osS0E1RjRDOztBQThGN0NrRCxlQUFXLE1BQUksRUE5RjhCOztBQWdHN0NxVixZQUFRLEtBQUc7QUFoR2tDLElBQXBCLENBQTdCOztBQW1HQSxZQUFTK0osU0FBVCxHQUFxQjtBQUNqQjtBQUNBLFFBQUlKLElBQUksS0FBS0MsRUFBYjtBQUNBLFFBQUlsa0IsSUFBSSxLQUFLbWtCLEVBQWI7O0FBRUE7QUFDQSxTQUFLLElBQUlwaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QitoQixRQUFHL2hCLENBQUgsSUFBUS9CLEVBQUUrQixDQUFGLENBQVI7QUFDSDs7QUFFRDtBQUNBL0IsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsR0FBb0IsS0FBS29rQixFQUExQixHQUFnQyxDQUF2QztBQUNBcGtCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQTlqQixNQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8sVUFBUCxJQUFzQkEsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUF4RCxDQUFELEdBQStELENBQXRFO0FBQ0E5akIsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsSUFBc0JBLEVBQUUsQ0FBRixNQUFTLENBQVYsR0FBZ0I4akIsR0FBRyxDQUFILE1BQVUsQ0FBMUIsR0FBK0IsQ0FBL0IsR0FBbUMsQ0FBeEQsQ0FBRCxHQUErRCxDQUF0RTtBQUNBOWpCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQTlqQixNQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8sVUFBUCxJQUFzQkEsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUF4RCxDQUFELEdBQStELENBQXRFO0FBQ0E5akIsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsSUFBc0JBLEVBQUUsQ0FBRixNQUFTLENBQVYsR0FBZ0I4akIsR0FBRyxDQUFILE1BQVUsQ0FBMUIsR0FBK0IsQ0FBL0IsR0FBbUMsQ0FBeEQsQ0FBRCxHQUErRCxDQUF0RTtBQUNBOWpCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQSxTQUFLTSxFQUFMLEdBQVdwa0IsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUE3Qzs7QUFFQTtBQUNBLFNBQUssSUFBSS9oQixJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCLFNBQUk4aUIsS0FBS1osRUFBRWxpQixDQUFGLElBQU8vQixFQUFFK0IsQ0FBRixDQUFoQjs7QUFFQTtBQUNBLFNBQUkraUIsS0FBS0QsS0FBSyxNQUFkO0FBQ0EsU0FBSUUsS0FBS0YsT0FBTyxFQUFoQjs7QUFFQTtBQUNBLFNBQUl2VCxLQUFLLENBQUUsQ0FBRXdULEtBQUtBLEVBQU4sS0FBYyxFQUFmLElBQXFCQSxLQUFLQyxFQUEzQixLQUFtQyxFQUFwQyxJQUEwQ0EsS0FBS0EsRUFBeEQ7QUFDQSxTQUFJeFQsS0FBSyxDQUFFLENBQUNzVCxLQUFLLFVBQU4sSUFBb0JBLEVBQXJCLEdBQTJCLENBQTVCLEtBQW1DLENBQUNBLEtBQUssVUFBTixJQUFvQkEsRUFBckIsR0FBMkIsQ0FBN0QsQ0FBVDs7QUFFQTtBQUNBZCxPQUFFaGlCLENBQUYsSUFBT3VQLEtBQUtDLEVBQVo7QUFDSDs7QUFFRDtBQUNBMFMsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDSDs7QUFFRDs7Ozs7Ozs7QUFRQS9qQixLQUFFZ2tCLE1BQUYsR0FBV2xKLGFBQWF6VSxhQUFiLENBQTJCMmQsTUFBM0IsQ0FBWDtBQUNILEdBM0tBLEdBQUQ7O0FBOEtBLFNBQU96a0IsU0FBU3lrQixNQUFoQjtBQUVBLEVBL0xDLENBQUQsQzs7Ozs7Ozs7OztBQ0FELEVBQUUsV0FBVWhsQixJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDakMsTUFBSSxnQ0FBT0MsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUNoQztBQUNBQyxVQUFPRCxPQUFQLEdBQWlCQSxVQUFVRixRQUFRLG1CQUFBSSxDQUFRLEVBQVIsQ0FBUixFQUEyQixtQkFBQUEsQ0FBUSxFQUFSLENBQTNCLEVBQW9ELG1CQUFBQSxDQUFRLEVBQVIsQ0FBcEQsRUFBc0UsbUJBQUFBLENBQVEsRUFBUixDQUF0RSxFQUEyRixtQkFBQUEsQ0FBUSxFQUFSLENBQTNGLENBQTNCO0FBQ0EsR0FIRCxNQUlLLElBQUksSUFBSixFQUFnRDtBQUNwRDtBQUNBQyxHQUFBLGlDQUFPLENBQUMsdUJBQUQsRUFBVyx1QkFBWCxFQUEyQix1QkFBM0IsRUFBb0MsdUJBQXBDLEVBQWdELHVCQUFoRCxDQUFQLG9DQUF5RUwsT0FBekU7QUFDQSxHQUhJLE1BSUE7QUFDSjtBQUNBQSxXQUFRRCxLQUFLTyxRQUFiO0FBQ0E7QUFDRCxFQWJDLGFBYU0sVUFBVUEsUUFBVixFQUFvQjs7QUFFMUIsZUFBWTtBQUNUO0FBQ0EsT0FBSVMsSUFBSVQsUUFBUjtBQUNBLE9BQUlVLFFBQVFELEVBQUVFLEdBQWQ7QUFDQSxPQUFJNGEsZUFBZTdhLE1BQU02YSxZQUF6QjtBQUNBLE9BQUlwVSxTQUFTMUcsRUFBRTRHLElBQWY7O0FBRUE7QUFDQSxPQUFJd2MsSUFBSyxFQUFUO0FBQ0EsT0FBSVUsS0FBSyxFQUFUO0FBQ0EsT0FBSUMsSUFBSyxFQUFUOztBQUVBOzs7Ozs7O0FBT0EsT0FBSWlCLGVBQWV0ZSxPQUFPc2UsWUFBUCxHQUFzQmxLLGFBQWExYSxNQUFiLENBQW9CO0FBQ3pEMkYsY0FBVSxvQkFBWTtBQUNsQjtBQUNBLFNBQUl5SCxJQUFJLEtBQUswTSxJQUFMLENBQVVoWixLQUFsQjtBQUNBLFNBQUlpYSxLQUFLLEtBQUtyVixHQUFMLENBQVNxVixFQUFsQjs7QUFFQTtBQUNBLFNBQUk4SSxJQUFJLEtBQUtDLEVBQUwsR0FBVSxDQUNkMVcsRUFBRSxDQUFGLENBRGMsRUFDUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFEakIsRUFFZEEsRUFBRSxDQUFGLENBRmMsRUFFUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFGakIsRUFHZEEsRUFBRSxDQUFGLENBSGMsRUFHUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFIakIsRUFJZEEsRUFBRSxDQUFGLENBSmMsRUFJUEEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFKakIsQ0FBbEI7O0FBT0E7QUFDQSxTQUFJeE4sSUFBSSxLQUFLbWtCLEVBQUwsR0FBVSxDQUNiM1csRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFEWCxFQUNpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFEOUMsRUFFYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFGWCxFQUVpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFGOUMsRUFHYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFIWCxFQUdpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFIOUMsRUFJYkEsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFKWCxFQUlpQkEsRUFBRSxDQUFGLElBQU8sVUFBUixHQUF1QkEsRUFBRSxDQUFGLElBQU8sVUFKOUMsQ0FBbEI7O0FBT0E7QUFDQSxVQUFLNFcsRUFBTCxHQUFVLENBQVY7O0FBRUE7QUFDQSxVQUFLLElBQUlyaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QnNpQixnQkFBVW5pQixJQUFWLENBQWUsSUFBZjtBQUNIOztBQUVEO0FBQ0EsVUFBSyxJQUFJSCxJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCL0IsUUFBRStCLENBQUYsS0FBUWtpQixFQUFHbGlCLElBQUksQ0FBTCxHQUFVLENBQVosQ0FBUjtBQUNIOztBQUVEO0FBQ0EsU0FBSW9aLEVBQUosRUFBUTtBQUNKO0FBQ0EsVUFBSW1KLEtBQUtuSixHQUFHamEsS0FBWjtBQUNBLFVBQUlxakIsT0FBT0QsR0FBRyxDQUFILENBQVg7QUFDQSxVQUFJRSxPQUFPRixHQUFHLENBQUgsQ0FBWDs7QUFFQTtBQUNBLFVBQUlHLEtBQU0sQ0FBRUYsUUFBUSxDQUFULEdBQWVBLFNBQVMsRUFBekIsSUFBZ0MsVUFBakMsR0FBZ0QsQ0FBRUEsUUFBUSxFQUFULEdBQWdCQSxTQUFTLENBQTFCLElBQWdDLFVBQXpGO0FBQ0EsVUFBSUcsS0FBTSxDQUFFRixRQUFRLENBQVQsR0FBZUEsU0FBUyxFQUF6QixJQUFnQyxVQUFqQyxHQUFnRCxDQUFFQSxRQUFRLEVBQVQsR0FBZ0JBLFNBQVMsQ0FBMUIsSUFBZ0MsVUFBekY7QUFDQSxVQUFJRyxLQUFNRixPQUFPLEVBQVIsR0FBZUMsS0FBSyxVQUE3QjtBQUNBLFVBQUlFLEtBQU1GLE1BQU0sRUFBUCxHQUFlRCxLQUFLLFVBQTdCOztBQUVBO0FBQ0F6a0IsUUFBRSxDQUFGLEtBQVF5a0IsRUFBUjtBQUNBemtCLFFBQUUsQ0FBRixLQUFRMmtCLEVBQVI7QUFDQTNrQixRQUFFLENBQUYsS0FBUTBrQixFQUFSO0FBQ0Exa0IsUUFBRSxDQUFGLEtBQVE0a0IsRUFBUjtBQUNBNWtCLFFBQUUsQ0FBRixLQUFReWtCLEVBQVI7QUFDQXprQixRQUFFLENBQUYsS0FBUTJrQixFQUFSO0FBQ0Eza0IsUUFBRSxDQUFGLEtBQVEwa0IsRUFBUjtBQUNBMWtCLFFBQUUsQ0FBRixLQUFRNGtCLEVBQVI7O0FBRUE7QUFDQSxXQUFLLElBQUk3aUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QnNpQixpQkFBVW5pQixJQUFWLENBQWUsSUFBZjtBQUNIO0FBQ0o7QUFDSixLQS9Ed0Q7O0FBaUV6RHdELHFCQUFpQix5QkFBVW9GLENBQVYsRUFBYXJGLE1BQWIsRUFBcUI7QUFDbEM7QUFDQSxTQUFJd2UsSUFBSSxLQUFLQyxFQUFiOztBQUVBO0FBQ0FHLGVBQVVuaUIsSUFBVixDQUFlLElBQWY7O0FBRUE7QUFDQWtoQixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2QztBQUNBYixPQUFFLENBQUYsSUFBT2EsRUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixNQUFTLEVBQWpCLEdBQXdCQSxFQUFFLENBQUYsS0FBUSxFQUF2Qzs7QUFFQSxVQUFLLElBQUlsaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QjtBQUNBcWhCLFFBQUVyaEIsQ0FBRixJQUFRLENBQUVxaEIsRUFBRXJoQixDQUFGLEtBQVEsQ0FBVCxHQUFnQnFoQixFQUFFcmhCLENBQUYsTUFBUyxFQUExQixJQUFpQyxVQUFsQyxHQUNDLENBQUVxaEIsRUFBRXJoQixDQUFGLEtBQVEsRUFBVCxHQUFnQnFoQixFQUFFcmhCLENBQUYsTUFBUyxDQUExQixJQUFpQyxVQUR6Qzs7QUFHQTtBQUNBK0ksUUFBRXJGLFNBQVMxRCxDQUFYLEtBQWlCcWhCLEVBQUVyaEIsQ0FBRixDQUFqQjtBQUNIO0FBQ0osS0F0RndEOztBQXdGekRrRCxlQUFXLE1BQUksRUF4RjBDOztBQTBGekRxVixZQUFRLEtBQUc7QUExRjhDLElBQXBCLENBQXpDOztBQTZGQSxZQUFTK0osU0FBVCxHQUFxQjtBQUNqQjtBQUNBLFFBQUlKLElBQUksS0FBS0MsRUFBYjtBQUNBLFFBQUlsa0IsSUFBSSxLQUFLbWtCLEVBQWI7O0FBRUE7QUFDQSxTQUFLLElBQUlwaUIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLENBQXBCLEVBQXVCQSxHQUF2QixFQUE0QjtBQUN4QitoQixRQUFHL2hCLENBQUgsSUFBUS9CLEVBQUUrQixDQUFGLENBQVI7QUFDSDs7QUFFRDtBQUNBL0IsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsR0FBb0IsS0FBS29rQixFQUExQixHQUFnQyxDQUF2QztBQUNBcGtCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQTlqQixNQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8sVUFBUCxJQUFzQkEsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUF4RCxDQUFELEdBQStELENBQXRFO0FBQ0E5akIsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsSUFBc0JBLEVBQUUsQ0FBRixNQUFTLENBQVYsR0FBZ0I4akIsR0FBRyxDQUFILE1BQVUsQ0FBMUIsR0FBK0IsQ0FBL0IsR0FBbUMsQ0FBeEQsQ0FBRCxHQUErRCxDQUF0RTtBQUNBOWpCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQTlqQixNQUFFLENBQUYsSUFBUUEsRUFBRSxDQUFGLElBQU8sVUFBUCxJQUFzQkEsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUF4RCxDQUFELEdBQStELENBQXRFO0FBQ0E5akIsTUFBRSxDQUFGLElBQVFBLEVBQUUsQ0FBRixJQUFPLFVBQVAsSUFBc0JBLEVBQUUsQ0FBRixNQUFTLENBQVYsR0FBZ0I4akIsR0FBRyxDQUFILE1BQVUsQ0FBMUIsR0FBK0IsQ0FBL0IsR0FBbUMsQ0FBeEQsQ0FBRCxHQUErRCxDQUF0RTtBQUNBOWpCLE1BQUUsQ0FBRixJQUFRQSxFQUFFLENBQUYsSUFBTyxVQUFQLElBQXNCQSxFQUFFLENBQUYsTUFBUyxDQUFWLEdBQWdCOGpCLEdBQUcsQ0FBSCxNQUFVLENBQTFCLEdBQStCLENBQS9CLEdBQW1DLENBQXhELENBQUQsR0FBK0QsQ0FBdEU7QUFDQSxTQUFLTSxFQUFMLEdBQVdwa0IsRUFBRSxDQUFGLE1BQVMsQ0FBVixHQUFnQjhqQixHQUFHLENBQUgsTUFBVSxDQUExQixHQUErQixDQUEvQixHQUFtQyxDQUE3Qzs7QUFFQTtBQUNBLFNBQUssSUFBSS9oQixJQUFJLENBQWIsRUFBZ0JBLElBQUksQ0FBcEIsRUFBdUJBLEdBQXZCLEVBQTRCO0FBQ3hCLFNBQUk4aUIsS0FBS1osRUFBRWxpQixDQUFGLElBQU8vQixFQUFFK0IsQ0FBRixDQUFoQjs7QUFFQTtBQUNBLFNBQUkraUIsS0FBS0QsS0FBSyxNQUFkO0FBQ0EsU0FBSUUsS0FBS0YsT0FBTyxFQUFoQjs7QUFFQTtBQUNBLFNBQUl2VCxLQUFLLENBQUUsQ0FBRXdULEtBQUtBLEVBQU4sS0FBYyxFQUFmLElBQXFCQSxLQUFLQyxFQUEzQixLQUFtQyxFQUFwQyxJQUEwQ0EsS0FBS0EsRUFBeEQ7QUFDQSxTQUFJeFQsS0FBSyxDQUFFLENBQUNzVCxLQUFLLFVBQU4sSUFBb0JBLEVBQXJCLEdBQTJCLENBQTVCLEtBQW1DLENBQUNBLEtBQUssVUFBTixJQUFvQkEsRUFBckIsR0FBMkIsQ0FBN0QsQ0FBVDs7QUFFQTtBQUNBZCxPQUFFaGlCLENBQUYsSUFBT3VQLEtBQUtDLEVBQVo7QUFDSDs7QUFFRDtBQUNBMFMsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDQUUsTUFBRSxDQUFGLElBQVFGLEVBQUUsQ0FBRixLQUFTQSxFQUFFLENBQUYsS0FBUSxFQUFULEdBQWdCQSxFQUFFLENBQUYsTUFBUyxFQUFqQyxLQUEwQ0EsRUFBRSxDQUFGLEtBQVEsRUFBVCxHQUFnQkEsRUFBRSxDQUFGLE1BQVMsRUFBbEUsQ0FBRCxHQUEyRSxDQUFsRjtBQUNBRSxNQUFFLENBQUYsSUFBUUYsRUFBRSxDQUFGLEtBQVNBLEVBQUUsQ0FBRixLQUFRLENBQVQsR0FBZ0JBLEVBQUUsQ0FBRixNQUFTLEVBQWpDLElBQXdDQSxFQUFFLENBQUYsQ0FBekMsR0FBaUQsQ0FBeEQ7QUFDSDs7QUFFRDs7Ozs7Ozs7QUFRQS9qQixLQUFFZ2xCLFlBQUYsR0FBaUJsSyxhQUFhelUsYUFBYixDQUEyQjJlLFlBQTNCLENBQWpCO0FBQ0gsR0F6S0EsR0FBRDs7QUE0S0EsU0FBT3psQixTQUFTeWxCLFlBQWhCO0FBRUEsRUE3TEMsQ0FBRCxDIiwiZmlsZSI6ImJ1aWxkL0hlbGxvL2hvbWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSlcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcblxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0ZXhwb3J0czoge30sXG4gXHRcdFx0aWQ6IG1vZHVsZUlkLFxuIFx0XHRcdGxvYWRlZDogZmFsc2VcbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubG9hZGVkID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXygwKTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyB3ZWJwYWNrL2Jvb3RzdHJhcCAyMWM4NjNkNjc4MjczNmVjMzVjOCIsInZhciAkbWlhcHBfdGVtcGxhdGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtdGVtcGxhdGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9dGVtcGxhdGVzIS4vaG9tZS5taXhcIilcbnZhciAkbWlhcHBfc3R5bGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc3R5bGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9c3R5bGVzJnJlc291cmNlUGF0aD0vaG9tZS91bmlxdWUvWlpaL3NyYy9IZWxsby9ob21lLm1peCEuL2hvbWUubWl4XCIpXG52YXIgJG1pYXBwX3NjcmlwdCQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1zY3JpcHQtbG9hZGVyLmpzIWJhYmVsLWxvYWRlcj9wcmVzZXRzW109L2hvbWUvdW5pcXVlL1paWi9ub2RlX21vZHVsZXMvYmFiZWwtcHJlc2V0LWVzMjAxNSZwcmVzZXRzPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcGx1Z2luc1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZwbHVnaW5zPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZjb21tZW50cz1mYWxzZSEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXNjcmlwdHMhLi9ob21lLm1peFwiKVxuXG4kbWlhcHBfZGVmaW5lJCgnQG1pYXBwLWNvbXBvbmVudC9ob21lJywgXG4gICAgICAgICAgICAgICAgW10sIGZ1bmN0aW9uKCRtaWFwcF9yZXF1aXJlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfbW9kdWxlJCl7XG4gICAgICRtaWFwcF9zY3JpcHQkKCRtaWFwcF9tb2R1bGUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9yZXF1aXJlJClcbiAgICAgaWYgKCRtaWFwcF9leHBvcnRzJC5fX2VzTW9kdWxlICYmICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0KSB7XG4gICAgICAgICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzID0gJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHRcbiAgICAgICAgfVxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnRlbXBsYXRlID0gJG1pYXBwX3RlbXBsYXRlJFxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnN0eWxlID0gJG1pYXBwX3N0eWxlJFxufSlcblxuJG1pYXBwX2Jvb3RzdHJhcCQoJ0BtaWFwcC1jb21wb25lbnQvaG9tZScseyBwYWNrYWdlclZlcnNpb246ICcwLjAuMyd9KVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vc3JjL0hlbGxvL2hvbWUubWl4XG4vLyBtb2R1bGUgaWQgPSAwXG4vLyBtb2R1bGUgY2h1bmtzID0gMSIsIm1vZHVsZS5leHBvcnRzID0ge1xuICBcInR5cGVcIjogXCJkaXZcIixcbiAgXCJhdHRyXCI6IHt9LFxuICBcImNsYXNzTGlzdFwiOiBbXG4gICAgXCJjb250YWluZXJcIlxuICBdLFxuICBcImNoaWxkcmVuXCI6IFtcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJyaWNodGV4dFwiLFxuICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgXCJ0eXBlXCI6IFwibWl4XCIsXG4gICAgICAgIFwidmFsdWVcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLm1peH1cbiAgICAgIH1cbiAgICB9XG4gIF1cbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC10ZW1wbGF0ZS1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT10ZW1wbGF0ZXMhLi9zcmMvSGVsbG8vaG9tZS5taXhcbi8vIG1vZHVsZSBpZCA9IDExXG4vLyBtb2R1bGUgY2h1bmtzID0gMSIsIm1vZHVsZS5leHBvcnRzID0ge1xuICBcIi5jb250YWluZXJcIjoge1xuICAgIFwiZmxleFwiOiAxLFxuICAgIFwiZmxleERpcmVjdGlvblwiOiBcImNvbHVtblwiXG4gIH0sXG4gIFwiLmFydGljYWwtY29udGVudFwiOiB7XG4gICAgXCJwYWRkaW5nTGVmdFwiOiBcIjEycHhcIixcbiAgICBcInBhZGRpbmdSaWdodFwiOiBcIjEycHhcIixcbiAgICBcImZvbnRTaXplXCI6IFwiMTVweFwiLFxuICAgIFwibGluZUhlaWdodFwiOiBcIjI1cHhcIixcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJjb2x1bW5cIlxuICB9LFxuICBcInRleHRcIjoge1xuICAgIFwicGFkZGluZ1RvcFwiOiBcIjhweFwiLFxuICAgIFwicGFkZGluZ0JvdHRvbVwiOiBcIjhweFwiXG4gIH0sXG4gIFwiYVwiOiB7XG4gICAgXCJjb2xvclwiOiBcIiMwMjVmYWRcIlxuICB9LFxuICBcIi5jb250ZW50LXF1b3RlXCI6IHtcbiAgICBcImJvcmRlckxlZnRDb2xvclwiOiBcIiNDMDFFMkZcIixcbiAgICBcImJvcmRlclN0eWxlXCI6IFwic29saWRcIixcbiAgICBcImJvcmRlckxlZnRXaWR0aFwiOiBcIjFweFwiLFxuICAgIFwicGFkZGluZ0xlZnRcIjogXCIxMHB4XCIsXG4gICAgXCJtYXJnaW5Cb3R0b21cIjogXCIyNXB4XCJcbiAgfSxcbiAgXCIuaXRlbS1jb250YWluZXJcIjoge1xuICAgIFwiZmxleERpcmVjdGlvblwiOiBcImNvbHVtblwiXG4gIH1cbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1zdHlsZS1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zdHlsZXMmcmVzb3VyY2VQYXRoPS9ob21lL3VuaXF1ZS9aWlovc3JjL0hlbGxvL2hvbWUubWl4IS4vc3JjL0hlbGxvL2hvbWUubWl4XG4vLyBtb2R1bGUgaWQgPSAxMlxuLy8gbW9kdWxlIGNodW5rcyA9IDEiLCI8dGVtcGxhdGU+XG4gICAgPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICAgICAgPHJpY2h0ZXh0IHR5cGU9XCJtaXhcIj57e21peH19PC9yaWNodGV4dD5cbiAgICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzdHlsZT5cbiAgIC5jb250YWluZXIge1xuICAgICAgIGZsZXg6MTtcbiAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgfVxuICAgLmFydGljYWwtY29udGVudCB7XG4gICAgICAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICAgICAgIHBhZGRpbmctcmlnaHQ6IDEycHg7XG4gICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICB9XG4gICB0ZXh0IHtcbiAgICAgICBwYWRkaW5nLXRvcDogOHB4O1xuICAgICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XG4gICB9XG4gICBhIHtcbiAgICAgICBjb2xvcjogIzAyNWZhZDtcbiAgIH1cbiAgIC5jb250ZW50LXF1b3RlIHtcbiAgICAgICBib3JkZXItbGVmdC1jb2xvcjogI0MwMUUyRjtcbiAgICAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICAgICAgIGJvcmRlci1sZWZ0LXdpZHRoOiAxcHg7XG4gICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XG4gICB9XG4gICAgLml0ZW0tY29udGFpbmVyIHtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICB9XG48L3N0eWxlPlxuXG48c2NyaXB0PlxuICB2YXIgQ3J5cHRvSlMgPSByZXF1aXJlKFwiY3J5cHRvLWpzXCIpO1xuXG4gIG1vZHVsZS5leHBvcnRzID0ge1xuICAgIGRhdGE6IHtcbiAgICAgIHNob3c6IHRydWUsXG4gICAgICBodG1sOiAnPHAgY2xhc3M9XCJhXCIgc3R5bGU9XCJmb250LXNpemU6IDE2cHg7Y29sb3I6I0ZGMDAwMDtcIj4gICAg5Y6f5qCH6aKY77ya5p2t5bee6L+b5LiA5q2l5Y2H57qn5oi/5Zyw5Lqn5biC5Zy66LCD5o6n5o6q5pa9IOiupOaIv+WPiOiupOi0tzwvcD48cCBzdHlsZT1cImZvbnQtc2l6ZTogMTZweDtcIj4gICAg5p2t5bee5biC5L2P5oi/5L+d6Zqc5ZKM5oi/5Lqn566h55CG5bGAMjjml6Xlj5HluIPpgJrnn6Xnp7DvvIzoh6oyMDE35bm0M+aciDI55pel6LW377yM6L+b5LiA5q2l5a6M5ZaE5L2P5oi/6ZmQ6LSt5Y+K6ZSA5ZSu55uR566h5o6q5pa944CC5YW25Lit5YyF5ous77yM5pys5biC5oi357GN5oiQ5bm05Y2V6LqrKOWQq+emu+W8ginkurrlo6vlnKjpmZDotK3ljLrln5/lhoXpmZDotK0x5aWX5L2P5oi/77yb5Zyo5biC5Yy66IyD5Zu05YaF77yM6IGM5bel5a625bqt5ZCN5LiL5bey5oul5pyJ5LiA5aWX5L2P5oi/5oiW5peg5L2P5oi/5L2G5pyJ5L2P5oi/6LS35qy+6K6w5b2V55qE77yM6LSt5Lmw5pmu6YCa6Ieq5L2P5L2P5oi/5omn6KGM5LqM5aWX5L2P5oi/5YWs56ev6YeR6LS35qy+5pS/562W77yM6LS35qy+6aaW5LuY5qy+5q+U5L6L5LiN5L2O5LqONjAl77yM5YWs56ev6YeR6LS35qy+5Yip546H5oyJ5ZCM5pyf5L2P5oi/5YWs56ev6YeR6LS35qy+5Z+65YeG5Yip546HMS4x5YCN5omn6KGM4oCm4oCmPC9wPjxpbWcgc3JjPVwiaHR0cDovL2hpbWcyLmh1YW5xaXUuY29tL2F0dGFjaG1lbnQyMDEwLzIwMTcvMDMyOS8yMDE3MDMyOTA3MTI0NDM2NC5qcGdcIj48aW1nIHNyYz1cImh0dHA6Ly9oaW1nMi5odWFucWl1LmNvbS9hdHRhY2htZW50MjAxMC8yMDE3LzAzMjkvMjAxNzAzMjkwNzEyNDU5NTcuanBnXCI+JyxcbiAgICAgIG1peDogJzxkaXYgY2xhc3M9XCJpdGVtLWNvbnRhaW5lclwiPjx0ZXh0IHN0eWxlPVwiYmFja2dyb3VuZC1jb2xvcjogcmVkO1wiPnRleHQ8L3RleHQ+PHRleHQ+PHNwYW4+c3Bhbjwvc3Bhbj48L3RleHQ+PC9kaXY+4oCLJ1xuICAgIH0sXG4gICAgb25SZWFkeTogZnVuY3Rpb24oKSB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5odG1sID0gJzxhcnRpY2xlIGNsYXNzPVwiYXJ0aWNhbC1jb250ZW50XCIgc3R5bGU9XCJmb250LXNpemU6IDE4cHg7XCI+PGRpdiBjbGFzcz1cImFydGljYWwtbWFpbi1waWNcIj48aW1nIHNyYz1cImh0dHA6Ly9pMTAuaG9vcGNoaW5hLmNvbS5jbi9odXB1YXBwL2thbnFpdS8yMDE3MDIva2FucWl1XzBfMjAxNzAyMTYxNzA3MjBfNzAxMDcwODIwLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzYwMC9mb3JtYXQsanBnL3F1YWxpdHksUV82MFwiPjwvZGl2PjxwPui1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS3otZ7otY/mlrDpl7vmtYvor5Ut6LWe6LWP5paw6Ze75rWL6K+VLei1nui1j+aWsOmXu+a1i+ivlS08L3A+PHA+PGJyPjwvcD48cCBjbGFzcz1cImNvbnRlbnQtcXVvdGVcIj5cIue7iOS6juWBmuS6hlxi57uI5LqOXGLnu4jkuo7lgZrkuoZcYue7iOS6jue7iOS6juWBmuS6hlxi57uI5LqO57uI5LqO5YGa5LqGXGIg57uI5LqObGFsbGFsYWxsYWxhYWFhYWFsbGxhbGFhbGxhbGFsbGFsYWFhYWFhbGxsYWxhbGxsYWxsYWxhbGxhbGFhYWFhYWxsbGFsYWxsbGFsbGFsYWxsYWxhYWFhYWFsbGxhbGFsbGxhbGxhbGFsbGFsYWFhYWFhbGxsYWxhbGxsbGxsbGxsbGxsbGxsbGxsbGxsbGxzamRmbHNkZmxkc2ZcIjwvcD48L2FydGljbGU+J1xuICAgICAgICB0aGlzLiRwYWdlLnNldFRpdGxlQmFyKHt0ZXh0OlwiQUJDXCIsIGJhY2tncm91bmRDb2xvcjpcIiMwMEZGMDBcIix0ZXh0Q29sb3I6XCIjMDBGRkZGXCJ9KVxuICAgICAgfSw1MDAwKVxuXG4gICAgfSxcbiAgICBvbkJhY2tQcmVzczogZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSxcbiAgICBjbGljazogZnVuY3Rpb24gKCkge1xuICAgICAgdGhpcy5rZXl3b3JkID0gJydcbiAgICB9XG4gIH1cbjwvc2NyaXB0PlxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9IZWxsby9ob21lLm1peD85Y2Y5NTNiNiIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi94NjQtY29yZVwiKSwgcmVxdWlyZShcIi4vbGliLXR5cGVkYXJyYXlzXCIpLCByZXF1aXJlKFwiLi9lbmMtdXRmMTZcIiksIHJlcXVpcmUoXCIuL2VuYy1iYXNlNjRcIiksIHJlcXVpcmUoXCIuL21kNVwiKSwgcmVxdWlyZShcIi4vc2hhMVwiKSwgcmVxdWlyZShcIi4vc2hhMjU2XCIpLCByZXF1aXJlKFwiLi9zaGEyMjRcIiksIHJlcXVpcmUoXCIuL3NoYTUxMlwiKSwgcmVxdWlyZShcIi4vc2hhMzg0XCIpLCByZXF1aXJlKFwiLi9zaGEzXCIpLCByZXF1aXJlKFwiLi9yaXBlbWQxNjBcIiksIHJlcXVpcmUoXCIuL2htYWNcIiksIHJlcXVpcmUoXCIuL3Bia2RmMlwiKSwgcmVxdWlyZShcIi4vZXZwa2RmXCIpLCByZXF1aXJlKFwiLi9jaXBoZXItY29yZVwiKSwgcmVxdWlyZShcIi4vbW9kZS1jZmJcIiksIHJlcXVpcmUoXCIuL21vZGUtY3RyXCIpLCByZXF1aXJlKFwiLi9tb2RlLWN0ci1nbGFkbWFuXCIpLCByZXF1aXJlKFwiLi9tb2RlLW9mYlwiKSwgcmVxdWlyZShcIi4vbW9kZS1lY2JcIiksIHJlcXVpcmUoXCIuL3BhZC1hbnNpeDkyM1wiKSwgcmVxdWlyZShcIi4vcGFkLWlzbzEwMTI2XCIpLCByZXF1aXJlKFwiLi9wYWQtaXNvOTc5NzFcIiksIHJlcXVpcmUoXCIuL3BhZC16ZXJvcGFkZGluZ1wiKSwgcmVxdWlyZShcIi4vcGFkLW5vcGFkZGluZ1wiKSwgcmVxdWlyZShcIi4vZm9ybWF0LWhleFwiKSwgcmVxdWlyZShcIi4vYWVzXCIpLCByZXF1aXJlKFwiLi90cmlwbGVkZXNcIiksIHJlcXVpcmUoXCIuL3JjNFwiKSwgcmVxdWlyZShcIi4vcmFiYml0XCIpLCByZXF1aXJlKFwiLi9yYWJiaXQtbGVnYWN5XCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL3g2NC1jb3JlXCIsIFwiLi9saWItdHlwZWRhcnJheXNcIiwgXCIuL2VuYy11dGYxNlwiLCBcIi4vZW5jLWJhc2U2NFwiLCBcIi4vbWQ1XCIsIFwiLi9zaGExXCIsIFwiLi9zaGEyNTZcIiwgXCIuL3NoYTIyNFwiLCBcIi4vc2hhNTEyXCIsIFwiLi9zaGEzODRcIiwgXCIuL3NoYTNcIiwgXCIuL3JpcGVtZDE2MFwiLCBcIi4vaG1hY1wiLCBcIi4vcGJrZGYyXCIsIFwiLi9ldnBrZGZcIiwgXCIuL2NpcGhlci1jb3JlXCIsIFwiLi9tb2RlLWNmYlwiLCBcIi4vbW9kZS1jdHJcIiwgXCIuL21vZGUtY3RyLWdsYWRtYW5cIiwgXCIuL21vZGUtb2ZiXCIsIFwiLi9tb2RlLWVjYlwiLCBcIi4vcGFkLWFuc2l4OTIzXCIsIFwiLi9wYWQtaXNvMTAxMjZcIiwgXCIuL3BhZC1pc285Nzk3MVwiLCBcIi4vcGFkLXplcm9wYWRkaW5nXCIsIFwiLi9wYWQtbm9wYWRkaW5nXCIsIFwiLi9mb3JtYXQtaGV4XCIsIFwiLi9hZXNcIiwgXCIuL3RyaXBsZWRlc1wiLCBcIi4vcmM0XCIsIFwiLi9yYWJiaXRcIiwgXCIuL3JhYmJpdC1sZWdhY3lcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRyb290LkNyeXB0b0pTID0gZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHRyZXR1cm4gQ3J5cHRvSlM7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9pbmRleC5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnkpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KCk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW10sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRyb290LkNyeXB0b0pTID0gZmFjdG9yeSgpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uICgpIHtcblxuXHQvKipcblx0ICogQ3J5cHRvSlMgY29yZSBjb21wb25lbnRzLlxuXHQgKi9cblx0dmFyIENyeXB0b0pTID0gQ3J5cHRvSlMgfHwgKGZ1bmN0aW9uIChNYXRoLCB1bmRlZmluZWQpIHtcblx0ICAgIC8qXG5cdCAgICAgKiBMb2NhbCBwb2x5ZmlsIG9mIE9iamVjdC5jcmVhdGVcblx0ICAgICAqL1xuXHQgICAgdmFyIGNyZWF0ZSA9IE9iamVjdC5jcmVhdGUgfHwgKGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICBmdW5jdGlvbiBGKCkge307XG5cblx0ICAgICAgICByZXR1cm4gZnVuY3Rpb24gKG9iaikge1xuXHQgICAgICAgICAgICB2YXIgc3VidHlwZTtcblxuXHQgICAgICAgICAgICBGLnByb3RvdHlwZSA9IG9iajtcblxuXHQgICAgICAgICAgICBzdWJ0eXBlID0gbmV3IEYoKTtcblxuXHQgICAgICAgICAgICBGLnByb3RvdHlwZSA9IG51bGw7XG5cblx0ICAgICAgICAgICAgcmV0dXJuIHN1YnR5cGU7XG5cdCAgICAgICAgfTtcblx0ICAgIH0oKSlcblxuXHQgICAgLyoqXG5cdCAgICAgKiBDcnlwdG9KUyBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogTGlicmFyeSBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDX2xpYiA9IEMubGliID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogQmFzZSBvYmplY3QgZm9yIHByb3RvdHlwYWwgaW5oZXJpdGFuY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBCYXNlID0gQ19saWIuQmFzZSA9IChmdW5jdGlvbiAoKSB7XG5cblxuXHQgICAgICAgIHJldHVybiB7XG5cdCAgICAgICAgICAgIC8qKlxuXHQgICAgICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IG9iamVjdCB0aGF0IGluaGVyaXRzIGZyb20gdGhpcyBvYmplY3QuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvdmVycmlkZXMgUHJvcGVydGllcyB0byBjb3B5IGludG8gdGhlIG5ldyBvYmplY3QuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEByZXR1cm4ge09iamVjdH0gVGhlIG5ldyBvYmplY3QuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgICAgICpcblx0ICAgICAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgICAgICpcblx0ICAgICAgICAgICAgICogICAgIHZhciBNeVR5cGUgPSBDcnlwdG9KUy5saWIuQmFzZS5leHRlbmQoe1xuXHQgICAgICAgICAgICAgKiAgICAgICAgIGZpZWxkOiAndmFsdWUnLFxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiAgICAgICAgIG1ldGhvZDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAgKiAgICAgICAgIH1cblx0ICAgICAgICAgICAgICogICAgIH0pO1xuXHQgICAgICAgICAgICAgKi9cblx0ICAgICAgICAgICAgZXh0ZW5kOiBmdW5jdGlvbiAob3ZlcnJpZGVzKSB7XG5cdCAgICAgICAgICAgICAgICAvLyBTcGF3blxuXHQgICAgICAgICAgICAgICAgdmFyIHN1YnR5cGUgPSBjcmVhdGUodGhpcyk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIEF1Z21lbnRcblx0ICAgICAgICAgICAgICAgIGlmIChvdmVycmlkZXMpIHtcblx0ICAgICAgICAgICAgICAgICAgICBzdWJ0eXBlLm1peEluKG92ZXJyaWRlcyk7XG5cdCAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBkZWZhdWx0IGluaXRpYWxpemVyXG5cdCAgICAgICAgICAgICAgICBpZiAoIXN1YnR5cGUuaGFzT3duUHJvcGVydHkoJ2luaXQnKSB8fCB0aGlzLmluaXQgPT09IHN1YnR5cGUuaW5pdCkge1xuXHQgICAgICAgICAgICAgICAgICAgIHN1YnR5cGUuaW5pdCA9IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgc3VidHlwZS4kc3VwZXIuaW5pdC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXHQgICAgICAgICAgICAgICAgICAgIH07XG5cdCAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgIC8vIEluaXRpYWxpemVyJ3MgcHJvdG90eXBlIGlzIHRoZSBzdWJ0eXBlIG9iamVjdFxuXHQgICAgICAgICAgICAgICAgc3VidHlwZS5pbml0LnByb3RvdHlwZSA9IHN1YnR5cGU7XG5cblx0ICAgICAgICAgICAgICAgIC8vIFJlZmVyZW5jZSBzdXBlcnR5cGVcblx0ICAgICAgICAgICAgICAgIHN1YnR5cGUuJHN1cGVyID0gdGhpcztcblxuXHQgICAgICAgICAgICAgICAgcmV0dXJuIHN1YnR5cGU7XG5cdCAgICAgICAgICAgIH0sXG5cblx0ICAgICAgICAgICAgLyoqXG5cdCAgICAgICAgICAgICAqIEV4dGVuZHMgdGhpcyBvYmplY3QgYW5kIHJ1bnMgdGhlIGluaXQgbWV0aG9kLlxuXHQgICAgICAgICAgICAgKiBBcmd1bWVudHMgdG8gY3JlYXRlKCkgd2lsbCBiZSBwYXNzZWQgdG8gaW5pdCgpLlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAcmV0dXJuIHtPYmplY3R9IFRoZSBuZXcgb2JqZWN0LlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqICAgICB2YXIgaW5zdGFuY2UgPSBNeVR5cGUuY3JlYXRlKCk7XG5cdCAgICAgICAgICAgICAqL1xuXHQgICAgICAgICAgICBjcmVhdGU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgICAgIHZhciBpbnN0YW5jZSA9IHRoaXMuZXh0ZW5kKCk7XG5cdCAgICAgICAgICAgICAgICBpbnN0YW5jZS5pbml0LmFwcGx5KGluc3RhbmNlLCBhcmd1bWVudHMpO1xuXG5cdCAgICAgICAgICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG5cdCAgICAgICAgICAgIH0sXG5cblx0ICAgICAgICAgICAgLyoqXG5cdCAgICAgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCBvYmplY3QuXG5cdCAgICAgICAgICAgICAqIE92ZXJyaWRlIHRoaXMgbWV0aG9kIHRvIGFkZCBzb21lIGxvZ2ljIHdoZW4geW91ciBvYmplY3RzIGFyZSBjcmVhdGVkLlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiAgICAgdmFyIE15VHlwZSA9IENyeXB0b0pTLmxpYi5CYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgICAgICAqICAgICAgICAgaW5pdDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAgKiAgICAgICAgICAgICAvLyAuLi5cblx0ICAgICAgICAgICAgICogICAgICAgICB9XG5cdCAgICAgICAgICAgICAqICAgICB9KTtcblx0ICAgICAgICAgICAgICovXG5cdCAgICAgICAgICAgIGluaXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgfSxcblxuXHQgICAgICAgICAgICAvKipcblx0ICAgICAgICAgICAgICogQ29waWVzIHByb3BlcnRpZXMgaW50byB0aGlzIG9iamVjdC5cblx0ICAgICAgICAgICAgICpcblx0ICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IHByb3BlcnRpZXMgVGhlIHByb3BlcnRpZXMgdG8gbWl4IGluLlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiAgICAgTXlUeXBlLm1peEluKHtcblx0ICAgICAgICAgICAgICogICAgICAgICBmaWVsZDogJ3ZhbHVlJ1xuXHQgICAgICAgICAgICAgKiAgICAgfSk7XG5cdCAgICAgICAgICAgICAqL1xuXHQgICAgICAgICAgICBtaXhJbjogZnVuY3Rpb24gKHByb3BlcnRpZXMpIHtcblx0ICAgICAgICAgICAgICAgIGZvciAodmFyIHByb3BlcnR5TmFtZSBpbiBwcm9wZXJ0aWVzKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMuaGFzT3duUHJvcGVydHkocHJvcGVydHlOYW1lKSkge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW3Byb3BlcnR5TmFtZV0gPSBwcm9wZXJ0aWVzW3Byb3BlcnR5TmFtZV07XG5cdCAgICAgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgICAgICAvLyBJRSB3b24ndCBjb3B5IHRvU3RyaW5nIHVzaW5nIHRoZSBsb29wIGFib3ZlXG5cdCAgICAgICAgICAgICAgICBpZiAocHJvcGVydGllcy5oYXNPd25Qcm9wZXJ0eSgndG9TdHJpbmcnKSkge1xuXHQgICAgICAgICAgICAgICAgICAgIHRoaXMudG9TdHJpbmcgPSBwcm9wZXJ0aWVzLnRvU3RyaW5nO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB9LFxuXG5cdCAgICAgICAgICAgIC8qKlxuXHQgICAgICAgICAgICAgKiBDcmVhdGVzIGEgY29weSBvZiB0aGlzIG9iamVjdC5cblx0ICAgICAgICAgICAgICpcblx0ICAgICAgICAgICAgICogQHJldHVybiB7T2JqZWN0fSBUaGUgY2xvbmUuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqICAgICB2YXIgY2xvbmUgPSBpbnN0YW5jZS5jbG9uZSgpO1xuXHQgICAgICAgICAgICAgKi9cblx0ICAgICAgICAgICAgY2xvbmU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmluaXQucHJvdG90eXBlLmV4dGVuZCh0aGlzKTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH07XG5cdCAgICB9KCkpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIEFuIGFycmF5IG9mIDMyLWJpdCB3b3Jkcy5cblx0ICAgICAqXG5cdCAgICAgKiBAcHJvcGVydHkge0FycmF5fSB3b3JkcyBUaGUgYXJyYXkgb2YgMzItYml0IHdvcmRzLlxuXHQgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IHNpZ0J5dGVzIFRoZSBudW1iZXIgb2Ygc2lnbmlmaWNhbnQgYnl0ZXMgaW4gdGhpcyB3b3JkIGFycmF5LlxuXHQgICAgICovXG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5ID0gQmFzZS5leHRlbmQoe1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtBcnJheX0gd29yZHMgKE9wdGlvbmFsKSBBbiBhcnJheSBvZiAzMi1iaXQgd29yZHMuXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IHNpZ0J5dGVzIChPcHRpb25hbCkgVGhlIG51bWJlciBvZiBzaWduaWZpY2FudCBieXRlcyBpbiB0aGUgd29yZHMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5saWIuV29yZEFycmF5LmNyZWF0ZSgpO1xuXHQgICAgICAgICAqICAgICB2YXIgd29yZEFycmF5ID0gQ3J5cHRvSlMubGliLldvcmRBcnJheS5jcmVhdGUoWzB4MDAwMTAyMDMsIDB4MDQwNTA2MDddKTtcblx0ICAgICAgICAgKiAgICAgdmFyIHdvcmRBcnJheSA9IENyeXB0b0pTLmxpYi5Xb3JkQXJyYXkuY3JlYXRlKFsweDAwMDEwMjAzLCAweDA0MDUwNjA3XSwgNik7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgaW5pdDogZnVuY3Rpb24gKHdvcmRzLCBzaWdCeXRlcykge1xuXHQgICAgICAgICAgICB3b3JkcyA9IHRoaXMud29yZHMgPSB3b3JkcyB8fCBbXTtcblxuXHQgICAgICAgICAgICBpZiAoc2lnQnl0ZXMgIT0gdW5kZWZpbmVkKSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLnNpZ0J5dGVzID0gc2lnQnl0ZXM7XG5cdCAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLnNpZ0J5dGVzID0gd29yZHMubGVuZ3RoICogNDtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIHdvcmQgYXJyYXkgdG8gYSBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0VuY29kZXJ9IGVuY29kZXIgKE9wdGlvbmFsKSBUaGUgZW5jb2Rpbmcgc3RyYXRlZ3kgdG8gdXNlLiBEZWZhdWx0OiBDcnlwdG9KUy5lbmMuSGV4XG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBzdHJpbmdpZmllZCB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgc3RyaW5nID0gd29yZEFycmF5ICsgJyc7XG5cdCAgICAgICAgICogICAgIHZhciBzdHJpbmcgPSB3b3JkQXJyYXkudG9TdHJpbmcoKTtcblx0ICAgICAgICAgKiAgICAgdmFyIHN0cmluZyA9IHdvcmRBcnJheS50b1N0cmluZyhDcnlwdG9KUy5lbmMuVXRmOCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgdG9TdHJpbmc6IGZ1bmN0aW9uIChlbmNvZGVyKSB7XG5cdCAgICAgICAgICAgIHJldHVybiAoZW5jb2RlciB8fCBIZXgpLnN0cmluZ2lmeSh0aGlzKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uY2F0ZW5hdGVzIGEgd29yZCBhcnJheSB0byB0aGlzIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0gd29yZEFycmF5IFRoZSB3b3JkIGFycmF5IHRvIGFwcGVuZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhpcyB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB3b3JkQXJyYXkxLmNvbmNhdCh3b3JkQXJyYXkyKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjb25jYXQ6IGZ1bmN0aW9uICh3b3JkQXJyYXkpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciB0aGlzV29yZHMgPSB0aGlzLndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgdGhhdFdvcmRzID0gd29yZEFycmF5LndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgdGhpc1NpZ0J5dGVzID0gdGhpcy5zaWdCeXRlcztcblx0ICAgICAgICAgICAgdmFyIHRoYXRTaWdCeXRlcyA9IHdvcmRBcnJheS5zaWdCeXRlcztcblxuXHQgICAgICAgICAgICAvLyBDbGFtcCBleGNlc3MgYml0c1xuXHQgICAgICAgICAgICB0aGlzLmNsYW1wKCk7XG5cblx0ICAgICAgICAgICAgLy8gQ29uY2F0XG5cdCAgICAgICAgICAgIGlmICh0aGlzU2lnQnl0ZXMgJSA0KSB7XG5cdCAgICAgICAgICAgICAgICAvLyBDb3B5IG9uZSBieXRlIGF0IGEgdGltZVxuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGF0U2lnQnl0ZXM7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciB0aGF0Qnl0ZSA9ICh0aGF0V29yZHNbaSA+Pj4gMl0gPj4+ICgyNCAtIChpICUgNCkgKiA4KSkgJiAweGZmO1xuXHQgICAgICAgICAgICAgICAgICAgIHRoaXNXb3Jkc1sodGhpc1NpZ0J5dGVzICsgaSkgPj4+IDJdIHw9IHRoYXRCeXRlIDw8ICgyNCAtICgodGhpc1NpZ0J5dGVzICsgaSkgJSA0KSAqIDgpO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgLy8gQ29weSBvbmUgd29yZCBhdCBhIHRpbWVcblx0ICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhhdFNpZ0J5dGVzOyBpICs9IDQpIHtcblx0ICAgICAgICAgICAgICAgICAgICB0aGlzV29yZHNbKHRoaXNTaWdCeXRlcyArIGkpID4+PiAyXSA9IHRoYXRXb3Jkc1tpID4+PiAyXTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB0aGlzLnNpZ0J5dGVzICs9IHRoYXRTaWdCeXRlcztcblxuXHQgICAgICAgICAgICAvLyBDaGFpbmFibGVcblx0ICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIFJlbW92ZXMgaW5zaWduaWZpY2FudCBiaXRzLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB3b3JkQXJyYXkuY2xhbXAoKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjbGFtcDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIHdvcmRzID0gdGhpcy53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIHNpZ0J5dGVzID0gdGhpcy5zaWdCeXRlcztcblxuXHQgICAgICAgICAgICAvLyBDbGFtcFxuXHQgICAgICAgICAgICB3b3Jkc1tzaWdCeXRlcyA+Pj4gMl0gJj0gMHhmZmZmZmZmZiA8PCAoMzIgLSAoc2lnQnl0ZXMgJSA0KSAqIDgpO1xuXHQgICAgICAgICAgICB3b3Jkcy5sZW5ndGggPSBNYXRoLmNlaWwoc2lnQnl0ZXMgLyA0KTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ3JlYXRlcyBhIGNvcHkgb2YgdGhpcyB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgY2xvbmUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBjbG9uZSA9IHdvcmRBcnJheS5jbG9uZSgpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGNsb25lOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHZhciBjbG9uZSA9IEJhc2UuY2xvbmUuY2FsbCh0aGlzKTtcblx0ICAgICAgICAgICAgY2xvbmUud29yZHMgPSB0aGlzLndvcmRzLnNsaWNlKDApO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBjbG9uZTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ3JlYXRlcyBhIHdvcmQgYXJyYXkgZmlsbGVkIHdpdGggcmFuZG9tIGJ5dGVzLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IG5CeXRlcyBUaGUgbnVtYmVyIG9mIHJhbmRvbSBieXRlcyB0byBnZW5lcmF0ZS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHJhbmRvbSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgd29yZEFycmF5ID0gQ3J5cHRvSlMubGliLldvcmRBcnJheS5yYW5kb20oMTYpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHJhbmRvbTogZnVuY3Rpb24gKG5CeXRlcykge1xuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSBbXTtcblxuXHQgICAgICAgICAgICB2YXIgciA9IChmdW5jdGlvbiAobV93KSB7XG5cdCAgICAgICAgICAgICAgICB2YXIgbV93ID0gbV93O1xuXHQgICAgICAgICAgICAgICAgdmFyIG1feiA9IDB4M2FkZTY4YjE7XG5cdCAgICAgICAgICAgICAgICB2YXIgbWFzayA9IDB4ZmZmZmZmZmY7XG5cblx0ICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgbV96ID0gKDB4OTA2OSAqIChtX3ogJiAweEZGRkYpICsgKG1feiA+PiAweDEwKSkgJiBtYXNrO1xuXHQgICAgICAgICAgICAgICAgICAgIG1fdyA9ICgweDQ2NTAgKiAobV93ICYgMHhGRkZGKSArIChtX3cgPj4gMHgxMCkpICYgbWFzaztcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gKChtX3ogPDwgMHgxMCkgKyBtX3cpICYgbWFzaztcblx0ICAgICAgICAgICAgICAgICAgICByZXN1bHQgLz0gMHgxMDAwMDAwMDA7XG5cdCAgICAgICAgICAgICAgICAgICAgcmVzdWx0ICs9IDAuNTtcblx0ICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0ICogKE1hdGgucmFuZG9tKCkgPiAuNSA/IDEgOiAtMSk7XG5cdCAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgIH0pO1xuXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCByY2FjaGU7IGkgPCBuQnl0ZXM7IGkgKz0gNCkge1xuXHQgICAgICAgICAgICAgICAgdmFyIF9yID0gcigocmNhY2hlIHx8IE1hdGgucmFuZG9tKCkpICogMHgxMDAwMDAwMDApO1xuXG5cdCAgICAgICAgICAgICAgICByY2FjaGUgPSBfcigpICogMHgzYWRlNjdiNztcblx0ICAgICAgICAgICAgICAgIHdvcmRzLnB1c2goKF9yKCkgKiAweDEwMDAwMDAwMCkgfCAwKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIHJldHVybiBuZXcgV29yZEFycmF5LmluaXQod29yZHMsIG5CeXRlcyk7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogRW5jb2RlciBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDX2VuYyA9IEMuZW5jID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogSGV4IGVuY29kaW5nIHN0cmF0ZWd5LlxuXHQgICAgICovXG5cdCAgICB2YXIgSGV4ID0gQ19lbmMuSGV4ID0ge1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENvbnZlcnRzIGEgd29yZCBhcnJheSB0byBhIGhleCBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0gd29yZEFycmF5IFRoZSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7c3RyaW5nfSBUaGUgaGV4IHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGhleFN0cmluZyA9IENyeXB0b0pTLmVuYy5IZXguc3RyaW5naWZ5KHdvcmRBcnJheSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgc3RyaW5naWZ5OiBmdW5jdGlvbiAod29yZEFycmF5KSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSB3b3JkQXJyYXkud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBzaWdCeXRlcyA9IHdvcmRBcnJheS5zaWdCeXRlcztcblxuXHQgICAgICAgICAgICAvLyBDb252ZXJ0XG5cdCAgICAgICAgICAgIHZhciBoZXhDaGFycyA9IFtdO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNpZ0J5dGVzOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIHZhciBiaXRlID0gKHdvcmRzW2kgPj4+IDJdID4+PiAoMjQgLSAoaSAlIDQpICogOCkpICYgMHhmZjtcblx0ICAgICAgICAgICAgICAgIGhleENoYXJzLnB1c2goKGJpdGUgPj4+IDQpLnRvU3RyaW5nKDE2KSk7XG5cdCAgICAgICAgICAgICAgICBoZXhDaGFycy5wdXNoKChiaXRlICYgMHgwZikudG9TdHJpbmcoMTYpKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIHJldHVybiBoZXhDaGFycy5qb2luKCcnKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBoZXggc3RyaW5nIHRvIGEgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBoZXhTdHIgVGhlIGhleCBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgd29yZEFycmF5ID0gQ3J5cHRvSlMuZW5jLkhleC5wYXJzZShoZXhTdHJpbmcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHBhcnNlOiBmdW5jdGlvbiAoaGV4U3RyKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBoZXhTdHJMZW5ndGggPSBoZXhTdHIubGVuZ3RoO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnRcblx0ICAgICAgICAgICAgdmFyIHdvcmRzID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgaGV4U3RyTGVuZ3RoOyBpICs9IDIpIHtcblx0ICAgICAgICAgICAgICAgIHdvcmRzW2kgPj4+IDNdIHw9IHBhcnNlSW50KGhleFN0ci5zdWJzdHIoaSwgMiksIDE2KSA8PCAoMjQgLSAoaSAlIDgpICogNCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gbmV3IFdvcmRBcnJheS5pbml0KHdvcmRzLCBoZXhTdHJMZW5ndGggLyAyKTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICAvKipcblx0ICAgICAqIExhdGluMSBlbmNvZGluZyBzdHJhdGVneS5cblx0ICAgICAqL1xuXHQgICAgdmFyIExhdGluMSA9IENfZW5jLkxhdGluMSA9IHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyBhIHdvcmQgYXJyYXkgdG8gYSBMYXRpbjEgc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IHdvcmRBcnJheSBUaGUgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIExhdGluMSBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBsYXRpbjFTdHJpbmcgPSBDcnlwdG9KUy5lbmMuTGF0aW4xLnN0cmluZ2lmeSh3b3JkQXJyYXkpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHN0cmluZ2lmeTogZnVuY3Rpb24gKHdvcmRBcnJheSkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIHdvcmRzID0gd29yZEFycmF5LndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgc2lnQnl0ZXMgPSB3b3JkQXJyYXkuc2lnQnl0ZXM7XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydFxuXHQgICAgICAgICAgICB2YXIgbGF0aW4xQ2hhcnMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzaWdCeXRlczsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIgYml0ZSA9ICh3b3Jkc1tpID4+PiAyXSA+Pj4gKDI0IC0gKGkgJSA0KSAqIDgpKSAmIDB4ZmY7XG5cdCAgICAgICAgICAgICAgICBsYXRpbjFDaGFycy5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUoYml0ZSkpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIGxhdGluMUNoYXJzLmpvaW4oJycpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyBhIExhdGluMSBzdHJpbmcgdG8gYSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGxhdGluMVN0ciBUaGUgTGF0aW4xIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5lbmMuTGF0aW4xLnBhcnNlKGxhdGluMVN0cmluZyk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcGFyc2U6IGZ1bmN0aW9uIChsYXRpbjFTdHIpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIGxhdGluMVN0ckxlbmd0aCA9IGxhdGluMVN0ci5sZW5ndGg7XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydFxuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsYXRpbjFTdHJMZW5ndGg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbaSA+Pj4gMl0gfD0gKGxhdGluMVN0ci5jaGFyQ29kZUF0KGkpICYgMHhmZikgPDwgKDI0IC0gKGkgJSA0KSAqIDgpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIG5ldyBXb3JkQXJyYXkuaW5pdCh3b3JkcywgbGF0aW4xU3RyTGVuZ3RoKTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICAvKipcblx0ICAgICAqIFVURi04IGVuY29kaW5nIHN0cmF0ZWd5LlxuXHQgICAgICovXG5cdCAgICB2YXIgVXRmOCA9IENfZW5jLlV0ZjggPSB7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSB3b3JkIGFycmF5IHRvIGEgVVRGLTggc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IHdvcmRBcnJheSBUaGUgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIFVURi04IHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIHV0ZjhTdHJpbmcgPSBDcnlwdG9KUy5lbmMuVXRmOC5zdHJpbmdpZnkod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBzdHJpbmdpZnk6IGZ1bmN0aW9uICh3b3JkQXJyYXkpIHtcblx0ICAgICAgICAgICAgdHJ5IHtcblx0ICAgICAgICAgICAgICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoZXNjYXBlKExhdGluMS5zdHJpbmdpZnkod29yZEFycmF5KSkpO1xuXHQgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG5cdCAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ01hbGZvcm1lZCBVVEYtOCBkYXRhJyk7XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBVVEYtOCBzdHJpbmcgdG8gYSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHV0ZjhTdHIgVGhlIFVURi04IHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5lbmMuVXRmOC5wYXJzZSh1dGY4U3RyaW5nKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBwYXJzZTogZnVuY3Rpb24gKHV0ZjhTdHIpIHtcblx0ICAgICAgICAgICAgcmV0dXJuIExhdGluMS5wYXJzZSh1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQodXRmOFN0cikpKTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICAvKipcblx0ICAgICAqIEFic3RyYWN0IGJ1ZmZlcmVkIGJsb2NrIGFsZ29yaXRobSB0ZW1wbGF0ZS5cblx0ICAgICAqXG5cdCAgICAgKiBUaGUgcHJvcGVydHkgYmxvY2tTaXplIG11c3QgYmUgaW1wbGVtZW50ZWQgaW4gYSBjb25jcmV0ZSBzdWJ0eXBlLlxuXHQgICAgICpcblx0ICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBfbWluQnVmZmVyU2l6ZSBUaGUgbnVtYmVyIG9mIGJsb2NrcyB0aGF0IHNob3VsZCBiZSBrZXB0IHVucHJvY2Vzc2VkIGluIHRoZSBidWZmZXIuIERlZmF1bHQ6IDBcblx0ICAgICAqL1xuXHQgICAgdmFyIEJ1ZmZlcmVkQmxvY2tBbGdvcml0aG0gPSBDX2xpYi5CdWZmZXJlZEJsb2NrQWxnb3JpdGhtID0gQmFzZS5leHRlbmQoe1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIFJlc2V0cyB0aGlzIGJsb2NrIGFsZ29yaXRobSdzIGRhdGEgYnVmZmVyIHRvIGl0cyBpbml0aWFsIHN0YXRlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICBidWZmZXJlZEJsb2NrQWxnb3JpdGhtLnJlc2V0KCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gSW5pdGlhbCB2YWx1ZXNcblx0ICAgICAgICAgICAgdGhpcy5fZGF0YSA9IG5ldyBXb3JkQXJyYXkuaW5pdCgpO1xuXHQgICAgICAgICAgICB0aGlzLl9uRGF0YUJ5dGVzID0gMDtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQWRkcyBuZXcgZGF0YSB0byB0aGlzIGJsb2NrIGFsZ29yaXRobSdzIGJ1ZmZlci5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gZGF0YSBUaGUgZGF0YSB0byBhcHBlbmQuIFN0cmluZ3MgYXJlIGNvbnZlcnRlZCB0byBhIFdvcmRBcnJheSB1c2luZyBVVEYtOC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgYnVmZmVyZWRCbG9ja0FsZ29yaXRobS5fYXBwZW5kKCdkYXRhJyk7XG5cdCAgICAgICAgICogICAgIGJ1ZmZlcmVkQmxvY2tBbGdvcml0aG0uX2FwcGVuZCh3b3JkQXJyYXkpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIF9hcHBlbmQ6IGZ1bmN0aW9uIChkYXRhKSB7XG5cdCAgICAgICAgICAgIC8vIENvbnZlcnQgc3RyaW5nIHRvIFdvcmRBcnJheSwgZWxzZSBhc3N1bWUgV29yZEFycmF5IGFscmVhZHlcblx0ICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXRhID09ICdzdHJpbmcnKSB7XG5cdCAgICAgICAgICAgICAgICBkYXRhID0gVXRmOC5wYXJzZShkYXRhKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIEFwcGVuZFxuXHQgICAgICAgICAgICB0aGlzLl9kYXRhLmNvbmNhdChkYXRhKTtcblx0ICAgICAgICAgICAgdGhpcy5fbkRhdGFCeXRlcyArPSBkYXRhLnNpZ0J5dGVzO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBQcm9jZXNzZXMgYXZhaWxhYmxlIGRhdGEgYmxvY2tzLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogVGhpcyBtZXRob2QgaW52b2tlcyBfZG9Qcm9jZXNzQmxvY2sob2Zmc2V0KSwgd2hpY2ggbXVzdCBiZSBpbXBsZW1lbnRlZCBieSBhIGNvbmNyZXRlIHN1YnR5cGUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IGRvRmx1c2ggV2hldGhlciBhbGwgYmxvY2tzIGFuZCBwYXJ0aWFsIGJsb2NrcyBzaG91bGQgYmUgcHJvY2Vzc2VkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgcHJvY2Vzc2VkIGRhdGEuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBwcm9jZXNzZWREYXRhID0gYnVmZmVyZWRCbG9ja0FsZ29yaXRobS5fcHJvY2VzcygpO1xuXHQgICAgICAgICAqICAgICB2YXIgcHJvY2Vzc2VkRGF0YSA9IGJ1ZmZlcmVkQmxvY2tBbGdvcml0aG0uX3Byb2Nlc3MoISEnZmx1c2gnKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBfcHJvY2VzczogZnVuY3Rpb24gKGRvRmx1c2gpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBkYXRhID0gdGhpcy5fZGF0YTtcblx0ICAgICAgICAgICAgdmFyIGRhdGFXb3JkcyA9IGRhdGEud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBkYXRhU2lnQnl0ZXMgPSBkYXRhLnNpZ0J5dGVzO1xuXHQgICAgICAgICAgICB2YXIgYmxvY2tTaXplID0gdGhpcy5ibG9ja1NpemU7XG5cdCAgICAgICAgICAgIHZhciBibG9ja1NpemVCeXRlcyA9IGJsb2NrU2l6ZSAqIDQ7XG5cblx0ICAgICAgICAgICAgLy8gQ291bnQgYmxvY2tzIHJlYWR5XG5cdCAgICAgICAgICAgIHZhciBuQmxvY2tzUmVhZHkgPSBkYXRhU2lnQnl0ZXMgLyBibG9ja1NpemVCeXRlcztcblx0ICAgICAgICAgICAgaWYgKGRvRmx1c2gpIHtcblx0ICAgICAgICAgICAgICAgIC8vIFJvdW5kIHVwIHRvIGluY2x1ZGUgcGFydGlhbCBibG9ja3Ncblx0ICAgICAgICAgICAgICAgIG5CbG9ja3NSZWFkeSA9IE1hdGguY2VpbChuQmxvY2tzUmVhZHkpO1xuXHQgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgLy8gUm91bmQgZG93biB0byBpbmNsdWRlIG9ubHkgZnVsbCBibG9ja3MsXG5cdCAgICAgICAgICAgICAgICAvLyBsZXNzIHRoZSBudW1iZXIgb2YgYmxvY2tzIHRoYXQgbXVzdCByZW1haW4gaW4gdGhlIGJ1ZmZlclxuXHQgICAgICAgICAgICAgICAgbkJsb2Nrc1JlYWR5ID0gTWF0aC5tYXgoKG5CbG9ja3NSZWFkeSB8IDApIC0gdGhpcy5fbWluQnVmZmVyU2l6ZSwgMCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBDb3VudCB3b3JkcyByZWFkeVxuXHQgICAgICAgICAgICB2YXIgbldvcmRzUmVhZHkgPSBuQmxvY2tzUmVhZHkgKiBibG9ja1NpemU7XG5cblx0ICAgICAgICAgICAgLy8gQ291bnQgYnl0ZXMgcmVhZHlcblx0ICAgICAgICAgICAgdmFyIG5CeXRlc1JlYWR5ID0gTWF0aC5taW4obldvcmRzUmVhZHkgKiA0LCBkYXRhU2lnQnl0ZXMpO1xuXG5cdCAgICAgICAgICAgIC8vIFByb2Nlc3MgYmxvY2tzXG5cdCAgICAgICAgICAgIGlmIChuV29yZHNSZWFkeSkge1xuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgb2Zmc2V0ID0gMDsgb2Zmc2V0IDwgbldvcmRzUmVhZHk7IG9mZnNldCArPSBibG9ja1NpemUpIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBQZXJmb3JtIGNvbmNyZXRlLWFsZ29yaXRobSBsb2dpY1xuXHQgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvUHJvY2Vzc0Jsb2NrKGRhdGFXb3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHByb2Nlc3NlZCB3b3Jkc1xuXHQgICAgICAgICAgICAgICAgdmFyIHByb2Nlc3NlZFdvcmRzID0gZGF0YVdvcmRzLnNwbGljZSgwLCBuV29yZHNSZWFkeSk7XG5cdCAgICAgICAgICAgICAgICBkYXRhLnNpZ0J5dGVzIC09IG5CeXRlc1JlYWR5O1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gUmV0dXJuIHByb2Nlc3NlZCB3b3Jkc1xuXHQgICAgICAgICAgICByZXR1cm4gbmV3IFdvcmRBcnJheS5pbml0KHByb2Nlc3NlZFdvcmRzLCBuQnl0ZXNSZWFkeSk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENyZWF0ZXMgYSBjb3B5IG9mIHRoaXMgb2JqZWN0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7T2JqZWN0fSBUaGUgY2xvbmUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBjbG9uZSA9IGJ1ZmZlcmVkQmxvY2tBbGdvcml0aG0uY2xvbmUoKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjbG9uZTogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICB2YXIgY2xvbmUgPSBCYXNlLmNsb25lLmNhbGwodGhpcyk7XG5cdCAgICAgICAgICAgIGNsb25lLl9kYXRhID0gdGhpcy5fZGF0YS5jbG9uZSgpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBjbG9uZTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX21pbkJ1ZmZlclNpemU6IDBcblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIEFic3RyYWN0IGhhc2hlciB0ZW1wbGF0ZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcHJvcGVydHkge251bWJlcn0gYmxvY2tTaXplIFRoZSBudW1iZXIgb2YgMzItYml0IHdvcmRzIHRoaXMgaGFzaGVyIG9wZXJhdGVzIG9uLiBEZWZhdWx0OiAxNiAoNTEyIGJpdHMpXG5cdCAgICAgKi9cblx0ICAgIHZhciBIYXNoZXIgPSBDX2xpYi5IYXNoZXIgPSBCdWZmZXJlZEJsb2NrQWxnb3JpdGhtLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGNmZzogQmFzZS5leHRlbmQoKSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCBoYXNoZXIuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gY2ZnIChPcHRpb25hbCkgVGhlIGNvbmZpZ3VyYXRpb24gb3B0aW9ucyB0byB1c2UgZm9yIHRoaXMgaGFzaCBjb21wdXRhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGhhc2hlciA9IENyeXB0b0pTLmFsZ28uU0hBMjU2LmNyZWF0ZSgpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGluaXQ6IGZ1bmN0aW9uIChjZmcpIHtcblx0ICAgICAgICAgICAgLy8gQXBwbHkgY29uZmlnIGRlZmF1bHRzXG5cdCAgICAgICAgICAgIHRoaXMuY2ZnID0gdGhpcy5jZmcuZXh0ZW5kKGNmZyk7XG5cblx0ICAgICAgICAgICAgLy8gU2V0IGluaXRpYWwgdmFsdWVzXG5cdCAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogUmVzZXRzIHRoaXMgaGFzaGVyIHRvIGl0cyBpbml0aWFsIHN0YXRlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICBoYXNoZXIucmVzZXQoKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICByZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBSZXNldCBkYXRhIGJ1ZmZlclxuXHQgICAgICAgICAgICBCdWZmZXJlZEJsb2NrQWxnb3JpdGhtLnJlc2V0LmNhbGwodGhpcyk7XG5cblx0ICAgICAgICAgICAgLy8gUGVyZm9ybSBjb25jcmV0ZS1oYXNoZXIgbG9naWNcblx0ICAgICAgICAgICAgdGhpcy5fZG9SZXNldCgpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBVcGRhdGVzIHRoaXMgaGFzaGVyIHdpdGggYSBtZXNzYWdlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlVXBkYXRlIFRoZSBtZXNzYWdlIHRvIGFwcGVuZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0hhc2hlcn0gVGhpcyBoYXNoZXIuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIGhhc2hlci51cGRhdGUoJ21lc3NhZ2UnKTtcblx0ICAgICAgICAgKiAgICAgaGFzaGVyLnVwZGF0ZSh3b3JkQXJyYXkpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHVwZGF0ZTogZnVuY3Rpb24gKG1lc3NhZ2VVcGRhdGUpIHtcblx0ICAgICAgICAgICAgLy8gQXBwZW5kXG5cdCAgICAgICAgICAgIHRoaXMuX2FwcGVuZChtZXNzYWdlVXBkYXRlKTtcblxuXHQgICAgICAgICAgICAvLyBVcGRhdGUgdGhlIGhhc2hcblx0ICAgICAgICAgICAgdGhpcy5fcHJvY2VzcygpO1xuXG5cdCAgICAgICAgICAgIC8vIENoYWluYWJsZVxuXHQgICAgICAgICAgICByZXR1cm4gdGhpcztcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogRmluYWxpemVzIHRoZSBoYXNoIGNvbXB1dGF0aW9uLlxuXHQgICAgICAgICAqIE5vdGUgdGhhdCB0aGUgZmluYWxpemUgb3BlcmF0aW9uIGlzIGVmZmVjdGl2ZWx5IGEgZGVzdHJ1Y3RpdmUsIHJlYWQtb25jZSBvcGVyYXRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2VVcGRhdGUgKE9wdGlvbmFsKSBBIGZpbmFsIG1lc3NhZ2UgdXBkYXRlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgaGFzaC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGhhc2ggPSBoYXNoZXIuZmluYWxpemUoKTtcblx0ICAgICAgICAgKiAgICAgdmFyIGhhc2ggPSBoYXNoZXIuZmluYWxpemUoJ21lc3NhZ2UnKTtcblx0ICAgICAgICAgKiAgICAgdmFyIGhhc2ggPSBoYXNoZXIuZmluYWxpemUod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBmaW5hbGl6ZTogZnVuY3Rpb24gKG1lc3NhZ2VVcGRhdGUpIHtcblx0ICAgICAgICAgICAgLy8gRmluYWwgbWVzc2FnZSB1cGRhdGVcblx0ICAgICAgICAgICAgaWYgKG1lc3NhZ2VVcGRhdGUpIHtcblx0ICAgICAgICAgICAgICAgIHRoaXMuX2FwcGVuZChtZXNzYWdlVXBkYXRlKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIFBlcmZvcm0gY29uY3JldGUtaGFzaGVyIGxvZ2ljXG5cdCAgICAgICAgICAgIHZhciBoYXNoID0gdGhpcy5fZG9GaW5hbGl6ZSgpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBoYXNoO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBibG9ja1NpemU6IDUxMi8zMixcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENyZWF0ZXMgYSBzaG9ydGN1dCBmdW5jdGlvbiB0byBhIGhhc2hlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0hhc2hlcn0gaGFzaGVyIFRoZSBoYXNoZXIgdG8gY3JlYXRlIGEgaGVscGVyIGZvci5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0Z1bmN0aW9ufSBUaGUgc2hvcnRjdXQgZnVuY3Rpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBTSEEyNTYgPSBDcnlwdG9KUy5saWIuSGFzaGVyLl9jcmVhdGVIZWxwZXIoQ3J5cHRvSlMuYWxnby5TSEEyNTYpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIF9jcmVhdGVIZWxwZXI6IGZ1bmN0aW9uIChoYXNoZXIpIHtcblx0ICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChtZXNzYWdlLCBjZmcpIHtcblx0ICAgICAgICAgICAgICAgIHJldHVybiBuZXcgaGFzaGVyLmluaXQoY2ZnKS5maW5hbGl6ZShtZXNzYWdlKTtcblx0ICAgICAgICAgICAgfTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ3JlYXRlcyBhIHNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7SGFzaGVyfSBoYXNoZXIgVGhlIGhhc2hlciB0byB1c2UgaW4gdGhpcyBITUFDIGhlbHBlci5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0Z1bmN0aW9ufSBUaGUgc2hvcnRjdXQgZnVuY3Rpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBIbWFjU0hBMjU2ID0gQ3J5cHRvSlMubGliLkhhc2hlci5fY3JlYXRlSG1hY0hlbHBlcihDcnlwdG9KUy5hbGdvLlNIQTI1Nik7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgX2NyZWF0ZUhtYWNIZWxwZXI6IGZ1bmN0aW9uIChoYXNoZXIpIHtcblx0ICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChtZXNzYWdlLCBrZXkpIHtcblx0ICAgICAgICAgICAgICAgIHJldHVybiBuZXcgQ19hbGdvLkhNQUMuaW5pdChoYXNoZXIsIGtleSkuZmluYWxpemUobWVzc2FnZSk7XG5cdCAgICAgICAgICAgIH07XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogQWxnb3JpdGhtIG5hbWVzcGFjZS5cblx0ICAgICAqL1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbyA9IHt9O1xuXG5cdCAgICByZXR1cm4gQztcblx0fShNYXRoKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlM7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9jb3JlLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSkge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKHVuZGVmaW5lZCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgQmFzZSA9IENfbGliLkJhc2U7XG5cdCAgICB2YXIgWDMyV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXG5cdCAgICAvKipcblx0ICAgICAqIHg2NCBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDX3g2NCA9IEMueDY0ID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogQSA2NC1iaXQgd29yZC5cblx0ICAgICAqL1xuXHQgICAgdmFyIFg2NFdvcmQgPSBDX3g2NC5Xb3JkID0gQmFzZS5leHRlbmQoe1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCA2NC1iaXQgd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBoaWdoIFRoZSBoaWdoIDMyIGJpdHMuXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IGxvdyBUaGUgbG93IDMyIGJpdHMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB4NjRXb3JkID0gQ3J5cHRvSlMueDY0LldvcmQuY3JlYXRlKDB4MDAwMTAyMDMsIDB4MDQwNTA2MDcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGluaXQ6IGZ1bmN0aW9uIChoaWdoLCBsb3cpIHtcblx0ICAgICAgICAgICAgdGhpcy5oaWdoID0gaGlnaDtcblx0ICAgICAgICAgICAgdGhpcy5sb3cgPSBsb3c7XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQml0d2lzZSBOT1RzIHRoaXMgd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1g2NFdvcmR9IEEgbmV3IHg2NC1Xb3JkIG9iamVjdCBhZnRlciBuZWdhdGluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIG5lZ2F0ZWQgPSB4NjRXb3JkLm5vdCgpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIC8vIG5vdDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyB2YXIgaGlnaCA9IH50aGlzLmhpZ2g7XG5cdCAgICAgICAgICAgIC8vIHZhciBsb3cgPSB+dGhpcy5sb3c7XG5cblx0ICAgICAgICAgICAgLy8gcmV0dXJuIFg2NFdvcmQuY3JlYXRlKGhpZ2gsIGxvdyk7XG5cdCAgICAgICAgLy8gfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEJpdHdpc2UgQU5EcyB0aGlzIHdvcmQgd2l0aCB0aGUgcGFzc2VkIHdvcmQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1g2NFdvcmR9IHdvcmQgVGhlIHg2NC1Xb3JkIHRvIEFORCB3aXRoIHRoaXMgd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1g2NFdvcmR9IEEgbmV3IHg2NC1Xb3JkIG9iamVjdCBhZnRlciBBTkRpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBhbmRlZCA9IHg2NFdvcmQuYW5kKGFub3RoZXJYNjRXb3JkKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICAvLyBhbmQ6IGZ1bmN0aW9uICh3b3JkKSB7XG5cdCAgICAgICAgICAgIC8vIHZhciBoaWdoID0gdGhpcy5oaWdoICYgd29yZC5oaWdoO1xuXHQgICAgICAgICAgICAvLyB2YXIgbG93ID0gdGhpcy5sb3cgJiB3b3JkLmxvdztcblxuXHQgICAgICAgICAgICAvLyByZXR1cm4gWDY0V29yZC5jcmVhdGUoaGlnaCwgbG93KTtcblx0ICAgICAgICAvLyB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQml0d2lzZSBPUnMgdGhpcyB3b3JkIHdpdGggdGhlIHBhc3NlZCB3b3JkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtYNjRXb3JkfSB3b3JkIFRoZSB4NjQtV29yZCB0byBPUiB3aXRoIHRoaXMgd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1g2NFdvcmR9IEEgbmV3IHg2NC1Xb3JkIG9iamVjdCBhZnRlciBPUmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIG9yZWQgPSB4NjRXb3JkLm9yKGFub3RoZXJYNjRXb3JkKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICAvLyBvcjogZnVuY3Rpb24gKHdvcmQpIHtcblx0ICAgICAgICAgICAgLy8gdmFyIGhpZ2ggPSB0aGlzLmhpZ2ggfCB3b3JkLmhpZ2g7XG5cdCAgICAgICAgICAgIC8vIHZhciBsb3cgPSB0aGlzLmxvdyB8IHdvcmQubG93O1xuXG5cdCAgICAgICAgICAgIC8vIHJldHVybiBYNjRXb3JkLmNyZWF0ZShoaWdoLCBsb3cpO1xuXHQgICAgICAgIC8vIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBCaXR3aXNlIFhPUnMgdGhpcyB3b3JkIHdpdGggdGhlIHBhc3NlZCB3b3JkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtYNjRXb3JkfSB3b3JkIFRoZSB4NjQtV29yZCB0byBYT1Igd2l0aCB0aGlzIHdvcmQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtYNjRXb3JkfSBBIG5ldyB4NjQtV29yZCBvYmplY3QgYWZ0ZXIgWE9SaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgeG9yZWQgPSB4NjRXb3JkLnhvcihhbm90aGVyWDY0V29yZCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgLy8geG9yOiBmdW5jdGlvbiAod29yZCkge1xuXHQgICAgICAgICAgICAvLyB2YXIgaGlnaCA9IHRoaXMuaGlnaCBeIHdvcmQuaGlnaDtcblx0ICAgICAgICAgICAgLy8gdmFyIGxvdyA9IHRoaXMubG93IF4gd29yZC5sb3c7XG5cblx0ICAgICAgICAgICAgLy8gcmV0dXJuIFg2NFdvcmQuY3JlYXRlKGhpZ2gsIGxvdyk7XG5cdCAgICAgICAgLy8gfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIFNoaWZ0cyB0aGlzIHdvcmQgbiBiaXRzIHRvIHRoZSBsZWZ0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IG4gVGhlIG51bWJlciBvZiBiaXRzIHRvIHNoaWZ0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7WDY0V29yZH0gQSBuZXcgeDY0LVdvcmQgb2JqZWN0IGFmdGVyIHNoaWZ0aW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgc2hpZnRlZCA9IHg2NFdvcmQuc2hpZnRMKDI1KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICAvLyBzaGlmdEw6IGZ1bmN0aW9uIChuKSB7XG5cdCAgICAgICAgICAgIC8vIGlmIChuIDwgMzIpIHtcblx0ICAgICAgICAgICAgICAgIC8vIHZhciBoaWdoID0gKHRoaXMuaGlnaCA8PCBuKSB8ICh0aGlzLmxvdyA+Pj4gKDMyIC0gbikpO1xuXHQgICAgICAgICAgICAgICAgLy8gdmFyIGxvdyA9IHRoaXMubG93IDw8IG47XG5cdCAgICAgICAgICAgIC8vIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICAvLyB2YXIgaGlnaCA9IHRoaXMubG93IDw8IChuIC0gMzIpO1xuXHQgICAgICAgICAgICAgICAgLy8gdmFyIGxvdyA9IDA7XG5cdCAgICAgICAgICAgIC8vIH1cblxuXHQgICAgICAgICAgICAvLyByZXR1cm4gWDY0V29yZC5jcmVhdGUoaGlnaCwgbG93KTtcblx0ICAgICAgICAvLyB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogU2hpZnRzIHRoaXMgd29yZCBuIGJpdHMgdG8gdGhlIHJpZ2h0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IG4gVGhlIG51bWJlciBvZiBiaXRzIHRvIHNoaWZ0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7WDY0V29yZH0gQSBuZXcgeDY0LVdvcmQgb2JqZWN0IGFmdGVyIHNoaWZ0aW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgc2hpZnRlZCA9IHg2NFdvcmQuc2hpZnRSKDcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIC8vIHNoaWZ0UjogZnVuY3Rpb24gKG4pIHtcblx0ICAgICAgICAgICAgLy8gaWYgKG4gPCAzMikge1xuXHQgICAgICAgICAgICAgICAgLy8gdmFyIGxvdyA9ICh0aGlzLmxvdyA+Pj4gbikgfCAodGhpcy5oaWdoIDw8ICgzMiAtIG4pKTtcblx0ICAgICAgICAgICAgICAgIC8vIHZhciBoaWdoID0gdGhpcy5oaWdoID4+PiBuO1xuXHQgICAgICAgICAgICAvLyB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgLy8gdmFyIGxvdyA9IHRoaXMuaGlnaCA+Pj4gKG4gLSAzMik7XG5cdCAgICAgICAgICAgICAgICAvLyB2YXIgaGlnaCA9IDA7XG5cdCAgICAgICAgICAgIC8vIH1cblxuXHQgICAgICAgICAgICAvLyByZXR1cm4gWDY0V29yZC5jcmVhdGUoaGlnaCwgbG93KTtcblx0ICAgICAgICAvLyB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogUm90YXRlcyB0aGlzIHdvcmQgbiBiaXRzIHRvIHRoZSBsZWZ0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IG4gVGhlIG51bWJlciBvZiBiaXRzIHRvIHJvdGF0ZS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1g2NFdvcmR9IEEgbmV3IHg2NC1Xb3JkIG9iamVjdCBhZnRlciByb3RhdGluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIHJvdGF0ZWQgPSB4NjRXb3JkLnJvdEwoMjUpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIC8vIHJvdEw6IGZ1bmN0aW9uIChuKSB7XG5cdCAgICAgICAgICAgIC8vIHJldHVybiB0aGlzLnNoaWZ0TChuKS5vcih0aGlzLnNoaWZ0Uig2NCAtIG4pKTtcblx0ICAgICAgICAvLyB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogUm90YXRlcyB0aGlzIHdvcmQgbiBiaXRzIHRvIHRoZSByaWdodC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBuIFRoZSBudW1iZXIgb2YgYml0cyB0byByb3RhdGUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtYNjRXb3JkfSBBIG5ldyB4NjQtV29yZCBvYmplY3QgYWZ0ZXIgcm90YXRpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciByb3RhdGVkID0geDY0V29yZC5yb3RSKDcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIC8vIHJvdFI6IGZ1bmN0aW9uIChuKSB7XG5cdCAgICAgICAgICAgIC8vIHJldHVybiB0aGlzLnNoaWZ0UihuKS5vcih0aGlzLnNoaWZ0TCg2NCAtIG4pKTtcblx0ICAgICAgICAvLyB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQWRkcyB0aGlzIHdvcmQgd2l0aCB0aGUgcGFzc2VkIHdvcmQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1g2NFdvcmR9IHdvcmQgVGhlIHg2NC1Xb3JkIHRvIGFkZCB3aXRoIHRoaXMgd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1g2NFdvcmR9IEEgbmV3IHg2NC1Xb3JkIG9iamVjdCBhZnRlciBhZGRpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBhZGRlZCA9IHg2NFdvcmQuYWRkKGFub3RoZXJYNjRXb3JkKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICAvLyBhZGQ6IGZ1bmN0aW9uICh3b3JkKSB7XG5cdCAgICAgICAgICAgIC8vIHZhciBsb3cgPSAodGhpcy5sb3cgKyB3b3JkLmxvdykgfCAwO1xuXHQgICAgICAgICAgICAvLyB2YXIgY2FycnkgPSAobG93ID4+PiAwKSA8ICh0aGlzLmxvdyA+Pj4gMCkgPyAxIDogMDtcblx0ICAgICAgICAgICAgLy8gdmFyIGhpZ2ggPSAodGhpcy5oaWdoICsgd29yZC5oaWdoICsgY2FycnkpIHwgMDtcblxuXHQgICAgICAgICAgICAvLyByZXR1cm4gWDY0V29yZC5jcmVhdGUoaGlnaCwgbG93KTtcblx0ICAgICAgICAvLyB9XG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBBbiBhcnJheSBvZiA2NC1iaXQgd29yZHMuXG5cdCAgICAgKlxuXHQgICAgICogQHByb3BlcnR5IHtBcnJheX0gd29yZHMgVGhlIGFycmF5IG9mIENyeXB0b0pTLng2NC5Xb3JkIG9iamVjdHMuXG5cdCAgICAgKiBAcHJvcGVydHkge251bWJlcn0gc2lnQnl0ZXMgVGhlIG51bWJlciBvZiBzaWduaWZpY2FudCBieXRlcyBpbiB0aGlzIHdvcmQgYXJyYXkuXG5cdCAgICAgKi9cblx0ICAgIHZhciBYNjRXb3JkQXJyYXkgPSBDX3g2NC5Xb3JkQXJyYXkgPSBCYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogSW5pdGlhbGl6ZXMgYSBuZXdseSBjcmVhdGVkIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSB3b3JkcyAoT3B0aW9uYWwpIEFuIGFycmF5IG9mIENyeXB0b0pTLng2NC5Xb3JkIG9iamVjdHMuXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IHNpZ0J5dGVzIChPcHRpb25hbCkgVGhlIG51bWJlciBvZiBzaWduaWZpY2FudCBieXRlcyBpbiB0aGUgd29yZHMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy54NjQuV29yZEFycmF5LmNyZWF0ZSgpO1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy54NjQuV29yZEFycmF5LmNyZWF0ZShbXG5cdCAgICAgICAgICogICAgICAgICBDcnlwdG9KUy54NjQuV29yZC5jcmVhdGUoMHgwMDAxMDIwMywgMHgwNDA1MDYwNyksXG5cdCAgICAgICAgICogICAgICAgICBDcnlwdG9KUy54NjQuV29yZC5jcmVhdGUoMHgxODE5MWExYiwgMHgxYzFkMWUxZilcblx0ICAgICAgICAgKiAgICAgXSk7XG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIHdvcmRBcnJheSA9IENyeXB0b0pTLng2NC5Xb3JkQXJyYXkuY3JlYXRlKFtcblx0ICAgICAgICAgKiAgICAgICAgIENyeXB0b0pTLng2NC5Xb3JkLmNyZWF0ZSgweDAwMDEwMjAzLCAweDA0MDUwNjA3KSxcblx0ICAgICAgICAgKiAgICAgICAgIENyeXB0b0pTLng2NC5Xb3JkLmNyZWF0ZSgweDE4MTkxYTFiLCAweDFjMWQxZTFmKVxuXHQgICAgICAgICAqICAgICBdLCAxMCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgaW5pdDogZnVuY3Rpb24gKHdvcmRzLCBzaWdCeXRlcykge1xuXHQgICAgICAgICAgICB3b3JkcyA9IHRoaXMud29yZHMgPSB3b3JkcyB8fCBbXTtcblxuXHQgICAgICAgICAgICBpZiAoc2lnQnl0ZXMgIT0gdW5kZWZpbmVkKSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLnNpZ0J5dGVzID0gc2lnQnl0ZXM7XG5cdCAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLnNpZ0J5dGVzID0gd29yZHMubGVuZ3RoICogODtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIDY0LWJpdCB3b3JkIGFycmF5IHRvIGEgMzItYml0IHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtDcnlwdG9KUy5saWIuV29yZEFycmF5fSBUaGlzIHdvcmQgYXJyYXkncyBkYXRhIGFzIGEgMzItYml0IHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB4MzJXb3JkQXJyYXkgPSB4NjRXb3JkQXJyYXkudG9YMzIoKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICB0b1gzMjogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIHg2NFdvcmRzID0gdGhpcy53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIHg2NFdvcmRzTGVuZ3RoID0geDY0V29yZHMubGVuZ3RoO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnRcblx0ICAgICAgICAgICAgdmFyIHgzMldvcmRzID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgeDY0V29yZHNMZW5ndGg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgdmFyIHg2NFdvcmQgPSB4NjRXb3Jkc1tpXTtcblx0ICAgICAgICAgICAgICAgIHgzMldvcmRzLnB1c2goeDY0V29yZC5oaWdoKTtcblx0ICAgICAgICAgICAgICAgIHgzMldvcmRzLnB1c2goeDY0V29yZC5sb3cpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIFgzMldvcmRBcnJheS5jcmVhdGUoeDMyV29yZHMsIHRoaXMuc2lnQnl0ZXMpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDcmVhdGVzIGEgY29weSBvZiB0aGlzIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtYNjRXb3JkQXJyYXl9IFRoZSBjbG9uZS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGNsb25lID0geDY0V29yZEFycmF5LmNsb25lKCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY2xvbmU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdmFyIGNsb25lID0gQmFzZS5jbG9uZS5jYWxsKHRoaXMpO1xuXG5cdCAgICAgICAgICAgIC8vIENsb25lIFwid29yZHNcIiBhcnJheVxuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSBjbG9uZS53b3JkcyA9IHRoaXMud29yZHMuc2xpY2UoMCk7XG5cblx0ICAgICAgICAgICAgLy8gQ2xvbmUgZWFjaCBYNjRXb3JkIG9iamVjdFxuXHQgICAgICAgICAgICB2YXIgd29yZHNMZW5ndGggPSB3b3Jkcy5sZW5ndGg7XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgd29yZHNMZW5ndGg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbaV0gPSB3b3Jkc1tpXS5jbG9uZSgpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIGNsb25lO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMveDY0LWNvcmUuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5KSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdChmdW5jdGlvbiAoKSB7XG5cdCAgICAvLyBDaGVjayBpZiB0eXBlZCBhcnJheXMgYXJlIHN1cHBvcnRlZFxuXHQgICAgaWYgKHR5cGVvZiBBcnJheUJ1ZmZlciAhPSAnZnVuY3Rpb24nKSB7XG5cdCAgICAgICAgcmV0dXJuO1xuXHQgICAgfVxuXG5cdCAgICAvLyBTaG9ydGN1dHNcblx0ICAgIHZhciBDID0gQ3J5cHRvSlM7XG5cdCAgICB2YXIgQ19saWIgPSBDLmxpYjtcblx0ICAgIHZhciBXb3JkQXJyYXkgPSBDX2xpYi5Xb3JkQXJyYXk7XG5cblx0ICAgIC8vIFJlZmVyZW5jZSBvcmlnaW5hbCBpbml0XG5cdCAgICB2YXIgc3VwZXJJbml0ID0gV29yZEFycmF5LmluaXQ7XG5cblx0ICAgIC8vIEF1Z21lbnQgV29yZEFycmF5LmluaXQgdG8gaGFuZGxlIHR5cGVkIGFycmF5c1xuXHQgICAgdmFyIHN1YkluaXQgPSBXb3JkQXJyYXkuaW5pdCA9IGZ1bmN0aW9uICh0eXBlZEFycmF5KSB7XG5cdCAgICAgICAgLy8gQ29udmVydCBidWZmZXJzIHRvIHVpbnQ4XG5cdCAgICAgICAgaWYgKHR5cGVkQXJyYXkgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuXHQgICAgICAgICAgICB0eXBlZEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkodHlwZWRBcnJheSk7XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLy8gQ29udmVydCBvdGhlciBhcnJheSB2aWV3cyB0byB1aW50OFxuXHQgICAgICAgIGlmIChcblx0ICAgICAgICAgICAgdHlwZWRBcnJheSBpbnN0YW5jZW9mIEludDhBcnJheSB8fFxuXHQgICAgICAgICAgICAodHlwZW9mIFVpbnQ4Q2xhbXBlZEFycmF5ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVkQXJyYXkgaW5zdGFuY2VvZiBVaW50OENsYW1wZWRBcnJheSkgfHxcblx0ICAgICAgICAgICAgdHlwZWRBcnJheSBpbnN0YW5jZW9mIEludDE2QXJyYXkgfHxcblx0ICAgICAgICAgICAgdHlwZWRBcnJheSBpbnN0YW5jZW9mIFVpbnQxNkFycmF5IHx8XG5cdCAgICAgICAgICAgIHR5cGVkQXJyYXkgaW5zdGFuY2VvZiBJbnQzMkFycmF5IHx8XG5cdCAgICAgICAgICAgIHR5cGVkQXJyYXkgaW5zdGFuY2VvZiBVaW50MzJBcnJheSB8fFxuXHQgICAgICAgICAgICB0eXBlZEFycmF5IGluc3RhbmNlb2YgRmxvYXQzMkFycmF5IHx8XG5cdCAgICAgICAgICAgIHR5cGVkQXJyYXkgaW5zdGFuY2VvZiBGbG9hdDY0QXJyYXlcblx0ICAgICAgICApIHtcblx0ICAgICAgICAgICAgdHlwZWRBcnJheSA9IG5ldyBVaW50OEFycmF5KHR5cGVkQXJyYXkuYnVmZmVyLCB0eXBlZEFycmF5LmJ5dGVPZmZzZXQsIHR5cGVkQXJyYXkuYnl0ZUxlbmd0aCk7XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLy8gSGFuZGxlIFVpbnQ4QXJyYXlcblx0ICAgICAgICBpZiAodHlwZWRBcnJheSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIHR5cGVkQXJyYXlCeXRlTGVuZ3RoID0gdHlwZWRBcnJheS5ieXRlTGVuZ3RoO1xuXG5cdCAgICAgICAgICAgIC8vIEV4dHJhY3QgYnl0ZXNcblx0ICAgICAgICAgICAgdmFyIHdvcmRzID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdHlwZWRBcnJheUJ5dGVMZW5ndGg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbaSA+Pj4gMl0gfD0gdHlwZWRBcnJheVtpXSA8PCAoMjQgLSAoaSAlIDQpICogOCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBJbml0aWFsaXplIHRoaXMgd29yZCBhcnJheVxuXHQgICAgICAgICAgICBzdXBlckluaXQuY2FsbCh0aGlzLCB3b3JkcywgdHlwZWRBcnJheUJ5dGVMZW5ndGgpO1xuXHQgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgIC8vIEVsc2UgY2FsbCBub3JtYWwgaW5pdFxuXHQgICAgICAgICAgICBzdXBlckluaXQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICBzdWJJbml0LnByb3RvdHlwZSA9IFdvcmRBcnJheTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5saWIuV29yZEFycmF5O1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvbGliLXR5cGVkYXJyYXlzLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSkge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXHQgICAgdmFyIENfZW5jID0gQy5lbmM7XG5cblx0ICAgIC8qKlxuXHQgICAgICogVVRGLTE2IEJFIGVuY29kaW5nIHN0cmF0ZWd5LlxuXHQgICAgICovXG5cdCAgICB2YXIgVXRmMTZCRSA9IENfZW5jLlV0ZjE2ID0gQ19lbmMuVXRmMTZCRSA9IHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyBhIHdvcmQgYXJyYXkgdG8gYSBVVEYtMTYgQkUgc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IHdvcmRBcnJheSBUaGUgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIFVURi0xNiBCRSBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB1dGYxNlN0cmluZyA9IENyeXB0b0pTLmVuYy5VdGYxNi5zdHJpbmdpZnkod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBzdHJpbmdpZnk6IGZ1bmN0aW9uICh3b3JkQXJyYXkpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciB3b3JkcyA9IHdvcmRBcnJheS53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIHNpZ0J5dGVzID0gd29yZEFycmF5LnNpZ0J5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnRcblx0ICAgICAgICAgICAgdmFyIHV0ZjE2Q2hhcnMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzaWdCeXRlczsgaSArPSAyKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIgY29kZVBvaW50ID0gKHdvcmRzW2kgPj4+IDJdID4+PiAoMTYgLSAoaSAlIDQpICogOCkpICYgMHhmZmZmO1xuXHQgICAgICAgICAgICAgICAgdXRmMTZDaGFycy5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUoY29kZVBvaW50KSk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gdXRmMTZDaGFycy5qb2luKCcnKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBVVEYtMTYgQkUgc3RyaW5nIHRvIGEgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1dGYxNlN0ciBUaGUgVVRGLTE2IEJFIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5lbmMuVXRmMTYucGFyc2UodXRmMTZTdHJpbmcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHBhcnNlOiBmdW5jdGlvbiAodXRmMTZTdHIpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIHV0ZjE2U3RyTGVuZ3RoID0gdXRmMTZTdHIubGVuZ3RoO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnRcblx0ICAgICAgICAgICAgdmFyIHdvcmRzID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdXRmMTZTdHJMZW5ndGg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbaSA+Pj4gMV0gfD0gdXRmMTZTdHIuY2hhckNvZGVBdChpKSA8PCAoMTYgLSAoaSAlIDIpICogMTYpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIFdvcmRBcnJheS5jcmVhdGUod29yZHMsIHV0ZjE2U3RyTGVuZ3RoICogMik7XG5cdCAgICAgICAgfVxuXHQgICAgfTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBVVEYtMTYgTEUgZW5jb2Rpbmcgc3RyYXRlZ3kuXG5cdCAgICAgKi9cblx0ICAgIENfZW5jLlV0ZjE2TEUgPSB7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSB3b3JkIGFycmF5IHRvIGEgVVRGLTE2IExFIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fSB3b3JkQXJyYXkgVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBVVEYtMTYgTEUgc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgdXRmMTZTdHIgPSBDcnlwdG9KUy5lbmMuVXRmMTZMRS5zdHJpbmdpZnkod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBzdHJpbmdpZnk6IGZ1bmN0aW9uICh3b3JkQXJyYXkpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciB3b3JkcyA9IHdvcmRBcnJheS53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIHNpZ0J5dGVzID0gd29yZEFycmF5LnNpZ0J5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnRcblx0ICAgICAgICAgICAgdmFyIHV0ZjE2Q2hhcnMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzaWdCeXRlczsgaSArPSAyKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIgY29kZVBvaW50ID0gc3dhcEVuZGlhbigod29yZHNbaSA+Pj4gMl0gPj4+ICgxNiAtIChpICUgNCkgKiA4KSkgJiAweGZmZmYpO1xuXHQgICAgICAgICAgICAgICAgdXRmMTZDaGFycy5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUoY29kZVBvaW50KSk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gdXRmMTZDaGFycy5qb2luKCcnKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBVVEYtMTYgTEUgc3RyaW5nIHRvIGEgd29yZCBhcnJheS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1dGYxNlN0ciBUaGUgVVRGLTE2IExFIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5lbmMuVXRmMTZMRS5wYXJzZSh1dGYxNlN0cik7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcGFyc2U6IGZ1bmN0aW9uICh1dGYxNlN0cikge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgICAgICB2YXIgdXRmMTZTdHJMZW5ndGggPSB1dGYxNlN0ci5sZW5ndGg7XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydFxuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1dGYxNlN0ckxlbmd0aDsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICB3b3Jkc1tpID4+PiAxXSB8PSBzd2FwRW5kaWFuKHV0ZjE2U3RyLmNoYXJDb2RlQXQoaSkgPDwgKDE2IC0gKGkgJSAyKSAqIDE2KSk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gV29yZEFycmF5LmNyZWF0ZSh3b3JkcywgdXRmMTZTdHJMZW5ndGggKiAyKTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICBmdW5jdGlvbiBzd2FwRW5kaWFuKHdvcmQpIHtcblx0ICAgICAgICByZXR1cm4gKCh3b3JkIDw8IDgpICYgMHhmZjAwZmYwMCkgfCAoKHdvcmQgPj4+IDgpICYgMHgwMGZmMDBmZik7XG5cdCAgICB9XG5cdH0oKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMuZW5jLlV0ZjE2O1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvZW5jLXV0ZjE2LmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSkge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXHQgICAgdmFyIENfZW5jID0gQy5lbmM7XG5cblx0ICAgIC8qKlxuXHQgICAgICogQmFzZTY0IGVuY29kaW5nIHN0cmF0ZWd5LlxuXHQgICAgICovXG5cdCAgICB2YXIgQmFzZTY0ID0gQ19lbmMuQmFzZTY0ID0ge1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENvbnZlcnRzIGEgd29yZCBhcnJheSB0byBhIEJhc2U2NCBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0gd29yZEFycmF5IFRoZSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7c3RyaW5nfSBUaGUgQmFzZTY0IHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGJhc2U2NFN0cmluZyA9IENyeXB0b0pTLmVuYy5CYXNlNjQuc3RyaW5naWZ5KHdvcmRBcnJheSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgc3RyaW5naWZ5OiBmdW5jdGlvbiAod29yZEFycmF5KSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgd29yZHMgPSB3b3JkQXJyYXkud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBzaWdCeXRlcyA9IHdvcmRBcnJheS5zaWdCeXRlcztcblx0ICAgICAgICAgICAgdmFyIG1hcCA9IHRoaXMuX21hcDtcblxuXHQgICAgICAgICAgICAvLyBDbGFtcCBleGNlc3MgYml0c1xuXHQgICAgICAgICAgICB3b3JkQXJyYXkuY2xhbXAoKTtcblxuXHQgICAgICAgICAgICAvLyBDb252ZXJ0XG5cdCAgICAgICAgICAgIHZhciBiYXNlNjRDaGFycyA9IFtdO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNpZ0J5dGVzOyBpICs9IDMpIHtcblx0ICAgICAgICAgICAgICAgIHZhciBieXRlMSA9ICh3b3Jkc1tpID4+PiAyXSAgICAgICA+Pj4gKDI0IC0gKGkgJSA0KSAqIDgpKSAgICAgICAmIDB4ZmY7XG5cdCAgICAgICAgICAgICAgICB2YXIgYnl0ZTIgPSAod29yZHNbKGkgKyAxKSA+Pj4gMl0gPj4+ICgyNCAtICgoaSArIDEpICUgNCkgKiA4KSkgJiAweGZmO1xuXHQgICAgICAgICAgICAgICAgdmFyIGJ5dGUzID0gKHdvcmRzWyhpICsgMikgPj4+IDJdID4+PiAoMjQgLSAoKGkgKyAyKSAlIDQpICogOCkpICYgMHhmZjtcblxuXHQgICAgICAgICAgICAgICAgdmFyIHRyaXBsZXQgPSAoYnl0ZTEgPDwgMTYpIHwgKGJ5dGUyIDw8IDgpIHwgYnl0ZTM7XG5cblx0ICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyAoaiA8IDQpICYmIChpICsgaiAqIDAuNzUgPCBzaWdCeXRlcyk7IGorKykge1xuXHQgICAgICAgICAgICAgICAgICAgIGJhc2U2NENoYXJzLnB1c2gobWFwLmNoYXJBdCgodHJpcGxldCA+Pj4gKDYgKiAoMyAtIGopKSkgJiAweDNmKSk7XG5cdCAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBBZGQgcGFkZGluZ1xuXHQgICAgICAgICAgICB2YXIgcGFkZGluZ0NoYXIgPSBtYXAuY2hhckF0KDY0KTtcblx0ICAgICAgICAgICAgaWYgKHBhZGRpbmdDaGFyKSB7XG5cdCAgICAgICAgICAgICAgICB3aGlsZSAoYmFzZTY0Q2hhcnMubGVuZ3RoICUgNCkge1xuXHQgICAgICAgICAgICAgICAgICAgIGJhc2U2NENoYXJzLnB1c2gocGFkZGluZ0NoYXIpO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIGJhc2U2NENoYXJzLmpvaW4oJycpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyBhIEJhc2U2NCBzdHJpbmcgdG8gYSB3b3JkIGFycmF5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGJhc2U2NFN0ciBUaGUgQmFzZTY0IHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHdvcmQgYXJyYXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciB3b3JkQXJyYXkgPSBDcnlwdG9KUy5lbmMuQmFzZTY0LnBhcnNlKGJhc2U2NFN0cmluZyk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcGFyc2U6IGZ1bmN0aW9uIChiYXNlNjRTdHIpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBiYXNlNjRTdHJMZW5ndGggPSBiYXNlNjRTdHIubGVuZ3RoO1xuXHQgICAgICAgICAgICB2YXIgbWFwID0gdGhpcy5fbWFwO1xuXHQgICAgICAgICAgICB2YXIgcmV2ZXJzZU1hcCA9IHRoaXMuX3JldmVyc2VNYXA7XG5cblx0ICAgICAgICAgICAgaWYgKCFyZXZlcnNlTWFwKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgcmV2ZXJzZU1hcCA9IHRoaXMuX3JldmVyc2VNYXAgPSBbXTtcblx0ICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IG1hcC5sZW5ndGg7IGorKykge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICByZXZlcnNlTWFwW21hcC5jaGFyQ29kZUF0KGopXSA9IGo7XG5cdCAgICAgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gSWdub3JlIHBhZGRpbmdcblx0ICAgICAgICAgICAgdmFyIHBhZGRpbmdDaGFyID0gbWFwLmNoYXJBdCg2NCk7XG5cdCAgICAgICAgICAgIGlmIChwYWRkaW5nQ2hhcikge1xuXHQgICAgICAgICAgICAgICAgdmFyIHBhZGRpbmdJbmRleCA9IGJhc2U2NFN0ci5pbmRleE9mKHBhZGRpbmdDaGFyKTtcblx0ICAgICAgICAgICAgICAgIGlmIChwYWRkaW5nSW5kZXggIT09IC0xKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgYmFzZTY0U3RyTGVuZ3RoID0gcGFkZGluZ0luZGV4O1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydFxuXHQgICAgICAgICAgICByZXR1cm4gcGFyc2VMb29wKGJhc2U2NFN0ciwgYmFzZTY0U3RyTGVuZ3RoLCByZXZlcnNlTWFwKTtcblxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfbWFwOiAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLz0nXG5cdCAgICB9O1xuXG5cdCAgICBmdW5jdGlvbiBwYXJzZUxvb3AoYmFzZTY0U3RyLCBiYXNlNjRTdHJMZW5ndGgsIHJldmVyc2VNYXApIHtcblx0ICAgICAgdmFyIHdvcmRzID0gW107XG5cdCAgICAgIHZhciBuQnl0ZXMgPSAwO1xuXHQgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJhc2U2NFN0ckxlbmd0aDsgaSsrKSB7XG5cdCAgICAgICAgICBpZiAoaSAlIDQpIHtcblx0ICAgICAgICAgICAgICB2YXIgYml0czEgPSByZXZlcnNlTWFwW2Jhc2U2NFN0ci5jaGFyQ29kZUF0KGkgLSAxKV0gPDwgKChpICUgNCkgKiAyKTtcblx0ICAgICAgICAgICAgICB2YXIgYml0czIgPSByZXZlcnNlTWFwW2Jhc2U2NFN0ci5jaGFyQ29kZUF0KGkpXSA+Pj4gKDYgLSAoaSAlIDQpICogMik7XG5cdCAgICAgICAgICAgICAgd29yZHNbbkJ5dGVzID4+PiAyXSB8PSAoYml0czEgfCBiaXRzMikgPDwgKDI0IC0gKG5CeXRlcyAlIDQpICogOCk7XG5cdCAgICAgICAgICAgICAgbkJ5dGVzKys7XG5cdCAgICAgICAgICB9XG5cdCAgICAgIH1cblx0ICAgICAgcmV0dXJuIFdvcmRBcnJheS5jcmVhdGUod29yZHMsIG5CeXRlcyk7XG5cdCAgICB9XG5cdH0oKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMuZW5jLkJhc2U2NDtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL2VuYy1iYXNlNjQuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5KSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdChmdW5jdGlvbiAoTWF0aCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXHQgICAgdmFyIEhhc2hlciA9IENfbGliLkhhc2hlcjtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cblx0ICAgIC8vIENvbnN0YW50cyB0YWJsZVxuXHQgICAgdmFyIFQgPSBbXTtcblxuXHQgICAgLy8gQ29tcHV0ZSBjb25zdGFudHNcblx0ICAgIChmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA2NDsgaSsrKSB7XG5cdCAgICAgICAgICAgIFRbaV0gPSAoTWF0aC5hYnMoTWF0aC5zaW4oaSArIDEpKSAqIDB4MTAwMDAwMDAwKSB8IDA7XG5cdCAgICAgICAgfVxuXHQgICAgfSgpKTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBNRDUgaGFzaCBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBNRDUgPSBDX2FsZ28uTUQ1ID0gSGFzaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgX2RvUmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdGhpcy5faGFzaCA9IG5ldyBXb3JkQXJyYXkuaW5pdChbXG5cdCAgICAgICAgICAgICAgICAweDY3NDUyMzAxLCAweGVmY2RhYjg5LFxuXHQgICAgICAgICAgICAgICAgMHg5OGJhZGNmZSwgMHgxMDMyNTQ3NlxuXHQgICAgICAgICAgICBdKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvUHJvY2Vzc0Jsb2NrOiBmdW5jdGlvbiAoTSwgb2Zmc2V0KSB7XG5cdCAgICAgICAgICAgIC8vIFN3YXAgZW5kaWFuXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTY7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgICAgICB2YXIgb2Zmc2V0X2kgPSBvZmZzZXQgKyBpO1xuXHQgICAgICAgICAgICAgICAgdmFyIE1fb2Zmc2V0X2kgPSBNW29mZnNldF9pXTtcblxuXHQgICAgICAgICAgICAgICAgTVtvZmZzZXRfaV0gPSAoXG5cdCAgICAgICAgICAgICAgICAgICAgKCgoTV9vZmZzZXRfaSA8PCA4KSAgfCAoTV9vZmZzZXRfaSA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAoKChNX29mZnNldF9pIDw8IDI0KSB8IChNX29mZnNldF9pID4+PiA4KSkgICYgMHhmZjAwZmYwMClcblx0ICAgICAgICAgICAgICAgICk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIEggPSB0aGlzLl9oYXNoLndvcmRzO1xuXG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8wICA9IE1bb2Zmc2V0ICsgMF07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8xICA9IE1bb2Zmc2V0ICsgMV07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8yICA9IE1bb2Zmc2V0ICsgMl07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8zICA9IE1bb2Zmc2V0ICsgM107XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF80ICA9IE1bb2Zmc2V0ICsgNF07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF81ICA9IE1bb2Zmc2V0ICsgNV07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF82ICA9IE1bb2Zmc2V0ICsgNl07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF83ICA9IE1bb2Zmc2V0ICsgN107XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF84ICA9IE1bb2Zmc2V0ICsgOF07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF85ICA9IE1bb2Zmc2V0ICsgOV07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8xMCA9IE1bb2Zmc2V0ICsgMTBdO1xuXHQgICAgICAgICAgICB2YXIgTV9vZmZzZXRfMTEgPSBNW29mZnNldCArIDExXTtcblx0ICAgICAgICAgICAgdmFyIE1fb2Zmc2V0XzEyID0gTVtvZmZzZXQgKyAxMl07XG5cdCAgICAgICAgICAgIHZhciBNX29mZnNldF8xMyA9IE1bb2Zmc2V0ICsgMTNdO1xuXHQgICAgICAgICAgICB2YXIgTV9vZmZzZXRfMTQgPSBNW29mZnNldCArIDE0XTtcblx0ICAgICAgICAgICAgdmFyIE1fb2Zmc2V0XzE1ID0gTVtvZmZzZXQgKyAxNV07XG5cblx0ICAgICAgICAgICAgLy8gV29ya2luZyB2YXJpYWxiZXNcblx0ICAgICAgICAgICAgdmFyIGEgPSBIWzBdO1xuXHQgICAgICAgICAgICB2YXIgYiA9IEhbMV07XG5cdCAgICAgICAgICAgIHZhciBjID0gSFsyXTtcblx0ICAgICAgICAgICAgdmFyIGQgPSBIWzNdO1xuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGF0aW9uXG5cdCAgICAgICAgICAgIGEgPSBGRihhLCBiLCBjLCBkLCBNX29mZnNldF8wLCAgNywgIFRbMF0pO1xuXHQgICAgICAgICAgICBkID0gRkYoZCwgYSwgYiwgYywgTV9vZmZzZXRfMSwgIDEyLCBUWzFdKTtcblx0ICAgICAgICAgICAgYyA9IEZGKGMsIGQsIGEsIGIsIE1fb2Zmc2V0XzIsICAxNywgVFsyXSk7XG5cdCAgICAgICAgICAgIGIgPSBGRihiLCBjLCBkLCBhLCBNX29mZnNldF8zLCAgMjIsIFRbM10pO1xuXHQgICAgICAgICAgICBhID0gRkYoYSwgYiwgYywgZCwgTV9vZmZzZXRfNCwgIDcsICBUWzRdKTtcblx0ICAgICAgICAgICAgZCA9IEZGKGQsIGEsIGIsIGMsIE1fb2Zmc2V0XzUsICAxMiwgVFs1XSk7XG5cdCAgICAgICAgICAgIGMgPSBGRihjLCBkLCBhLCBiLCBNX29mZnNldF82LCAgMTcsIFRbNl0pO1xuXHQgICAgICAgICAgICBiID0gRkYoYiwgYywgZCwgYSwgTV9vZmZzZXRfNywgIDIyLCBUWzddKTtcblx0ICAgICAgICAgICAgYSA9IEZGKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzgsICA3LCAgVFs4XSk7XG5cdCAgICAgICAgICAgIGQgPSBGRihkLCBhLCBiLCBjLCBNX29mZnNldF85LCAgMTIsIFRbOV0pO1xuXHQgICAgICAgICAgICBjID0gRkYoYywgZCwgYSwgYiwgTV9vZmZzZXRfMTAsIDE3LCBUWzEwXSk7XG5cdCAgICAgICAgICAgIGIgPSBGRihiLCBjLCBkLCBhLCBNX29mZnNldF8xMSwgMjIsIFRbMTFdKTtcblx0ICAgICAgICAgICAgYSA9IEZGKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzEyLCA3LCAgVFsxMl0pO1xuXHQgICAgICAgICAgICBkID0gRkYoZCwgYSwgYiwgYywgTV9vZmZzZXRfMTMsIDEyLCBUWzEzXSk7XG5cdCAgICAgICAgICAgIGMgPSBGRihjLCBkLCBhLCBiLCBNX29mZnNldF8xNCwgMTcsIFRbMTRdKTtcblx0ICAgICAgICAgICAgYiA9IEZGKGIsIGMsIGQsIGEsIE1fb2Zmc2V0XzE1LCAyMiwgVFsxNV0pO1xuXG5cdCAgICAgICAgICAgIGEgPSBHRyhhLCBiLCBjLCBkLCBNX29mZnNldF8xLCAgNSwgIFRbMTZdKTtcblx0ICAgICAgICAgICAgZCA9IEdHKGQsIGEsIGIsIGMsIE1fb2Zmc2V0XzYsICA5LCAgVFsxN10pO1xuXHQgICAgICAgICAgICBjID0gR0coYywgZCwgYSwgYiwgTV9vZmZzZXRfMTEsIDE0LCBUWzE4XSk7XG5cdCAgICAgICAgICAgIGIgPSBHRyhiLCBjLCBkLCBhLCBNX29mZnNldF8wLCAgMjAsIFRbMTldKTtcblx0ICAgICAgICAgICAgYSA9IEdHKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzUsICA1LCAgVFsyMF0pO1xuXHQgICAgICAgICAgICBkID0gR0coZCwgYSwgYiwgYywgTV9vZmZzZXRfMTAsIDksICBUWzIxXSk7XG5cdCAgICAgICAgICAgIGMgPSBHRyhjLCBkLCBhLCBiLCBNX29mZnNldF8xNSwgMTQsIFRbMjJdKTtcblx0ICAgICAgICAgICAgYiA9IEdHKGIsIGMsIGQsIGEsIE1fb2Zmc2V0XzQsICAyMCwgVFsyM10pO1xuXHQgICAgICAgICAgICBhID0gR0coYSwgYiwgYywgZCwgTV9vZmZzZXRfOSwgIDUsICBUWzI0XSk7XG5cdCAgICAgICAgICAgIGQgPSBHRyhkLCBhLCBiLCBjLCBNX29mZnNldF8xNCwgOSwgIFRbMjVdKTtcblx0ICAgICAgICAgICAgYyA9IEdHKGMsIGQsIGEsIGIsIE1fb2Zmc2V0XzMsICAxNCwgVFsyNl0pO1xuXHQgICAgICAgICAgICBiID0gR0coYiwgYywgZCwgYSwgTV9vZmZzZXRfOCwgIDIwLCBUWzI3XSk7XG5cdCAgICAgICAgICAgIGEgPSBHRyhhLCBiLCBjLCBkLCBNX29mZnNldF8xMywgNSwgIFRbMjhdKTtcblx0ICAgICAgICAgICAgZCA9IEdHKGQsIGEsIGIsIGMsIE1fb2Zmc2V0XzIsICA5LCAgVFsyOV0pO1xuXHQgICAgICAgICAgICBjID0gR0coYywgZCwgYSwgYiwgTV9vZmZzZXRfNywgIDE0LCBUWzMwXSk7XG5cdCAgICAgICAgICAgIGIgPSBHRyhiLCBjLCBkLCBhLCBNX29mZnNldF8xMiwgMjAsIFRbMzFdKTtcblxuXHQgICAgICAgICAgICBhID0gSEgoYSwgYiwgYywgZCwgTV9vZmZzZXRfNSwgIDQsICBUWzMyXSk7XG5cdCAgICAgICAgICAgIGQgPSBISChkLCBhLCBiLCBjLCBNX29mZnNldF84LCAgMTEsIFRbMzNdKTtcblx0ICAgICAgICAgICAgYyA9IEhIKGMsIGQsIGEsIGIsIE1fb2Zmc2V0XzExLCAxNiwgVFszNF0pO1xuXHQgICAgICAgICAgICBiID0gSEgoYiwgYywgZCwgYSwgTV9vZmZzZXRfMTQsIDIzLCBUWzM1XSk7XG5cdCAgICAgICAgICAgIGEgPSBISChhLCBiLCBjLCBkLCBNX29mZnNldF8xLCAgNCwgIFRbMzZdKTtcblx0ICAgICAgICAgICAgZCA9IEhIKGQsIGEsIGIsIGMsIE1fb2Zmc2V0XzQsICAxMSwgVFszN10pO1xuXHQgICAgICAgICAgICBjID0gSEgoYywgZCwgYSwgYiwgTV9vZmZzZXRfNywgIDE2LCBUWzM4XSk7XG5cdCAgICAgICAgICAgIGIgPSBISChiLCBjLCBkLCBhLCBNX29mZnNldF8xMCwgMjMsIFRbMzldKTtcblx0ICAgICAgICAgICAgYSA9IEhIKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzEzLCA0LCAgVFs0MF0pO1xuXHQgICAgICAgICAgICBkID0gSEgoZCwgYSwgYiwgYywgTV9vZmZzZXRfMCwgIDExLCBUWzQxXSk7XG5cdCAgICAgICAgICAgIGMgPSBISChjLCBkLCBhLCBiLCBNX29mZnNldF8zLCAgMTYsIFRbNDJdKTtcblx0ICAgICAgICAgICAgYiA9IEhIKGIsIGMsIGQsIGEsIE1fb2Zmc2V0XzYsICAyMywgVFs0M10pO1xuXHQgICAgICAgICAgICBhID0gSEgoYSwgYiwgYywgZCwgTV9vZmZzZXRfOSwgIDQsICBUWzQ0XSk7XG5cdCAgICAgICAgICAgIGQgPSBISChkLCBhLCBiLCBjLCBNX29mZnNldF8xMiwgMTEsIFRbNDVdKTtcblx0ICAgICAgICAgICAgYyA9IEhIKGMsIGQsIGEsIGIsIE1fb2Zmc2V0XzE1LCAxNiwgVFs0Nl0pO1xuXHQgICAgICAgICAgICBiID0gSEgoYiwgYywgZCwgYSwgTV9vZmZzZXRfMiwgIDIzLCBUWzQ3XSk7XG5cblx0ICAgICAgICAgICAgYSA9IElJKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzAsICA2LCAgVFs0OF0pO1xuXHQgICAgICAgICAgICBkID0gSUkoZCwgYSwgYiwgYywgTV9vZmZzZXRfNywgIDEwLCBUWzQ5XSk7XG5cdCAgICAgICAgICAgIGMgPSBJSShjLCBkLCBhLCBiLCBNX29mZnNldF8xNCwgMTUsIFRbNTBdKTtcblx0ICAgICAgICAgICAgYiA9IElJKGIsIGMsIGQsIGEsIE1fb2Zmc2V0XzUsICAyMSwgVFs1MV0pO1xuXHQgICAgICAgICAgICBhID0gSUkoYSwgYiwgYywgZCwgTV9vZmZzZXRfMTIsIDYsICBUWzUyXSk7XG5cdCAgICAgICAgICAgIGQgPSBJSShkLCBhLCBiLCBjLCBNX29mZnNldF8zLCAgMTAsIFRbNTNdKTtcblx0ICAgICAgICAgICAgYyA9IElJKGMsIGQsIGEsIGIsIE1fb2Zmc2V0XzEwLCAxNSwgVFs1NF0pO1xuXHQgICAgICAgICAgICBiID0gSUkoYiwgYywgZCwgYSwgTV9vZmZzZXRfMSwgIDIxLCBUWzU1XSk7XG5cdCAgICAgICAgICAgIGEgPSBJSShhLCBiLCBjLCBkLCBNX29mZnNldF84LCAgNiwgIFRbNTZdKTtcblx0ICAgICAgICAgICAgZCA9IElJKGQsIGEsIGIsIGMsIE1fb2Zmc2V0XzE1LCAxMCwgVFs1N10pO1xuXHQgICAgICAgICAgICBjID0gSUkoYywgZCwgYSwgYiwgTV9vZmZzZXRfNiwgIDE1LCBUWzU4XSk7XG5cdCAgICAgICAgICAgIGIgPSBJSShiLCBjLCBkLCBhLCBNX29mZnNldF8xMywgMjEsIFRbNTldKTtcblx0ICAgICAgICAgICAgYSA9IElJKGEsIGIsIGMsIGQsIE1fb2Zmc2V0XzQsICA2LCAgVFs2MF0pO1xuXHQgICAgICAgICAgICBkID0gSUkoZCwgYSwgYiwgYywgTV9vZmZzZXRfMTEsIDEwLCBUWzYxXSk7XG5cdCAgICAgICAgICAgIGMgPSBJSShjLCBkLCBhLCBiLCBNX29mZnNldF8yLCAgMTUsIFRbNjJdKTtcblx0ICAgICAgICAgICAgYiA9IElJKGIsIGMsIGQsIGEsIE1fb2Zmc2V0XzksICAyMSwgVFs2M10pO1xuXG5cdCAgICAgICAgICAgIC8vIEludGVybWVkaWF0ZSBoYXNoIHZhbHVlXG5cdCAgICAgICAgICAgIEhbMF0gPSAoSFswXSArIGEpIHwgMDtcblx0ICAgICAgICAgICAgSFsxXSA9IChIWzFdICsgYikgfCAwO1xuXHQgICAgICAgICAgICBIWzJdID0gKEhbMl0gKyBjKSB8IDA7XG5cdCAgICAgICAgICAgIEhbM10gPSAoSFszXSArIGQpIHwgMDtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvRmluYWxpemU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBkYXRhID0gdGhpcy5fZGF0YTtcblx0ICAgICAgICAgICAgdmFyIGRhdGFXb3JkcyA9IGRhdGEud29yZHM7XG5cblx0ICAgICAgICAgICAgdmFyIG5CaXRzVG90YWwgPSB0aGlzLl9uRGF0YUJ5dGVzICogODtcblx0ICAgICAgICAgICAgdmFyIG5CaXRzTGVmdCA9IGRhdGEuc2lnQnl0ZXMgKiA4O1xuXG5cdCAgICAgICAgICAgIC8vIEFkZCBwYWRkaW5nXG5cdCAgICAgICAgICAgIGRhdGFXb3Jkc1tuQml0c0xlZnQgPj4+IDVdIHw9IDB4ODAgPDwgKDI0IC0gbkJpdHNMZWZ0ICUgMzIpO1xuXG5cdCAgICAgICAgICAgIHZhciBuQml0c1RvdGFsSCA9IE1hdGguZmxvb3IobkJpdHNUb3RhbCAvIDB4MTAwMDAwMDAwKTtcblx0ICAgICAgICAgICAgdmFyIG5CaXRzVG90YWxMID0gbkJpdHNUb3RhbDtcblx0ICAgICAgICAgICAgZGF0YVdvcmRzWygoKG5CaXRzTGVmdCArIDY0KSA+Pj4gOSkgPDwgNCkgKyAxNV0gPSAoXG5cdCAgICAgICAgICAgICAgICAoKChuQml0c1RvdGFsSCA8PCA4KSAgfCAobkJpdHNUb3RhbEggPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8XG5cdCAgICAgICAgICAgICAgICAoKChuQml0c1RvdGFsSCA8PCAyNCkgfCAobkJpdHNUb3RhbEggPj4+IDgpKSAgJiAweGZmMDBmZjAwKVxuXHQgICAgICAgICAgICApO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKCgobkJpdHNMZWZ0ICsgNjQpID4+PiA5KSA8PCA0KSArIDE0XSA9IChcblx0ICAgICAgICAgICAgICAgICgoKG5CaXRzVG90YWxMIDw8IDgpICB8IChuQml0c1RvdGFsTCA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICgoKG5CaXRzVG90YWxMIDw8IDI0KSB8IChuQml0c1RvdGFsTCA+Pj4gOCkpICAmIDB4ZmYwMGZmMDApXG5cdCAgICAgICAgICAgICk7XG5cblx0ICAgICAgICAgICAgZGF0YS5zaWdCeXRlcyA9IChkYXRhV29yZHMubGVuZ3RoICsgMSkgKiA0O1xuXG5cdCAgICAgICAgICAgIC8vIEhhc2ggZmluYWwgYmxvY2tzXG5cdCAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3MoKTtcblxuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGhhc2ggPSB0aGlzLl9oYXNoO1xuXHQgICAgICAgICAgICB2YXIgSCA9IGhhc2gud29yZHM7XG5cblx0ICAgICAgICAgICAgLy8gU3dhcCBlbmRpYW5cblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgICAgICB2YXIgSF9pID0gSFtpXTtcblxuXHQgICAgICAgICAgICAgICAgSFtpXSA9ICgoKEhfaSA8PCA4KSAgfCAoSF9pID4+PiAyNCkpICYgMHgwMGZmMDBmZikgfFxuXHQgICAgICAgICAgICAgICAgICAgICAgICgoKEhfaSA8PCAyNCkgfCAoSF9pID4+PiA4KSkgICYgMHhmZjAwZmYwMCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBSZXR1cm4gZmluYWwgY29tcHV0ZWQgaGFzaFxuXHQgICAgICAgICAgICByZXR1cm4gaGFzaDtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgY2xvbmU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdmFyIGNsb25lID0gSGFzaGVyLmNsb25lLmNhbGwodGhpcyk7XG5cdCAgICAgICAgICAgIGNsb25lLl9oYXNoID0gdGhpcy5faGFzaC5jbG9uZSgpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBjbG9uZTtcblx0ICAgICAgICB9XG5cdCAgICB9KTtcblxuXHQgICAgZnVuY3Rpb24gRkYoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuXHQgICAgICAgIHZhciBuID0gYSArICgoYiAmIGMpIHwgKH5iICYgZCkpICsgeCArIHQ7XG5cdCAgICAgICAgcmV0dXJuICgobiA8PCBzKSB8IChuID4+PiAoMzIgLSBzKSkpICsgYjtcblx0ICAgIH1cblxuXHQgICAgZnVuY3Rpb24gR0coYSwgYiwgYywgZCwgeCwgcywgdCkge1xuXHQgICAgICAgIHZhciBuID0gYSArICgoYiAmIGQpIHwgKGMgJiB+ZCkpICsgeCArIHQ7XG5cdCAgICAgICAgcmV0dXJuICgobiA8PCBzKSB8IChuID4+PiAoMzIgLSBzKSkpICsgYjtcblx0ICAgIH1cblxuXHQgICAgZnVuY3Rpb24gSEgoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuXHQgICAgICAgIHZhciBuID0gYSArIChiIF4gYyBeIGQpICsgeCArIHQ7XG5cdCAgICAgICAgcmV0dXJuICgobiA8PCBzKSB8IChuID4+PiAoMzIgLSBzKSkpICsgYjtcblx0ICAgIH1cblxuXHQgICAgZnVuY3Rpb24gSUkoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuXHQgICAgICAgIHZhciBuID0gYSArIChjIF4gKGIgfCB+ZCkpICsgeCArIHQ7XG5cdCAgICAgICAgcmV0dXJuICgobiA8PCBzKSB8IChuID4+PiAoMzIgLSBzKSkpICsgYjtcblx0ICAgIH1cblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbiB0byB0aGUgaGFzaGVyJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBoYXNoLlxuXHQgICAgICpcblx0ICAgICAqIEBzdGF0aWNcblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgaGFzaCA9IENyeXB0b0pTLk1ENSgnbWVzc2FnZScpO1xuXHQgICAgICogICAgIHZhciBoYXNoID0gQ3J5cHRvSlMuTUQ1KHdvcmRBcnJheSk7XG5cdCAgICAgKi9cblx0ICAgIEMuTUQ1ID0gSGFzaGVyLl9jcmVhdGVIZWxwZXIoTUQ1KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbiB0byB0aGUgSE1BQydzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGhhc2guXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IGtleSBUaGUgc2VjcmV0IGtleS5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBITUFDLlxuXHQgICAgICpcblx0ICAgICAqIEBzdGF0aWNcblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgaG1hYyA9IENyeXB0b0pTLkhtYWNNRDUobWVzc2FnZSwga2V5KTtcblx0ICAgICAqL1xuXHQgICAgQy5IbWFjTUQ1ID0gSGFzaGVyLl9jcmVhdGVIbWFjSGVscGVyKE1ENSk7XG5cdH0oTWF0aCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLk1ENTtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL21kNS5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnkpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0KGZ1bmN0aW9uICgpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX2xpYiA9IEMubGliO1xuXHQgICAgdmFyIFdvcmRBcnJheSA9IENfbGliLldvcmRBcnJheTtcblx0ICAgIHZhciBIYXNoZXIgPSBDX2xpYi5IYXNoZXI7XG5cdCAgICB2YXIgQ19hbGdvID0gQy5hbGdvO1xuXG5cdCAgICAvLyBSZXVzYWJsZSBvYmplY3Rcblx0ICAgIHZhciBXID0gW107XG5cblx0ICAgIC8qKlxuXHQgICAgICogU0hBLTEgaGFzaCBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBTSEExID0gQ19hbGdvLlNIQTEgPSBIYXNoZXIuZXh0ZW5kKHtcblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICB0aGlzLl9oYXNoID0gbmV3IFdvcmRBcnJheS5pbml0KFtcblx0ICAgICAgICAgICAgICAgIDB4Njc0NTIzMDEsIDB4ZWZjZGFiODksXG5cdCAgICAgICAgICAgICAgICAweDk4YmFkY2ZlLCAweDEwMzI1NDc2LFxuXHQgICAgICAgICAgICAgICAgMHhjM2QyZTFmMFxuXHQgICAgICAgICAgICBdKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvUHJvY2Vzc0Jsb2NrOiBmdW5jdGlvbiAoTSwgb2Zmc2V0KSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBIID0gdGhpcy5faGFzaC53b3JkcztcblxuXHQgICAgICAgICAgICAvLyBXb3JraW5nIHZhcmlhYmxlc1xuXHQgICAgICAgICAgICB2YXIgYSA9IEhbMF07XG5cdCAgICAgICAgICAgIHZhciBiID0gSFsxXTtcblx0ICAgICAgICAgICAgdmFyIGMgPSBIWzJdO1xuXHQgICAgICAgICAgICB2YXIgZCA9IEhbM107XG5cdCAgICAgICAgICAgIHZhciBlID0gSFs0XTtcblxuXHQgICAgICAgICAgICAvLyBDb21wdXRhdGlvblxuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDgwOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIGlmIChpIDwgMTYpIHtcblx0ICAgICAgICAgICAgICAgICAgICBXW2ldID0gTVtvZmZzZXQgKyBpXSB8IDA7XG5cdCAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBuID0gV1tpIC0gM10gXiBXW2kgLSA4XSBeIFdbaSAtIDE0XSBeIFdbaSAtIDE2XTtcblx0ICAgICAgICAgICAgICAgICAgICBXW2ldID0gKG4gPDwgMSkgfCAobiA+Pj4gMzEpO1xuXHQgICAgICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgICAgICB2YXIgdCA9ICgoYSA8PCA1KSB8IChhID4+PiAyNykpICsgZSArIFdbaV07XG5cdCAgICAgICAgICAgICAgICBpZiAoaSA8IDIwKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgdCArPSAoKGIgJiBjKSB8ICh+YiAmIGQpKSArIDB4NWE4Mjc5OTk7XG5cdCAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGkgPCA0MCkge1xuXHQgICAgICAgICAgICAgICAgICAgIHQgKz0gKGIgXiBjIF4gZCkgKyAweDZlZDllYmExO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpIDwgNjApIHtcblx0ICAgICAgICAgICAgICAgICAgICB0ICs9ICgoYiAmIGMpIHwgKGIgJiBkKSB8IChjICYgZCkpIC0gMHg3MGU0NDMyNDtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSAvKiBpZiAoaSA8IDgwKSAqLyB7XG5cdCAgICAgICAgICAgICAgICAgICAgdCArPSAoYiBeIGMgXiBkKSAtIDB4MzU5ZDNlMmE7XG5cdCAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgIGUgPSBkO1xuXHQgICAgICAgICAgICAgICAgZCA9IGM7XG5cdCAgICAgICAgICAgICAgICBjID0gKGIgPDwgMzApIHwgKGIgPj4+IDIpO1xuXHQgICAgICAgICAgICAgICAgYiA9IGE7XG5cdCAgICAgICAgICAgICAgICBhID0gdDtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIEludGVybWVkaWF0ZSBoYXNoIHZhbHVlXG5cdCAgICAgICAgICAgIEhbMF0gPSAoSFswXSArIGEpIHwgMDtcblx0ICAgICAgICAgICAgSFsxXSA9IChIWzFdICsgYikgfCAwO1xuXHQgICAgICAgICAgICBIWzJdID0gKEhbMl0gKyBjKSB8IDA7XG5cdCAgICAgICAgICAgIEhbM10gPSAoSFszXSArIGQpIHwgMDtcblx0ICAgICAgICAgICAgSFs0XSA9IChIWzRdICsgZSkgfCAwO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9GaW5hbGl6ZTogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGRhdGEgPSB0aGlzLl9kYXRhO1xuXHQgICAgICAgICAgICB2YXIgZGF0YVdvcmRzID0gZGF0YS53b3JkcztcblxuXHQgICAgICAgICAgICB2YXIgbkJpdHNUb3RhbCA9IHRoaXMuX25EYXRhQnl0ZXMgKiA4O1xuXHQgICAgICAgICAgICB2YXIgbkJpdHNMZWZ0ID0gZGF0YS5zaWdCeXRlcyAqIDg7XG5cblx0ICAgICAgICAgICAgLy8gQWRkIHBhZGRpbmdcblx0ICAgICAgICAgICAgZGF0YVdvcmRzW25CaXRzTGVmdCA+Pj4gNV0gfD0gMHg4MCA8PCAoMjQgLSBuQml0c0xlZnQgJSAzMik7XG5cdCAgICAgICAgICAgIGRhdGFXb3Jkc1soKChuQml0c0xlZnQgKyA2NCkgPj4+IDkpIDw8IDQpICsgMTRdID0gTWF0aC5mbG9vcihuQml0c1RvdGFsIC8gMHgxMDAwMDAwMDApO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKCgobkJpdHNMZWZ0ICsgNjQpID4+PiA5KSA8PCA0KSArIDE1XSA9IG5CaXRzVG90YWw7XG5cdCAgICAgICAgICAgIGRhdGEuc2lnQnl0ZXMgPSBkYXRhV29yZHMubGVuZ3RoICogNDtcblxuXHQgICAgICAgICAgICAvLyBIYXNoIGZpbmFsIGJsb2Nrc1xuXHQgICAgICAgICAgICB0aGlzLl9wcm9jZXNzKCk7XG5cblx0ICAgICAgICAgICAgLy8gUmV0dXJuIGZpbmFsIGNvbXB1dGVkIGhhc2hcblx0ICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2hhc2g7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGNsb25lOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHZhciBjbG9uZSA9IEhhc2hlci5jbG9uZS5jYWxsKHRoaXMpO1xuXHQgICAgICAgICAgICBjbG9uZS5faGFzaCA9IHRoaXMuX2hhc2guY2xvbmUoKTtcblxuXHQgICAgICAgICAgICByZXR1cm4gY2xvbmU7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb24gdG8gdGhlIGhhc2hlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgaGFzaC5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEExKCdtZXNzYWdlJyk7XG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEExKHdvcmRBcnJheSk7XG5cdCAgICAgKi9cblx0ICAgIEMuU0hBMSA9IEhhc2hlci5fY3JlYXRlSGVscGVyKFNIQTEpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30ga2V5IFRoZSBzZWNyZXQga2V5LlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIEhNQUMuXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBobWFjID0gQ3J5cHRvSlMuSG1hY1NIQTEobWVzc2FnZSwga2V5KTtcblx0ICAgICAqL1xuXHQgICAgQy5IbWFjU0hBMSA9IEhhc2hlci5fY3JlYXRlSG1hY0hlbHBlcihTSEExKTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5TSEExO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvc2hhMS5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnkpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0KGZ1bmN0aW9uIChNYXRoKSB7XG5cdCAgICAvLyBTaG9ydGN1dHNcblx0ICAgIHZhciBDID0gQ3J5cHRvSlM7XG5cdCAgICB2YXIgQ19saWIgPSBDLmxpYjtcblx0ICAgIHZhciBXb3JkQXJyYXkgPSBDX2xpYi5Xb3JkQXJyYXk7XG5cdCAgICB2YXIgSGFzaGVyID0gQ19saWIuSGFzaGVyO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLy8gSW5pdGlhbGl6YXRpb24gYW5kIHJvdW5kIGNvbnN0YW50cyB0YWJsZXNcblx0ICAgIHZhciBIID0gW107XG5cdCAgICB2YXIgSyA9IFtdO1xuXG5cdCAgICAvLyBDb21wdXRlIGNvbnN0YW50c1xuXHQgICAgKGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICBmdW5jdGlvbiBpc1ByaW1lKG4pIHtcblx0ICAgICAgICAgICAgdmFyIHNxcnROID0gTWF0aC5zcXJ0KG4pO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBmYWN0b3IgPSAyOyBmYWN0b3IgPD0gc3FydE47IGZhY3RvcisrKSB7XG5cdCAgICAgICAgICAgICAgICBpZiAoIShuICUgZmFjdG9yKSkge1xuXHQgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIHJldHVybiB0cnVlO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIGZ1bmN0aW9uIGdldEZyYWN0aW9uYWxCaXRzKG4pIHtcblx0ICAgICAgICAgICAgcmV0dXJuICgobiAtIChuIHwgMCkpICogMHgxMDAwMDAwMDApIHwgMDtcblx0ICAgICAgICB9XG5cblx0ICAgICAgICB2YXIgbiA9IDI7XG5cdCAgICAgICAgdmFyIG5QcmltZSA9IDA7XG5cdCAgICAgICAgd2hpbGUgKG5QcmltZSA8IDY0KSB7XG5cdCAgICAgICAgICAgIGlmIChpc1ByaW1lKG4pKSB7XG5cdCAgICAgICAgICAgICAgICBpZiAoblByaW1lIDwgOCkge1xuXHQgICAgICAgICAgICAgICAgICAgIEhbblByaW1lXSA9IGdldEZyYWN0aW9uYWxCaXRzKE1hdGgucG93KG4sIDEgLyAyKSk7XG5cdCAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgICAgICBLW25QcmltZV0gPSBnZXRGcmFjdGlvbmFsQml0cyhNYXRoLnBvdyhuLCAxIC8gMykpO1xuXG5cdCAgICAgICAgICAgICAgICBuUHJpbWUrKztcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIG4rKztcblx0ICAgICAgICB9XG5cdCAgICB9KCkpO1xuXG5cdCAgICAvLyBSZXVzYWJsZSBvYmplY3Rcblx0ICAgIHZhciBXID0gW107XG5cblx0ICAgIC8qKlxuXHQgICAgICogU0hBLTI1NiBoYXNoIGFsZ29yaXRobS5cblx0ICAgICAqL1xuXHQgICAgdmFyIFNIQTI1NiA9IENfYWxnby5TSEEyNTYgPSBIYXNoZXIuZXh0ZW5kKHtcblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICB0aGlzLl9oYXNoID0gbmV3IFdvcmRBcnJheS5pbml0KEguc2xpY2UoMCkpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9Qcm9jZXNzQmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIEggPSB0aGlzLl9oYXNoLndvcmRzO1xuXG5cdCAgICAgICAgICAgIC8vIFdvcmtpbmcgdmFyaWFibGVzXG5cdCAgICAgICAgICAgIHZhciBhID0gSFswXTtcblx0ICAgICAgICAgICAgdmFyIGIgPSBIWzFdO1xuXHQgICAgICAgICAgICB2YXIgYyA9IEhbMl07XG5cdCAgICAgICAgICAgIHZhciBkID0gSFszXTtcblx0ICAgICAgICAgICAgdmFyIGUgPSBIWzRdO1xuXHQgICAgICAgICAgICB2YXIgZiA9IEhbNV07XG5cdCAgICAgICAgICAgIHZhciBnID0gSFs2XTtcblx0ICAgICAgICAgICAgdmFyIGggPSBIWzddO1xuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGF0aW9uXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNjQ7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgaWYgKGkgPCAxNikge1xuXHQgICAgICAgICAgICAgICAgICAgIFdbaV0gPSBNW29mZnNldCArIGldIHwgMDtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMHggPSBXW2kgLSAxNV07XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMCAgPSAoKGdhbW1hMHggPDwgMjUpIHwgKGdhbW1hMHggPj4+IDcpKSAgXlxuXHQgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKChnYW1tYTB4IDw8IDE0KSB8IChnYW1tYTB4ID4+PiAxOCkpIF5cblx0ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZ2FtbWEweCA+Pj4gMyk7XG5cblx0ICAgICAgICAgICAgICAgICAgICB2YXIgZ2FtbWExeCA9IFdbaSAtIDJdO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBnYW1tYTEgID0gKChnYW1tYTF4IDw8IDE1KSB8IChnYW1tYTF4ID4+PiAxNykpIF5cblx0ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoZ2FtbWExeCA8PCAxMykgfCAoZ2FtbWExeCA+Pj4gMTkpKSBeXG5cdCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGdhbW1hMXggPj4+IDEwKTtcblxuXHQgICAgICAgICAgICAgICAgICAgIFdbaV0gPSBnYW1tYTAgKyBXW2kgLSA3XSArIGdhbW1hMSArIFdbaSAtIDE2XTtcblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgdmFyIGNoICA9IChlICYgZikgXiAofmUgJiBnKTtcblx0ICAgICAgICAgICAgICAgIHZhciBtYWogPSAoYSAmIGIpIF4gKGEgJiBjKSBeIChiICYgYyk7XG5cblx0ICAgICAgICAgICAgICAgIHZhciBzaWdtYTAgPSAoKGEgPDwgMzApIHwgKGEgPj4+IDIpKSBeICgoYSA8PCAxOSkgfCAoYSA+Pj4gMTMpKSBeICgoYSA8PCAxMCkgfCAoYSA+Pj4gMjIpKTtcblx0ICAgICAgICAgICAgICAgIHZhciBzaWdtYTEgPSAoKGUgPDwgMjYpIHwgKGUgPj4+IDYpKSBeICgoZSA8PCAyMSkgfCAoZSA+Pj4gMTEpKSBeICgoZSA8PCA3KSAgfCAoZSA+Pj4gMjUpKTtcblxuXHQgICAgICAgICAgICAgICAgdmFyIHQxID0gaCArIHNpZ21hMSArIGNoICsgS1tpXSArIFdbaV07XG5cdCAgICAgICAgICAgICAgICB2YXIgdDIgPSBzaWdtYTAgKyBtYWo7XG5cblx0ICAgICAgICAgICAgICAgIGggPSBnO1xuXHQgICAgICAgICAgICAgICAgZyA9IGY7XG5cdCAgICAgICAgICAgICAgICBmID0gZTtcblx0ICAgICAgICAgICAgICAgIGUgPSAoZCArIHQxKSB8IDA7XG5cdCAgICAgICAgICAgICAgICBkID0gYztcblx0ICAgICAgICAgICAgICAgIGMgPSBiO1xuXHQgICAgICAgICAgICAgICAgYiA9IGE7XG5cdCAgICAgICAgICAgICAgICBhID0gKHQxICsgdDIpIHwgMDtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIEludGVybWVkaWF0ZSBoYXNoIHZhbHVlXG5cdCAgICAgICAgICAgIEhbMF0gPSAoSFswXSArIGEpIHwgMDtcblx0ICAgICAgICAgICAgSFsxXSA9IChIWzFdICsgYikgfCAwO1xuXHQgICAgICAgICAgICBIWzJdID0gKEhbMl0gKyBjKSB8IDA7XG5cdCAgICAgICAgICAgIEhbM10gPSAoSFszXSArIGQpIHwgMDtcblx0ICAgICAgICAgICAgSFs0XSA9IChIWzRdICsgZSkgfCAwO1xuXHQgICAgICAgICAgICBIWzVdID0gKEhbNV0gKyBmKSB8IDA7XG5cdCAgICAgICAgICAgIEhbNl0gPSAoSFs2XSArIGcpIHwgMDtcblx0ICAgICAgICAgICAgSFs3XSA9IChIWzddICsgaCkgfCAwO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9GaW5hbGl6ZTogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGRhdGEgPSB0aGlzLl9kYXRhO1xuXHQgICAgICAgICAgICB2YXIgZGF0YVdvcmRzID0gZGF0YS53b3JkcztcblxuXHQgICAgICAgICAgICB2YXIgbkJpdHNUb3RhbCA9IHRoaXMuX25EYXRhQnl0ZXMgKiA4O1xuXHQgICAgICAgICAgICB2YXIgbkJpdHNMZWZ0ID0gZGF0YS5zaWdCeXRlcyAqIDg7XG5cblx0ICAgICAgICAgICAgLy8gQWRkIHBhZGRpbmdcblx0ICAgICAgICAgICAgZGF0YVdvcmRzW25CaXRzTGVmdCA+Pj4gNV0gfD0gMHg4MCA8PCAoMjQgLSBuQml0c0xlZnQgJSAzMik7XG5cdCAgICAgICAgICAgIGRhdGFXb3Jkc1soKChuQml0c0xlZnQgKyA2NCkgPj4+IDkpIDw8IDQpICsgMTRdID0gTWF0aC5mbG9vcihuQml0c1RvdGFsIC8gMHgxMDAwMDAwMDApO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKCgobkJpdHNMZWZ0ICsgNjQpID4+PiA5KSA8PCA0KSArIDE1XSA9IG5CaXRzVG90YWw7XG5cdCAgICAgICAgICAgIGRhdGEuc2lnQnl0ZXMgPSBkYXRhV29yZHMubGVuZ3RoICogNDtcblxuXHQgICAgICAgICAgICAvLyBIYXNoIGZpbmFsIGJsb2Nrc1xuXHQgICAgICAgICAgICB0aGlzLl9wcm9jZXNzKCk7XG5cblx0ICAgICAgICAgICAgLy8gUmV0dXJuIGZpbmFsIGNvbXB1dGVkIGhhc2hcblx0ICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2hhc2g7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGNsb25lOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHZhciBjbG9uZSA9IEhhc2hlci5jbG9uZS5jYWxsKHRoaXMpO1xuXHQgICAgICAgICAgICBjbG9uZS5faGFzaCA9IHRoaXMuX2hhc2guY2xvbmUoKTtcblxuXHQgICAgICAgICAgICByZXR1cm4gY2xvbmU7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb24gdG8gdGhlIGhhc2hlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgaGFzaC5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEEyNTYoJ21lc3NhZ2UnKTtcblx0ICAgICAqICAgICB2YXIgaGFzaCA9IENyeXB0b0pTLlNIQTI1Nih3b3JkQXJyYXkpO1xuXHQgICAgICovXG5cdCAgICBDLlNIQTI1NiA9IEhhc2hlci5fY3JlYXRlSGVscGVyKFNIQTI1Nik7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb24gdG8gdGhlIEhNQUMncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBoYXNoLlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBrZXkgVGhlIHNlY3JldCBrZXkuXG5cdCAgICAgKlxuXHQgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgSE1BQy5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGhtYWMgPSBDcnlwdG9KUy5IbWFjU0hBMjU2KG1lc3NhZ2UsIGtleSk7XG5cdCAgICAgKi9cblx0ICAgIEMuSG1hY1NIQTI1NiA9IEhhc2hlci5fY3JlYXRlSG1hY0hlbHBlcihTSEEyNTYpO1xuXHR9KE1hdGgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5TSEEyNTY7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9zaGEyNTYuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4vc2hhMjU2XCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL3NoYTI1NlwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0KGZ1bmN0aW9uICgpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX2xpYiA9IEMubGliO1xuXHQgICAgdmFyIFdvcmRBcnJheSA9IENfbGliLldvcmRBcnJheTtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cdCAgICB2YXIgU0hBMjU2ID0gQ19hbGdvLlNIQTI1NjtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTSEEtMjI0IGhhc2ggYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgU0hBMjI0ID0gQ19hbGdvLlNIQTIyNCA9IFNIQTI1Ni5leHRlbmQoe1xuXHQgICAgICAgIF9kb1Jlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHRoaXMuX2hhc2ggPSBuZXcgV29yZEFycmF5LmluaXQoW1xuXHQgICAgICAgICAgICAgICAgMHhjMTA1OWVkOCwgMHgzNjdjZDUwNywgMHgzMDcwZGQxNywgMHhmNzBlNTkzOSxcblx0ICAgICAgICAgICAgICAgIDB4ZmZjMDBiMzEsIDB4Njg1ODE1MTEsIDB4NjRmOThmYTcsIDB4YmVmYTRmYTRcblx0ICAgICAgICAgICAgXSk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb0ZpbmFsaXplOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHZhciBoYXNoID0gU0hBMjU2Ll9kb0ZpbmFsaXplLmNhbGwodGhpcyk7XG5cblx0ICAgICAgICAgICAgaGFzaC5zaWdCeXRlcyAtPSA0O1xuXG5cdCAgICAgICAgICAgIHJldHVybiBoYXNoO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBoYXNoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBoYXNoLlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBoYXNoID0gQ3J5cHRvSlMuU0hBMjI0KCdtZXNzYWdlJyk7XG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEEyMjQod29yZEFycmF5KTtcblx0ICAgICAqL1xuXHQgICAgQy5TSEEyMjQgPSBTSEEyNTYuX2NyZWF0ZUhlbHBlcihTSEEyMjQpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30ga2V5IFRoZSBzZWNyZXQga2V5LlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIEhNQUMuXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBobWFjID0gQ3J5cHRvSlMuSG1hY1NIQTIyNChtZXNzYWdlLCBrZXkpO1xuXHQgICAgICovXG5cdCAgICBDLkhtYWNTSEEyMjQgPSBTSEEyNTYuX2NyZWF0ZUhtYWNIZWxwZXIoU0hBMjI0KTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5TSEEyMjQ7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9zaGEyMjQuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4veDY0LWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4veDY0LWNvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdChmdW5jdGlvbiAoKSB7XG5cdCAgICAvLyBTaG9ydGN1dHNcblx0ICAgIHZhciBDID0gQ3J5cHRvSlM7XG5cdCAgICB2YXIgQ19saWIgPSBDLmxpYjtcblx0ICAgIHZhciBIYXNoZXIgPSBDX2xpYi5IYXNoZXI7XG5cdCAgICB2YXIgQ194NjQgPSBDLng2NDtcblx0ICAgIHZhciBYNjRXb3JkID0gQ194NjQuV29yZDtcblx0ICAgIHZhciBYNjRXb3JkQXJyYXkgPSBDX3g2NC5Xb3JkQXJyYXk7XG5cdCAgICB2YXIgQ19hbGdvID0gQy5hbGdvO1xuXG5cdCAgICBmdW5jdGlvbiBYNjRXb3JkX2NyZWF0ZSgpIHtcblx0ICAgICAgICByZXR1cm4gWDY0V29yZC5jcmVhdGUuYXBwbHkoWDY0V29yZCwgYXJndW1lbnRzKTtcblx0ICAgIH1cblxuXHQgICAgLy8gQ29uc3RhbnRzXG5cdCAgICB2YXIgSyA9IFtcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDQyOGEyZjk4LCAweGQ3MjhhZTIyKSwgWDY0V29yZF9jcmVhdGUoMHg3MTM3NDQ5MSwgMHgyM2VmNjVjZCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHhiNWMwZmJjZiwgMHhlYzRkM2IyZiksIFg2NFdvcmRfY3JlYXRlKDB4ZTliNWRiYTUsIDB4ODE4OWRiYmMpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4Mzk1NmMyNWIsIDB4ZjM0OGI1MzgpLCBYNjRXb3JkX2NyZWF0ZSgweDU5ZjExMWYxLCAweGI2MDVkMDE5KSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDkyM2Y4MmE0LCAweGFmMTk0ZjliKSwgWDY0V29yZF9jcmVhdGUoMHhhYjFjNWVkNSwgMHhkYTZkODExOCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHhkODA3YWE5OCwgMHhhMzAzMDI0MiksIFg2NFdvcmRfY3JlYXRlKDB4MTI4MzViMDEsIDB4NDU3MDZmYmUpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4MjQzMTg1YmUsIDB4NGVlNGIyOGMpLCBYNjRXb3JkX2NyZWF0ZSgweDU1MGM3ZGMzLCAweGQ1ZmZiNGUyKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDcyYmU1ZDc0LCAweGYyN2I4OTZmKSwgWDY0V29yZF9jcmVhdGUoMHg4MGRlYjFmZSwgMHgzYjE2OTZiMSksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHg5YmRjMDZhNywgMHgyNWM3MTIzNSksIFg2NFdvcmRfY3JlYXRlKDB4YzE5YmYxNzQsIDB4Y2Y2OTI2OTQpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4ZTQ5YjY5YzEsIDB4OWVmMTRhZDIpLCBYNjRXb3JkX2NyZWF0ZSgweGVmYmU0Nzg2LCAweDM4NGYyNWUzKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDBmYzE5ZGM2LCAweDhiOGNkNWI1KSwgWDY0V29yZF9jcmVhdGUoMHgyNDBjYTFjYywgMHg3N2FjOWM2NSksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHgyZGU5MmM2ZiwgMHg1OTJiMDI3NSksIFg2NFdvcmRfY3JlYXRlKDB4NGE3NDg0YWEsIDB4NmVhNmU0ODMpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4NWNiMGE5ZGMsIDB4YmQ0MWZiZDQpLCBYNjRXb3JkX2NyZWF0ZSgweDc2Zjk4OGRhLCAweDgzMTE1M2I1KSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDk4M2U1MTUyLCAweGVlNjZkZmFiKSwgWDY0V29yZF9jcmVhdGUoMHhhODMxYzY2ZCwgMHgyZGI0MzIxMCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHhiMDAzMjdjOCwgMHg5OGZiMjEzZiksIFg2NFdvcmRfY3JlYXRlKDB4YmY1OTdmYzcsIDB4YmVlZjBlZTQpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4YzZlMDBiZjMsIDB4M2RhODhmYzIpLCBYNjRXb3JkX2NyZWF0ZSgweGQ1YTc5MTQ3LCAweDkzMGFhNzI1KSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDA2Y2E2MzUxLCAweGUwMDM4MjZmKSwgWDY0V29yZF9jcmVhdGUoMHgxNDI5Mjk2NywgMHgwYTBlNmU3MCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHgyN2I3MGE4NSwgMHg0NmQyMmZmYyksIFg2NFdvcmRfY3JlYXRlKDB4MmUxYjIxMzgsIDB4NWMyNmM5MjYpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4NGQyYzZkZmMsIDB4NWFjNDJhZWQpLCBYNjRXb3JkX2NyZWF0ZSgweDUzMzgwZDEzLCAweDlkOTViM2RmKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDY1MGE3MzU0LCAweDhiYWY2M2RlKSwgWDY0V29yZF9jcmVhdGUoMHg3NjZhMGFiYiwgMHgzYzc3YjJhOCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHg4MWMyYzkyZSwgMHg0N2VkYWVlNiksIFg2NFdvcmRfY3JlYXRlKDB4OTI3MjJjODUsIDB4MTQ4MjM1M2IpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4YTJiZmU4YTEsIDB4NGNmMTAzNjQpLCBYNjRXb3JkX2NyZWF0ZSgweGE4MWE2NjRiLCAweGJjNDIzMDAxKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweGMyNGI4YjcwLCAweGQwZjg5NzkxKSwgWDY0V29yZF9jcmVhdGUoMHhjNzZjNTFhMywgMHgwNjU0YmUzMCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHhkMTkyZTgxOSwgMHhkNmVmNTIxOCksIFg2NFdvcmRfY3JlYXRlKDB4ZDY5OTA2MjQsIDB4NTU2NWE5MTApLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4ZjQwZTM1ODUsIDB4NTc3MTIwMmEpLCBYNjRXb3JkX2NyZWF0ZSgweDEwNmFhMDcwLCAweDMyYmJkMWI4KSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDE5YTRjMTE2LCAweGI4ZDJkMGM4KSwgWDY0V29yZF9jcmVhdGUoMHgxZTM3NmMwOCwgMHg1MTQxYWI1MyksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHgyNzQ4Nzc0YywgMHhkZjhlZWI5OSksIFg2NFdvcmRfY3JlYXRlKDB4MzRiMGJjYjUsIDB4ZTE5YjQ4YTgpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4MzkxYzBjYjMsIDB4YzVjOTVhNjMpLCBYNjRXb3JkX2NyZWF0ZSgweDRlZDhhYTRhLCAweGUzNDE4YWNiKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDViOWNjYTRmLCAweDc3NjNlMzczKSwgWDY0V29yZF9jcmVhdGUoMHg2ODJlNmZmMywgMHhkNmIyYjhhMyksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHg3NDhmODJlZSwgMHg1ZGVmYjJmYyksIFg2NFdvcmRfY3JlYXRlKDB4NzhhNTYzNmYsIDB4NDMxNzJmNjApLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4ODRjODc4MTQsIDB4YTFmMGFiNzIpLCBYNjRXb3JkX2NyZWF0ZSgweDhjYzcwMjA4LCAweDFhNjQzOWVjKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDkwYmVmZmZhLCAweDIzNjMxZTI4KSwgWDY0V29yZF9jcmVhdGUoMHhhNDUwNmNlYiwgMHhkZTgyYmRlOSksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHhiZWY5YTNmNywgMHhiMmM2NzkxNSksIFg2NFdvcmRfY3JlYXRlKDB4YzY3MTc4ZjIsIDB4ZTM3MjUzMmIpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4Y2EyNzNlY2UsIDB4ZWEyNjYxOWMpLCBYNjRXb3JkX2NyZWF0ZSgweGQxODZiOGM3LCAweDIxYzBjMjA3KSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweGVhZGE3ZGQ2LCAweGNkZTBlYjFlKSwgWDY0V29yZF9jcmVhdGUoMHhmNTdkNGY3ZiwgMHhlZTZlZDE3OCksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHgwNmYwNjdhYSwgMHg3MjE3NmZiYSksIFg2NFdvcmRfY3JlYXRlKDB4MGE2MzdkYzUsIDB4YTJjODk4YTYpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4MTEzZjk4MDQsIDB4YmVmOTBkYWUpLCBYNjRXb3JkX2NyZWF0ZSgweDFiNzEwYjM1LCAweDEzMWM0NzFiKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDI4ZGI3N2Y1LCAweDIzMDQ3ZDg0KSwgWDY0V29yZF9jcmVhdGUoMHgzMmNhYWI3YiwgMHg0MGM3MjQ5MyksXG5cdCAgICAgICAgWDY0V29yZF9jcmVhdGUoMHgzYzllYmUwYSwgMHgxNWM5YmViYyksIFg2NFdvcmRfY3JlYXRlKDB4NDMxZDY3YzQsIDB4OWMxMDBkNGMpLFxuXHQgICAgICAgIFg2NFdvcmRfY3JlYXRlKDB4NGNjNWQ0YmUsIDB4Y2IzZTQyYjYpLCBYNjRXb3JkX2NyZWF0ZSgweDU5N2YyOTljLCAweGZjNjU3ZTJhKSxcblx0ICAgICAgICBYNjRXb3JkX2NyZWF0ZSgweDVmY2I2ZmFiLCAweDNhZDZmYWVjKSwgWDY0V29yZF9jcmVhdGUoMHg2YzQ0MTk4YywgMHg0YTQ3NTgxNylcblx0ICAgIF07XG5cblx0ICAgIC8vIFJldXNhYmxlIG9iamVjdHNcblx0ICAgIHZhciBXID0gW107XG5cdCAgICAoZnVuY3Rpb24gKCkge1xuXHQgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgODA7IGkrKykge1xuXHQgICAgICAgICAgICBXW2ldID0gWDY0V29yZF9jcmVhdGUoKTtcblx0ICAgICAgICB9XG5cdCAgICB9KCkpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNIQS01MTIgaGFzaCBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBTSEE1MTIgPSBDX2FsZ28uU0hBNTEyID0gSGFzaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgX2RvUmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdGhpcy5faGFzaCA9IG5ldyBYNjRXb3JkQXJyYXkuaW5pdChbXG5cdCAgICAgICAgICAgICAgICBuZXcgWDY0V29yZC5pbml0KDB4NmEwOWU2NjcsIDB4ZjNiY2M5MDgpLCBuZXcgWDY0V29yZC5pbml0KDB4YmI2N2FlODUsIDB4ODRjYWE3M2IpLFxuXHQgICAgICAgICAgICAgICAgbmV3IFg2NFdvcmQuaW5pdCgweDNjNmVmMzcyLCAweGZlOTRmODJiKSwgbmV3IFg2NFdvcmQuaW5pdCgweGE1NGZmNTNhLCAweDVmMWQzNmYxKSxcblx0ICAgICAgICAgICAgICAgIG5ldyBYNjRXb3JkLmluaXQoMHg1MTBlNTI3ZiwgMHhhZGU2ODJkMSksIG5ldyBYNjRXb3JkLmluaXQoMHg5YjA1Njg4YywgMHgyYjNlNmMxZiksXG5cdCAgICAgICAgICAgICAgICBuZXcgWDY0V29yZC5pbml0KDB4MWY4M2Q5YWIsIDB4ZmI0MWJkNmIpLCBuZXcgWDY0V29yZC5pbml0KDB4NWJlMGNkMTksIDB4MTM3ZTIxNzkpXG5cdCAgICAgICAgICAgIF0pO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9Qcm9jZXNzQmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBIID0gdGhpcy5faGFzaC53b3JkcztcblxuXHQgICAgICAgICAgICB2YXIgSDAgPSBIWzBdO1xuXHQgICAgICAgICAgICB2YXIgSDEgPSBIWzFdO1xuXHQgICAgICAgICAgICB2YXIgSDIgPSBIWzJdO1xuXHQgICAgICAgICAgICB2YXIgSDMgPSBIWzNdO1xuXHQgICAgICAgICAgICB2YXIgSDQgPSBIWzRdO1xuXHQgICAgICAgICAgICB2YXIgSDUgPSBIWzVdO1xuXHQgICAgICAgICAgICB2YXIgSDYgPSBIWzZdO1xuXHQgICAgICAgICAgICB2YXIgSDcgPSBIWzddO1xuXG5cdCAgICAgICAgICAgIHZhciBIMGggPSBIMC5oaWdoO1xuXHQgICAgICAgICAgICB2YXIgSDBsID0gSDAubG93O1xuXHQgICAgICAgICAgICB2YXIgSDFoID0gSDEuaGlnaDtcblx0ICAgICAgICAgICAgdmFyIEgxbCA9IEgxLmxvdztcblx0ICAgICAgICAgICAgdmFyIEgyaCA9IEgyLmhpZ2g7XG5cdCAgICAgICAgICAgIHZhciBIMmwgPSBIMi5sb3c7XG5cdCAgICAgICAgICAgIHZhciBIM2ggPSBIMy5oaWdoO1xuXHQgICAgICAgICAgICB2YXIgSDNsID0gSDMubG93O1xuXHQgICAgICAgICAgICB2YXIgSDRoID0gSDQuaGlnaDtcblx0ICAgICAgICAgICAgdmFyIEg0bCA9IEg0Lmxvdztcblx0ICAgICAgICAgICAgdmFyIEg1aCA9IEg1LmhpZ2g7XG5cdCAgICAgICAgICAgIHZhciBINWwgPSBINS5sb3c7XG5cdCAgICAgICAgICAgIHZhciBINmggPSBINi5oaWdoO1xuXHQgICAgICAgICAgICB2YXIgSDZsID0gSDYubG93O1xuXHQgICAgICAgICAgICB2YXIgSDdoID0gSDcuaGlnaDtcblx0ICAgICAgICAgICAgdmFyIEg3bCA9IEg3LmxvdztcblxuXHQgICAgICAgICAgICAvLyBXb3JraW5nIHZhcmlhYmxlc1xuXHQgICAgICAgICAgICB2YXIgYWggPSBIMGg7XG5cdCAgICAgICAgICAgIHZhciBhbCA9IEgwbDtcblx0ICAgICAgICAgICAgdmFyIGJoID0gSDFoO1xuXHQgICAgICAgICAgICB2YXIgYmwgPSBIMWw7XG5cdCAgICAgICAgICAgIHZhciBjaCA9IEgyaDtcblx0ICAgICAgICAgICAgdmFyIGNsID0gSDJsO1xuXHQgICAgICAgICAgICB2YXIgZGggPSBIM2g7XG5cdCAgICAgICAgICAgIHZhciBkbCA9IEgzbDtcblx0ICAgICAgICAgICAgdmFyIGVoID0gSDRoO1xuXHQgICAgICAgICAgICB2YXIgZWwgPSBINGw7XG5cdCAgICAgICAgICAgIHZhciBmaCA9IEg1aDtcblx0ICAgICAgICAgICAgdmFyIGZsID0gSDVsO1xuXHQgICAgICAgICAgICB2YXIgZ2ggPSBINmg7XG5cdCAgICAgICAgICAgIHZhciBnbCA9IEg2bDtcblx0ICAgICAgICAgICAgdmFyIGhoID0gSDdoO1xuXHQgICAgICAgICAgICB2YXIgaGwgPSBIN2w7XG5cblx0ICAgICAgICAgICAgLy8gUm91bmRzXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgODA7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgICAgIHZhciBXaSA9IFdbaV07XG5cblx0ICAgICAgICAgICAgICAgIC8vIEV4dGVuZCBtZXNzYWdlXG5cdCAgICAgICAgICAgICAgICBpZiAoaSA8IDE2KSB7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFdpaCA9IFdpLmhpZ2ggPSBNW29mZnNldCArIGkgKiAyXSAgICAgfCAwO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBXaWwgPSBXaS5sb3cgID0gTVtvZmZzZXQgKyBpICogMiArIDFdIHwgMDtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICAgICAgLy8gR2FtbWEwXG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMHggID0gV1tpIC0gMTVdO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBnYW1tYTB4aCA9IGdhbW1hMHguaGlnaDtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgZ2FtbWEweGwgPSBnYW1tYTB4Lmxvdztcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgZ2FtbWEwaCAgPSAoKGdhbW1hMHhoID4+PiAxKSB8IChnYW1tYTB4bCA8PCAzMSkpIF4gKChnYW1tYTB4aCA+Pj4gOCkgfCAoZ2FtbWEweGwgPDwgMjQpKSBeIChnYW1tYTB4aCA+Pj4gNyk7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMGwgID0gKChnYW1tYTB4bCA+Pj4gMSkgfCAoZ2FtbWEweGggPDwgMzEpKSBeICgoZ2FtbWEweGwgPj4+IDgpIHwgKGdhbW1hMHhoIDw8IDI0KSkgXiAoKGdhbW1hMHhsID4+PiA3KSB8IChnYW1tYTB4aCA8PCAyNSkpO1xuXG5cdCAgICAgICAgICAgICAgICAgICAgLy8gR2FtbWExXG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMXggID0gV1tpIC0gMl07XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMXhoID0gZ2FtbWExeC5oaWdoO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBnYW1tYTF4bCA9IGdhbW1hMXgubG93O1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBnYW1tYTFoICA9ICgoZ2FtbWExeGggPj4+IDE5KSB8IChnYW1tYTF4bCA8PCAxMykpIF4gKChnYW1tYTF4aCA8PCAzKSB8IChnYW1tYTF4bCA+Pj4gMjkpKSBeIChnYW1tYTF4aCA+Pj4gNik7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGdhbW1hMWwgID0gKChnYW1tYTF4bCA+Pj4gMTkpIHwgKGdhbW1hMXhoIDw8IDEzKSkgXiAoKGdhbW1hMXhsIDw8IDMpIHwgKGdhbW1hMXhoID4+PiAyOSkpIF4gKChnYW1tYTF4bCA+Pj4gNikgfCAoZ2FtbWExeGggPDwgMjYpKTtcblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIFdbaV0gPSBnYW1tYTAgKyBXW2kgLSA3XSArIGdhbW1hMSArIFdbaSAtIDE2XVxuXHQgICAgICAgICAgICAgICAgICAgIHZhciBXaTcgID0gV1tpIC0gN107XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFdpN2ggPSBXaTcuaGlnaDtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgV2k3bCA9IFdpNy5sb3c7XG5cblx0ICAgICAgICAgICAgICAgICAgICB2YXIgV2kxNiAgPSBXW2kgLSAxNl07XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFdpMTZoID0gV2kxNi5oaWdoO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBXaTE2bCA9IFdpMTYubG93O1xuXG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFdpbCA9IGdhbW1hMGwgKyBXaTdsO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBXaWggPSBnYW1tYTBoICsgV2k3aCArICgoV2lsID4+PiAwKSA8IChnYW1tYTBsID4+PiAwKSA/IDEgOiAwKTtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgV2lsID0gV2lsICsgZ2FtbWExbDtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgV2loID0gV2loICsgZ2FtbWExaCArICgoV2lsID4+PiAwKSA8IChnYW1tYTFsID4+PiAwKSA/IDEgOiAwKTtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgV2lsID0gV2lsICsgV2kxNmw7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFdpaCA9IFdpaCArIFdpMTZoICsgKChXaWwgPj4+IDApIDwgKFdpMTZsID4+PiAwKSA/IDEgOiAwKTtcblxuXHQgICAgICAgICAgICAgICAgICAgIFdpLmhpZ2ggPSBXaWg7XG5cdCAgICAgICAgICAgICAgICAgICAgV2kubG93ICA9IFdpbDtcblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgdmFyIGNoaCAgPSAoZWggJiBmaCkgXiAofmVoICYgZ2gpO1xuXHQgICAgICAgICAgICAgICAgdmFyIGNobCAgPSAoZWwgJiBmbCkgXiAofmVsICYgZ2wpO1xuXHQgICAgICAgICAgICAgICAgdmFyIG1hamggPSAoYWggJiBiaCkgXiAoYWggJiBjaCkgXiAoYmggJiBjaCk7XG5cdCAgICAgICAgICAgICAgICB2YXIgbWFqbCA9IChhbCAmIGJsKSBeIChhbCAmIGNsKSBeIChibCAmIGNsKTtcblxuXHQgICAgICAgICAgICAgICAgdmFyIHNpZ21hMGggPSAoKGFoID4+PiAyOCkgfCAoYWwgPDwgNCkpICBeICgoYWggPDwgMzApICB8IChhbCA+Pj4gMikpIF4gKChhaCA8PCAyNSkgfCAoYWwgPj4+IDcpKTtcblx0ICAgICAgICAgICAgICAgIHZhciBzaWdtYTBsID0gKChhbCA+Pj4gMjgpIHwgKGFoIDw8IDQpKSAgXiAoKGFsIDw8IDMwKSAgfCAoYWggPj4+IDIpKSBeICgoYWwgPDwgMjUpIHwgKGFoID4+PiA3KSk7XG5cdCAgICAgICAgICAgICAgICB2YXIgc2lnbWExaCA9ICgoZWggPj4+IDE0KSB8IChlbCA8PCAxOCkpIF4gKChlaCA+Pj4gMTgpIHwgKGVsIDw8IDE0KSkgXiAoKGVoIDw8IDIzKSB8IChlbCA+Pj4gOSkpO1xuXHQgICAgICAgICAgICAgICAgdmFyIHNpZ21hMWwgPSAoKGVsID4+PiAxNCkgfCAoZWggPDwgMTgpKSBeICgoZWwgPj4+IDE4KSB8IChlaCA8PCAxNCkpIF4gKChlbCA8PCAyMykgfCAoZWggPj4+IDkpKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gdDEgPSBoICsgc2lnbWExICsgY2ggKyBLW2ldICsgV1tpXVxuXHQgICAgICAgICAgICAgICAgdmFyIEtpICA9IEtbaV07XG5cdCAgICAgICAgICAgICAgICB2YXIgS2loID0gS2kuaGlnaDtcblx0ICAgICAgICAgICAgICAgIHZhciBLaWwgPSBLaS5sb3c7XG5cblx0ICAgICAgICAgICAgICAgIHZhciB0MWwgPSBobCArIHNpZ21hMWw7XG5cdCAgICAgICAgICAgICAgICB2YXIgdDFoID0gaGggKyBzaWdtYTFoICsgKCh0MWwgPj4+IDApIDwgKGhsID4+PiAwKSA/IDEgOiAwKTtcblx0ICAgICAgICAgICAgICAgIHZhciB0MWwgPSB0MWwgKyBjaGw7XG5cdCAgICAgICAgICAgICAgICB2YXIgdDFoID0gdDFoICsgY2hoICsgKCh0MWwgPj4+IDApIDwgKGNobCA+Pj4gMCkgPyAxIDogMCk7XG5cdCAgICAgICAgICAgICAgICB2YXIgdDFsID0gdDFsICsgS2lsO1xuXHQgICAgICAgICAgICAgICAgdmFyIHQxaCA9IHQxaCArIEtpaCArICgodDFsID4+PiAwKSA8IChLaWwgPj4+IDApID8gMSA6IDApO1xuXHQgICAgICAgICAgICAgICAgdmFyIHQxbCA9IHQxbCArIFdpbDtcblx0ICAgICAgICAgICAgICAgIHZhciB0MWggPSB0MWggKyBXaWggKyAoKHQxbCA+Pj4gMCkgPCAoV2lsID4+PiAwKSA/IDEgOiAwKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gdDIgPSBzaWdtYTAgKyBtYWpcblx0ICAgICAgICAgICAgICAgIHZhciB0MmwgPSBzaWdtYTBsICsgbWFqbDtcblx0ICAgICAgICAgICAgICAgIHZhciB0MmggPSBzaWdtYTBoICsgbWFqaCArICgodDJsID4+PiAwKSA8IChzaWdtYTBsID4+PiAwKSA/IDEgOiAwKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gVXBkYXRlIHdvcmtpbmcgdmFyaWFibGVzXG5cdCAgICAgICAgICAgICAgICBoaCA9IGdoO1xuXHQgICAgICAgICAgICAgICAgaGwgPSBnbDtcblx0ICAgICAgICAgICAgICAgIGdoID0gZmg7XG5cdCAgICAgICAgICAgICAgICBnbCA9IGZsO1xuXHQgICAgICAgICAgICAgICAgZmggPSBlaDtcblx0ICAgICAgICAgICAgICAgIGZsID0gZWw7XG5cdCAgICAgICAgICAgICAgICBlbCA9IChkbCArIHQxbCkgfCAwO1xuXHQgICAgICAgICAgICAgICAgZWggPSAoZGggKyB0MWggKyAoKGVsID4+PiAwKSA8IChkbCA+Pj4gMCkgPyAxIDogMCkpIHwgMDtcblx0ICAgICAgICAgICAgICAgIGRoID0gY2g7XG5cdCAgICAgICAgICAgICAgICBkbCA9IGNsO1xuXHQgICAgICAgICAgICAgICAgY2ggPSBiaDtcblx0ICAgICAgICAgICAgICAgIGNsID0gYmw7XG5cdCAgICAgICAgICAgICAgICBiaCA9IGFoO1xuXHQgICAgICAgICAgICAgICAgYmwgPSBhbDtcblx0ICAgICAgICAgICAgICAgIGFsID0gKHQxbCArIHQybCkgfCAwO1xuXHQgICAgICAgICAgICAgICAgYWggPSAodDFoICsgdDJoICsgKChhbCA+Pj4gMCkgPCAodDFsID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gSW50ZXJtZWRpYXRlIGhhc2ggdmFsdWVcblx0ICAgICAgICAgICAgSDBsID0gSDAubG93ICA9IChIMGwgKyBhbCk7XG5cdCAgICAgICAgICAgIEgwLmhpZ2ggPSAoSDBoICsgYWggKyAoKEgwbCA+Pj4gMCkgPCAoYWwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDFsID0gSDEubG93ICA9IChIMWwgKyBibCk7XG5cdCAgICAgICAgICAgIEgxLmhpZ2ggPSAoSDFoICsgYmggKyAoKEgxbCA+Pj4gMCkgPCAoYmwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDJsID0gSDIubG93ICA9IChIMmwgKyBjbCk7XG5cdCAgICAgICAgICAgIEgyLmhpZ2ggPSAoSDJoICsgY2ggKyAoKEgybCA+Pj4gMCkgPCAoY2wgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDNsID0gSDMubG93ICA9IChIM2wgKyBkbCk7XG5cdCAgICAgICAgICAgIEgzLmhpZ2ggPSAoSDNoICsgZGggKyAoKEgzbCA+Pj4gMCkgPCAoZGwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDRsID0gSDQubG93ICA9IChINGwgKyBlbCk7XG5cdCAgICAgICAgICAgIEg0LmhpZ2ggPSAoSDRoICsgZWggKyAoKEg0bCA+Pj4gMCkgPCAoZWwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDVsID0gSDUubG93ICA9IChINWwgKyBmbCk7XG5cdCAgICAgICAgICAgIEg1LmhpZ2ggPSAoSDVoICsgZmggKyAoKEg1bCA+Pj4gMCkgPCAoZmwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDZsID0gSDYubG93ICA9IChINmwgKyBnbCk7XG5cdCAgICAgICAgICAgIEg2LmhpZ2ggPSAoSDZoICsgZ2ggKyAoKEg2bCA+Pj4gMCkgPCAoZ2wgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICAgICAgSDdsID0gSDcubG93ICA9IChIN2wgKyBobCk7XG5cdCAgICAgICAgICAgIEg3LmhpZ2ggPSAoSDdoICsgaGggKyAoKEg3bCA+Pj4gMCkgPCAoaGwgPj4+IDApID8gMSA6IDApKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvRmluYWxpemU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBkYXRhID0gdGhpcy5fZGF0YTtcblx0ICAgICAgICAgICAgdmFyIGRhdGFXb3JkcyA9IGRhdGEud29yZHM7XG5cblx0ICAgICAgICAgICAgdmFyIG5CaXRzVG90YWwgPSB0aGlzLl9uRGF0YUJ5dGVzICogODtcblx0ICAgICAgICAgICAgdmFyIG5CaXRzTGVmdCA9IGRhdGEuc2lnQnl0ZXMgKiA4O1xuXG5cdCAgICAgICAgICAgIC8vIEFkZCBwYWRkaW5nXG5cdCAgICAgICAgICAgIGRhdGFXb3Jkc1tuQml0c0xlZnQgPj4+IDVdIHw9IDB4ODAgPDwgKDI0IC0gbkJpdHNMZWZ0ICUgMzIpO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKCgobkJpdHNMZWZ0ICsgMTI4KSA+Pj4gMTApIDw8IDUpICsgMzBdID0gTWF0aC5mbG9vcihuQml0c1RvdGFsIC8gMHgxMDAwMDAwMDApO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKCgobkJpdHNMZWZ0ICsgMTI4KSA+Pj4gMTApIDw8IDUpICsgMzFdID0gbkJpdHNUb3RhbDtcblx0ICAgICAgICAgICAgZGF0YS5zaWdCeXRlcyA9IGRhdGFXb3Jkcy5sZW5ndGggKiA0O1xuXG5cdCAgICAgICAgICAgIC8vIEhhc2ggZmluYWwgYmxvY2tzXG5cdCAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3MoKTtcblxuXHQgICAgICAgICAgICAvLyBDb252ZXJ0IGhhc2ggdG8gMzItYml0IHdvcmQgYXJyYXkgYmVmb3JlIHJldHVybmluZ1xuXHQgICAgICAgICAgICB2YXIgaGFzaCA9IHRoaXMuX2hhc2gudG9YMzIoKTtcblxuXHQgICAgICAgICAgICAvLyBSZXR1cm4gZmluYWwgY29tcHV0ZWQgaGFzaFxuXHQgICAgICAgICAgICByZXR1cm4gaGFzaDtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgY2xvbmU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdmFyIGNsb25lID0gSGFzaGVyLmNsb25lLmNhbGwodGhpcyk7XG5cdCAgICAgICAgICAgIGNsb25lLl9oYXNoID0gdGhpcy5faGFzaC5jbG9uZSgpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBjbG9uZTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgYmxvY2tTaXplOiAxMDI0LzMyXG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbiB0byB0aGUgaGFzaGVyJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBoYXNoLlxuXHQgICAgICpcblx0ICAgICAqIEBzdGF0aWNcblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgaGFzaCA9IENyeXB0b0pTLlNIQTUxMignbWVzc2FnZScpO1xuXHQgICAgICogICAgIHZhciBoYXNoID0gQ3J5cHRvSlMuU0hBNTEyKHdvcmRBcnJheSk7XG5cdCAgICAgKi9cblx0ICAgIEMuU0hBNTEyID0gSGFzaGVyLl9jcmVhdGVIZWxwZXIoU0hBNTEyKTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbiB0byB0aGUgSE1BQydzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGhhc2guXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IGtleSBUaGUgc2VjcmV0IGtleS5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBITUFDLlxuXHQgICAgICpcblx0ICAgICAqIEBzdGF0aWNcblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgaG1hYyA9IENyeXB0b0pTLkhtYWNTSEE1MTIobWVzc2FnZSwga2V5KTtcblx0ICAgICAqL1xuXHQgICAgQy5IbWFjU0hBNTEyID0gSGFzaGVyLl9jcmVhdGVIbWFjSGVscGVyKFNIQTUxMik7XG5cdH0oKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMuU0hBNTEyO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvc2hhNTEyLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL3g2NC1jb3JlXCIpLCByZXF1aXJlKFwiLi9zaGE1MTJcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4veDY0LWNvcmVcIiwgXCIuL3NoYTUxMlwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0KGZ1bmN0aW9uICgpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX3g2NCA9IEMueDY0O1xuXHQgICAgdmFyIFg2NFdvcmQgPSBDX3g2NC5Xb3JkO1xuXHQgICAgdmFyIFg2NFdvcmRBcnJheSA9IENfeDY0LldvcmRBcnJheTtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cdCAgICB2YXIgU0hBNTEyID0gQ19hbGdvLlNIQTUxMjtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTSEEtMzg0IGhhc2ggYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgU0hBMzg0ID0gQ19hbGdvLlNIQTM4NCA9IFNIQTUxMi5leHRlbmQoe1xuXHQgICAgICAgIF9kb1Jlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHRoaXMuX2hhc2ggPSBuZXcgWDY0V29yZEFycmF5LmluaXQoW1xuXHQgICAgICAgICAgICAgICAgbmV3IFg2NFdvcmQuaW5pdCgweGNiYmI5ZDVkLCAweGMxMDU5ZWQ4KSwgbmV3IFg2NFdvcmQuaW5pdCgweDYyOWEyOTJhLCAweDM2N2NkNTA3KSxcblx0ICAgICAgICAgICAgICAgIG5ldyBYNjRXb3JkLmluaXQoMHg5MTU5MDE1YSwgMHgzMDcwZGQxNyksIG5ldyBYNjRXb3JkLmluaXQoMHgxNTJmZWNkOCwgMHhmNzBlNTkzOSksXG5cdCAgICAgICAgICAgICAgICBuZXcgWDY0V29yZC5pbml0KDB4NjczMzI2NjcsIDB4ZmZjMDBiMzEpLCBuZXcgWDY0V29yZC5pbml0KDB4OGViNDRhODcsIDB4Njg1ODE1MTEpLFxuXHQgICAgICAgICAgICAgICAgbmV3IFg2NFdvcmQuaW5pdCgweGRiMGMyZTBkLCAweDY0Zjk4ZmE3KSwgbmV3IFg2NFdvcmQuaW5pdCgweDQ3YjU0ODFkLCAweGJlZmE0ZmE0KVxuXHQgICAgICAgICAgICBdKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvRmluYWxpemU6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgdmFyIGhhc2ggPSBTSEE1MTIuX2RvRmluYWxpemUuY2FsbCh0aGlzKTtcblxuXHQgICAgICAgICAgICBoYXNoLnNpZ0J5dGVzIC09IDE2O1xuXG5cdCAgICAgICAgICAgIHJldHVybiBoYXNoO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBoYXNoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBoYXNoLlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBoYXNoID0gQ3J5cHRvSlMuU0hBMzg0KCdtZXNzYWdlJyk7XG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEEzODQod29yZEFycmF5KTtcblx0ICAgICAqL1xuXHQgICAgQy5TSEEzODQgPSBTSEE1MTIuX2NyZWF0ZUhlbHBlcihTSEEzODQpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30ga2V5IFRoZSBzZWNyZXQga2V5LlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIEhNQUMuXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBobWFjID0gQ3J5cHRvSlMuSG1hY1NIQTM4NChtZXNzYWdlLCBrZXkpO1xuXHQgICAgICovXG5cdCAgICBDLkhtYWNTSEEzODQgPSBTSEE1MTIuX2NyZWF0ZUhtYWNIZWxwZXIoU0hBMzg0KTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5TSEEzODQ7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9zaGEzODQuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4veDY0LWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4veDY0LWNvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdChmdW5jdGlvbiAoTWF0aCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXHQgICAgdmFyIEhhc2hlciA9IENfbGliLkhhc2hlcjtcblx0ICAgIHZhciBDX3g2NCA9IEMueDY0O1xuXHQgICAgdmFyIFg2NFdvcmQgPSBDX3g2NC5Xb3JkO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLy8gQ29uc3RhbnRzIHRhYmxlc1xuXHQgICAgdmFyIFJIT19PRkZTRVRTID0gW107XG5cdCAgICB2YXIgUElfSU5ERVhFUyAgPSBbXTtcblx0ICAgIHZhciBST1VORF9DT05TVEFOVFMgPSBbXTtcblxuXHQgICAgLy8gQ29tcHV0ZSBDb25zdGFudHNcblx0ICAgIChmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgLy8gQ29tcHV0ZSByaG8gb2Zmc2V0IGNvbnN0YW50c1xuXHQgICAgICAgIHZhciB4ID0gMSwgeSA9IDA7XG5cdCAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCAyNDsgdCsrKSB7XG5cdCAgICAgICAgICAgIFJIT19PRkZTRVRTW3ggKyA1ICogeV0gPSAoKHQgKyAxKSAqICh0ICsgMikgLyAyKSAlIDY0O1xuXG5cdCAgICAgICAgICAgIHZhciBuZXdYID0geSAlIDU7XG5cdCAgICAgICAgICAgIHZhciBuZXdZID0gKDIgKiB4ICsgMyAqIHkpICUgNTtcblx0ICAgICAgICAgICAgeCA9IG5ld1g7XG5cdCAgICAgICAgICAgIHkgPSBuZXdZO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIC8vIENvbXB1dGUgcGkgaW5kZXggY29uc3RhbnRzXG5cdCAgICAgICAgZm9yICh2YXIgeCA9IDA7IHggPCA1OyB4KyspIHtcblx0ICAgICAgICAgICAgZm9yICh2YXIgeSA9IDA7IHkgPCA1OyB5KyspIHtcblx0ICAgICAgICAgICAgICAgIFBJX0lOREVYRVNbeCArIDUgKiB5XSA9IHkgKyAoKDIgKiB4ICsgMyAqIHkpICUgNSkgKiA1O1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLy8gQ29tcHV0ZSByb3VuZCBjb25zdGFudHNcblx0ICAgICAgICB2YXIgTEZTUiA9IDB4MDE7XG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNDsgaSsrKSB7XG5cdCAgICAgICAgICAgIHZhciByb3VuZENvbnN0YW50TXN3ID0gMDtcblx0ICAgICAgICAgICAgdmFyIHJvdW5kQ29uc3RhbnRMc3cgPSAwO1xuXG5cdCAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgNzsgaisrKSB7XG5cdCAgICAgICAgICAgICAgICBpZiAoTEZTUiAmIDB4MDEpIHtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgYml0UG9zaXRpb24gPSAoMSA8PCBqKSAtIDE7XG5cdCAgICAgICAgICAgICAgICAgICAgaWYgKGJpdFBvc2l0aW9uIDwgMzIpIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgcm91bmRDb25zdGFudExzdyBePSAxIDw8IGJpdFBvc2l0aW9uO1xuXHQgICAgICAgICAgICAgICAgICAgIH0gZWxzZSAvKiBpZiAoYml0UG9zaXRpb24gPj0gMzIpICovIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgcm91bmRDb25zdGFudE1zdyBePSAxIDw8IChiaXRQb3NpdGlvbiAtIDMyKTtcblx0ICAgICAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgIC8vIENvbXB1dGUgbmV4dCBMRlNSXG5cdCAgICAgICAgICAgICAgICBpZiAoTEZTUiAmIDB4ODApIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBQcmltaXRpdmUgcG9seW5vbWlhbCBvdmVyIEdGKDIpOiB4XjggKyB4XjYgKyB4XjUgKyB4XjQgKyAxXG5cdCAgICAgICAgICAgICAgICAgICAgTEZTUiA9IChMRlNSIDw8IDEpIF4gMHg3MTtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICAgICAgTEZTUiA8PD0gMTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIFJPVU5EX0NPTlNUQU5UU1tpXSA9IFg2NFdvcmQuY3JlYXRlKHJvdW5kQ29uc3RhbnRNc3csIHJvdW5kQ29uc3RhbnRMc3cpO1xuXHQgICAgICAgIH1cblx0ICAgIH0oKSk7XG5cblx0ICAgIC8vIFJldXNhYmxlIG9iamVjdHMgZm9yIHRlbXBvcmFyeSB2YWx1ZXNcblx0ICAgIHZhciBUID0gW107XG5cdCAgICAoZnVuY3Rpb24gKCkge1xuXHQgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMjU7IGkrKykge1xuXHQgICAgICAgICAgICBUW2ldID0gWDY0V29yZC5jcmVhdGUoKTtcblx0ICAgICAgICB9XG5cdCAgICB9KCkpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNIQS0zIGhhc2ggYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgU0hBMyA9IENfYWxnby5TSEEzID0gSGFzaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IG91dHB1dExlbmd0aFxuXHQgICAgICAgICAqICAgVGhlIGRlc2lyZWQgbnVtYmVyIG9mIGJpdHMgaW4gdGhlIG91dHB1dCBoYXNoLlxuXHQgICAgICAgICAqICAgT25seSB2YWx1ZXMgcGVybWl0dGVkIGFyZTogMjI0LCAyNTYsIDM4NCwgNTEyLlxuXHQgICAgICAgICAqICAgRGVmYXVsdDogNTEyXG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY2ZnOiBIYXNoZXIuY2ZnLmV4dGVuZCh7XG5cdCAgICAgICAgICAgIG91dHB1dExlbmd0aDogNTEyXG5cdCAgICAgICAgfSksXG5cblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICB2YXIgc3RhdGUgPSB0aGlzLl9zdGF0ZSA9IFtdXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMjU7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgc3RhdGVbaV0gPSBuZXcgWDY0V29yZC5pbml0KCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICB0aGlzLmJsb2NrU2l6ZSA9ICgxNjAwIC0gMiAqIHRoaXMuY2ZnLm91dHB1dExlbmd0aCkgLyAzMjtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvUHJvY2Vzc0Jsb2NrOiBmdW5jdGlvbiAoTSwgb2Zmc2V0KSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgc3RhdGUgPSB0aGlzLl9zdGF0ZTtcblx0ICAgICAgICAgICAgdmFyIG5CbG9ja1NpemVMYW5lcyA9IHRoaXMuYmxvY2tTaXplIC8gMjtcblxuXHQgICAgICAgICAgICAvLyBBYnNvcmJcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBuQmxvY2tTaXplTGFuZXM7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgICAgICB2YXIgTTJpICA9IE1bb2Zmc2V0ICsgMiAqIGldO1xuXHQgICAgICAgICAgICAgICAgdmFyIE0yaTEgPSBNW29mZnNldCArIDIgKiBpICsgMV07XG5cblx0ICAgICAgICAgICAgICAgIC8vIFN3YXAgZW5kaWFuXG5cdCAgICAgICAgICAgICAgICBNMmkgPSAoXG5cdCAgICAgICAgICAgICAgICAgICAgKCgoTTJpIDw8IDgpICB8IChNMmkgPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8XG5cdCAgICAgICAgICAgICAgICAgICAgKCgoTTJpIDw8IDI0KSB8IChNMmkgPj4+IDgpKSAgJiAweGZmMDBmZjAwKVxuXHQgICAgICAgICAgICAgICAgKTtcblx0ICAgICAgICAgICAgICAgIE0yaTEgPSAoXG5cdCAgICAgICAgICAgICAgICAgICAgKCgoTTJpMSA8PCA4KSAgfCAoTTJpMSA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAoKChNMmkxIDw8IDI0KSB8IChNMmkxID4+PiA4KSkgICYgMHhmZjAwZmYwMClcblx0ICAgICAgICAgICAgICAgICk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIEFic29yYiBtZXNzYWdlIGludG8gc3RhdGVcblx0ICAgICAgICAgICAgICAgIHZhciBsYW5lID0gc3RhdGVbaV07XG5cdCAgICAgICAgICAgICAgICBsYW5lLmhpZ2ggXj0gTTJpMTtcblx0ICAgICAgICAgICAgICAgIGxhbmUubG93ICBePSBNMmk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBSb3VuZHNcblx0ICAgICAgICAgICAgZm9yICh2YXIgcm91bmQgPSAwOyByb3VuZCA8IDI0OyByb3VuZCsrKSB7XG5cdCAgICAgICAgICAgICAgICAvLyBUaGV0YVxuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgeCA9IDA7IHggPCA1OyB4KyspIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBNaXggY29sdW1uIGxhbmVzXG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIHRNc3cgPSAwLCB0THN3ID0gMDtcblx0ICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciB5ID0gMDsgeSA8IDU7IHkrKykge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFuZSA9IHN0YXRlW3ggKyA1ICogeV07XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHRNc3cgXj0gbGFuZS5oaWdoO1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB0THN3IF49IGxhbmUubG93O1xuXHQgICAgICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIFRlbXBvcmFyeSB2YWx1ZXNcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgVHggPSBUW3hdO1xuXHQgICAgICAgICAgICAgICAgICAgIFR4LmhpZ2ggPSB0TXN3O1xuXHQgICAgICAgICAgICAgICAgICAgIFR4LmxvdyAgPSB0THN3O1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgeCA9IDA7IHggPCA1OyB4KyspIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgVHg0ID0gVFsoeCArIDQpICUgNV07XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIFR4MSA9IFRbKHggKyAxKSAlIDVdO1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBUeDFNc3cgPSBUeDEuaGlnaDtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgVHgxTHN3ID0gVHgxLmxvdztcblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIE1peCBzdXJyb3VuZGluZyBjb2x1bW5zXG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIHRNc3cgPSBUeDQuaGlnaCBeICgoVHgxTXN3IDw8IDEpIHwgKFR4MUxzdyA+Pj4gMzEpKTtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgdExzdyA9IFR4NC5sb3cgIF4gKChUeDFMc3cgPDwgMSkgfCAoVHgxTXN3ID4+PiAzMSkpO1xuXHQgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHkgPSAwOyB5IDwgNTsgeSsrKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5lID0gc3RhdGVbeCArIDUgKiB5XTtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgbGFuZS5oaWdoIF49IHRNc3c7XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIGxhbmUubG93ICBePSB0THN3O1xuXHQgICAgICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgLy8gUmhvIFBpXG5cdCAgICAgICAgICAgICAgICBmb3IgKHZhciBsYW5lSW5kZXggPSAxOyBsYW5lSW5kZXggPCAyNTsgbGFuZUluZGV4KyspIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgbGFuZSA9IHN0YXRlW2xhbmVJbmRleF07XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGxhbmVNc3cgPSBsYW5lLmhpZ2g7XG5cdCAgICAgICAgICAgICAgICAgICAgdmFyIGxhbmVMc3cgPSBsYW5lLmxvdztcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgcmhvT2Zmc2V0ID0gUkhPX09GRlNFVFNbbGFuZUluZGV4XTtcblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIFJvdGF0ZSBsYW5lc1xuXHQgICAgICAgICAgICAgICAgICAgIGlmIChyaG9PZmZzZXQgPCAzMikge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdE1zdyA9IChsYW5lTXN3IDw8IHJob09mZnNldCkgfCAobGFuZUxzdyA+Pj4gKDMyIC0gcmhvT2Zmc2V0KSk7XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0THN3ID0gKGxhbmVMc3cgPDwgcmhvT2Zmc2V0KSB8IChsYW5lTXN3ID4+PiAoMzIgLSByaG9PZmZzZXQpKTtcblx0ICAgICAgICAgICAgICAgICAgICB9IGVsc2UgLyogaWYgKHJob09mZnNldCA+PSAzMikgKi8ge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdE1zdyA9IChsYW5lTHN3IDw8IChyaG9PZmZzZXQgLSAzMikpIHwgKGxhbmVNc3cgPj4+ICg2NCAtIHJob09mZnNldCkpO1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdExzdyA9IChsYW5lTXN3IDw8IChyaG9PZmZzZXQgLSAzMikpIHwgKGxhbmVMc3cgPj4+ICg2NCAtIHJob09mZnNldCkpO1xuXHQgICAgICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIFRyYW5zcG9zZSBsYW5lc1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciBUUGlMYW5lID0gVFtQSV9JTkRFWEVTW2xhbmVJbmRleF1dO1xuXHQgICAgICAgICAgICAgICAgICAgIFRQaUxhbmUuaGlnaCA9IHRNc3c7XG5cdCAgICAgICAgICAgICAgICAgICAgVFBpTGFuZS5sb3cgID0gdExzdztcblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgLy8gUmhvIHBpIGF0IHggPSB5ID0gMFxuXHQgICAgICAgICAgICAgICAgdmFyIFQwID0gVFswXTtcblx0ICAgICAgICAgICAgICAgIHZhciBzdGF0ZTAgPSBzdGF0ZVswXTtcblx0ICAgICAgICAgICAgICAgIFQwLmhpZ2ggPSBzdGF0ZTAuaGlnaDtcblx0ICAgICAgICAgICAgICAgIFQwLmxvdyAgPSBzdGF0ZTAubG93O1xuXG5cdCAgICAgICAgICAgICAgICAvLyBDaGlcblx0ICAgICAgICAgICAgICAgIGZvciAodmFyIHggPSAwOyB4IDwgNTsgeCsrKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgeSA9IDA7IHkgPCA1OyB5KyspIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5lSW5kZXggPSB4ICsgNSAqIHk7XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYW5lID0gc3RhdGVbbGFuZUluZGV4XTtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFRMYW5lID0gVFtsYW5lSW5kZXhdO1xuXHQgICAgICAgICAgICAgICAgICAgICAgICB2YXIgVHgxTGFuZSA9IFRbKCh4ICsgMSkgJSA1KSArIDUgKiB5XTtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFR4MkxhbmUgPSBUWygoeCArIDIpICUgNSkgKyA1ICogeV07XG5cblx0ICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWl4IHJvd3Ncblx0ICAgICAgICAgICAgICAgICAgICAgICAgbGFuZS5oaWdoID0gVExhbmUuaGlnaCBeICh+VHgxTGFuZS5oaWdoICYgVHgyTGFuZS5oaWdoKTtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgbGFuZS5sb3cgID0gVExhbmUubG93ICBeICh+VHgxTGFuZS5sb3cgICYgVHgyTGFuZS5sb3cpO1xuXHQgICAgICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgLy8gSW90YVxuXHQgICAgICAgICAgICAgICAgdmFyIGxhbmUgPSBzdGF0ZVswXTtcblx0ICAgICAgICAgICAgICAgIHZhciByb3VuZENvbnN0YW50ID0gUk9VTkRfQ09OU1RBTlRTW3JvdW5kXTtcblx0ICAgICAgICAgICAgICAgIGxhbmUuaGlnaCBePSByb3VuZENvbnN0YW50LmhpZ2g7XG5cdCAgICAgICAgICAgICAgICBsYW5lLmxvdyAgXj0gcm91bmRDb25zdGFudC5sb3c7O1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb0ZpbmFsaXplOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgZGF0YSA9IHRoaXMuX2RhdGE7XG5cdCAgICAgICAgICAgIHZhciBkYXRhV29yZHMgPSBkYXRhLndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgbkJpdHNUb3RhbCA9IHRoaXMuX25EYXRhQnl0ZXMgKiA4O1xuXHQgICAgICAgICAgICB2YXIgbkJpdHNMZWZ0ID0gZGF0YS5zaWdCeXRlcyAqIDg7XG5cdCAgICAgICAgICAgIHZhciBibG9ja1NpemVCaXRzID0gdGhpcy5ibG9ja1NpemUgKiAzMjtcblxuXHQgICAgICAgICAgICAvLyBBZGQgcGFkZGluZ1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbbkJpdHNMZWZ0ID4+PiA1XSB8PSAweDEgPDwgKDI0IC0gbkJpdHNMZWZ0ICUgMzIpO1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbKChNYXRoLmNlaWwoKG5CaXRzTGVmdCArIDEpIC8gYmxvY2tTaXplQml0cykgKiBibG9ja1NpemVCaXRzKSA+Pj4gNSkgLSAxXSB8PSAweDgwO1xuXHQgICAgICAgICAgICBkYXRhLnNpZ0J5dGVzID0gZGF0YVdvcmRzLmxlbmd0aCAqIDQ7XG5cblx0ICAgICAgICAgICAgLy8gSGFzaCBmaW5hbCBibG9ja3Ncblx0ICAgICAgICAgICAgdGhpcy5fcHJvY2VzcygpO1xuXG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgc3RhdGUgPSB0aGlzLl9zdGF0ZTtcblx0ICAgICAgICAgICAgdmFyIG91dHB1dExlbmd0aEJ5dGVzID0gdGhpcy5jZmcub3V0cHV0TGVuZ3RoIC8gODtcblx0ICAgICAgICAgICAgdmFyIG91dHB1dExlbmd0aExhbmVzID0gb3V0cHV0TGVuZ3RoQnl0ZXMgLyA4O1xuXG5cdCAgICAgICAgICAgIC8vIFNxdWVlemVcblx0ICAgICAgICAgICAgdmFyIGhhc2hXb3JkcyA9IFtdO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG91dHB1dExlbmd0aExhbmVzOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIGxhbmUgPSBzdGF0ZVtpXTtcblx0ICAgICAgICAgICAgICAgIHZhciBsYW5lTXN3ID0gbGFuZS5oaWdoO1xuXHQgICAgICAgICAgICAgICAgdmFyIGxhbmVMc3cgPSBsYW5lLmxvdztcblxuXHQgICAgICAgICAgICAgICAgLy8gU3dhcCBlbmRpYW5cblx0ICAgICAgICAgICAgICAgIGxhbmVNc3cgPSAoXG5cdCAgICAgICAgICAgICAgICAgICAgKCgobGFuZU1zdyA8PCA4KSAgfCAobGFuZU1zdyA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAoKChsYW5lTXN3IDw8IDI0KSB8IChsYW5lTXN3ID4+PiA4KSkgICYgMHhmZjAwZmYwMClcblx0ICAgICAgICAgICAgICAgICk7XG5cdCAgICAgICAgICAgICAgICBsYW5lTHN3ID0gKFxuXHQgICAgICAgICAgICAgICAgICAgICgoKGxhbmVMc3cgPDwgOCkgIHwgKGxhbmVMc3cgPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8XG5cdCAgICAgICAgICAgICAgICAgICAgKCgobGFuZUxzdyA8PCAyNCkgfCAobGFuZUxzdyA+Pj4gOCkpICAmIDB4ZmYwMGZmMDApXG5cdCAgICAgICAgICAgICAgICApO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBTcXVlZXplIHN0YXRlIHRvIHJldHJpZXZlIGhhc2hcblx0ICAgICAgICAgICAgICAgIGhhc2hXb3Jkcy5wdXNoKGxhbmVMc3cpO1xuXHQgICAgICAgICAgICAgICAgaGFzaFdvcmRzLnB1c2gobGFuZU1zdyk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBSZXR1cm4gZmluYWwgY29tcHV0ZWQgaGFzaFxuXHQgICAgICAgICAgICByZXR1cm4gbmV3IFdvcmRBcnJheS5pbml0KGhhc2hXb3Jkcywgb3V0cHV0TGVuZ3RoQnl0ZXMpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBjbG9uZTogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICB2YXIgY2xvbmUgPSBIYXNoZXIuY2xvbmUuY2FsbCh0aGlzKTtcblxuXHQgICAgICAgICAgICB2YXIgc3RhdGUgPSBjbG9uZS5fc3RhdGUgPSB0aGlzLl9zdGF0ZS5zbGljZSgwKTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNTsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICBzdGF0ZVtpXSA9IHN0YXRlW2ldLmNsb25lKCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gY2xvbmU7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb24gdG8gdGhlIGhhc2hlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgaGFzaC5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEEzKCdtZXNzYWdlJyk7XG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5TSEEzKHdvcmRBcnJheSk7XG5cdCAgICAgKi9cblx0ICAgIEMuU0hBMyA9IEhhc2hlci5fY3JlYXRlSGVscGVyKFNIQTMpO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30ga2V5IFRoZSBzZWNyZXQga2V5LlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIEhNQUMuXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBobWFjID0gQ3J5cHRvSlMuSG1hY1NIQTMobWVzc2FnZSwga2V5KTtcblx0ICAgICAqL1xuXHQgICAgQy5IbWFjU0hBMyA9IEhhc2hlci5fY3JlYXRlSG1hY0hlbHBlcihTSEEzKTtcblx0fShNYXRoKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMuU0hBMztcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3NoYTMuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5KSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdC8qKiBAcHJlc2VydmVcblx0KGMpIDIwMTIgYnkgQ8OpZHJpYyBNZXNuaWwuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG5cblx0UmVkaXN0cmlidXRpb24gYW5kIHVzZSBpbiBzb3VyY2UgYW5kIGJpbmFyeSBmb3Jtcywgd2l0aCBvciB3aXRob3V0IG1vZGlmaWNhdGlvbiwgYXJlIHBlcm1pdHRlZCBwcm92aWRlZCB0aGF0IHRoZSBmb2xsb3dpbmcgY29uZGl0aW9ucyBhcmUgbWV0OlxuXG5cdCAgICAtIFJlZGlzdHJpYnV0aW9ucyBvZiBzb3VyY2UgY29kZSBtdXN0IHJldGFpbiB0aGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSwgdGhpcyBsaXN0IG9mIGNvbmRpdGlvbnMgYW5kIHRoZSBmb2xsb3dpbmcgZGlzY2xhaW1lci5cblx0ICAgIC0gUmVkaXN0cmlidXRpb25zIGluIGJpbmFyeSBmb3JtIG11c3QgcmVwcm9kdWNlIHRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlLCB0aGlzIGxpc3Qgb2YgY29uZGl0aW9ucyBhbmQgdGhlIGZvbGxvd2luZyBkaXNjbGFpbWVyIGluIHRoZSBkb2N1bWVudGF0aW9uIGFuZC9vciBvdGhlciBtYXRlcmlhbHMgcHJvdmlkZWQgd2l0aCB0aGUgZGlzdHJpYnV0aW9uLlxuXG5cdFRISVMgU09GVFdBUkUgSVMgUFJPVklERUQgQlkgVEhFIENPUFlSSUdIVCBIT0xERVJTIEFORCBDT05UUklCVVRPUlMgXCJBUyBJU1wiIEFORCBBTlkgRVhQUkVTUyBPUiBJTVBMSUVEIFdBUlJBTlRJRVMsIElOQ0xVRElORywgQlVUIE5PVCBMSU1JVEVEIFRPLCBUSEUgSU1QTElFRCBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSBBTkQgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQVJFIERJU0NMQUlNRUQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBDT1BZUklHSFQgSE9MREVSIE9SIENPTlRSSUJVVE9SUyBCRSBMSUFCTEUgRk9SIEFOWSBESVJFQ1QsIElORElSRUNULCBJTkNJREVOVEFMLCBTUEVDSUFMLCBFWEVNUExBUlksIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyAoSU5DTFVESU5HLCBCVVQgTk9UIExJTUlURUQgVE8sIFBST0NVUkVNRU5UIE9GIFNVQlNUSVRVVEUgR09PRFMgT1IgU0VSVklDRVM7IExPU1MgT0YgVVNFLCBEQVRBLCBPUiBQUk9GSVRTOyBPUiBCVVNJTkVTUyBJTlRFUlJVUFRJT04pIEhPV0VWRVIgQ0FVU0VEIEFORCBPTiBBTlkgVEhFT1JZIE9GIExJQUJJTElUWSwgV0hFVEhFUiBJTiBDT05UUkFDVCwgU1RSSUNUIExJQUJJTElUWSwgT1IgVE9SVCAoSU5DTFVESU5HIE5FR0xJR0VOQ0UgT1IgT1RIRVJXSVNFKSBBUklTSU5HIElOIEFOWSBXQVkgT1VUIE9GIFRIRSBVU0UgT0YgVEhJUyBTT0ZUV0FSRSwgRVZFTiBJRiBBRFZJU0VEIE9GIFRIRSBQT1NTSUJJTElUWSBPRiBTVUNIIERBTUFHRS5cblx0Ki9cblxuXHQoZnVuY3Rpb24gKE1hdGgpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX2xpYiA9IEMubGliO1xuXHQgICAgdmFyIFdvcmRBcnJheSA9IENfbGliLldvcmRBcnJheTtcblx0ICAgIHZhciBIYXNoZXIgPSBDX2xpYi5IYXNoZXI7XG5cdCAgICB2YXIgQ19hbGdvID0gQy5hbGdvO1xuXG5cdCAgICAvLyBDb25zdGFudHMgdGFibGVcblx0ICAgIHZhciBfemwgPSBXb3JkQXJyYXkuY3JlYXRlKFtcblx0ICAgICAgICAwLCAgMSwgIDIsICAzLCAgNCwgIDUsICA2LCAgNywgIDgsICA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1LFxuXHQgICAgICAgIDcsICA0LCAxMywgIDEsIDEwLCAgNiwgMTUsICAzLCAxMiwgIDAsICA5LCAgNSwgIDIsIDE0LCAxMSwgIDgsXG5cdCAgICAgICAgMywgMTAsIDE0LCAgNCwgIDksIDE1LCAgOCwgIDEsICAyLCAgNywgIDAsICA2LCAxMywgMTEsICA1LCAxMixcblx0ICAgICAgICAxLCAgOSwgMTEsIDEwLCAgMCwgIDgsIDEyLCAgNCwgMTMsICAzLCAgNywgMTUsIDE0LCAgNSwgIDYsICAyLFxuXHQgICAgICAgIDQsICAwLCAgNSwgIDksICA3LCAxMiwgIDIsIDEwLCAxNCwgIDEsICAzLCAgOCwgMTEsICA2LCAxNSwgMTNdKTtcblx0ICAgIHZhciBfenIgPSBXb3JkQXJyYXkuY3JlYXRlKFtcblx0ICAgICAgICA1LCAxNCwgIDcsICAwLCAgOSwgIDIsIDExLCAgNCwgMTMsICA2LCAxNSwgIDgsICAxLCAxMCwgIDMsIDEyLFxuXHQgICAgICAgIDYsIDExLCAgMywgIDcsICAwLCAxMywgIDUsIDEwLCAxNCwgMTUsICA4LCAxMiwgIDQsICA5LCAgMSwgIDIsXG5cdCAgICAgICAgMTUsICA1LCAgMSwgIDMsICA3LCAxNCwgIDYsICA5LCAxMSwgIDgsIDEyLCAgMiwgMTAsICAwLCAgNCwgMTMsXG5cdCAgICAgICAgOCwgIDYsICA0LCAgMSwgIDMsIDExLCAxNSwgIDAsICA1LCAxMiwgIDIsIDEzLCAgOSwgIDcsIDEwLCAxNCxcblx0ICAgICAgICAxMiwgMTUsIDEwLCAgNCwgIDEsICA1LCAgOCwgIDcsICA2LCAgMiwgMTMsIDE0LCAgMCwgIDMsICA5LCAxMV0pO1xuXHQgICAgdmFyIF9zbCA9IFdvcmRBcnJheS5jcmVhdGUoW1xuXHQgICAgICAgICAxMSwgMTQsIDE1LCAxMiwgIDUsICA4LCAgNywgIDksIDExLCAxMywgMTQsIDE1LCAgNiwgIDcsICA5LCAgOCxcblx0ICAgICAgICA3LCA2LCAgIDgsIDEzLCAxMSwgIDksICA3LCAxNSwgIDcsIDEyLCAxNSwgIDksIDExLCAgNywgMTMsIDEyLFxuXHQgICAgICAgIDExLCAxMywgIDYsICA3LCAxNCwgIDksIDEzLCAxNSwgMTQsICA4LCAxMywgIDYsICA1LCAxMiwgIDcsICA1LFxuXHQgICAgICAgICAgMTEsIDEyLCAxNCwgMTUsIDE0LCAxNSwgIDksICA4LCAgOSwgMTQsICA1LCAgNiwgIDgsICA2LCAgNSwgMTIsXG5cdCAgICAgICAgOSwgMTUsICA1LCAxMSwgIDYsICA4LCAxMywgMTIsICA1LCAxMiwgMTMsIDE0LCAxMSwgIDgsICA1LCAgNiBdKTtcblx0ICAgIHZhciBfc3IgPSBXb3JkQXJyYXkuY3JlYXRlKFtcblx0ICAgICAgICA4LCAgOSwgIDksIDExLCAxMywgMTUsIDE1LCAgNSwgIDcsICA3LCAgOCwgMTEsIDE0LCAxNCwgMTIsICA2LFxuXHQgICAgICAgIDksIDEzLCAxNSwgIDcsIDEyLCAgOCwgIDksIDExLCAgNywgIDcsIDEyLCAgNywgIDYsIDE1LCAxMywgMTEsXG5cdCAgICAgICAgOSwgIDcsIDE1LCAxMSwgIDgsICA2LCAgNiwgMTQsIDEyLCAxMywgIDUsIDE0LCAxMywgMTMsICA3LCAgNSxcblx0ICAgICAgICAxNSwgIDUsICA4LCAxMSwgMTQsIDE0LCAgNiwgMTQsICA2LCAgOSwgMTIsICA5LCAxMiwgIDUsIDE1LCAgOCxcblx0ICAgICAgICA4LCAgNSwgMTIsICA5LCAxMiwgIDUsIDE0LCAgNiwgIDgsIDEzLCAgNiwgIDUsIDE1LCAxMywgMTEsIDExIF0pO1xuXG5cdCAgICB2YXIgX2hsID0gIFdvcmRBcnJheS5jcmVhdGUoWyAweDAwMDAwMDAwLCAweDVBODI3OTk5LCAweDZFRDlFQkExLCAweDhGMUJCQ0RDLCAweEE5NTNGRDRFXSk7XG5cdCAgICB2YXIgX2hyID0gIFdvcmRBcnJheS5jcmVhdGUoWyAweDUwQTI4QkU2LCAweDVDNEREMTI0LCAweDZENzAzRUYzLCAweDdBNkQ3NkU5LCAweDAwMDAwMDAwXSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogUklQRU1EMTYwIGhhc2ggYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgUklQRU1EMTYwID0gQ19hbGdvLlJJUEVNRDE2MCA9IEhhc2hlci5leHRlbmQoe1xuXHQgICAgICAgIF9kb1Jlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHRoaXMuX2hhc2ggID0gV29yZEFycmF5LmNyZWF0ZShbMHg2NzQ1MjMwMSwgMHhFRkNEQUI4OSwgMHg5OEJBRENGRSwgMHgxMDMyNTQ3NiwgMHhDM0QyRTFGMF0pO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9Qcm9jZXNzQmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblxuXHQgICAgICAgICAgICAvLyBTd2FwIGVuZGlhblxuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDE2OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIG9mZnNldF9pID0gb2Zmc2V0ICsgaTtcblx0ICAgICAgICAgICAgICAgIHZhciBNX29mZnNldF9pID0gTVtvZmZzZXRfaV07XG5cblx0ICAgICAgICAgICAgICAgIC8vIFN3YXBcblx0ICAgICAgICAgICAgICAgIE1bb2Zmc2V0X2ldID0gKFxuXHQgICAgICAgICAgICAgICAgICAgICgoKE1fb2Zmc2V0X2kgPDwgOCkgIHwgKE1fb2Zmc2V0X2kgPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8XG5cdCAgICAgICAgICAgICAgICAgICAgKCgoTV9vZmZzZXRfaSA8PCAyNCkgfCAoTV9vZmZzZXRfaSA+Pj4gOCkpICAmIDB4ZmYwMGZmMDApXG5cdCAgICAgICAgICAgICAgICApO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBIICA9IHRoaXMuX2hhc2gud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBobCA9IF9obC53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIGhyID0gX2hyLndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgemwgPSBfemwud29yZHM7XG5cdCAgICAgICAgICAgIHZhciB6ciA9IF96ci53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIHNsID0gX3NsLndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgc3IgPSBfc3Iud29yZHM7XG5cblx0ICAgICAgICAgICAgLy8gV29ya2luZyB2YXJpYWJsZXNcblx0ICAgICAgICAgICAgdmFyIGFsLCBibCwgY2wsIGRsLCBlbDtcblx0ICAgICAgICAgICAgdmFyIGFyLCBiciwgY3IsIGRyLCBlcjtcblxuXHQgICAgICAgICAgICBhciA9IGFsID0gSFswXTtcblx0ICAgICAgICAgICAgYnIgPSBibCA9IEhbMV07XG5cdCAgICAgICAgICAgIGNyID0gY2wgPSBIWzJdO1xuXHQgICAgICAgICAgICBkciA9IGRsID0gSFszXTtcblx0ICAgICAgICAgICAgZXIgPSBlbCA9IEhbNF07XG5cdCAgICAgICAgICAgIC8vIENvbXB1dGF0aW9uXG5cdCAgICAgICAgICAgIHZhciB0O1xuXHQgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDgwOyBpICs9IDEpIHtcblx0ICAgICAgICAgICAgICAgIHQgPSAoYWwgKyAgTVtvZmZzZXQremxbaV1dKXwwO1xuXHQgICAgICAgICAgICAgICAgaWYgKGk8MTYpe1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGYxKGJsLGNsLGRsKSArIGhsWzBdO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpPDMyKSB7XG5cdFx0ICAgICAgICAgICAgdCArPSAgZjIoYmwsY2wsZGwpICsgaGxbMV07XG5cdCAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGk8NDgpIHtcblx0XHQgICAgICAgICAgICB0ICs9ICBmMyhibCxjbCxkbCkgKyBobFsyXTtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaTw2NCkge1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGY0KGJsLGNsLGRsKSArIGhsWzNdO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIHsvLyBpZiAoaTw4MCkge1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGY1KGJsLGNsLGRsKSArIGhsWzRdO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgdCA9IHR8MDtcblx0ICAgICAgICAgICAgICAgIHQgPSAgcm90bCh0LHNsW2ldKTtcblx0ICAgICAgICAgICAgICAgIHQgPSAodCtlbCl8MDtcblx0ICAgICAgICAgICAgICAgIGFsID0gZWw7XG5cdCAgICAgICAgICAgICAgICBlbCA9IGRsO1xuXHQgICAgICAgICAgICAgICAgZGwgPSByb3RsKGNsLCAxMCk7XG5cdCAgICAgICAgICAgICAgICBjbCA9IGJsO1xuXHQgICAgICAgICAgICAgICAgYmwgPSB0O1xuXG5cdCAgICAgICAgICAgICAgICB0ID0gKGFyICsgTVtvZmZzZXQrenJbaV1dKXwwO1xuXHQgICAgICAgICAgICAgICAgaWYgKGk8MTYpe1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGY1KGJyLGNyLGRyKSArIGhyWzBdO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpPDMyKSB7XG5cdFx0ICAgICAgICAgICAgdCArPSAgZjQoYnIsY3IsZHIpICsgaHJbMV07XG5cdCAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGk8NDgpIHtcblx0XHQgICAgICAgICAgICB0ICs9ICBmMyhicixjcixkcikgKyBoclsyXTtcblx0ICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaTw2NCkge1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGYyKGJyLGNyLGRyKSArIGhyWzNdO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIHsvLyBpZiAoaTw4MCkge1xuXHRcdCAgICAgICAgICAgIHQgKz0gIGYxKGJyLGNyLGRyKSArIGhyWzRdO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgdCA9IHR8MDtcblx0ICAgICAgICAgICAgICAgIHQgPSAgcm90bCh0LHNyW2ldKSA7XG5cdCAgICAgICAgICAgICAgICB0ID0gKHQrZXIpfDA7XG5cdCAgICAgICAgICAgICAgICBhciA9IGVyO1xuXHQgICAgICAgICAgICAgICAgZXIgPSBkcjtcblx0ICAgICAgICAgICAgICAgIGRyID0gcm90bChjciwgMTApO1xuXHQgICAgICAgICAgICAgICAgY3IgPSBicjtcblx0ICAgICAgICAgICAgICAgIGJyID0gdDtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAvLyBJbnRlcm1lZGlhdGUgaGFzaCB2YWx1ZVxuXHQgICAgICAgICAgICB0ICAgID0gKEhbMV0gKyBjbCArIGRyKXwwO1xuXHQgICAgICAgICAgICBIWzFdID0gKEhbMl0gKyBkbCArIGVyKXwwO1xuXHQgICAgICAgICAgICBIWzJdID0gKEhbM10gKyBlbCArIGFyKXwwO1xuXHQgICAgICAgICAgICBIWzNdID0gKEhbNF0gKyBhbCArIGJyKXwwO1xuXHQgICAgICAgICAgICBIWzRdID0gKEhbMF0gKyBibCArIGNyKXwwO1xuXHQgICAgICAgICAgICBIWzBdID0gIHQ7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb0ZpbmFsaXplOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgZGF0YSA9IHRoaXMuX2RhdGE7XG5cdCAgICAgICAgICAgIHZhciBkYXRhV29yZHMgPSBkYXRhLndvcmRzO1xuXG5cdCAgICAgICAgICAgIHZhciBuQml0c1RvdGFsID0gdGhpcy5fbkRhdGFCeXRlcyAqIDg7XG5cdCAgICAgICAgICAgIHZhciBuQml0c0xlZnQgPSBkYXRhLnNpZ0J5dGVzICogODtcblxuXHQgICAgICAgICAgICAvLyBBZGQgcGFkZGluZ1xuXHQgICAgICAgICAgICBkYXRhV29yZHNbbkJpdHNMZWZ0ID4+PiA1XSB8PSAweDgwIDw8ICgyNCAtIG5CaXRzTGVmdCAlIDMyKTtcblx0ICAgICAgICAgICAgZGF0YVdvcmRzWygoKG5CaXRzTGVmdCArIDY0KSA+Pj4gOSkgPDwgNCkgKyAxNF0gPSAoXG5cdCAgICAgICAgICAgICAgICAoKChuQml0c1RvdGFsIDw8IDgpICB8IChuQml0c1RvdGFsID4+PiAyNCkpICYgMHgwMGZmMDBmZikgfFxuXHQgICAgICAgICAgICAgICAgKCgobkJpdHNUb3RhbCA8PCAyNCkgfCAobkJpdHNUb3RhbCA+Pj4gOCkpICAmIDB4ZmYwMGZmMDApXG5cdCAgICAgICAgICAgICk7XG5cdCAgICAgICAgICAgIGRhdGEuc2lnQnl0ZXMgPSAoZGF0YVdvcmRzLmxlbmd0aCArIDEpICogNDtcblxuXHQgICAgICAgICAgICAvLyBIYXNoIGZpbmFsIGJsb2Nrc1xuXHQgICAgICAgICAgICB0aGlzLl9wcm9jZXNzKCk7XG5cblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBoYXNoID0gdGhpcy5faGFzaDtcblx0ICAgICAgICAgICAgdmFyIEggPSBoYXNoLndvcmRzO1xuXG5cdCAgICAgICAgICAgIC8vIFN3YXAgZW5kaWFuXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNTsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgICAgICAgICAgdmFyIEhfaSA9IEhbaV07XG5cblx0ICAgICAgICAgICAgICAgIC8vIFN3YXBcblx0ICAgICAgICAgICAgICAgIEhbaV0gPSAoKChIX2kgPDwgOCkgIHwgKEhfaSA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAgICAoKChIX2kgPDwgMjQpIHwgKEhfaSA+Pj4gOCkpICAmIDB4ZmYwMGZmMDApO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gUmV0dXJuIGZpbmFsIGNvbXB1dGVkIGhhc2hcblx0ICAgICAgICAgICAgcmV0dXJuIGhhc2g7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGNsb25lOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIHZhciBjbG9uZSA9IEhhc2hlci5jbG9uZS5jYWxsKHRoaXMpO1xuXHQgICAgICAgICAgICBjbG9uZS5faGFzaCA9IHRoaXMuX2hhc2guY2xvbmUoKTtcblxuXHQgICAgICAgICAgICByZXR1cm4gY2xvbmU7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblxuXHQgICAgZnVuY3Rpb24gZjEoeCwgeSwgeikge1xuXHQgICAgICAgIHJldHVybiAoKHgpIF4gKHkpIF4gKHopKTtcblxuXHQgICAgfVxuXG5cdCAgICBmdW5jdGlvbiBmMih4LCB5LCB6KSB7XG5cdCAgICAgICAgcmV0dXJuICgoKHgpJih5KSkgfCAoKH54KSYoeikpKTtcblx0ICAgIH1cblxuXHQgICAgZnVuY3Rpb24gZjMoeCwgeSwgeikge1xuXHQgICAgICAgIHJldHVybiAoKCh4KSB8ICh+KHkpKSkgXiAoeikpO1xuXHQgICAgfVxuXG5cdCAgICBmdW5jdGlvbiBmNCh4LCB5LCB6KSB7XG5cdCAgICAgICAgcmV0dXJuICgoKHgpICYgKHopKSB8ICgoeSkmKH4oeikpKSk7XG5cdCAgICB9XG5cblx0ICAgIGZ1bmN0aW9uIGY1KHgsIHksIHopIHtcblx0ICAgICAgICByZXR1cm4gKCh4KSBeICgoeSkgfCh+KHopKSkpO1xuXG5cdCAgICB9XG5cblx0ICAgIGZ1bmN0aW9uIHJvdGwoeCxuKSB7XG5cdCAgICAgICAgcmV0dXJuICh4PDxuKSB8ICh4Pj4+KDMyLW4pKTtcblx0ICAgIH1cblxuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBoYXNoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBoYXNoLlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIGhhc2guXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBoYXNoID0gQ3J5cHRvSlMuUklQRU1EMTYwKCdtZXNzYWdlJyk7XG5cdCAgICAgKiAgICAgdmFyIGhhc2ggPSBDcnlwdG9KUy5SSVBFTUQxNjAod29yZEFycmF5KTtcblx0ICAgICAqL1xuXHQgICAgQy5SSVBFTUQxNjAgPSBIYXNoZXIuX2NyZWF0ZUhlbHBlcihSSVBFTUQxNjApO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9uIHRvIHRoZSBITUFDJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gaGFzaC5cblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30ga2V5IFRoZSBzZWNyZXQga2V5LlxuXHQgICAgICpcblx0ICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIEhNQUMuXG5cdCAgICAgKlxuXHQgICAgICogQHN0YXRpY1xuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBobWFjID0gQ3J5cHRvSlMuSG1hY1JJUEVNRDE2MChtZXNzYWdlLCBrZXkpO1xuXHQgICAgICovXG5cdCAgICBDLkhtYWNSSVBFTUQxNjAgPSBIYXNoZXIuX2NyZWF0ZUhtYWNIZWxwZXIoUklQRU1EMTYwKTtcblx0fShNYXRoKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMuUklQRU1EMTYwO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvcmlwZW1kMTYwLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSkge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgQmFzZSA9IENfbGliLkJhc2U7XG5cdCAgICB2YXIgQ19lbmMgPSBDLmVuYztcblx0ICAgIHZhciBVdGY4ID0gQ19lbmMuVXRmODtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cblx0ICAgIC8qKlxuXHQgICAgICogSE1BQyBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBITUFDID0gQ19hbGdvLkhNQUMgPSBCYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogSW5pdGlhbGl6ZXMgYSBuZXdseSBjcmVhdGVkIEhNQUMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0hhc2hlcn0gaGFzaGVyIFRoZSBoYXNoIGFsZ29yaXRobSB0byB1c2UuXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBrZXkgVGhlIHNlY3JldCBrZXkuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBobWFjSGFzaGVyID0gQ3J5cHRvSlMuYWxnby5ITUFDLmNyZWF0ZShDcnlwdG9KUy5hbGdvLlNIQTI1Niwga2V5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBpbml0OiBmdW5jdGlvbiAoaGFzaGVyLCBrZXkpIHtcblx0ICAgICAgICAgICAgLy8gSW5pdCBoYXNoZXJcblx0ICAgICAgICAgICAgaGFzaGVyID0gdGhpcy5faGFzaGVyID0gbmV3IGhhc2hlci5pbml0KCk7XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydCBzdHJpbmcgdG8gV29yZEFycmF5LCBlbHNlIGFzc3VtZSBXb3JkQXJyYXkgYWxyZWFkeVxuXHQgICAgICAgICAgICBpZiAodHlwZW9mIGtleSA9PSAnc3RyaW5nJykge1xuXHQgICAgICAgICAgICAgICAga2V5ID0gVXRmOC5wYXJzZShrZXkpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBoYXNoZXJCbG9ja1NpemUgPSBoYXNoZXIuYmxvY2tTaXplO1xuXHQgICAgICAgICAgICB2YXIgaGFzaGVyQmxvY2tTaXplQnl0ZXMgPSBoYXNoZXJCbG9ja1NpemUgKiA0O1xuXG5cdCAgICAgICAgICAgIC8vIEFsbG93IGFyYml0cmFyeSBsZW5ndGgga2V5c1xuXHQgICAgICAgICAgICBpZiAoa2V5LnNpZ0J5dGVzID4gaGFzaGVyQmxvY2tTaXplQnl0ZXMpIHtcblx0ICAgICAgICAgICAgICAgIGtleSA9IGhhc2hlci5maW5hbGl6ZShrZXkpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gQ2xhbXAgZXhjZXNzIGJpdHNcblx0ICAgICAgICAgICAga2V5LmNsYW1wKCk7XG5cblx0ICAgICAgICAgICAgLy8gQ2xvbmUga2V5IGZvciBpbm5lciBhbmQgb3V0ZXIgcGFkc1xuXHQgICAgICAgICAgICB2YXIgb0tleSA9IHRoaXMuX29LZXkgPSBrZXkuY2xvbmUoKTtcblx0ICAgICAgICAgICAgdmFyIGlLZXkgPSB0aGlzLl9pS2V5ID0ga2V5LmNsb25lKCk7XG5cblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBvS2V5V29yZHMgPSBvS2V5LndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgaUtleVdvcmRzID0gaUtleS53b3JkcztcblxuXHQgICAgICAgICAgICAvLyBYT1Iga2V5cyB3aXRoIHBhZCBjb25zdGFudHNcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBoYXNoZXJCbG9ja1NpemU7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgb0tleVdvcmRzW2ldIF49IDB4NWM1YzVjNWM7XG5cdCAgICAgICAgICAgICAgICBpS2V5V29yZHNbaV0gXj0gMHgzNjM2MzYzNjtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICBvS2V5LnNpZ0J5dGVzID0gaUtleS5zaWdCeXRlcyA9IGhhc2hlckJsb2NrU2l6ZUJ5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIFNldCBpbml0aWFsIHZhbHVlc1xuXHQgICAgICAgICAgICB0aGlzLnJlc2V0KCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIFJlc2V0cyB0aGlzIEhNQUMgdG8gaXRzIGluaXRpYWwgc3RhdGUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIGhtYWNIYXNoZXIucmVzZXQoKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICByZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgICAgICB2YXIgaGFzaGVyID0gdGhpcy5faGFzaGVyO1xuXG5cdCAgICAgICAgICAgIC8vIFJlc2V0XG5cdCAgICAgICAgICAgIGhhc2hlci5yZXNldCgpO1xuXHQgICAgICAgICAgICBoYXNoZXIudXBkYXRlKHRoaXMuX2lLZXkpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBVcGRhdGVzIHRoaXMgSE1BQyB3aXRoIGEgbWVzc2FnZS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZVVwZGF0ZSBUaGUgbWVzc2FnZSB0byBhcHBlbmQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtITUFDfSBUaGlzIEhNQUMgaW5zdGFuY2UuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIGhtYWNIYXNoZXIudXBkYXRlKCdtZXNzYWdlJyk7XG5cdCAgICAgICAgICogICAgIGhtYWNIYXNoZXIudXBkYXRlKHdvcmRBcnJheSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgdXBkYXRlOiBmdW5jdGlvbiAobWVzc2FnZVVwZGF0ZSkge1xuXHQgICAgICAgICAgICB0aGlzLl9oYXNoZXIudXBkYXRlKG1lc3NhZ2VVcGRhdGUpO1xuXG5cdCAgICAgICAgICAgIC8vIENoYWluYWJsZVxuXHQgICAgICAgICAgICByZXR1cm4gdGhpcztcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogRmluYWxpemVzIHRoZSBITUFDIGNvbXB1dGF0aW9uLlxuXHQgICAgICAgICAqIE5vdGUgdGhhdCB0aGUgZmluYWxpemUgb3BlcmF0aW9uIGlzIGVmZmVjdGl2ZWx5IGEgZGVzdHJ1Y3RpdmUsIHJlYWQtb25jZSBvcGVyYXRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IG1lc3NhZ2VVcGRhdGUgKE9wdGlvbmFsKSBBIGZpbmFsIG1lc3NhZ2UgdXBkYXRlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgSE1BQy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGhtYWMgPSBobWFjSGFzaGVyLmZpbmFsaXplKCk7XG5cdCAgICAgICAgICogICAgIHZhciBobWFjID0gaG1hY0hhc2hlci5maW5hbGl6ZSgnbWVzc2FnZScpO1xuXHQgICAgICAgICAqICAgICB2YXIgaG1hYyA9IGhtYWNIYXNoZXIuZmluYWxpemUod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBmaW5hbGl6ZTogZnVuY3Rpb24gKG1lc3NhZ2VVcGRhdGUpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIGhhc2hlciA9IHRoaXMuX2hhc2hlcjtcblxuXHQgICAgICAgICAgICAvLyBDb21wdXRlIEhNQUNcblx0ICAgICAgICAgICAgdmFyIGlubmVySGFzaCA9IGhhc2hlci5maW5hbGl6ZShtZXNzYWdlVXBkYXRlKTtcblx0ICAgICAgICAgICAgaGFzaGVyLnJlc2V0KCk7XG5cdCAgICAgICAgICAgIHZhciBobWFjID0gaGFzaGVyLmZpbmFsaXplKHRoaXMuX29LZXkuY2xvbmUoKS5jb25jYXQoaW5uZXJIYXNoKSk7XG5cblx0ICAgICAgICAgICAgcmV0dXJuIGhtYWM7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cdH0oKSk7XG5cblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL2htYWMuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4vc2hhMVwiKSwgcmVxdWlyZShcIi4vaG1hY1wiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCIsIFwiLi9zaGExXCIsIFwiLi9obWFjXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgQmFzZSA9IENfbGliLkJhc2U7XG5cdCAgICB2YXIgV29yZEFycmF5ID0gQ19saWIuV29yZEFycmF5O1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblx0ICAgIHZhciBTSEExID0gQ19hbGdvLlNIQTE7XG5cdCAgICB2YXIgSE1BQyA9IENfYWxnby5ITUFDO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFBhc3N3b3JkLUJhc2VkIEtleSBEZXJpdmF0aW9uIEZ1bmN0aW9uIDIgYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgUEJLREYyID0gQ19hbGdvLlBCS0RGMiA9IEJhc2UuZXh0ZW5kKHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb25maWd1cmF0aW9uIG9wdGlvbnMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcn0ga2V5U2l6ZSBUaGUga2V5IHNpemUgaW4gd29yZHMgdG8gZ2VuZXJhdGUuIERlZmF1bHQ6IDQgKDEyOCBiaXRzKVxuXHQgICAgICAgICAqIEBwcm9wZXJ0eSB7SGFzaGVyfSBoYXNoZXIgVGhlIGhhc2hlciB0byB1c2UuIERlZmF1bHQ6IFNIQTFcblx0ICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcn0gaXRlcmF0aW9ucyBUaGUgbnVtYmVyIG9mIGl0ZXJhdGlvbnMgdG8gcGVyZm9ybS4gRGVmYXVsdDogMVxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGNmZzogQmFzZS5leHRlbmQoe1xuXHQgICAgICAgICAgICBrZXlTaXplOiAxMjgvMzIsXG5cdCAgICAgICAgICAgIGhhc2hlcjogU0hBMSxcblx0ICAgICAgICAgICAgaXRlcmF0aW9uczogMVxuXHQgICAgICAgIH0pLFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogSW5pdGlhbGl6ZXMgYSBuZXdseSBjcmVhdGVkIGtleSBkZXJpdmF0aW9uIGZ1bmN0aW9uLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNmZyAoT3B0aW9uYWwpIFRoZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgdG8gdXNlIGZvciB0aGUgZGVyaXZhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGtkZiA9IENyeXB0b0pTLmFsZ28uUEJLREYyLmNyZWF0ZSgpO1xuXHQgICAgICAgICAqICAgICB2YXIga2RmID0gQ3J5cHRvSlMuYWxnby5QQktERjIuY3JlYXRlKHsga2V5U2l6ZTogOCB9KTtcblx0ICAgICAgICAgKiAgICAgdmFyIGtkZiA9IENyeXB0b0pTLmFsZ28uUEJLREYyLmNyZWF0ZSh7IGtleVNpemU6IDgsIGl0ZXJhdGlvbnM6IDEwMDAgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgaW5pdDogZnVuY3Rpb24gKGNmZykge1xuXHQgICAgICAgICAgICB0aGlzLmNmZyA9IHRoaXMuY2ZnLmV4dGVuZChjZmcpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb21wdXRlcyB0aGUgUGFzc3dvcmQtQmFzZWQgS2V5IERlcml2YXRpb24gRnVuY3Rpb24gMi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gcGFzc3dvcmQgVGhlIHBhc3N3b3JkLlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gc2FsdCBBIHNhbHQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBkZXJpdmVkIGtleS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGtleSA9IGtkZi5jb21wdXRlKHBhc3N3b3JkLCBzYWx0KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjb21wdXRlOiBmdW5jdGlvbiAocGFzc3dvcmQsIHNhbHQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIGNmZyA9IHRoaXMuY2ZnO1xuXG5cdCAgICAgICAgICAgIC8vIEluaXQgSE1BQ1xuXHQgICAgICAgICAgICB2YXIgaG1hYyA9IEhNQUMuY3JlYXRlKGNmZy5oYXNoZXIsIHBhc3N3b3JkKTtcblxuXHQgICAgICAgICAgICAvLyBJbml0aWFsIHZhbHVlc1xuXHQgICAgICAgICAgICB2YXIgZGVyaXZlZEtleSA9IFdvcmRBcnJheS5jcmVhdGUoKTtcblx0ICAgICAgICAgICAgdmFyIGJsb2NrSW5kZXggPSBXb3JkQXJyYXkuY3JlYXRlKFsweDAwMDAwMDAxXSk7XG5cblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBkZXJpdmVkS2V5V29yZHMgPSBkZXJpdmVkS2V5LndvcmRzO1xuXHQgICAgICAgICAgICB2YXIgYmxvY2tJbmRleFdvcmRzID0gYmxvY2tJbmRleC53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIGtleVNpemUgPSBjZmcua2V5U2l6ZTtcblx0ICAgICAgICAgICAgdmFyIGl0ZXJhdGlvbnMgPSBjZmcuaXRlcmF0aW9ucztcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBrZXlcblx0ICAgICAgICAgICAgd2hpbGUgKGRlcml2ZWRLZXlXb3Jkcy5sZW5ndGggPCBrZXlTaXplKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIgYmxvY2sgPSBobWFjLnVwZGF0ZShzYWx0KS5maW5hbGl6ZShibG9ja0luZGV4KTtcblx0ICAgICAgICAgICAgICAgIGhtYWMucmVzZXQoKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgICAgICB2YXIgYmxvY2tXb3JkcyA9IGJsb2NrLndvcmRzO1xuXHQgICAgICAgICAgICAgICAgdmFyIGJsb2NrV29yZHNMZW5ndGggPSBibG9ja1dvcmRzLmxlbmd0aDtcblxuXHQgICAgICAgICAgICAgICAgLy8gSXRlcmF0aW9uc1xuXHQgICAgICAgICAgICAgICAgdmFyIGludGVybWVkaWF0ZSA9IGJsb2NrO1xuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBpdGVyYXRpb25zOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgICAgICBpbnRlcm1lZGlhdGUgPSBobWFjLmZpbmFsaXplKGludGVybWVkaWF0ZSk7XG5cdCAgICAgICAgICAgICAgICAgICAgaG1hYy5yZXNldCgpO1xuXG5cdCAgICAgICAgICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgaW50ZXJtZWRpYXRlV29yZHMgPSBpbnRlcm1lZGlhdGUud29yZHM7XG5cblx0ICAgICAgICAgICAgICAgICAgICAvLyBYT1IgaW50ZXJtZWRpYXRlIHdpdGggYmxvY2tcblx0ICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGJsb2NrV29yZHNMZW5ndGg7IGorKykge1xuXHQgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1dvcmRzW2pdIF49IGludGVybWVkaWF0ZVdvcmRzW2pdO1xuXHQgICAgICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgZGVyaXZlZEtleS5jb25jYXQoYmxvY2spO1xuXHQgICAgICAgICAgICAgICAgYmxvY2tJbmRleFdvcmRzWzBdKys7XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgZGVyaXZlZEtleS5zaWdCeXRlcyA9IGtleVNpemUgKiA0O1xuXG5cdCAgICAgICAgICAgIHJldHVybiBkZXJpdmVkS2V5O1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIENvbXB1dGVzIHRoZSBQYXNzd29yZC1CYXNlZCBLZXkgRGVyaXZhdGlvbiBGdW5jdGlvbiAyLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gcGFzc3dvcmQgVGhlIHBhc3N3b3JkLlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBzYWx0IEEgc2FsdC5cblx0ICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjZmcgKE9wdGlvbmFsKSBUaGUgY29uZmlndXJhdGlvbiBvcHRpb25zIHRvIHVzZSBmb3IgdGhpcyBjb21wdXRhdGlvbi5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBkZXJpdmVkIGtleS5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGtleSA9IENyeXB0b0pTLlBCS0RGMihwYXNzd29yZCwgc2FsdCk7XG5cdCAgICAgKiAgICAgdmFyIGtleSA9IENyeXB0b0pTLlBCS0RGMihwYXNzd29yZCwgc2FsdCwgeyBrZXlTaXplOiA4IH0pO1xuXHQgICAgICogICAgIHZhciBrZXkgPSBDcnlwdG9KUy5QQktERjIocGFzc3dvcmQsIHNhbHQsIHsga2V5U2l6ZTogOCwgaXRlcmF0aW9uczogMTAwMCB9KTtcblx0ICAgICAqL1xuXHQgICAgQy5QQktERjIgPSBmdW5jdGlvbiAocGFzc3dvcmQsIHNhbHQsIGNmZykge1xuXHQgICAgICAgIHJldHVybiBQQktERjIuY3JlYXRlKGNmZykuY29tcHV0ZShwYXNzd29yZCwgc2FsdCk7XG5cdCAgICB9O1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLlBCS0RGMjtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3Bia2RmMi5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9zaGExXCIpLCByZXF1aXJlKFwiLi9obWFjXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL3NoYTFcIiwgXCIuL2htYWNcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdChmdW5jdGlvbiAoKSB7XG5cdCAgICAvLyBTaG9ydGN1dHNcblx0ICAgIHZhciBDID0gQ3J5cHRvSlM7XG5cdCAgICB2YXIgQ19saWIgPSBDLmxpYjtcblx0ICAgIHZhciBCYXNlID0gQ19saWIuQmFzZTtcblx0ICAgIHZhciBXb3JkQXJyYXkgPSBDX2xpYi5Xb3JkQXJyYXk7XG5cdCAgICB2YXIgQ19hbGdvID0gQy5hbGdvO1xuXHQgICAgdmFyIE1ENSA9IENfYWxnby5NRDU7XG5cblx0ICAgIC8qKlxuXHQgICAgICogVGhpcyBrZXkgZGVyaXZhdGlvbiBmdW5jdGlvbiBpcyBtZWFudCB0byBjb25mb3JtIHdpdGggRVZQX0J5dGVzVG9LZXkuXG5cdCAgICAgKiB3d3cub3BlbnNzbC5vcmcvZG9jcy9jcnlwdG8vRVZQX0J5dGVzVG9LZXkuaHRtbFxuXHQgICAgICovXG5cdCAgICB2YXIgRXZwS0RGID0gQ19hbGdvLkV2cEtERiA9IEJhc2UuZXh0ZW5kKHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb25maWd1cmF0aW9uIG9wdGlvbnMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcn0ga2V5U2l6ZSBUaGUga2V5IHNpemUgaW4gd29yZHMgdG8gZ2VuZXJhdGUuIERlZmF1bHQ6IDQgKDEyOCBiaXRzKVxuXHQgICAgICAgICAqIEBwcm9wZXJ0eSB7SGFzaGVyfSBoYXNoZXIgVGhlIGhhc2ggYWxnb3JpdGhtIHRvIHVzZS4gRGVmYXVsdDogTUQ1XG5cdCAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IGl0ZXJhdGlvbnMgVGhlIG51bWJlciBvZiBpdGVyYXRpb25zIHRvIHBlcmZvcm0uIERlZmF1bHQ6IDFcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjZmc6IEJhc2UuZXh0ZW5kKHtcblx0ICAgICAgICAgICAga2V5U2l6ZTogMTI4LzMyLFxuXHQgICAgICAgICAgICBoYXNoZXI6IE1ENSxcblx0ICAgICAgICAgICAgaXRlcmF0aW9uczogMVxuXHQgICAgICAgIH0pLFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogSW5pdGlhbGl6ZXMgYSBuZXdseSBjcmVhdGVkIGtleSBkZXJpdmF0aW9uIGZ1bmN0aW9uLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNmZyAoT3B0aW9uYWwpIFRoZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgdG8gdXNlIGZvciB0aGUgZGVyaXZhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGtkZiA9IENyeXB0b0pTLmFsZ28uRXZwS0RGLmNyZWF0ZSgpO1xuXHQgICAgICAgICAqICAgICB2YXIga2RmID0gQ3J5cHRvSlMuYWxnby5FdnBLREYuY3JlYXRlKHsga2V5U2l6ZTogOCB9KTtcblx0ICAgICAgICAgKiAgICAgdmFyIGtkZiA9IENyeXB0b0pTLmFsZ28uRXZwS0RGLmNyZWF0ZSh7IGtleVNpemU6IDgsIGl0ZXJhdGlvbnM6IDEwMDAgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgaW5pdDogZnVuY3Rpb24gKGNmZykge1xuXHQgICAgICAgICAgICB0aGlzLmNmZyA9IHRoaXMuY2ZnLmV4dGVuZChjZmcpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBEZXJpdmVzIGEga2V5IGZyb20gYSBwYXNzd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gcGFzc3dvcmQgVGhlIHBhc3N3b3JkLlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gc2FsdCBBIHNhbHQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBkZXJpdmVkIGtleS5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGtleSA9IGtkZi5jb21wdXRlKHBhc3N3b3JkLCBzYWx0KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjb21wdXRlOiBmdW5jdGlvbiAocGFzc3dvcmQsIHNhbHQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIGNmZyA9IHRoaXMuY2ZnO1xuXG5cdCAgICAgICAgICAgIC8vIEluaXQgaGFzaGVyXG5cdCAgICAgICAgICAgIHZhciBoYXNoZXIgPSBjZmcuaGFzaGVyLmNyZWF0ZSgpO1xuXG5cdCAgICAgICAgICAgIC8vIEluaXRpYWwgdmFsdWVzXG5cdCAgICAgICAgICAgIHZhciBkZXJpdmVkS2V5ID0gV29yZEFycmF5LmNyZWF0ZSgpO1xuXG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgZGVyaXZlZEtleVdvcmRzID0gZGVyaXZlZEtleS53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIGtleVNpemUgPSBjZmcua2V5U2l6ZTtcblx0ICAgICAgICAgICAgdmFyIGl0ZXJhdGlvbnMgPSBjZmcuaXRlcmF0aW9ucztcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBrZXlcblx0ICAgICAgICAgICAgd2hpbGUgKGRlcml2ZWRLZXlXb3Jkcy5sZW5ndGggPCBrZXlTaXplKSB7XG5cdCAgICAgICAgICAgICAgICBpZiAoYmxvY2spIHtcblx0ICAgICAgICAgICAgICAgICAgICBoYXNoZXIudXBkYXRlKGJsb2NrKTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgICAgIHZhciBibG9jayA9IGhhc2hlci51cGRhdGUocGFzc3dvcmQpLmZpbmFsaXplKHNhbHQpO1xuXHQgICAgICAgICAgICAgICAgaGFzaGVyLnJlc2V0KCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIEl0ZXJhdGlvbnNcblx0ICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgaXRlcmF0aW9uczsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgYmxvY2sgPSBoYXNoZXIuZmluYWxpemUoYmxvY2spO1xuXHQgICAgICAgICAgICAgICAgICAgIGhhc2hlci5yZXNldCgpO1xuXHQgICAgICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgICAgICBkZXJpdmVkS2V5LmNvbmNhdChibG9jayk7XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgZGVyaXZlZEtleS5zaWdCeXRlcyA9IGtleVNpemUgKiA0O1xuXG5cdCAgICAgICAgICAgIHJldHVybiBkZXJpdmVkS2V5O1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIERlcml2ZXMgYSBrZXkgZnJvbSBhIHBhc3N3b3JkLlxuXHQgICAgICpcblx0ICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gcGFzc3dvcmQgVGhlIHBhc3N3b3JkLlxuXHQgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBzYWx0IEEgc2FsdC5cblx0ICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjZmcgKE9wdGlvbmFsKSBUaGUgY29uZmlndXJhdGlvbiBvcHRpb25zIHRvIHVzZSBmb3IgdGhpcyBjb21wdXRhdGlvbi5cblx0ICAgICAqXG5cdCAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBkZXJpdmVkIGtleS5cblx0ICAgICAqXG5cdCAgICAgKiBAc3RhdGljXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGtleSA9IENyeXB0b0pTLkV2cEtERihwYXNzd29yZCwgc2FsdCk7XG5cdCAgICAgKiAgICAgdmFyIGtleSA9IENyeXB0b0pTLkV2cEtERihwYXNzd29yZCwgc2FsdCwgeyBrZXlTaXplOiA4IH0pO1xuXHQgICAgICogICAgIHZhciBrZXkgPSBDcnlwdG9KUy5FdnBLREYocGFzc3dvcmQsIHNhbHQsIHsga2V5U2l6ZTogOCwgaXRlcmF0aW9uczogMTAwMCB9KTtcblx0ICAgICAqL1xuXHQgICAgQy5FdnBLREYgPSBmdW5jdGlvbiAocGFzc3dvcmQsIHNhbHQsIGNmZykge1xuXHQgICAgICAgIHJldHVybiBFdnBLREYuY3JlYXRlKGNmZykuY29tcHV0ZShwYXNzd29yZCwgc2FsdCk7XG5cdCAgICB9O1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLkV2cEtERjtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL2V2cGtkZi5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9ldnBrZGZcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vZXZwa2RmXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogQ2lwaGVyIGNvcmUgY29tcG9uZW50cy5cblx0ICovXG5cdENyeXB0b0pTLmxpYi5DaXBoZXIgfHwgKGZ1bmN0aW9uICh1bmRlZmluZWQpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX2xpYiA9IEMubGliO1xuXHQgICAgdmFyIEJhc2UgPSBDX2xpYi5CYXNlO1xuXHQgICAgdmFyIFdvcmRBcnJheSA9IENfbGliLldvcmRBcnJheTtcblx0ICAgIHZhciBCdWZmZXJlZEJsb2NrQWxnb3JpdGhtID0gQ19saWIuQnVmZmVyZWRCbG9ja0FsZ29yaXRobTtcblx0ICAgIHZhciBDX2VuYyA9IEMuZW5jO1xuXHQgICAgdmFyIFV0ZjggPSBDX2VuYy5VdGY4O1xuXHQgICAgdmFyIEJhc2U2NCA9IENfZW5jLkJhc2U2NDtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cdCAgICB2YXIgRXZwS0RGID0gQ19hbGdvLkV2cEtERjtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBBYnN0cmFjdCBiYXNlIGNpcGhlciB0ZW1wbGF0ZS5cblx0ICAgICAqXG5cdCAgICAgKiBAcHJvcGVydHkge251bWJlcn0ga2V5U2l6ZSBUaGlzIGNpcGhlcidzIGtleSBzaXplLiBEZWZhdWx0OiA0ICgxMjggYml0cylcblx0ICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBpdlNpemUgVGhpcyBjaXBoZXIncyBJViBzaXplLiBEZWZhdWx0OiA0ICgxMjggYml0cylcblx0ICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBfRU5DX1hGT1JNX01PREUgQSBjb25zdGFudCByZXByZXNlbnRpbmcgZW5jcnlwdGlvbiBtb2RlLlxuXHQgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IF9ERUNfWEZPUk1fTU9ERSBBIGNvbnN0YW50IHJlcHJlc2VudGluZyBkZWNyeXB0aW9uIG1vZGUuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDaXBoZXIgPSBDX2xpYi5DaXBoZXIgPSBCdWZmZXJlZEJsb2NrQWxnb3JpdGhtLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtXb3JkQXJyYXl9IGl2IFRoZSBJViB0byB1c2UgZm9yIHRoaXMgb3BlcmF0aW9uLlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGNmZzogQmFzZS5leHRlbmQoKSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENyZWF0ZXMgdGhpcyBjaXBoZXIgaW4gZW5jcnlwdGlvbiBtb2RlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IGtleSBUaGUga2V5LlxuXHQgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjZmcgKE9wdGlvbmFsKSBUaGUgY29uZmlndXJhdGlvbiBvcHRpb25zIHRvIHVzZSBmb3IgdGhpcyBvcGVyYXRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtDaXBoZXJ9IEEgY2lwaGVyIGluc3RhbmNlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVyID0gQ3J5cHRvSlMuYWxnby5BRVMuY3JlYXRlRW5jcnlwdG9yKGtleVdvcmRBcnJheSwgeyBpdjogaXZXb3JkQXJyYXkgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY3JlYXRlRW5jcnlwdG9yOiBmdW5jdGlvbiAoa2V5LCBjZmcpIHtcblx0ICAgICAgICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlKHRoaXMuX0VOQ19YRk9STV9NT0RFLCBrZXksIGNmZyk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENyZWF0ZXMgdGhpcyBjaXBoZXIgaW4gZGVjcnlwdGlvbiBtb2RlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IGtleSBUaGUga2V5LlxuXHQgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjZmcgKE9wdGlvbmFsKSBUaGUgY29uZmlndXJhdGlvbiBvcHRpb25zIHRvIHVzZSBmb3IgdGhpcyBvcGVyYXRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtDaXBoZXJ9IEEgY2lwaGVyIGluc3RhbmNlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVyID0gQ3J5cHRvSlMuYWxnby5BRVMuY3JlYXRlRGVjcnlwdG9yKGtleVdvcmRBcnJheSwgeyBpdjogaXZXb3JkQXJyYXkgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY3JlYXRlRGVjcnlwdG9yOiBmdW5jdGlvbiAoa2V5LCBjZmcpIHtcblx0ICAgICAgICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlKHRoaXMuX0RFQ19YRk9STV9NT0RFLCBrZXksIGNmZyk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCBjaXBoZXIuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0geGZvcm1Nb2RlIEVpdGhlciB0aGUgZW5jcnlwdGlvbiBvciBkZWNyeXB0aW9uIHRyYW5zb3JtYXRpb24gbW9kZSBjb25zdGFudC5cblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0ga2V5IFRoZSBrZXkuXG5cdCAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNmZyAoT3B0aW9uYWwpIFRoZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgdG8gdXNlIGZvciB0aGlzIG9wZXJhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGNpcGhlciA9IENyeXB0b0pTLmFsZ28uQUVTLmNyZWF0ZShDcnlwdG9KUy5hbGdvLkFFUy5fRU5DX1hGT1JNX01PREUsIGtleVdvcmRBcnJheSwgeyBpdjogaXZXb3JkQXJyYXkgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgaW5pdDogZnVuY3Rpb24gKHhmb3JtTW9kZSwga2V5LCBjZmcpIHtcblx0ICAgICAgICAgICAgLy8gQXBwbHkgY29uZmlnIGRlZmF1bHRzXG5cdCAgICAgICAgICAgIHRoaXMuY2ZnID0gdGhpcy5jZmcuZXh0ZW5kKGNmZyk7XG5cblx0ICAgICAgICAgICAgLy8gU3RvcmUgdHJhbnNmb3JtIG1vZGUgYW5kIGtleVxuXHQgICAgICAgICAgICB0aGlzLl94Zm9ybU1vZGUgPSB4Zm9ybU1vZGU7XG5cdCAgICAgICAgICAgIHRoaXMuX2tleSA9IGtleTtcblxuXHQgICAgICAgICAgICAvLyBTZXQgaW5pdGlhbCB2YWx1ZXNcblx0ICAgICAgICAgICAgdGhpcy5yZXNldCgpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBSZXNldHMgdGhpcyBjaXBoZXIgdG8gaXRzIGluaXRpYWwgc3RhdGUuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIGNpcGhlci5yZXNldCgpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHJlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFJlc2V0IGRhdGEgYnVmZmVyXG5cdCAgICAgICAgICAgIEJ1ZmZlcmVkQmxvY2tBbGdvcml0aG0ucmVzZXQuY2FsbCh0aGlzKTtcblxuXHQgICAgICAgICAgICAvLyBQZXJmb3JtIGNvbmNyZXRlLWNpcGhlciBsb2dpY1xuXHQgICAgICAgICAgICB0aGlzLl9kb1Jlc2V0KCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEFkZHMgZGF0YSB0byBiZSBlbmNyeXB0ZWQgb3IgZGVjcnlwdGVkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBkYXRhVXBkYXRlIFRoZSBkYXRhIHRvIGVuY3J5cHQgb3IgZGVjcnlwdC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIGRhdGEgYWZ0ZXIgcHJvY2Vzc2luZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGVuY3J5cHRlZCA9IGNpcGhlci5wcm9jZXNzKCdkYXRhJyk7XG5cdCAgICAgICAgICogICAgIHZhciBlbmNyeXB0ZWQgPSBjaXBoZXIucHJvY2Vzcyh3b3JkQXJyYXkpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHByb2Nlc3M6IGZ1bmN0aW9uIChkYXRhVXBkYXRlKSB7XG5cdCAgICAgICAgICAgIC8vIEFwcGVuZFxuXHQgICAgICAgICAgICB0aGlzLl9hcHBlbmQoZGF0YVVwZGF0ZSk7XG5cblx0ICAgICAgICAgICAgLy8gUHJvY2VzcyBhdmFpbGFibGUgYmxvY2tzXG5cdCAgICAgICAgICAgIHJldHVybiB0aGlzLl9wcm9jZXNzKCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEZpbmFsaXplcyB0aGUgZW5jcnlwdGlvbiBvciBkZWNyeXB0aW9uIHByb2Nlc3MuXG5cdCAgICAgICAgICogTm90ZSB0aGF0IHRoZSBmaW5hbGl6ZSBvcGVyYXRpb24gaXMgZWZmZWN0aXZlbHkgYSBkZXN0cnVjdGl2ZSwgcmVhZC1vbmNlIG9wZXJhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gZGF0YVVwZGF0ZSBUaGUgZmluYWwgZGF0YSB0byBlbmNyeXB0IG9yIGRlY3J5cHQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtXb3JkQXJyYXl9IFRoZSBkYXRhIGFmdGVyIGZpbmFsIHByb2Nlc3NpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBlbmNyeXB0ZWQgPSBjaXBoZXIuZmluYWxpemUoKTtcblx0ICAgICAgICAgKiAgICAgdmFyIGVuY3J5cHRlZCA9IGNpcGhlci5maW5hbGl6ZSgnZGF0YScpO1xuXHQgICAgICAgICAqICAgICB2YXIgZW5jcnlwdGVkID0gY2lwaGVyLmZpbmFsaXplKHdvcmRBcnJheSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgZmluYWxpemU6IGZ1bmN0aW9uIChkYXRhVXBkYXRlKSB7XG5cdCAgICAgICAgICAgIC8vIEZpbmFsIGRhdGEgdXBkYXRlXG5cdCAgICAgICAgICAgIGlmIChkYXRhVXBkYXRlKSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLl9hcHBlbmQoZGF0YVVwZGF0ZSk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBQZXJmb3JtIGNvbmNyZXRlLWNpcGhlciBsb2dpY1xuXHQgICAgICAgICAgICB2YXIgZmluYWxQcm9jZXNzZWREYXRhID0gdGhpcy5fZG9GaW5hbGl6ZSgpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBmaW5hbFByb2Nlc3NlZERhdGE7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGtleVNpemU6IDEyOC8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogMTI4LzMyLFxuXG5cdCAgICAgICAgX0VOQ19YRk9STV9NT0RFOiAxLFxuXG5cdCAgICAgICAgX0RFQ19YRk9STV9NT0RFOiAyLFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ3JlYXRlcyBzaG9ydGN1dCBmdW5jdGlvbnMgdG8gYSBjaXBoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJ9IGNpcGhlciBUaGUgY2lwaGVyIHRvIGNyZWF0ZSBhIGhlbHBlciBmb3IuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtPYmplY3R9IEFuIG9iamVjdCB3aXRoIGVuY3J5cHQgYW5kIGRlY3J5cHQgc2hvcnRjdXQgZnVuY3Rpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgQUVTID0gQ3J5cHRvSlMubGliLkNpcGhlci5fY3JlYXRlSGVscGVyKENyeXB0b0pTLmFsZ28uQUVTKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBfY3JlYXRlSGVscGVyOiAoZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICBmdW5jdGlvbiBzZWxlY3RDaXBoZXJTdHJhdGVneShrZXkpIHtcblx0ICAgICAgICAgICAgICAgIGlmICh0eXBlb2Yga2V5ID09ICdzdHJpbmcnKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFBhc3N3b3JkQmFzZWRDaXBoZXI7XG5cdCAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgICAgIHJldHVybiBTZXJpYWxpemFibGVDaXBoZXI7XG5cdCAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGNpcGhlcikge1xuXHQgICAgICAgICAgICAgICAgcmV0dXJuIHtcblx0ICAgICAgICAgICAgICAgICAgICBlbmNyeXB0OiBmdW5jdGlvbiAobWVzc2FnZSwga2V5LCBjZmcpIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNlbGVjdENpcGhlclN0cmF0ZWd5KGtleSkuZW5jcnlwdChjaXBoZXIsIG1lc3NhZ2UsIGtleSwgY2ZnKTtcblx0ICAgICAgICAgICAgICAgICAgICB9LFxuXG5cdCAgICAgICAgICAgICAgICAgICAgZGVjcnlwdDogZnVuY3Rpb24gKGNpcGhlcnRleHQsIGtleSwgY2ZnKSB7XG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxlY3RDaXBoZXJTdHJhdGVneShrZXkpLmRlY3J5cHQoY2lwaGVyLCBjaXBoZXJ0ZXh0LCBrZXksIGNmZyk7XG5cdCAgICAgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgfTtcblx0ICAgICAgICAgICAgfTtcblx0ICAgICAgICB9KCkpXG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBBYnN0cmFjdCBiYXNlIHN0cmVhbSBjaXBoZXIgdGVtcGxhdGUuXG5cdCAgICAgKlxuXHQgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IGJsb2NrU2l6ZSBUaGUgbnVtYmVyIG9mIDMyLWJpdCB3b3JkcyB0aGlzIGNpcGhlciBvcGVyYXRlcyBvbi4gRGVmYXVsdDogMSAoMzIgYml0cylcblx0ICAgICAqL1xuXHQgICAgdmFyIFN0cmVhbUNpcGhlciA9IENfbGliLlN0cmVhbUNpcGhlciA9IENpcGhlci5leHRlbmQoe1xuXHQgICAgICAgIF9kb0ZpbmFsaXplOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFByb2Nlc3MgcGFydGlhbCBibG9ja3Ncblx0ICAgICAgICAgICAgdmFyIGZpbmFsUHJvY2Vzc2VkQmxvY2tzID0gdGhpcy5fcHJvY2VzcyghISdmbHVzaCcpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBmaW5hbFByb2Nlc3NlZEJsb2Nrcztcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgYmxvY2tTaXplOiAxXG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBNb2RlIG5hbWVzcGFjZS5cblx0ICAgICAqL1xuXHQgICAgdmFyIENfbW9kZSA9IEMubW9kZSA9IHt9O1xuXG5cdCAgICAvKipcblx0ICAgICAqIEFic3RyYWN0IGJhc2UgYmxvY2sgY2lwaGVyIG1vZGUgdGVtcGxhdGUuXG5cdCAgICAgKi9cblx0ICAgIHZhciBCbG9ja0NpcGhlck1vZGUgPSBDX2xpYi5CbG9ja0NpcGhlck1vZGUgPSBCYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ3JlYXRlcyB0aGlzIG1vZGUgZm9yIGVuY3J5cHRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0NpcGhlcn0gY2lwaGVyIEEgYmxvY2sgY2lwaGVyIGluc3RhbmNlLlxuXHQgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IGl2IFRoZSBJViB3b3Jkcy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIG1vZGUgPSBDcnlwdG9KUy5tb2RlLkNCQy5jcmVhdGVFbmNyeXB0b3IoY2lwaGVyLCBpdi53b3Jkcyk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY3JlYXRlRW5jcnlwdG9yOiBmdW5jdGlvbiAoY2lwaGVyLCBpdikge1xuXHQgICAgICAgICAgICByZXR1cm4gdGhpcy5FbmNyeXB0b3IuY3JlYXRlKGNpcGhlciwgaXYpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDcmVhdGVzIHRoaXMgbW9kZSBmb3IgZGVjcnlwdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7Q2lwaGVyfSBjaXBoZXIgQSBibG9jayBjaXBoZXIgaW5zdGFuY2UuXG5cdCAgICAgICAgICogQHBhcmFtIHtBcnJheX0gaXYgVGhlIElWIHdvcmRzLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgbW9kZSA9IENyeXB0b0pTLm1vZGUuQ0JDLmNyZWF0ZURlY3J5cHRvcihjaXBoZXIsIGl2LndvcmRzKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjcmVhdGVEZWNyeXB0b3I6IGZ1bmN0aW9uIChjaXBoZXIsIGl2KSB7XG5cdCAgICAgICAgICAgIHJldHVybiB0aGlzLkRlY3J5cHRvci5jcmVhdGUoY2lwaGVyLCBpdik7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3bHkgY3JlYXRlZCBtb2RlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJ9IGNpcGhlciBBIGJsb2NrIGNpcGhlciBpbnN0YW5jZS5cblx0ICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBpdiBUaGUgSVYgd29yZHMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBtb2RlID0gQ3J5cHRvSlMubW9kZS5DQkMuRW5jcnlwdG9yLmNyZWF0ZShjaXBoZXIsIGl2LndvcmRzKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBpbml0OiBmdW5jdGlvbiAoY2lwaGVyLCBpdikge1xuXHQgICAgICAgICAgICB0aGlzLl9jaXBoZXIgPSBjaXBoZXI7XG5cdCAgICAgICAgICAgIHRoaXMuX2l2ID0gaXY7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogQ2lwaGVyIEJsb2NrIENoYWluaW5nIG1vZGUuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDQkMgPSBDX21vZGUuQ0JDID0gKGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBBYnN0cmFjdCBiYXNlIENCQyBtb2RlLlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHZhciBDQkMgPSBCbG9ja0NpcGhlck1vZGUuZXh0ZW5kKCk7XG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDQkMgZW5jcnlwdG9yLlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIENCQy5FbmNyeXB0b3IgPSBDQkMuZXh0ZW5kKHtcblx0ICAgICAgICAgICAgLyoqXG5cdCAgICAgICAgICAgICAqIFByb2Nlc3NlcyB0aGUgZGF0YSBibG9jayBhdCBvZmZzZXQuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IHdvcmRzIFRoZSBkYXRhIHdvcmRzIHRvIG9wZXJhdGUgb24uXG5cdCAgICAgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBvZmZzZXQgVGhlIG9mZnNldCB3aGVyZSB0aGUgYmxvY2sgc3RhcnRzLlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiAgICAgbW9kZS5wcm9jZXNzQmxvY2soZGF0YS53b3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgICovXG5cdCAgICAgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIGNpcGhlciA9IHRoaXMuX2NpcGhlcjtcblx0ICAgICAgICAgICAgICAgIHZhciBibG9ja1NpemUgPSBjaXBoZXIuYmxvY2tTaXplO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBYT1IgYW5kIGVuY3J5cHRcblx0ICAgICAgICAgICAgICAgIHhvckJsb2NrLmNhbGwodGhpcywgd29yZHMsIG9mZnNldCwgYmxvY2tTaXplKTtcblx0ICAgICAgICAgICAgICAgIGNpcGhlci5lbmNyeXB0QmxvY2sod29yZHMsIG9mZnNldCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIFJlbWVtYmVyIHRoaXMgYmxvY2sgdG8gdXNlIHdpdGggbmV4dCBibG9ja1xuXHQgICAgICAgICAgICAgICAgdGhpcy5fcHJldkJsb2NrID0gd29yZHMuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBibG9ja1NpemUpO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfSk7XG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDQkMgZGVjcnlwdG9yLlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIENCQy5EZWNyeXB0b3IgPSBDQkMuZXh0ZW5kKHtcblx0ICAgICAgICAgICAgLyoqXG5cdCAgICAgICAgICAgICAqIFByb2Nlc3NlcyB0aGUgZGF0YSBibG9jayBhdCBvZmZzZXQuXG5cdCAgICAgICAgICAgICAqXG5cdCAgICAgICAgICAgICAqIEBwYXJhbSB7QXJyYXl9IHdvcmRzIFRoZSBkYXRhIHdvcmRzIHRvIG9wZXJhdGUgb24uXG5cdCAgICAgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBvZmZzZXQgVGhlIG9mZnNldCB3aGVyZSB0aGUgYmxvY2sgc3RhcnRzLlxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAgICAgKlxuXHQgICAgICAgICAgICAgKiAgICAgbW9kZS5wcm9jZXNzQmxvY2soZGF0YS53b3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgICovXG5cdCAgICAgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIGNpcGhlciA9IHRoaXMuX2NpcGhlcjtcblx0ICAgICAgICAgICAgICAgIHZhciBibG9ja1NpemUgPSBjaXBoZXIuYmxvY2tTaXplO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBSZW1lbWJlciB0aGlzIGJsb2NrIHRvIHVzZSB3aXRoIG5leHQgYmxvY2tcblx0ICAgICAgICAgICAgICAgIHZhciB0aGlzQmxvY2sgPSB3b3Jkcy5zbGljZShvZmZzZXQsIG9mZnNldCArIGJsb2NrU2l6ZSk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIERlY3J5cHQgYW5kIFhPUlxuXHQgICAgICAgICAgICAgICAgY2lwaGVyLmRlY3J5cHRCbG9jayh3b3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgICAgIHhvckJsb2NrLmNhbGwodGhpcywgd29yZHMsIG9mZnNldCwgYmxvY2tTaXplKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gVGhpcyBibG9jayBiZWNvbWVzIHRoZSBwcmV2aW91cyBibG9ja1xuXHQgICAgICAgICAgICAgICAgdGhpcy5fcHJldkJsb2NrID0gdGhpc0Jsb2NrO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfSk7XG5cblx0ICAgICAgICBmdW5jdGlvbiB4b3JCbG9jayh3b3Jkcywgb2Zmc2V0LCBibG9ja1NpemUpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIGl2ID0gdGhpcy5faXY7XG5cblx0ICAgICAgICAgICAgLy8gQ2hvb3NlIG1peGluZyBibG9ja1xuXHQgICAgICAgICAgICBpZiAoaXYpIHtcblx0ICAgICAgICAgICAgICAgIHZhciBibG9jayA9IGl2O1xuXG5cdCAgICAgICAgICAgICAgICAvLyBSZW1vdmUgSVYgZm9yIHN1YnNlcXVlbnQgYmxvY2tzXG5cdCAgICAgICAgICAgICAgICB0aGlzLl9pdiA9IHVuZGVmaW5lZDtcblx0ICAgICAgICAgICAgfSBlbHNlIHtcblx0ICAgICAgICAgICAgICAgIHZhciBibG9jayA9IHRoaXMuX3ByZXZCbG9jaztcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIFhPUiBibG9ja3Ncblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBibG9ja1NpemU7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbb2Zmc2V0ICsgaV0gXj0gYmxvY2tbaV07XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICB9XG5cblx0ICAgICAgICByZXR1cm4gQ0JDO1xuXHQgICAgfSgpKTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBQYWRkaW5nIG5hbWVzcGFjZS5cblx0ICAgICAqL1xuXHQgICAgdmFyIENfcGFkID0gQy5wYWQgPSB7fTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBQS0NTICM1LzcgcGFkZGluZyBzdHJhdGVneS5cblx0ICAgICAqL1xuXHQgICAgdmFyIFBrY3M3ID0gQ19wYWQuUGtjczcgPSB7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogUGFkcyBkYXRhIHVzaW5nIHRoZSBhbGdvcml0aG0gZGVmaW5lZCBpbiBQS0NTICM1LzcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0gZGF0YSBUaGUgZGF0YSB0byBwYWQuXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IGJsb2NrU2l6ZSBUaGUgbXVsdGlwbGUgdGhhdCB0aGUgZGF0YSBzaG91bGQgYmUgcGFkZGVkIHRvLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICBDcnlwdG9KUy5wYWQuUGtjczcucGFkKHdvcmRBcnJheSwgNCk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcGFkOiBmdW5jdGlvbiAoZGF0YSwgYmxvY2tTaXplKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBibG9ja1NpemVCeXRlcyA9IGJsb2NrU2l6ZSAqIDQ7XG5cblx0ICAgICAgICAgICAgLy8gQ291bnQgcGFkZGluZyBieXRlc1xuXHQgICAgICAgICAgICB2YXIgblBhZGRpbmdCeXRlcyA9IGJsb2NrU2l6ZUJ5dGVzIC0gZGF0YS5zaWdCeXRlcyAlIGJsb2NrU2l6ZUJ5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIENyZWF0ZSBwYWRkaW5nIHdvcmRcblx0ICAgICAgICAgICAgdmFyIHBhZGRpbmdXb3JkID0gKG5QYWRkaW5nQnl0ZXMgPDwgMjQpIHwgKG5QYWRkaW5nQnl0ZXMgPDwgMTYpIHwgKG5QYWRkaW5nQnl0ZXMgPDwgOCkgfCBuUGFkZGluZ0J5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIENyZWF0ZSBwYWRkaW5nXG5cdCAgICAgICAgICAgIHZhciBwYWRkaW5nV29yZHMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBuUGFkZGluZ0J5dGVzOyBpICs9IDQpIHtcblx0ICAgICAgICAgICAgICAgIHBhZGRpbmdXb3Jkcy5wdXNoKHBhZGRpbmdXb3JkKTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICB2YXIgcGFkZGluZyA9IFdvcmRBcnJheS5jcmVhdGUocGFkZGluZ1dvcmRzLCBuUGFkZGluZ0J5dGVzKTtcblxuXHQgICAgICAgICAgICAvLyBBZGQgcGFkZGluZ1xuXHQgICAgICAgICAgICBkYXRhLmNvbmNhdChwYWRkaW5nKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogVW5wYWRzIGRhdGEgdGhhdCBoYWQgYmVlbiBwYWRkZWQgdXNpbmcgdGhlIGFsZ29yaXRobSBkZWZpbmVkIGluIFBLQ1MgIzUvNy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fSBkYXRhIFRoZSBkYXRhIHRvIHVucGFkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICBDcnlwdG9KUy5wYWQuUGtjczcudW5wYWQod29yZEFycmF5KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICB1bnBhZDogZnVuY3Rpb24gKGRhdGEpIHtcblx0ICAgICAgICAgICAgLy8gR2V0IG51bWJlciBvZiBwYWRkaW5nIGJ5dGVzIGZyb20gbGFzdCBieXRlXG5cdCAgICAgICAgICAgIHZhciBuUGFkZGluZ0J5dGVzID0gZGF0YS53b3Jkc1soZGF0YS5zaWdCeXRlcyAtIDEpID4+PiAyXSAmIDB4ZmY7XG5cblx0ICAgICAgICAgICAgLy8gUmVtb3ZlIHBhZGRpbmdcblx0ICAgICAgICAgICAgZGF0YS5zaWdCeXRlcyAtPSBuUGFkZGluZ0J5dGVzO1xuXHQgICAgICAgIH1cblx0ICAgIH07XG5cblx0ICAgIC8qKlxuXHQgICAgICogQWJzdHJhY3QgYmFzZSBibG9jayBjaXBoZXIgdGVtcGxhdGUuXG5cdCAgICAgKlxuXHQgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IGJsb2NrU2l6ZSBUaGUgbnVtYmVyIG9mIDMyLWJpdCB3b3JkcyB0aGlzIGNpcGhlciBvcGVyYXRlcyBvbi4gRGVmYXVsdDogNCAoMTI4IGJpdHMpXG5cdCAgICAgKi9cblx0ICAgIHZhciBCbG9ja0NpcGhlciA9IENfbGliLkJsb2NrQ2lwaGVyID0gQ2lwaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtNb2RlfSBtb2RlIFRoZSBibG9jayBtb2RlIHRvIHVzZS4gRGVmYXVsdDogQ0JDXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtQYWRkaW5nfSBwYWRkaW5nIFRoZSBwYWRkaW5nIHN0cmF0ZWd5IHRvIHVzZS4gRGVmYXVsdDogUGtjczdcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjZmc6IENpcGhlci5jZmcuZXh0ZW5kKHtcblx0ICAgICAgICAgICAgbW9kZTogQ0JDLFxuXHQgICAgICAgICAgICBwYWRkaW5nOiBQa2NzN1xuXHQgICAgICAgIH0pLFxuXG5cdCAgICAgICAgcmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gUmVzZXQgY2lwaGVyXG5cdCAgICAgICAgICAgIENpcGhlci5yZXNldC5jYWxsKHRoaXMpO1xuXG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgY2ZnID0gdGhpcy5jZmc7XG5cdCAgICAgICAgICAgIHZhciBpdiA9IGNmZy5pdjtcblx0ICAgICAgICAgICAgdmFyIG1vZGUgPSBjZmcubW9kZTtcblxuXHQgICAgICAgICAgICAvLyBSZXNldCBibG9jayBtb2RlXG5cdCAgICAgICAgICAgIGlmICh0aGlzLl94Zm9ybU1vZGUgPT0gdGhpcy5fRU5DX1hGT1JNX01PREUpIHtcblx0ICAgICAgICAgICAgICAgIHZhciBtb2RlQ3JlYXRvciA9IG1vZGUuY3JlYXRlRW5jcnlwdG9yO1xuXHQgICAgICAgICAgICB9IGVsc2UgLyogaWYgKHRoaXMuX3hmb3JtTW9kZSA9PSB0aGlzLl9ERUNfWEZPUk1fTU9ERSkgKi8ge1xuXHQgICAgICAgICAgICAgICAgdmFyIG1vZGVDcmVhdG9yID0gbW9kZS5jcmVhdGVEZWNyeXB0b3I7XG5cdCAgICAgICAgICAgICAgICAvLyBLZWVwIGF0IGxlYXN0IG9uZSBibG9jayBpbiB0aGUgYnVmZmVyIGZvciB1bnBhZGRpbmdcblx0ICAgICAgICAgICAgICAgIHRoaXMuX21pbkJ1ZmZlclNpemUgPSAxO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgaWYgKHRoaXMuX21vZGUgJiYgdGhpcy5fbW9kZS5fX2NyZWF0b3IgPT0gbW9kZUNyZWF0b3IpIHtcblx0ICAgICAgICAgICAgICAgIHRoaXMuX21vZGUuaW5pdCh0aGlzLCBpdiAmJiBpdi53b3Jkcyk7XG5cdCAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICB0aGlzLl9tb2RlID0gbW9kZUNyZWF0b3IuY2FsbChtb2RlLCB0aGlzLCBpdiAmJiBpdi53b3Jkcyk7XG5cdCAgICAgICAgICAgICAgICB0aGlzLl9tb2RlLl9fY3JlYXRvciA9IG1vZGVDcmVhdG9yO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb1Byb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fbW9kZS5wcm9jZXNzQmxvY2sod29yZHMsIG9mZnNldCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb0ZpbmFsaXplOiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBwYWRkaW5nID0gdGhpcy5jZmcucGFkZGluZztcblxuXHQgICAgICAgICAgICAvLyBGaW5hbGl6ZVxuXHQgICAgICAgICAgICBpZiAodGhpcy5feGZvcm1Nb2RlID09IHRoaXMuX0VOQ19YRk9STV9NT0RFKSB7XG5cdCAgICAgICAgICAgICAgICAvLyBQYWQgZGF0YVxuXHQgICAgICAgICAgICAgICAgcGFkZGluZy5wYWQodGhpcy5fZGF0YSwgdGhpcy5ibG9ja1NpemUpO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBQcm9jZXNzIGZpbmFsIGJsb2Nrc1xuXHQgICAgICAgICAgICAgICAgdmFyIGZpbmFsUHJvY2Vzc2VkQmxvY2tzID0gdGhpcy5fcHJvY2VzcyghISdmbHVzaCcpO1xuXHQgICAgICAgICAgICB9IGVsc2UgLyogaWYgKHRoaXMuX3hmb3JtTW9kZSA9PSB0aGlzLl9ERUNfWEZPUk1fTU9ERSkgKi8ge1xuXHQgICAgICAgICAgICAgICAgLy8gUHJvY2VzcyBmaW5hbCBibG9ja3Ncblx0ICAgICAgICAgICAgICAgIHZhciBmaW5hbFByb2Nlc3NlZEJsb2NrcyA9IHRoaXMuX3Byb2Nlc3MoISEnZmx1c2gnKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gVW5wYWQgZGF0YVxuXHQgICAgICAgICAgICAgICAgcGFkZGluZy51bnBhZChmaW5hbFByb2Nlc3NlZEJsb2Nrcyk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICByZXR1cm4gZmluYWxQcm9jZXNzZWRCbG9ja3M7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGJsb2NrU2l6ZTogMTI4LzMyXG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBBIGNvbGxlY3Rpb24gb2YgY2lwaGVyIHBhcmFtZXRlcnMuXG5cdCAgICAgKlxuXHQgICAgICogQHByb3BlcnR5IHtXb3JkQXJyYXl9IGNpcGhlcnRleHQgVGhlIHJhdyBjaXBoZXJ0ZXh0LlxuXHQgICAgICogQHByb3BlcnR5IHtXb3JkQXJyYXl9IGtleSBUaGUga2V5IHRvIHRoaXMgY2lwaGVydGV4dC5cblx0ICAgICAqIEBwcm9wZXJ0eSB7V29yZEFycmF5fSBpdiBUaGUgSVYgdXNlZCBpbiB0aGUgY2lwaGVyaW5nIG9wZXJhdGlvbi5cblx0ICAgICAqIEBwcm9wZXJ0eSB7V29yZEFycmF5fSBzYWx0IFRoZSBzYWx0IHVzZWQgd2l0aCBhIGtleSBkZXJpdmF0aW9uIGZ1bmN0aW9uLlxuXHQgICAgICogQHByb3BlcnR5IHtDaXBoZXJ9IGFsZ29yaXRobSBUaGUgY2lwaGVyIGFsZ29yaXRobS5cblx0ICAgICAqIEBwcm9wZXJ0eSB7TW9kZX0gbW9kZSBUaGUgYmxvY2sgbW9kZSB1c2VkIGluIHRoZSBjaXBoZXJpbmcgb3BlcmF0aW9uLlxuXHQgICAgICogQHByb3BlcnR5IHtQYWRkaW5nfSBwYWRkaW5nIFRoZSBwYWRkaW5nIHNjaGVtZSB1c2VkIGluIHRoZSBjaXBoZXJpbmcgb3BlcmF0aW9uLlxuXHQgICAgICogQHByb3BlcnR5IHtudW1iZXJ9IGJsb2NrU2l6ZSBUaGUgYmxvY2sgc2l6ZSBvZiB0aGUgY2lwaGVyLlxuXHQgICAgICogQHByb3BlcnR5IHtGb3JtYXR9IGZvcm1hdHRlciBUaGUgZGVmYXVsdCBmb3JtYXR0aW5nIHN0cmF0ZWd5IHRvIGNvbnZlcnQgdGhpcyBjaXBoZXIgcGFyYW1zIG9iamVjdCB0byBhIHN0cmluZy5cblx0ICAgICAqL1xuXHQgICAgdmFyIENpcGhlclBhcmFtcyA9IENfbGliLkNpcGhlclBhcmFtcyA9IEJhc2UuZXh0ZW5kKHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBJbml0aWFsaXplcyBhIG5ld2x5IGNyZWF0ZWQgY2lwaGVyIHBhcmFtcyBvYmplY3QuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gY2lwaGVyUGFyYW1zIEFuIG9iamVjdCB3aXRoIGFueSBvZiB0aGUgcG9zc2libGUgY2lwaGVyIHBhcmFtZXRlcnMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBjaXBoZXJQYXJhbXMgPSBDcnlwdG9KUy5saWIuQ2lwaGVyUGFyYW1zLmNyZWF0ZSh7XG5cdCAgICAgICAgICogICAgICAgICBjaXBoZXJ0ZXh0OiBjaXBoZXJ0ZXh0V29yZEFycmF5LFxuXHQgICAgICAgICAqICAgICAgICAga2V5OiBrZXlXb3JkQXJyYXksXG5cdCAgICAgICAgICogICAgICAgICBpdjogaXZXb3JkQXJyYXksXG5cdCAgICAgICAgICogICAgICAgICBzYWx0OiBzYWx0V29yZEFycmF5LFxuXHQgICAgICAgICAqICAgICAgICAgYWxnb3JpdGhtOiBDcnlwdG9KUy5hbGdvLkFFUyxcblx0ICAgICAgICAgKiAgICAgICAgIG1vZGU6IENyeXB0b0pTLm1vZGUuQ0JDLFxuXHQgICAgICAgICAqICAgICAgICAgcGFkZGluZzogQ3J5cHRvSlMucGFkLlBLQ1M3LFxuXHQgICAgICAgICAqICAgICAgICAgYmxvY2tTaXplOiA0LFxuXHQgICAgICAgICAqICAgICAgICAgZm9ybWF0dGVyOiBDcnlwdG9KUy5mb3JtYXQuT3BlblNTTFxuXHQgICAgICAgICAqICAgICB9KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBpbml0OiBmdW5jdGlvbiAoY2lwaGVyUGFyYW1zKSB7XG5cdCAgICAgICAgICAgIHRoaXMubWl4SW4oY2lwaGVyUGFyYW1zKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgdGhpcyBjaXBoZXIgcGFyYW1zIG9iamVjdCB0byBhIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7Rm9ybWF0fSBmb3JtYXR0ZXIgKE9wdGlvbmFsKSBUaGUgZm9ybWF0dGluZyBzdHJhdGVneSB0byB1c2UuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBzdHJpbmdpZmllZCBjaXBoZXIgcGFyYW1zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHRocm93cyBFcnJvciBJZiBuZWl0aGVyIHRoZSBmb3JtYXR0ZXIgbm9yIHRoZSBkZWZhdWx0IGZvcm1hdHRlciBpcyBzZXQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBzdHJpbmcgPSBjaXBoZXJQYXJhbXMgKyAnJztcblx0ICAgICAgICAgKiAgICAgdmFyIHN0cmluZyA9IGNpcGhlclBhcmFtcy50b1N0cmluZygpO1xuXHQgICAgICAgICAqICAgICB2YXIgc3RyaW5nID0gY2lwaGVyUGFyYW1zLnRvU3RyaW5nKENyeXB0b0pTLmZvcm1hdC5PcGVuU1NMKTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICB0b1N0cmluZzogZnVuY3Rpb24gKGZvcm1hdHRlcikge1xuXHQgICAgICAgICAgICByZXR1cm4gKGZvcm1hdHRlciB8fCB0aGlzLmZvcm1hdHRlcikuc3RyaW5naWZ5KHRoaXMpO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICAvKipcblx0ICAgICAqIEZvcm1hdCBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDX2Zvcm1hdCA9IEMuZm9ybWF0ID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogT3BlblNTTCBmb3JtYXR0aW5nIHN0cmF0ZWd5LlxuXHQgICAgICovXG5cdCAgICB2YXIgT3BlblNTTEZvcm1hdHRlciA9IENfZm9ybWF0Lk9wZW5TU0wgPSB7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBjaXBoZXIgcGFyYW1zIG9iamVjdCB0byBhbiBPcGVuU1NMLWNvbXBhdGlibGUgc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJQYXJhbXN9IGNpcGhlclBhcmFtcyBUaGUgY2lwaGVyIHBhcmFtcyBvYmplY3QuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBPcGVuU1NMLWNvbXBhdGlibGUgc3RyaW5nLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgb3BlblNTTFN0cmluZyA9IENyeXB0b0pTLmZvcm1hdC5PcGVuU1NMLnN0cmluZ2lmeShjaXBoZXJQYXJhbXMpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHN0cmluZ2lmeTogZnVuY3Rpb24gKGNpcGhlclBhcmFtcykge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGNpcGhlcnRleHQgPSBjaXBoZXJQYXJhbXMuY2lwaGVydGV4dDtcblx0ICAgICAgICAgICAgdmFyIHNhbHQgPSBjaXBoZXJQYXJhbXMuc2FsdDtcblxuXHQgICAgICAgICAgICAvLyBGb3JtYXRcblx0ICAgICAgICAgICAgaWYgKHNhbHQpIHtcblx0ICAgICAgICAgICAgICAgIHZhciB3b3JkQXJyYXkgPSBXb3JkQXJyYXkuY3JlYXRlKFsweDUzNjE2Yzc0LCAweDY1NjQ1ZjVmXSkuY29uY2F0KHNhbHQpLmNvbmNhdChjaXBoZXJ0ZXh0KTtcblx0ICAgICAgICAgICAgfSBlbHNlIHtcblx0ICAgICAgICAgICAgICAgIHZhciB3b3JkQXJyYXkgPSBjaXBoZXJ0ZXh0O1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgcmV0dXJuIHdvcmRBcnJheS50b1N0cmluZyhCYXNlNjQpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb252ZXJ0cyBhbiBPcGVuU1NMLWNvbXBhdGlibGUgc3RyaW5nIHRvIGEgY2lwaGVyIHBhcmFtcyBvYmplY3QuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge3N0cmluZ30gb3BlblNTTFN0ciBUaGUgT3BlblNTTC1jb21wYXRpYmxlIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0NpcGhlclBhcmFtc30gVGhlIGNpcGhlciBwYXJhbXMgb2JqZWN0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVyUGFyYW1zID0gQ3J5cHRvSlMuZm9ybWF0Lk9wZW5TU0wucGFyc2Uob3BlblNTTFN0cmluZyk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgcGFyc2U6IGZ1bmN0aW9uIChvcGVuU1NMU3RyKSB7XG5cdCAgICAgICAgICAgIC8vIFBhcnNlIGJhc2U2NFxuXHQgICAgICAgICAgICB2YXIgY2lwaGVydGV4dCA9IEJhc2U2NC5wYXJzZShvcGVuU1NMU3RyKTtcblxuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgICAgICB2YXIgY2lwaGVydGV4dFdvcmRzID0gY2lwaGVydGV4dC53b3JkcztcblxuXHQgICAgICAgICAgICAvLyBUZXN0IGZvciBzYWx0XG5cdCAgICAgICAgICAgIGlmIChjaXBoZXJ0ZXh0V29yZHNbMF0gPT0gMHg1MzYxNmM3NCAmJiBjaXBoZXJ0ZXh0V29yZHNbMV0gPT0gMHg2NTY0NWY1Zikge1xuXHQgICAgICAgICAgICAgICAgLy8gRXh0cmFjdCBzYWx0XG5cdCAgICAgICAgICAgICAgICB2YXIgc2FsdCA9IFdvcmRBcnJheS5jcmVhdGUoY2lwaGVydGV4dFdvcmRzLnNsaWNlKDIsIDQpKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHNhbHQgZnJvbSBjaXBoZXJ0ZXh0XG5cdCAgICAgICAgICAgICAgICBjaXBoZXJ0ZXh0V29yZHMuc3BsaWNlKDAsIDQpO1xuXHQgICAgICAgICAgICAgICAgY2lwaGVydGV4dC5zaWdCeXRlcyAtPSAxNjtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIHJldHVybiBDaXBoZXJQYXJhbXMuY3JlYXRlKHsgY2lwaGVydGV4dDogY2lwaGVydGV4dCwgc2FsdDogc2FsdCB9KTtcblx0ICAgICAgICB9XG5cdCAgICB9O1xuXG5cdCAgICAvKipcblx0ICAgICAqIEEgY2lwaGVyIHdyYXBwZXIgdGhhdCByZXR1cm5zIGNpcGhlcnRleHQgYXMgYSBzZXJpYWxpemFibGUgY2lwaGVyIHBhcmFtcyBvYmplY3QuXG5cdCAgICAgKi9cblx0ICAgIHZhciBTZXJpYWxpemFibGVDaXBoZXIgPSBDX2xpYi5TZXJpYWxpemFibGVDaXBoZXIgPSBCYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtGb3JtYXR0ZXJ9IGZvcm1hdCBUaGUgZm9ybWF0dGluZyBzdHJhdGVneSB0byBjb252ZXJ0IGNpcGhlciBwYXJhbSBvYmplY3RzIHRvIGFuZCBmcm9tIGEgc3RyaW5nLiBEZWZhdWx0OiBPcGVuU1NMXG5cdCAgICAgICAgICovXG5cdCAgICAgICAgY2ZnOiBCYXNlLmV4dGVuZCh7XG5cdCAgICAgICAgICAgIGZvcm1hdDogT3BlblNTTEZvcm1hdHRlclxuXHQgICAgICAgIH0pLFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogRW5jcnlwdHMgYSBtZXNzYWdlLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJ9IGNpcGhlciBUaGUgY2lwaGVyIGFsZ29yaXRobSB0byB1c2UuXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl8c3RyaW5nfSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGVuY3J5cHQuXG5cdCAgICAgICAgICogQHBhcmFtIHtXb3JkQXJyYXl9IGtleSBUaGUga2V5LlxuXHQgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjZmcgKE9wdGlvbmFsKSBUaGUgY29uZmlndXJhdGlvbiBvcHRpb25zIHRvIHVzZSBmb3IgdGhpcyBvcGVyYXRpb24uXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcmV0dXJuIHtDaXBoZXJQYXJhbXN9IEEgY2lwaGVyIHBhcmFtcyBvYmplY3QuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBjaXBoZXJ0ZXh0UGFyYW1zID0gQ3J5cHRvSlMubGliLlNlcmlhbGl6YWJsZUNpcGhlci5lbmNyeXB0KENyeXB0b0pTLmFsZ28uQUVTLCBtZXNzYWdlLCBrZXkpO1xuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVydGV4dFBhcmFtcyA9IENyeXB0b0pTLmxpYi5TZXJpYWxpemFibGVDaXBoZXIuZW5jcnlwdChDcnlwdG9KUy5hbGdvLkFFUywgbWVzc2FnZSwga2V5LCB7IGl2OiBpdiB9KTtcblx0ICAgICAgICAgKiAgICAgdmFyIGNpcGhlcnRleHRQYXJhbXMgPSBDcnlwdG9KUy5saWIuU2VyaWFsaXphYmxlQ2lwaGVyLmVuY3J5cHQoQ3J5cHRvSlMuYWxnby5BRVMsIG1lc3NhZ2UsIGtleSwgeyBpdjogaXYsIGZvcm1hdDogQ3J5cHRvSlMuZm9ybWF0Lk9wZW5TU0wgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgZW5jcnlwdDogZnVuY3Rpb24gKGNpcGhlciwgbWVzc2FnZSwga2V5LCBjZmcpIHtcblx0ICAgICAgICAgICAgLy8gQXBwbHkgY29uZmlnIGRlZmF1bHRzXG5cdCAgICAgICAgICAgIGNmZyA9IHRoaXMuY2ZnLmV4dGVuZChjZmcpO1xuXG5cdCAgICAgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICAgICAgdmFyIGVuY3J5cHRvciA9IGNpcGhlci5jcmVhdGVFbmNyeXB0b3Ioa2V5LCBjZmcpO1xuXHQgICAgICAgICAgICB2YXIgY2lwaGVydGV4dCA9IGVuY3J5cHRvci5maW5hbGl6ZShtZXNzYWdlKTtcblxuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgICAgICB2YXIgY2lwaGVyQ2ZnID0gZW5jcnlwdG9yLmNmZztcblxuXHQgICAgICAgICAgICAvLyBDcmVhdGUgYW5kIHJldHVybiBzZXJpYWxpemFibGUgY2lwaGVyIHBhcmFtc1xuXHQgICAgICAgICAgICByZXR1cm4gQ2lwaGVyUGFyYW1zLmNyZWF0ZSh7XG5cdCAgICAgICAgICAgICAgICBjaXBoZXJ0ZXh0OiBjaXBoZXJ0ZXh0LFxuXHQgICAgICAgICAgICAgICAga2V5OiBrZXksXG5cdCAgICAgICAgICAgICAgICBpdjogY2lwaGVyQ2ZnLml2LFxuXHQgICAgICAgICAgICAgICAgYWxnb3JpdGhtOiBjaXBoZXIsXG5cdCAgICAgICAgICAgICAgICBtb2RlOiBjaXBoZXJDZmcubW9kZSxcblx0ICAgICAgICAgICAgICAgIHBhZGRpbmc6IGNpcGhlckNmZy5wYWRkaW5nLFxuXHQgICAgICAgICAgICAgICAgYmxvY2tTaXplOiBjaXBoZXIuYmxvY2tTaXplLFxuXHQgICAgICAgICAgICAgICAgZm9ybWF0dGVyOiBjZmcuZm9ybWF0XG5cdCAgICAgICAgICAgIH0pO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBEZWNyeXB0cyBzZXJpYWxpemVkIGNpcGhlcnRleHQuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0NpcGhlcn0gY2lwaGVyIFRoZSBjaXBoZXIgYWxnb3JpdGhtIHRvIHVzZS5cblx0ICAgICAgICAgKiBAcGFyYW0ge0NpcGhlclBhcmFtc3xzdHJpbmd9IGNpcGhlcnRleHQgVGhlIGNpcGhlcnRleHQgdG8gZGVjcnlwdC5cblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheX0ga2V5IFRoZSBrZXkuXG5cdCAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNmZyAoT3B0aW9uYWwpIFRoZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgdG8gdXNlIGZvciB0aGlzIG9wZXJhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge1dvcmRBcnJheX0gVGhlIHBsYWludGV4dC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIHBsYWludGV4dCA9IENyeXB0b0pTLmxpYi5TZXJpYWxpemFibGVDaXBoZXIuZGVjcnlwdChDcnlwdG9KUy5hbGdvLkFFUywgZm9ybWF0dGVkQ2lwaGVydGV4dCwga2V5LCB7IGl2OiBpdiwgZm9ybWF0OiBDcnlwdG9KUy5mb3JtYXQuT3BlblNTTCB9KTtcblx0ICAgICAgICAgKiAgICAgdmFyIHBsYWludGV4dCA9IENyeXB0b0pTLmxpYi5TZXJpYWxpemFibGVDaXBoZXIuZGVjcnlwdChDcnlwdG9KUy5hbGdvLkFFUywgY2lwaGVydGV4dFBhcmFtcywga2V5LCB7IGl2OiBpdiwgZm9ybWF0OiBDcnlwdG9KUy5mb3JtYXQuT3BlblNTTCB9KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBkZWNyeXB0OiBmdW5jdGlvbiAoY2lwaGVyLCBjaXBoZXJ0ZXh0LCBrZXksIGNmZykge1xuXHQgICAgICAgICAgICAvLyBBcHBseSBjb25maWcgZGVmYXVsdHNcblx0ICAgICAgICAgICAgY2ZnID0gdGhpcy5jZmcuZXh0ZW5kKGNmZyk7XG5cblx0ICAgICAgICAgICAgLy8gQ29udmVydCBzdHJpbmcgdG8gQ2lwaGVyUGFyYW1zXG5cdCAgICAgICAgICAgIGNpcGhlcnRleHQgPSB0aGlzLl9wYXJzZShjaXBoZXJ0ZXh0LCBjZmcuZm9ybWF0KTtcblxuXHQgICAgICAgICAgICAvLyBEZWNyeXB0XG5cdCAgICAgICAgICAgIHZhciBwbGFpbnRleHQgPSBjaXBoZXIuY3JlYXRlRGVjcnlwdG9yKGtleSwgY2ZnKS5maW5hbGl6ZShjaXBoZXJ0ZXh0LmNpcGhlcnRleHQpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBwbGFpbnRleHQ7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIENvbnZlcnRzIHNlcmlhbGl6ZWQgY2lwaGVydGV4dCB0byBDaXBoZXJQYXJhbXMsXG5cdCAgICAgICAgICogZWxzZSBhc3N1bWVkIENpcGhlclBhcmFtcyBhbHJlYWR5IGFuZCByZXR1cm5zIGNpcGhlcnRleHQgdW5jaGFuZ2VkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJQYXJhbXN8c3RyaW5nfSBjaXBoZXJ0ZXh0IFRoZSBjaXBoZXJ0ZXh0LlxuXHQgICAgICAgICAqIEBwYXJhbSB7Rm9ybWF0dGVyfSBmb3JtYXQgVGhlIGZvcm1hdHRpbmcgc3RyYXRlZ3kgdG8gdXNlIHRvIHBhcnNlIHNlcmlhbGl6ZWQgY2lwaGVydGV4dC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0NpcGhlclBhcmFtc30gVGhlIHVuc2VyaWFsaXplZCBjaXBoZXJ0ZXh0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVydGV4dFBhcmFtcyA9IENyeXB0b0pTLmxpYi5TZXJpYWxpemFibGVDaXBoZXIuX3BhcnNlKGNpcGhlcnRleHRTdHJpbmdPclBhcmFtcywgZm9ybWF0KTtcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBfcGFyc2U6IGZ1bmN0aW9uIChjaXBoZXJ0ZXh0LCBmb3JtYXQpIHtcblx0ICAgICAgICAgICAgaWYgKHR5cGVvZiBjaXBoZXJ0ZXh0ID09ICdzdHJpbmcnKSB7XG5cdCAgICAgICAgICAgICAgICByZXR1cm4gZm9ybWF0LnBhcnNlKGNpcGhlcnRleHQsIHRoaXMpO1xuXHQgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgcmV0dXJuIGNpcGhlcnRleHQ7XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICB9XG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBLZXkgZGVyaXZhdGlvbiBmdW5jdGlvbiBuYW1lc3BhY2UuXG5cdCAgICAgKi9cblx0ICAgIHZhciBDX2tkZiA9IEMua2RmID0ge307XG5cblx0ICAgIC8qKlxuXHQgICAgICogT3BlblNTTCBrZXkgZGVyaXZhdGlvbiBmdW5jdGlvbi5cblx0ICAgICAqL1xuXHQgICAgdmFyIE9wZW5TU0xLZGYgPSBDX2tkZi5PcGVuU1NMID0ge1xuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIERlcml2ZXMgYSBrZXkgYW5kIElWIGZyb20gYSBwYXNzd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwYXNzd29yZCBUaGUgcGFzc3dvcmQgdG8gZGVyaXZlIGZyb20uXG5cdCAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IGtleVNpemUgVGhlIHNpemUgaW4gd29yZHMgb2YgdGhlIGtleSB0byBnZW5lcmF0ZS5cblx0ICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gaXZTaXplIFRoZSBzaXplIGluIHdvcmRzIG9mIHRoZSBJViB0byBnZW5lcmF0ZS5cblx0ICAgICAgICAgKiBAcGFyYW0ge1dvcmRBcnJheXxzdHJpbmd9IHNhbHQgKE9wdGlvbmFsKSBBIDY0LWJpdCBzYWx0IHRvIHVzZS4gSWYgb21pdHRlZCwgYSBzYWx0IHdpbGwgYmUgZ2VuZXJhdGVkIHJhbmRvbWx5LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7Q2lwaGVyUGFyYW1zfSBBIGNpcGhlciBwYXJhbXMgb2JqZWN0IHdpdGggdGhlIGtleSwgSVYsIGFuZCBzYWx0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgZGVyaXZlZFBhcmFtcyA9IENyeXB0b0pTLmtkZi5PcGVuU1NMLmV4ZWN1dGUoJ1Bhc3N3b3JkJywgMjU2LzMyLCAxMjgvMzIpO1xuXHQgICAgICAgICAqICAgICB2YXIgZGVyaXZlZFBhcmFtcyA9IENyeXB0b0pTLmtkZi5PcGVuU1NMLmV4ZWN1dGUoJ1Bhc3N3b3JkJywgMjU2LzMyLCAxMjgvMzIsICdzYWx0c2FsdCcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGV4ZWN1dGU6IGZ1bmN0aW9uIChwYXNzd29yZCwga2V5U2l6ZSwgaXZTaXplLCBzYWx0KSB7XG5cdCAgICAgICAgICAgIC8vIEdlbmVyYXRlIHJhbmRvbSBzYWx0XG5cdCAgICAgICAgICAgIGlmICghc2FsdCkge1xuXHQgICAgICAgICAgICAgICAgc2FsdCA9IFdvcmRBcnJheS5yYW5kb20oNjQvOCk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBEZXJpdmUga2V5IGFuZCBJVlxuXHQgICAgICAgICAgICB2YXIga2V5ID0gRXZwS0RGLmNyZWF0ZSh7IGtleVNpemU6IGtleVNpemUgKyBpdlNpemUgfSkuY29tcHV0ZShwYXNzd29yZCwgc2FsdCk7XG5cblx0ICAgICAgICAgICAgLy8gU2VwYXJhdGUga2V5IGFuZCBJVlxuXHQgICAgICAgICAgICB2YXIgaXYgPSBXb3JkQXJyYXkuY3JlYXRlKGtleS53b3Jkcy5zbGljZShrZXlTaXplKSwgaXZTaXplICogNCk7XG5cdCAgICAgICAgICAgIGtleS5zaWdCeXRlcyA9IGtleVNpemUgKiA0O1xuXG5cdCAgICAgICAgICAgIC8vIFJldHVybiBwYXJhbXNcblx0ICAgICAgICAgICAgcmV0dXJuIENpcGhlclBhcmFtcy5jcmVhdGUoeyBrZXk6IGtleSwgaXY6IGl2LCBzYWx0OiBzYWx0IH0pO1xuXHQgICAgICAgIH1cblx0ICAgIH07XG5cblx0ICAgIC8qKlxuXHQgICAgICogQSBzZXJpYWxpemFibGUgY2lwaGVyIHdyYXBwZXIgdGhhdCBkZXJpdmVzIHRoZSBrZXkgZnJvbSBhIHBhc3N3b3JkLFxuXHQgICAgICogYW5kIHJldHVybnMgY2lwaGVydGV4dCBhcyBhIHNlcmlhbGl6YWJsZSBjaXBoZXIgcGFyYW1zIG9iamVjdC5cblx0ICAgICAqL1xuXHQgICAgdmFyIFBhc3N3b3JkQmFzZWRDaXBoZXIgPSBDX2xpYi5QYXNzd29yZEJhc2VkQ2lwaGVyID0gU2VyaWFsaXphYmxlQ2lwaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHByb3BlcnR5IHtLREZ9IGtkZiBUaGUga2V5IGRlcml2YXRpb24gZnVuY3Rpb24gdG8gdXNlIHRvIGdlbmVyYXRlIGEga2V5IGFuZCBJViBmcm9tIGEgcGFzc3dvcmQuIERlZmF1bHQ6IE9wZW5TU0xcblx0ICAgICAgICAgKi9cblx0ICAgICAgICBjZmc6IFNlcmlhbGl6YWJsZUNpcGhlci5jZmcuZXh0ZW5kKHtcblx0ICAgICAgICAgICAga2RmOiBPcGVuU1NMS2RmXG5cdCAgICAgICAgfSksXG5cblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBFbmNyeXB0cyBhIG1lc3NhZ2UgdXNpbmcgYSBwYXNzd29yZC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7Q2lwaGVyfSBjaXBoZXIgVGhlIGNpcGhlciBhbGdvcml0aG0gdG8gdXNlLlxuXHQgICAgICAgICAqIEBwYXJhbSB7V29yZEFycmF5fHN0cmluZ30gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBlbmNyeXB0LlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwYXNzd29yZCBUaGUgcGFzc3dvcmQuXG5cdCAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNmZyAoT3B0aW9uYWwpIFRoZSBjb25maWd1cmF0aW9uIG9wdGlvbnMgdG8gdXNlIGZvciB0aGlzIG9wZXJhdGlvbi5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0NpcGhlclBhcmFtc30gQSBjaXBoZXIgcGFyYW1zIG9iamVjdC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBzdGF0aWNcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBleGFtcGxlXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiAgICAgdmFyIGNpcGhlcnRleHRQYXJhbXMgPSBDcnlwdG9KUy5saWIuUGFzc3dvcmRCYXNlZENpcGhlci5lbmNyeXB0KENyeXB0b0pTLmFsZ28uQUVTLCBtZXNzYWdlLCAncGFzc3dvcmQnKTtcblx0ICAgICAgICAgKiAgICAgdmFyIGNpcGhlcnRleHRQYXJhbXMgPSBDcnlwdG9KUy5saWIuUGFzc3dvcmRCYXNlZENpcGhlci5lbmNyeXB0KENyeXB0b0pTLmFsZ28uQUVTLCBtZXNzYWdlLCAncGFzc3dvcmQnLCB7IGZvcm1hdDogQ3J5cHRvSlMuZm9ybWF0Lk9wZW5TU0wgfSk7XG5cdCAgICAgICAgICovXG5cdCAgICAgICAgZW5jcnlwdDogZnVuY3Rpb24gKGNpcGhlciwgbWVzc2FnZSwgcGFzc3dvcmQsIGNmZykge1xuXHQgICAgICAgICAgICAvLyBBcHBseSBjb25maWcgZGVmYXVsdHNcblx0ICAgICAgICAgICAgY2ZnID0gdGhpcy5jZmcuZXh0ZW5kKGNmZyk7XG5cblx0ICAgICAgICAgICAgLy8gRGVyaXZlIGtleSBhbmQgb3RoZXIgcGFyYW1zXG5cdCAgICAgICAgICAgIHZhciBkZXJpdmVkUGFyYW1zID0gY2ZnLmtkZi5leGVjdXRlKHBhc3N3b3JkLCBjaXBoZXIua2V5U2l6ZSwgY2lwaGVyLml2U2l6ZSk7XG5cblx0ICAgICAgICAgICAgLy8gQWRkIElWIHRvIGNvbmZpZ1xuXHQgICAgICAgICAgICBjZmcuaXYgPSBkZXJpdmVkUGFyYW1zLml2O1xuXG5cdCAgICAgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICAgICAgdmFyIGNpcGhlcnRleHQgPSBTZXJpYWxpemFibGVDaXBoZXIuZW5jcnlwdC5jYWxsKHRoaXMsIGNpcGhlciwgbWVzc2FnZSwgZGVyaXZlZFBhcmFtcy5rZXksIGNmZyk7XG5cblx0ICAgICAgICAgICAgLy8gTWl4IGluIGRlcml2ZWQgcGFyYW1zXG5cdCAgICAgICAgICAgIGNpcGhlcnRleHQubWl4SW4oZGVyaXZlZFBhcmFtcyk7XG5cblx0ICAgICAgICAgICAgcmV0dXJuIGNpcGhlcnRleHQ7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIC8qKlxuXHQgICAgICAgICAqIERlY3J5cHRzIHNlcmlhbGl6ZWQgY2lwaGVydGV4dCB1c2luZyBhIHBhc3N3b3JkLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJ9IGNpcGhlciBUaGUgY2lwaGVyIGFsZ29yaXRobSB0byB1c2UuXG5cdCAgICAgICAgICogQHBhcmFtIHtDaXBoZXJQYXJhbXN8c3RyaW5nfSBjaXBoZXJ0ZXh0IFRoZSBjaXBoZXJ0ZXh0IHRvIGRlY3J5cHQuXG5cdCAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHBhc3N3b3JkIFRoZSBwYXNzd29yZC5cblx0ICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gY2ZnIChPcHRpb25hbCkgVGhlIGNvbmZpZ3VyYXRpb24gb3B0aW9ucyB0byB1c2UgZm9yIHRoaXMgb3BlcmF0aW9uLlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHJldHVybiB7V29yZEFycmF5fSBUaGUgcGxhaW50ZXh0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgcGxhaW50ZXh0ID0gQ3J5cHRvSlMubGliLlBhc3N3b3JkQmFzZWRDaXBoZXIuZGVjcnlwdChDcnlwdG9KUy5hbGdvLkFFUywgZm9ybWF0dGVkQ2lwaGVydGV4dCwgJ3Bhc3N3b3JkJywgeyBmb3JtYXQ6IENyeXB0b0pTLmZvcm1hdC5PcGVuU1NMIH0pO1xuXHQgICAgICAgICAqICAgICB2YXIgcGxhaW50ZXh0ID0gQ3J5cHRvSlMubGliLlBhc3N3b3JkQmFzZWRDaXBoZXIuZGVjcnlwdChDcnlwdG9KUy5hbGdvLkFFUywgY2lwaGVydGV4dFBhcmFtcywgJ3Bhc3N3b3JkJywgeyBmb3JtYXQ6IENyeXB0b0pTLmZvcm1hdC5PcGVuU1NMIH0pO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGRlY3J5cHQ6IGZ1bmN0aW9uIChjaXBoZXIsIGNpcGhlcnRleHQsIHBhc3N3b3JkLCBjZmcpIHtcblx0ICAgICAgICAgICAgLy8gQXBwbHkgY29uZmlnIGRlZmF1bHRzXG5cdCAgICAgICAgICAgIGNmZyA9IHRoaXMuY2ZnLmV4dGVuZChjZmcpO1xuXG5cdCAgICAgICAgICAgIC8vIENvbnZlcnQgc3RyaW5nIHRvIENpcGhlclBhcmFtc1xuXHQgICAgICAgICAgICBjaXBoZXJ0ZXh0ID0gdGhpcy5fcGFyc2UoY2lwaGVydGV4dCwgY2ZnLmZvcm1hdCk7XG5cblx0ICAgICAgICAgICAgLy8gRGVyaXZlIGtleSBhbmQgb3RoZXIgcGFyYW1zXG5cdCAgICAgICAgICAgIHZhciBkZXJpdmVkUGFyYW1zID0gY2ZnLmtkZi5leGVjdXRlKHBhc3N3b3JkLCBjaXBoZXIua2V5U2l6ZSwgY2lwaGVyLml2U2l6ZSwgY2lwaGVydGV4dC5zYWx0KTtcblxuXHQgICAgICAgICAgICAvLyBBZGQgSVYgdG8gY29uZmlnXG5cdCAgICAgICAgICAgIGNmZy5pdiA9IGRlcml2ZWRQYXJhbXMuaXY7XG5cblx0ICAgICAgICAgICAgLy8gRGVjcnlwdFxuXHQgICAgICAgICAgICB2YXIgcGxhaW50ZXh0ID0gU2VyaWFsaXphYmxlQ2lwaGVyLmRlY3J5cHQuY2FsbCh0aGlzLCBjaXBoZXIsIGNpcGhlcnRleHQsIGRlcml2ZWRQYXJhbXMua2V5LCBjZmcpO1xuXG5cdCAgICAgICAgICAgIHJldHVybiBwbGFpbnRleHQ7XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cdH0oKSk7XG5cblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL2NpcGhlci1jb3JlLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogQ2lwaGVyIEZlZWRiYWNrIGJsb2NrIG1vZGUuXG5cdCAqL1xuXHRDcnlwdG9KUy5tb2RlLkNGQiA9IChmdW5jdGlvbiAoKSB7XG5cdCAgICB2YXIgQ0ZCID0gQ3J5cHRvSlMubGliLkJsb2NrQ2lwaGVyTW9kZS5leHRlbmQoKTtcblxuXHQgICAgQ0ZCLkVuY3J5cHRvciA9IENGQi5leHRlbmQoe1xuXHQgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBjaXBoZXIgPSB0aGlzLl9jaXBoZXI7XG5cdCAgICAgICAgICAgIHZhciBibG9ja1NpemUgPSBjaXBoZXIuYmxvY2tTaXplO1xuXG5cdCAgICAgICAgICAgIGdlbmVyYXRlS2V5c3RyZWFtQW5kRW5jcnlwdC5jYWxsKHRoaXMsIHdvcmRzLCBvZmZzZXQsIGJsb2NrU2l6ZSwgY2lwaGVyKTtcblxuXHQgICAgICAgICAgICAvLyBSZW1lbWJlciB0aGlzIGJsb2NrIHRvIHVzZSB3aXRoIG5leHQgYmxvY2tcblx0ICAgICAgICAgICAgdGhpcy5fcHJldkJsb2NrID0gd29yZHMuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBibG9ja1NpemUpO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICBDRkIuRGVjcnlwdG9yID0gQ0ZCLmV4dGVuZCh7XG5cdCAgICAgICAgcHJvY2Vzc0Jsb2NrOiBmdW5jdGlvbiAod29yZHMsIG9mZnNldCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGNpcGhlciA9IHRoaXMuX2NpcGhlcjtcblx0ICAgICAgICAgICAgdmFyIGJsb2NrU2l6ZSA9IGNpcGhlci5ibG9ja1NpemU7XG5cblx0ICAgICAgICAgICAgLy8gUmVtZW1iZXIgdGhpcyBibG9jayB0byB1c2Ugd2l0aCBuZXh0IGJsb2NrXG5cdCAgICAgICAgICAgIHZhciB0aGlzQmxvY2sgPSB3b3Jkcy5zbGljZShvZmZzZXQsIG9mZnNldCArIGJsb2NrU2l6ZSk7XG5cblx0ICAgICAgICAgICAgZ2VuZXJhdGVLZXlzdHJlYW1BbmRFbmNyeXB0LmNhbGwodGhpcywgd29yZHMsIG9mZnNldCwgYmxvY2tTaXplLCBjaXBoZXIpO1xuXG5cdCAgICAgICAgICAgIC8vIFRoaXMgYmxvY2sgYmVjb21lcyB0aGUgcHJldmlvdXMgYmxvY2tcblx0ICAgICAgICAgICAgdGhpcy5fcHJldkJsb2NrID0gdGhpc0Jsb2NrO1xuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICBmdW5jdGlvbiBnZW5lcmF0ZUtleXN0cmVhbUFuZEVuY3J5cHQod29yZHMsIG9mZnNldCwgYmxvY2tTaXplLCBjaXBoZXIpIHtcblx0ICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgIHZhciBpdiA9IHRoaXMuX2l2O1xuXG5cdCAgICAgICAgLy8gR2VuZXJhdGUga2V5c3RyZWFtXG5cdCAgICAgICAgaWYgKGl2KSB7XG5cdCAgICAgICAgICAgIHZhciBrZXlzdHJlYW0gPSBpdi5zbGljZSgwKTtcblxuXHQgICAgICAgICAgICAvLyBSZW1vdmUgSVYgZm9yIHN1YnNlcXVlbnQgYmxvY2tzXG5cdCAgICAgICAgICAgIHRoaXMuX2l2ID0gdW5kZWZpbmVkO1xuXHQgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgIHZhciBrZXlzdHJlYW0gPSB0aGlzLl9wcmV2QmxvY2s7XG5cdCAgICAgICAgfVxuXHQgICAgICAgIGNpcGhlci5lbmNyeXB0QmxvY2soa2V5c3RyZWFtLCAwKTtcblxuXHQgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJsb2NrU2l6ZTsgaSsrKSB7XG5cdCAgICAgICAgICAgIHdvcmRzW29mZnNldCArIGldIF49IGtleXN0cmVhbVtpXTtcblx0ICAgICAgICB9XG5cdCAgICB9XG5cblx0ICAgIHJldHVybiBDRkI7XG5cdH0oKSk7XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMubW9kZS5DRkI7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9tb2RlLWNmYi5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9jaXBoZXItY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCIsIFwiLi9jaXBoZXItY29yZVwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0LyoqXG5cdCAqIENvdW50ZXIgYmxvY2sgbW9kZS5cblx0ICovXG5cdENyeXB0b0pTLm1vZGUuQ1RSID0gKGZ1bmN0aW9uICgpIHtcblx0ICAgIHZhciBDVFIgPSBDcnlwdG9KUy5saWIuQmxvY2tDaXBoZXJNb2RlLmV4dGVuZCgpO1xuXG5cdCAgICB2YXIgRW5jcnlwdG9yID0gQ1RSLkVuY3J5cHRvciA9IENUUi5leHRlbmQoe1xuXHQgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBjaXBoZXIgPSB0aGlzLl9jaXBoZXJcblx0ICAgICAgICAgICAgdmFyIGJsb2NrU2l6ZSA9IGNpcGhlci5ibG9ja1NpemU7XG5cdCAgICAgICAgICAgIHZhciBpdiA9IHRoaXMuX2l2O1xuXHQgICAgICAgICAgICB2YXIgY291bnRlciA9IHRoaXMuX2NvdW50ZXI7XG5cblx0ICAgICAgICAgICAgLy8gR2VuZXJhdGUga2V5c3RyZWFtXG5cdCAgICAgICAgICAgIGlmIChpdikge1xuXHQgICAgICAgICAgICAgICAgY291bnRlciA9IHRoaXMuX2NvdW50ZXIgPSBpdi5zbGljZSgwKTtcblxuXHQgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIElWIGZvciBzdWJzZXF1ZW50IGJsb2Nrc1xuXHQgICAgICAgICAgICAgICAgdGhpcy5faXYgPSB1bmRlZmluZWQ7XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgdmFyIGtleXN0cmVhbSA9IGNvdW50ZXIuc2xpY2UoMCk7XG5cdCAgICAgICAgICAgIGNpcGhlci5lbmNyeXB0QmxvY2soa2V5c3RyZWFtLCAwKTtcblxuXHQgICAgICAgICAgICAvLyBJbmNyZW1lbnQgY291bnRlclxuXHQgICAgICAgICAgICBjb3VudGVyW2Jsb2NrU2l6ZSAtIDFdID0gKGNvdW50ZXJbYmxvY2tTaXplIC0gMV0gKyAxKSB8IDBcblxuXHQgICAgICAgICAgICAvLyBFbmNyeXB0XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYmxvY2tTaXplOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIHdvcmRzW29mZnNldCArIGldIF49IGtleXN0cmVhbVtpXTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICBDVFIuRGVjcnlwdG9yID0gRW5jcnlwdG9yO1xuXG5cdCAgICByZXR1cm4gQ1RSO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLm1vZGUuQ1RSO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvbW9kZS1jdHIuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vY2lwaGVyLWNvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdC8qKiBAcHJlc2VydmVcblx0ICogQ291bnRlciBibG9jayBtb2RlIGNvbXBhdGlibGUgd2l0aCAgRHIgQnJpYW4gR2xhZG1hbiBmaWxlZW5jLmNcblx0ICogZGVyaXZlZCBmcm9tIENyeXB0b0pTLm1vZGUuQ1RSXG5cdCAqIEphbiBIcnVieSBqaHJ1Ynkud2ViQGdtYWlsLmNvbVxuXHQgKi9cblx0Q3J5cHRvSlMubW9kZS5DVFJHbGFkbWFuID0gKGZ1bmN0aW9uICgpIHtcblx0ICAgIHZhciBDVFJHbGFkbWFuID0gQ3J5cHRvSlMubGliLkJsb2NrQ2lwaGVyTW9kZS5leHRlbmQoKTtcblxuXHRcdGZ1bmN0aW9uIGluY1dvcmQod29yZClcblx0XHR7XG5cdFx0XHRpZiAoKCh3b3JkID4+IDI0KSAmIDB4ZmYpID09PSAweGZmKSB7IC8vb3ZlcmZsb3dcblx0XHRcdHZhciBiMSA9ICh3b3JkID4+IDE2KSYweGZmO1xuXHRcdFx0dmFyIGIyID0gKHdvcmQgPj4gOCkmMHhmZjtcblx0XHRcdHZhciBiMyA9IHdvcmQgJiAweGZmO1xuXG5cdFx0XHRpZiAoYjEgPT09IDB4ZmYpIC8vIG92ZXJmbG93IGIxXG5cdFx0XHR7XG5cdFx0XHRiMSA9IDA7XG5cdFx0XHRpZiAoYjIgPT09IDB4ZmYpXG5cdFx0XHR7XG5cdFx0XHRcdGIyID0gMDtcblx0XHRcdFx0aWYgKGIzID09PSAweGZmKVxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0YjMgPSAwO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2Vcblx0XHRcdFx0e1xuXHRcdFx0XHRcdCsrYjM7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGVsc2Vcblx0XHRcdHtcblx0XHRcdFx0KytiMjtcblx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGVsc2Vcblx0XHRcdHtcblx0XHRcdCsrYjE7XG5cdFx0XHR9XG5cblx0XHRcdHdvcmQgPSAwO1xuXHRcdFx0d29yZCArPSAoYjEgPDwgMTYpO1xuXHRcdFx0d29yZCArPSAoYjIgPDwgOCk7XG5cdFx0XHR3b3JkICs9IGIzO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZVxuXHRcdFx0e1xuXHRcdFx0d29yZCArPSAoMHgwMSA8PCAyNCk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gd29yZDtcblx0XHR9XG5cblx0XHRmdW5jdGlvbiBpbmNDb3VudGVyKGNvdW50ZXIpXG5cdFx0e1xuXHRcdFx0aWYgKChjb3VudGVyWzBdID0gaW5jV29yZChjb3VudGVyWzBdKSkgPT09IDApXG5cdFx0XHR7XG5cdFx0XHRcdC8vIGVuY3JfZGF0YSBpbiBmaWxlZW5jLmMgZnJvbSAgRHIgQnJpYW4gR2xhZG1hbidzIGNvdW50cyBvbmx5IHdpdGggRFdPUkQgaiA8IDhcblx0XHRcdFx0Y291bnRlclsxXSA9IGluY1dvcmQoY291bnRlclsxXSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gY291bnRlcjtcblx0XHR9XG5cblx0ICAgIHZhciBFbmNyeXB0b3IgPSBDVFJHbGFkbWFuLkVuY3J5cHRvciA9IENUUkdsYWRtYW4uZXh0ZW5kKHtcblx0ICAgICAgICBwcm9jZXNzQmxvY2s6IGZ1bmN0aW9uICh3b3Jkcywgb2Zmc2V0KSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgY2lwaGVyID0gdGhpcy5fY2lwaGVyXG5cdCAgICAgICAgICAgIHZhciBibG9ja1NpemUgPSBjaXBoZXIuYmxvY2tTaXplO1xuXHQgICAgICAgICAgICB2YXIgaXYgPSB0aGlzLl9pdjtcblx0ICAgICAgICAgICAgdmFyIGNvdW50ZXIgPSB0aGlzLl9jb3VudGVyO1xuXG5cdCAgICAgICAgICAgIC8vIEdlbmVyYXRlIGtleXN0cmVhbVxuXHQgICAgICAgICAgICBpZiAoaXYpIHtcblx0ICAgICAgICAgICAgICAgIGNvdW50ZXIgPSB0aGlzLl9jb3VudGVyID0gaXYuc2xpY2UoMCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIFJlbW92ZSBJViBmb3Igc3Vic2VxdWVudCBibG9ja3Ncblx0ICAgICAgICAgICAgICAgIHRoaXMuX2l2ID0gdW5kZWZpbmVkO1xuXHQgICAgICAgICAgICB9XG5cblx0XHRcdFx0aW5jQ291bnRlcihjb3VudGVyKTtcblxuXHRcdFx0XHR2YXIga2V5c3RyZWFtID0gY291bnRlci5zbGljZSgwKTtcblx0ICAgICAgICAgICAgY2lwaGVyLmVuY3J5cHRCbG9jayhrZXlzdHJlYW0sIDApO1xuXG5cdCAgICAgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBibG9ja1NpemU7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgd29yZHNbb2Zmc2V0ICsgaV0gXj0ga2V5c3RyZWFtW2ldO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIENUUkdsYWRtYW4uRGVjcnlwdG9yID0gRW5jcnlwdG9yO1xuXG5cdCAgICByZXR1cm4gQ1RSR2xhZG1hbjtcblx0fSgpKTtcblxuXG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMubW9kZS5DVFJHbGFkbWFuO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvbW9kZS1jdHItZ2xhZG1hbi5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9jaXBoZXItY29yZVwiKSk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcblx0XHQvLyBBTURcblx0XHRkZWZpbmUoW1wiLi9jb3JlXCIsIFwiLi9jaXBoZXItY29yZVwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0LyoqXG5cdCAqIE91dHB1dCBGZWVkYmFjayBibG9jayBtb2RlLlxuXHQgKi9cblx0Q3J5cHRvSlMubW9kZS5PRkIgPSAoZnVuY3Rpb24gKCkge1xuXHQgICAgdmFyIE9GQiA9IENyeXB0b0pTLmxpYi5CbG9ja0NpcGhlck1vZGUuZXh0ZW5kKCk7XG5cblx0ICAgIHZhciBFbmNyeXB0b3IgPSBPRkIuRW5jcnlwdG9yID0gT0ZCLmV4dGVuZCh7XG5cdCAgICAgICAgcHJvY2Vzc0Jsb2NrOiBmdW5jdGlvbiAod29yZHMsIG9mZnNldCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGNpcGhlciA9IHRoaXMuX2NpcGhlclxuXHQgICAgICAgICAgICB2YXIgYmxvY2tTaXplID0gY2lwaGVyLmJsb2NrU2l6ZTtcblx0ICAgICAgICAgICAgdmFyIGl2ID0gdGhpcy5faXY7XG5cdCAgICAgICAgICAgIHZhciBrZXlzdHJlYW0gPSB0aGlzLl9rZXlzdHJlYW07XG5cblx0ICAgICAgICAgICAgLy8gR2VuZXJhdGUga2V5c3RyZWFtXG5cdCAgICAgICAgICAgIGlmIChpdikge1xuXHQgICAgICAgICAgICAgICAga2V5c3RyZWFtID0gdGhpcy5fa2V5c3RyZWFtID0gaXYuc2xpY2UoMCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIFJlbW92ZSBJViBmb3Igc3Vic2VxdWVudCBibG9ja3Ncblx0ICAgICAgICAgICAgICAgIHRoaXMuX2l2ID0gdW5kZWZpbmVkO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgIGNpcGhlci5lbmNyeXB0QmxvY2soa2V5c3RyZWFtLCAwKTtcblxuXHQgICAgICAgICAgICAvLyBFbmNyeXB0XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYmxvY2tTaXplOyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIHdvcmRzW29mZnNldCArIGldIF49IGtleXN0cmVhbVtpXTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH1cblx0ICAgIH0pO1xuXG5cdCAgICBPRkIuRGVjcnlwdG9yID0gRW5jcnlwdG9yO1xuXG5cdCAgICByZXR1cm4gT0ZCO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLm1vZGUuT0ZCO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvbW9kZS1vZmIuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vY2lwaGVyLWNvcmVcIl0sIGZhY3RvcnkpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdC8vIEdsb2JhbCAoYnJvd3Nlcilcblx0XHRmYWN0b3J5KHJvb3QuQ3J5cHRvSlMpO1xuXHR9XG59KHRoaXMsIGZ1bmN0aW9uIChDcnlwdG9KUykge1xuXG5cdC8qKlxuXHQgKiBFbGVjdHJvbmljIENvZGVib29rIGJsb2NrIG1vZGUuXG5cdCAqL1xuXHRDcnlwdG9KUy5tb2RlLkVDQiA9IChmdW5jdGlvbiAoKSB7XG5cdCAgICB2YXIgRUNCID0gQ3J5cHRvSlMubGliLkJsb2NrQ2lwaGVyTW9kZS5leHRlbmQoKTtcblxuXHQgICAgRUNCLkVuY3J5cHRvciA9IEVDQi5leHRlbmQoe1xuXHQgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fY2lwaGVyLmVuY3J5cHRCbG9jayh3b3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICB9XG5cdCAgICB9KTtcblxuXHQgICAgRUNCLkRlY3J5cHRvciA9IEVDQi5leHRlbmQoe1xuXHQgICAgICAgIHByb2Nlc3NCbG9jazogZnVuY3Rpb24gKHdvcmRzLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fY2lwaGVyLmRlY3J5cHRCbG9jayh3b3Jkcywgb2Zmc2V0KTtcblx0ICAgICAgICB9XG5cdCAgICB9KTtcblxuXHQgICAgcmV0dXJuIEVDQjtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5tb2RlLkVDQjtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL21vZGUtZWNiLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogQU5TSSBYLjkyMyBwYWRkaW5nIHN0cmF0ZWd5LlxuXHQgKi9cblx0Q3J5cHRvSlMucGFkLkFuc2lYOTIzID0ge1xuXHQgICAgcGFkOiBmdW5jdGlvbiAoZGF0YSwgYmxvY2tTaXplKSB7XG5cdCAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgdmFyIGRhdGFTaWdCeXRlcyA9IGRhdGEuc2lnQnl0ZXM7XG5cdCAgICAgICAgdmFyIGJsb2NrU2l6ZUJ5dGVzID0gYmxvY2tTaXplICogNDtcblxuXHQgICAgICAgIC8vIENvdW50IHBhZGRpbmcgYnl0ZXNcblx0ICAgICAgICB2YXIgblBhZGRpbmdCeXRlcyA9IGJsb2NrU2l6ZUJ5dGVzIC0gZGF0YVNpZ0J5dGVzICUgYmxvY2tTaXplQnl0ZXM7XG5cblx0ICAgICAgICAvLyBDb21wdXRlIGxhc3QgYnl0ZSBwb3NpdGlvblxuXHQgICAgICAgIHZhciBsYXN0Qnl0ZVBvcyA9IGRhdGFTaWdCeXRlcyArIG5QYWRkaW5nQnl0ZXMgLSAxO1xuXG5cdCAgICAgICAgLy8gUGFkXG5cdCAgICAgICAgZGF0YS5jbGFtcCgpO1xuXHQgICAgICAgIGRhdGEud29yZHNbbGFzdEJ5dGVQb3MgPj4+IDJdIHw9IG5QYWRkaW5nQnl0ZXMgPDwgKDI0IC0gKGxhc3RCeXRlUG9zICUgNCkgKiA4KTtcblx0ICAgICAgICBkYXRhLnNpZ0J5dGVzICs9IG5QYWRkaW5nQnl0ZXM7XG5cdCAgICB9LFxuXG5cdCAgICB1bnBhZDogZnVuY3Rpb24gKGRhdGEpIHtcblx0ICAgICAgICAvLyBHZXQgbnVtYmVyIG9mIHBhZGRpbmcgYnl0ZXMgZnJvbSBsYXN0IGJ5dGVcblx0ICAgICAgICB2YXIgblBhZGRpbmdCeXRlcyA9IGRhdGEud29yZHNbKGRhdGEuc2lnQnl0ZXMgLSAxKSA+Pj4gMl0gJiAweGZmO1xuXG5cdCAgICAgICAgLy8gUmVtb3ZlIHBhZGRpbmdcblx0ICAgICAgICBkYXRhLnNpZ0J5dGVzIC09IG5QYWRkaW5nQnl0ZXM7XG5cdCAgICB9XG5cdH07XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMucGFkLkFuc2l4OTIzO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvcGFkLWFuc2l4OTIzLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogSVNPIDEwMTI2IHBhZGRpbmcgc3RyYXRlZ3kuXG5cdCAqL1xuXHRDcnlwdG9KUy5wYWQuSXNvMTAxMjYgPSB7XG5cdCAgICBwYWQ6IGZ1bmN0aW9uIChkYXRhLCBibG9ja1NpemUpIHtcblx0ICAgICAgICAvLyBTaG9ydGN1dFxuXHQgICAgICAgIHZhciBibG9ja1NpemVCeXRlcyA9IGJsb2NrU2l6ZSAqIDQ7XG5cblx0ICAgICAgICAvLyBDb3VudCBwYWRkaW5nIGJ5dGVzXG5cdCAgICAgICAgdmFyIG5QYWRkaW5nQnl0ZXMgPSBibG9ja1NpemVCeXRlcyAtIGRhdGEuc2lnQnl0ZXMgJSBibG9ja1NpemVCeXRlcztcblxuXHQgICAgICAgIC8vIFBhZFxuXHQgICAgICAgIGRhdGEuY29uY2F0KENyeXB0b0pTLmxpYi5Xb3JkQXJyYXkucmFuZG9tKG5QYWRkaW5nQnl0ZXMgLSAxKSkuXG5cdCAgICAgICAgICAgICBjb25jYXQoQ3J5cHRvSlMubGliLldvcmRBcnJheS5jcmVhdGUoW25QYWRkaW5nQnl0ZXMgPDwgMjRdLCAxKSk7XG5cdCAgICB9LFxuXG5cdCAgICB1bnBhZDogZnVuY3Rpb24gKGRhdGEpIHtcblx0ICAgICAgICAvLyBHZXQgbnVtYmVyIG9mIHBhZGRpbmcgYnl0ZXMgZnJvbSBsYXN0IGJ5dGVcblx0ICAgICAgICB2YXIgblBhZGRpbmdCeXRlcyA9IGRhdGEud29yZHNbKGRhdGEuc2lnQnl0ZXMgLSAxKSA+Pj4gMl0gJiAweGZmO1xuXG5cdCAgICAgICAgLy8gUmVtb3ZlIHBhZGRpbmdcblx0ICAgICAgICBkYXRhLnNpZ0J5dGVzIC09IG5QYWRkaW5nQnl0ZXM7XG5cdCAgICB9XG5cdH07XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMucGFkLklzbzEwMTI2O1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvcGFkLWlzbzEwMTI2LmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogSVNPL0lFQyA5Nzk3LTEgUGFkZGluZyBNZXRob2QgMi5cblx0ICovXG5cdENyeXB0b0pTLnBhZC5Jc285Nzk3MSA9IHtcblx0ICAgIHBhZDogZnVuY3Rpb24gKGRhdGEsIGJsb2NrU2l6ZSkge1xuXHQgICAgICAgIC8vIEFkZCAweDgwIGJ5dGVcblx0ICAgICAgICBkYXRhLmNvbmNhdChDcnlwdG9KUy5saWIuV29yZEFycmF5LmNyZWF0ZShbMHg4MDAwMDAwMF0sIDEpKTtcblxuXHQgICAgICAgIC8vIFplcm8gcGFkIHRoZSByZXN0XG5cdCAgICAgICAgQ3J5cHRvSlMucGFkLlplcm9QYWRkaW5nLnBhZChkYXRhLCBibG9ja1NpemUpO1xuXHQgICAgfSxcblxuXHQgICAgdW5wYWQ6IGZ1bmN0aW9uIChkYXRhKSB7XG5cdCAgICAgICAgLy8gUmVtb3ZlIHplcm8gcGFkZGluZ1xuXHQgICAgICAgIENyeXB0b0pTLnBhZC5aZXJvUGFkZGluZy51bnBhZChkYXRhKTtcblxuXHQgICAgICAgIC8vIFJlbW92ZSBvbmUgbW9yZSBieXRlIC0tIHRoZSAweDgwIGJ5dGVcblx0ICAgICAgICBkYXRhLnNpZ0J5dGVzLS07XG5cdCAgICB9XG5cdH07XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMucGFkLklzbzk3OTcxO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvcGFkLWlzbzk3OTcxLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogWmVybyBwYWRkaW5nIHN0cmF0ZWd5LlxuXHQgKi9cblx0Q3J5cHRvSlMucGFkLlplcm9QYWRkaW5nID0ge1xuXHQgICAgcGFkOiBmdW5jdGlvbiAoZGF0YSwgYmxvY2tTaXplKSB7XG5cdCAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICB2YXIgYmxvY2tTaXplQnl0ZXMgPSBibG9ja1NpemUgKiA0O1xuXG5cdCAgICAgICAgLy8gUGFkXG5cdCAgICAgICAgZGF0YS5jbGFtcCgpO1xuXHQgICAgICAgIGRhdGEuc2lnQnl0ZXMgKz0gYmxvY2tTaXplQnl0ZXMgLSAoKGRhdGEuc2lnQnl0ZXMgJSBibG9ja1NpemVCeXRlcykgfHwgYmxvY2tTaXplQnl0ZXMpO1xuXHQgICAgfSxcblxuXHQgICAgdW5wYWQ6IGZ1bmN0aW9uIChkYXRhKSB7XG5cdCAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICB2YXIgZGF0YVdvcmRzID0gZGF0YS53b3JkcztcblxuXHQgICAgICAgIC8vIFVucGFkXG5cdCAgICAgICAgdmFyIGkgPSBkYXRhLnNpZ0J5dGVzIC0gMTtcblx0ICAgICAgICB3aGlsZSAoISgoZGF0YVdvcmRzW2kgPj4+IDJdID4+PiAoMjQgLSAoaSAlIDQpICogOCkpICYgMHhmZikpIHtcblx0ICAgICAgICAgICAgaS0tO1xuXHQgICAgICAgIH1cblx0ICAgICAgICBkYXRhLnNpZ0J5dGVzID0gaSArIDE7XG5cdCAgICB9XG5cdH07XG5cblxuXHRyZXR1cm4gQ3J5cHRvSlMucGFkLlplcm9QYWRkaW5nO1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvcGFkLXplcm9wYWRkaW5nLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQvKipcblx0ICogQSBub29wIHBhZGRpbmcgc3RyYXRlZ3kuXG5cdCAqL1xuXHRDcnlwdG9KUy5wYWQuTm9QYWRkaW5nID0ge1xuXHQgICAgcGFkOiBmdW5jdGlvbiAoKSB7XG5cdCAgICB9LFxuXG5cdCAgICB1bnBhZDogZnVuY3Rpb24gKCkge1xuXHQgICAgfVxuXHR9O1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLnBhZC5Ob1BhZGRpbmc7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9wYWQtbm9wYWRkaW5nLmpzIiwiOyhmdW5jdGlvbiAocm9vdCwgZmFjdG9yeSwgdW5kZWYpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0Ly8gQ29tbW9uSlNcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHMgPSBmYWN0b3J5KHJlcXVpcmUoXCIuL2NvcmVcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKHVuZGVmaW5lZCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgQ2lwaGVyUGFyYW1zID0gQ19saWIuQ2lwaGVyUGFyYW1zO1xuXHQgICAgdmFyIENfZW5jID0gQy5lbmM7XG5cdCAgICB2YXIgSGV4ID0gQ19lbmMuSGV4O1xuXHQgICAgdmFyIENfZm9ybWF0ID0gQy5mb3JtYXQ7XG5cblx0ICAgIHZhciBIZXhGb3JtYXR0ZXIgPSBDX2Zvcm1hdC5IZXggPSB7XG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgdGhlIGNpcGhlcnRleHQgb2YgYSBjaXBoZXIgcGFyYW1zIG9iamVjdCB0byBhIGhleGFkZWNpbWFsbHkgZW5jb2RlZCBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcGFyYW0ge0NpcGhlclBhcmFtc30gY2lwaGVyUGFyYW1zIFRoZSBjaXBoZXIgcGFyYW1zIG9iamVjdC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIGhleGFkZWNpbWFsbHkgZW5jb2RlZCBzdHJpbmcuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAc3RhdGljXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAZXhhbXBsZVxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogICAgIHZhciBoZXhTdHJpbmcgPSBDcnlwdG9KUy5mb3JtYXQuSGV4LnN0cmluZ2lmeShjaXBoZXJQYXJhbXMpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHN0cmluZ2lmeTogZnVuY3Rpb24gKGNpcGhlclBhcmFtcykge1xuXHQgICAgICAgICAgICByZXR1cm4gY2lwaGVyUGFyYW1zLmNpcGhlcnRleHQudG9TdHJpbmcoSGV4KTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgLyoqXG5cdCAgICAgICAgICogQ29udmVydHMgYSBoZXhhZGVjaW1hbGx5IGVuY29kZWQgY2lwaGVydGV4dCBzdHJpbmcgdG8gYSBjaXBoZXIgcGFyYW1zIG9iamVjdC5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBpbnB1dCBUaGUgaGV4YWRlY2ltYWxseSBlbmNvZGVkIHN0cmluZy5cblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqIEByZXR1cm4ge0NpcGhlclBhcmFtc30gVGhlIGNpcGhlciBwYXJhbXMgb2JqZWN0LlxuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQHN0YXRpY1xuXHQgICAgICAgICAqXG5cdCAgICAgICAgICogQGV4YW1wbGVcblx0ICAgICAgICAgKlxuXHQgICAgICAgICAqICAgICB2YXIgY2lwaGVyUGFyYW1zID0gQ3J5cHRvSlMuZm9ybWF0LkhleC5wYXJzZShoZXhTdHJpbmcpO1xuXHQgICAgICAgICAqL1xuXHQgICAgICAgIHBhcnNlOiBmdW5jdGlvbiAoaW5wdXQpIHtcblx0ICAgICAgICAgICAgdmFyIGNpcGhlcnRleHQgPSBIZXgucGFyc2UoaW5wdXQpO1xuXHQgICAgICAgICAgICByZXR1cm4gQ2lwaGVyUGFyYW1zLmNyZWF0ZSh7IGNpcGhlcnRleHQ6IGNpcGhlcnRleHQgfSk7XG5cdCAgICAgICAgfVxuXHQgICAgfTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5mb3JtYXQuSGV4O1xuXG59KSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vfi9jcnlwdG8tanMvZm9ybWF0LWhleC5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9lbmMtYmFzZTY0XCIpLCByZXF1aXJlKFwiLi9tZDVcIiksIHJlcXVpcmUoXCIuL2V2cGtkZlwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vZW5jLWJhc2U2NFwiLCBcIi4vbWQ1XCIsIFwiLi9ldnBrZGZcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgQmxvY2tDaXBoZXIgPSBDX2xpYi5CbG9ja0NpcGhlcjtcblx0ICAgIHZhciBDX2FsZ28gPSBDLmFsZ287XG5cblx0ICAgIC8vIExvb2t1cCB0YWJsZXNcblx0ICAgIHZhciBTQk9YID0gW107XG5cdCAgICB2YXIgSU5WX1NCT1ggPSBbXTtcblx0ICAgIHZhciBTVUJfTUlYXzAgPSBbXTtcblx0ICAgIHZhciBTVUJfTUlYXzEgPSBbXTtcblx0ICAgIHZhciBTVUJfTUlYXzIgPSBbXTtcblx0ICAgIHZhciBTVUJfTUlYXzMgPSBbXTtcblx0ICAgIHZhciBJTlZfU1VCX01JWF8wID0gW107XG5cdCAgICB2YXIgSU5WX1NVQl9NSVhfMSA9IFtdO1xuXHQgICAgdmFyIElOVl9TVUJfTUlYXzIgPSBbXTtcblx0ICAgIHZhciBJTlZfU1VCX01JWF8zID0gW107XG5cblx0ICAgIC8vIENvbXB1dGUgbG9va3VwIHRhYmxlc1xuXHQgICAgKGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAvLyBDb21wdXRlIGRvdWJsZSB0YWJsZVxuXHQgICAgICAgIHZhciBkID0gW107XG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNTY7IGkrKykge1xuXHQgICAgICAgICAgICBpZiAoaSA8IDEyOCkge1xuXHQgICAgICAgICAgICAgICAgZFtpXSA9IGkgPDwgMTtcblx0ICAgICAgICAgICAgfSBlbHNlIHtcblx0ICAgICAgICAgICAgICAgIGRbaV0gPSAoaSA8PCAxKSBeIDB4MTFiO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLy8gV2FsayBHRigyXjgpXG5cdCAgICAgICAgdmFyIHggPSAwO1xuXHQgICAgICAgIHZhciB4aSA9IDA7XG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNTY7IGkrKykge1xuXHQgICAgICAgICAgICAvLyBDb21wdXRlIHNib3hcblx0ICAgICAgICAgICAgdmFyIHN4ID0geGkgXiAoeGkgPDwgMSkgXiAoeGkgPDwgMikgXiAoeGkgPDwgMykgXiAoeGkgPDwgNCk7XG5cdCAgICAgICAgICAgIHN4ID0gKHN4ID4+PiA4KSBeIChzeCAmIDB4ZmYpIF4gMHg2Mztcblx0ICAgICAgICAgICAgU0JPWFt4XSA9IHN4O1xuXHQgICAgICAgICAgICBJTlZfU0JPWFtzeF0gPSB4O1xuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGUgbXVsdGlwbGljYXRpb25cblx0ICAgICAgICAgICAgdmFyIHgyID0gZFt4XTtcblx0ICAgICAgICAgICAgdmFyIHg0ID0gZFt4Ml07XG5cdCAgICAgICAgICAgIHZhciB4OCA9IGRbeDRdO1xuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGUgc3ViIGJ5dGVzLCBtaXggY29sdW1ucyB0YWJsZXNcblx0ICAgICAgICAgICAgdmFyIHQgPSAoZFtzeF0gKiAweDEwMSkgXiAoc3ggKiAweDEwMTAxMDApO1xuXHQgICAgICAgICAgICBTVUJfTUlYXzBbeF0gPSAodCA8PCAyNCkgfCAodCA+Pj4gOCk7XG5cdCAgICAgICAgICAgIFNVQl9NSVhfMVt4XSA9ICh0IDw8IDE2KSB8ICh0ID4+PiAxNik7XG5cdCAgICAgICAgICAgIFNVQl9NSVhfMlt4XSA9ICh0IDw8IDgpICB8ICh0ID4+PiAyNCk7XG5cdCAgICAgICAgICAgIFNVQl9NSVhfM1t4XSA9IHQ7XG5cblx0ICAgICAgICAgICAgLy8gQ29tcHV0ZSBpbnYgc3ViIGJ5dGVzLCBpbnYgbWl4IGNvbHVtbnMgdGFibGVzXG5cdCAgICAgICAgICAgIHZhciB0ID0gKHg4ICogMHgxMDEwMTAxKSBeICh4NCAqIDB4MTAwMDEpIF4gKHgyICogMHgxMDEpIF4gKHggKiAweDEwMTAxMDApO1xuXHQgICAgICAgICAgICBJTlZfU1VCX01JWF8wW3N4XSA9ICh0IDw8IDI0KSB8ICh0ID4+PiA4KTtcblx0ICAgICAgICAgICAgSU5WX1NVQl9NSVhfMVtzeF0gPSAodCA8PCAxNikgfCAodCA+Pj4gMTYpO1xuXHQgICAgICAgICAgICBJTlZfU1VCX01JWF8yW3N4XSA9ICh0IDw8IDgpICB8ICh0ID4+PiAyNCk7XG5cdCAgICAgICAgICAgIElOVl9TVUJfTUlYXzNbc3hdID0gdDtcblxuXHQgICAgICAgICAgICAvLyBDb21wdXRlIG5leHQgY291bnRlclxuXHQgICAgICAgICAgICBpZiAoIXgpIHtcblx0ICAgICAgICAgICAgICAgIHggPSB4aSA9IDE7XG5cdCAgICAgICAgICAgIH0gZWxzZSB7XG5cdCAgICAgICAgICAgICAgICB4ID0geDIgXiBkW2RbZFt4OCBeIHgyXV1dO1xuXHQgICAgICAgICAgICAgICAgeGkgXj0gZFtkW3hpXV07XG5cdCAgICAgICAgICAgIH1cblx0ICAgICAgICB9XG5cdCAgICB9KCkpO1xuXG5cdCAgICAvLyBQcmVjb21wdXRlZCBSY29uIGxvb2t1cFxuXHQgICAgdmFyIFJDT04gPSBbMHgwMCwgMHgwMSwgMHgwMiwgMHgwNCwgMHgwOCwgMHgxMCwgMHgyMCwgMHg0MCwgMHg4MCwgMHgxYiwgMHgzNl07XG5cblx0ICAgIC8qKlxuXHQgICAgICogQUVTIGJsb2NrIGNpcGhlciBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBBRVMgPSBDX2FsZ28uQUVTID0gQmxvY2tDaXBoZXIuZXh0ZW5kKHtcblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTa2lwIHJlc2V0IG9mIG5Sb3VuZHMgaGFzIGJlZW4gc2V0IGJlZm9yZSBhbmQga2V5IGRpZCBub3QgY2hhbmdlXG5cdCAgICAgICAgICAgIGlmICh0aGlzLl9uUm91bmRzICYmIHRoaXMuX2tleVByaW9yUmVzZXQgPT09IHRoaXMuX2tleSkge1xuXHQgICAgICAgICAgICAgICAgcmV0dXJuO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBrZXkgPSB0aGlzLl9rZXlQcmlvclJlc2V0ID0gdGhpcy5fa2V5O1xuXHQgICAgICAgICAgICB2YXIga2V5V29yZHMgPSBrZXkud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBrZXlTaXplID0ga2V5LnNpZ0J5dGVzIC8gNDtcblxuXHQgICAgICAgICAgICAvLyBDb21wdXRlIG51bWJlciBvZiByb3VuZHNcblx0ICAgICAgICAgICAgdmFyIG5Sb3VuZHMgPSB0aGlzLl9uUm91bmRzID0ga2V5U2l6ZSArIDY7XG5cblx0ICAgICAgICAgICAgLy8gQ29tcHV0ZSBudW1iZXIgb2Yga2V5IHNjaGVkdWxlIHJvd3Ncblx0ICAgICAgICAgICAgdmFyIGtzUm93cyA9IChuUm91bmRzICsgMSkgKiA0O1xuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGUga2V5IHNjaGVkdWxlXG5cdCAgICAgICAgICAgIHZhciBrZXlTY2hlZHVsZSA9IHRoaXMuX2tleVNjaGVkdWxlID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGtzUm93ID0gMDsga3NSb3cgPCBrc1Jvd3M7IGtzUm93KyspIHtcblx0ICAgICAgICAgICAgICAgIGlmIChrc1JvdyA8IGtleVNpemUpIHtcblx0ICAgICAgICAgICAgICAgICAgICBrZXlTY2hlZHVsZVtrc1Jvd10gPSBrZXlXb3Jkc1trc1Jvd107XG5cdCAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciB0ID0ga2V5U2NoZWR1bGVba3NSb3cgLSAxXTtcblxuXHQgICAgICAgICAgICAgICAgICAgIGlmICghKGtzUm93ICUga2V5U2l6ZSkpIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgLy8gUm90IHdvcmRcblx0ICAgICAgICAgICAgICAgICAgICAgICAgdCA9ICh0IDw8IDgpIHwgKHQgPj4+IDI0KTtcblxuXHQgICAgICAgICAgICAgICAgICAgICAgICAvLyBTdWIgd29yZFxuXHQgICAgICAgICAgICAgICAgICAgICAgICB0ID0gKFNCT1hbdCA+Pj4gMjRdIDw8IDI0KSB8IChTQk9YWyh0ID4+PiAxNikgJiAweGZmXSA8PCAxNikgfCAoU0JPWFsodCA+Pj4gOCkgJiAweGZmXSA8PCA4KSB8IFNCT1hbdCAmIDB4ZmZdO1xuXG5cdCAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1peCBSY29uXG5cdCAgICAgICAgICAgICAgICAgICAgICAgIHQgXj0gUkNPTlsoa3NSb3cgLyBrZXlTaXplKSB8IDBdIDw8IDI0O1xuXHQgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoa2V5U2l6ZSA+IDYgJiYga3NSb3cgJSBrZXlTaXplID09IDQpIHtcblx0ICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3ViIHdvcmRcblx0ICAgICAgICAgICAgICAgICAgICAgICAgdCA9IChTQk9YW3QgPj4+IDI0XSA8PCAyNCkgfCAoU0JPWFsodCA+Pj4gMTYpICYgMHhmZl0gPDwgMTYpIHwgKFNCT1hbKHQgPj4+IDgpICYgMHhmZl0gPDwgOCkgfCBTQk9YW3QgJiAweGZmXTtcblx0ICAgICAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgICAgICBrZXlTY2hlZHVsZVtrc1Jvd10gPSBrZXlTY2hlZHVsZVtrc1JvdyAtIGtleVNpemVdIF4gdDtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIENvbXB1dGUgaW52IGtleSBzY2hlZHVsZVxuXHQgICAgICAgICAgICB2YXIgaW52S2V5U2NoZWR1bGUgPSB0aGlzLl9pbnZLZXlTY2hlZHVsZSA9IFtdO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBpbnZLc1JvdyA9IDA7IGludktzUm93IDwga3NSb3dzOyBpbnZLc1JvdysrKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIga3NSb3cgPSBrc1Jvd3MgLSBpbnZLc1JvdztcblxuXHQgICAgICAgICAgICAgICAgaWYgKGludktzUm93ICUgNCkge1xuXHQgICAgICAgICAgICAgICAgICAgIHZhciB0ID0ga2V5U2NoZWR1bGVba3NSb3ddO1xuXHQgICAgICAgICAgICAgICAgfSBlbHNlIHtcblx0ICAgICAgICAgICAgICAgICAgICB2YXIgdCA9IGtleVNjaGVkdWxlW2tzUm93IC0gNF07XG5cdCAgICAgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgICAgIGlmIChpbnZLc1JvdyA8IDQgfHwga3NSb3cgPD0gNCkge1xuXHQgICAgICAgICAgICAgICAgICAgIGludktleVNjaGVkdWxlW2ludktzUm93XSA9IHQ7XG5cdCAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXHQgICAgICAgICAgICAgICAgICAgIGludktleVNjaGVkdWxlW2ludktzUm93XSA9IElOVl9TVUJfTUlYXzBbU0JPWFt0ID4+PiAyNF1dIF4gSU5WX1NVQl9NSVhfMVtTQk9YWyh0ID4+PiAxNikgJiAweGZmXV0gXlxuXHQgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIElOVl9TVUJfTUlYXzJbU0JPWFsodCA+Pj4gOCkgJiAweGZmXV0gXiBJTlZfU1VCX01JWF8zW1NCT1hbdCAmIDB4ZmZdXTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBlbmNyeXB0QmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fZG9DcnlwdEJsb2NrKE0sIG9mZnNldCwgdGhpcy5fa2V5U2NoZWR1bGUsIFNVQl9NSVhfMCwgU1VCX01JWF8xLCBTVUJfTUlYXzIsIFNVQl9NSVhfMywgU0JPWCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGRlY3J5cHRCbG9jazogZnVuY3Rpb24gKE0sIG9mZnNldCkge1xuXHQgICAgICAgICAgICAvLyBTd2FwIDJuZCBhbmQgNHRoIHJvd3Ncblx0ICAgICAgICAgICAgdmFyIHQgPSBNW29mZnNldCArIDFdO1xuXHQgICAgICAgICAgICBNW29mZnNldCArIDFdID0gTVtvZmZzZXQgKyAzXTtcblx0ICAgICAgICAgICAgTVtvZmZzZXQgKyAzXSA9IHQ7XG5cblx0ICAgICAgICAgICAgdGhpcy5fZG9DcnlwdEJsb2NrKE0sIG9mZnNldCwgdGhpcy5faW52S2V5U2NoZWR1bGUsIElOVl9TVUJfTUlYXzAsIElOVl9TVUJfTUlYXzEsIElOVl9TVUJfTUlYXzIsIElOVl9TVUJfTUlYXzMsIElOVl9TQk9YKTtcblxuXHQgICAgICAgICAgICAvLyBJbnYgc3dhcCAybmQgYW5kIDR0aCByb3dzXG5cdCAgICAgICAgICAgIHZhciB0ID0gTVtvZmZzZXQgKyAxXTtcblx0ICAgICAgICAgICAgTVtvZmZzZXQgKyAxXSA9IE1bb2Zmc2V0ICsgM107XG5cdCAgICAgICAgICAgIE1bb2Zmc2V0ICsgM10gPSB0O1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9DcnlwdEJsb2NrOiBmdW5jdGlvbiAoTSwgb2Zmc2V0LCBrZXlTY2hlZHVsZSwgU1VCX01JWF8wLCBTVUJfTUlYXzEsIFNVQl9NSVhfMiwgU1VCX01JWF8zLCBTQk9YKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgIHZhciBuUm91bmRzID0gdGhpcy5fblJvdW5kcztcblxuXHQgICAgICAgICAgICAvLyBHZXQgaW5wdXQsIGFkZCByb3VuZCBrZXlcblx0ICAgICAgICAgICAgdmFyIHMwID0gTVtvZmZzZXRdICAgICBeIGtleVNjaGVkdWxlWzBdO1xuXHQgICAgICAgICAgICB2YXIgczEgPSBNW29mZnNldCArIDFdIF4ga2V5U2NoZWR1bGVbMV07XG5cdCAgICAgICAgICAgIHZhciBzMiA9IE1bb2Zmc2V0ICsgMl0gXiBrZXlTY2hlZHVsZVsyXTtcblx0ICAgICAgICAgICAgdmFyIHMzID0gTVtvZmZzZXQgKyAzXSBeIGtleVNjaGVkdWxlWzNdO1xuXG5cdCAgICAgICAgICAgIC8vIEtleSBzY2hlZHVsZSByb3cgY291bnRlclxuXHQgICAgICAgICAgICB2YXIga3NSb3cgPSA0O1xuXG5cdCAgICAgICAgICAgIC8vIFJvdW5kc1xuXHQgICAgICAgICAgICBmb3IgKHZhciByb3VuZCA9IDE7IHJvdW5kIDwgblJvdW5kczsgcm91bmQrKykge1xuXHQgICAgICAgICAgICAgICAgLy8gU2hpZnQgcm93cywgc3ViIGJ5dGVzLCBtaXggY29sdW1ucywgYWRkIHJvdW5kIGtleVxuXHQgICAgICAgICAgICAgICAgdmFyIHQwID0gU1VCX01JWF8wW3MwID4+PiAyNF0gXiBTVUJfTUlYXzFbKHMxID4+PiAxNikgJiAweGZmXSBeIFNVQl9NSVhfMlsoczIgPj4+IDgpICYgMHhmZl0gXiBTVUJfTUlYXzNbczMgJiAweGZmXSBeIGtleVNjaGVkdWxlW2tzUm93KytdO1xuXHQgICAgICAgICAgICAgICAgdmFyIHQxID0gU1VCX01JWF8wW3MxID4+PiAyNF0gXiBTVUJfTUlYXzFbKHMyID4+PiAxNikgJiAweGZmXSBeIFNVQl9NSVhfMlsoczMgPj4+IDgpICYgMHhmZl0gXiBTVUJfTUlYXzNbczAgJiAweGZmXSBeIGtleVNjaGVkdWxlW2tzUm93KytdO1xuXHQgICAgICAgICAgICAgICAgdmFyIHQyID0gU1VCX01JWF8wW3MyID4+PiAyNF0gXiBTVUJfTUlYXzFbKHMzID4+PiAxNikgJiAweGZmXSBeIFNVQl9NSVhfMlsoczAgPj4+IDgpICYgMHhmZl0gXiBTVUJfTUlYXzNbczEgJiAweGZmXSBeIGtleVNjaGVkdWxlW2tzUm93KytdO1xuXHQgICAgICAgICAgICAgICAgdmFyIHQzID0gU1VCX01JWF8wW3MzID4+PiAyNF0gXiBTVUJfTUlYXzFbKHMwID4+PiAxNikgJiAweGZmXSBeIFNVQl9NSVhfMlsoczEgPj4+IDgpICYgMHhmZl0gXiBTVUJfTUlYXzNbczIgJiAweGZmXSBeIGtleVNjaGVkdWxlW2tzUm93KytdO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBVcGRhdGUgc3RhdGVcblx0ICAgICAgICAgICAgICAgIHMwID0gdDA7XG5cdCAgICAgICAgICAgICAgICBzMSA9IHQxO1xuXHQgICAgICAgICAgICAgICAgczIgPSB0Mjtcblx0ICAgICAgICAgICAgICAgIHMzID0gdDM7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBTaGlmdCByb3dzLCBzdWIgYnl0ZXMsIGFkZCByb3VuZCBrZXlcblx0ICAgICAgICAgICAgdmFyIHQwID0gKChTQk9YW3MwID4+PiAyNF0gPDwgMjQpIHwgKFNCT1hbKHMxID4+PiAxNikgJiAweGZmXSA8PCAxNikgfCAoU0JPWFsoczIgPj4+IDgpICYgMHhmZl0gPDwgOCkgfCBTQk9YW3MzICYgMHhmZl0pIF4ga2V5U2NoZWR1bGVba3NSb3crK107XG5cdCAgICAgICAgICAgIHZhciB0MSA9ICgoU0JPWFtzMSA+Pj4gMjRdIDw8IDI0KSB8IChTQk9YWyhzMiA+Pj4gMTYpICYgMHhmZl0gPDwgMTYpIHwgKFNCT1hbKHMzID4+PiA4KSAmIDB4ZmZdIDw8IDgpIHwgU0JPWFtzMCAmIDB4ZmZdKSBeIGtleVNjaGVkdWxlW2tzUm93KytdO1xuXHQgICAgICAgICAgICB2YXIgdDIgPSAoKFNCT1hbczIgPj4+IDI0XSA8PCAyNCkgfCAoU0JPWFsoczMgPj4+IDE2KSAmIDB4ZmZdIDw8IDE2KSB8IChTQk9YWyhzMCA+Pj4gOCkgJiAweGZmXSA8PCA4KSB8IFNCT1hbczEgJiAweGZmXSkgXiBrZXlTY2hlZHVsZVtrc1JvdysrXTtcblx0ICAgICAgICAgICAgdmFyIHQzID0gKChTQk9YW3MzID4+PiAyNF0gPDwgMjQpIHwgKFNCT1hbKHMwID4+PiAxNikgJiAweGZmXSA8PCAxNikgfCAoU0JPWFsoczEgPj4+IDgpICYgMHhmZl0gPDwgOCkgfCBTQk9YW3MyICYgMHhmZl0pIF4ga2V5U2NoZWR1bGVba3NSb3crK107XG5cblx0ICAgICAgICAgICAgLy8gU2V0IG91dHB1dFxuXHQgICAgICAgICAgICBNW29mZnNldF0gICAgID0gdDA7XG5cdCAgICAgICAgICAgIE1bb2Zmc2V0ICsgMV0gPSB0MTtcblx0ICAgICAgICAgICAgTVtvZmZzZXQgKyAyXSA9IHQyO1xuXHQgICAgICAgICAgICBNW29mZnNldCArIDNdID0gdDM7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGtleVNpemU6IDI1Ni8zMlxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb25zIHRvIHRoZSBjaXBoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBjaXBoZXJ0ZXh0ID0gQ3J5cHRvSlMuQUVTLmVuY3J5cHQobWVzc2FnZSwga2V5LCBjZmcpO1xuXHQgICAgICogICAgIHZhciBwbGFpbnRleHQgID0gQ3J5cHRvSlMuQUVTLmRlY3J5cHQoY2lwaGVydGV4dCwga2V5LCBjZmcpO1xuXHQgICAgICovXG5cdCAgICBDLkFFUyA9IEJsb2NrQ2lwaGVyLl9jcmVhdGVIZWxwZXIoQUVTKTtcblx0fSgpKTtcblxuXG5cdHJldHVybiBDcnlwdG9KUy5BRVM7XG5cbn0pKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9+L2NyeXB0by1qcy9hZXMuanMiLCI7KGZ1bmN0aW9uIChyb290LCBmYWN0b3J5LCB1bmRlZikge1xuXHRpZiAodHlwZW9mIGV4cG9ydHMgPT09IFwib2JqZWN0XCIpIHtcblx0XHQvLyBDb21tb25KU1xuXHRcdG1vZHVsZS5leHBvcnRzID0gZXhwb3J0cyA9IGZhY3RvcnkocmVxdWlyZShcIi4vY29yZVwiKSwgcmVxdWlyZShcIi4vZW5jLWJhc2U2NFwiKSwgcmVxdWlyZShcIi4vbWQ1XCIpLCByZXF1aXJlKFwiLi9ldnBrZGZcIiksIHJlcXVpcmUoXCIuL2NpcGhlci1jb3JlXCIpKTtcblx0fVxuXHRlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuXHRcdC8vIEFNRFxuXHRcdGRlZmluZShbXCIuL2NvcmVcIiwgXCIuL2VuYy1iYXNlNjRcIiwgXCIuL21kNVwiLCBcIi4vZXZwa2RmXCIsIFwiLi9jaXBoZXItY29yZVwiXSwgZmFjdG9yeSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Ly8gR2xvYmFsIChicm93c2VyKVxuXHRcdGZhY3Rvcnkocm9vdC5DcnlwdG9KUyk7XG5cdH1cbn0odGhpcywgZnVuY3Rpb24gKENyeXB0b0pTKSB7XG5cblx0KGZ1bmN0aW9uICgpIHtcblx0ICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgdmFyIEMgPSBDcnlwdG9KUztcblx0ICAgIHZhciBDX2xpYiA9IEMubGliO1xuXHQgICAgdmFyIFdvcmRBcnJheSA9IENfbGliLldvcmRBcnJheTtcblx0ICAgIHZhciBCbG9ja0NpcGhlciA9IENfbGliLkJsb2NrQ2lwaGVyO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLy8gUGVybXV0ZWQgQ2hvaWNlIDEgY29uc3RhbnRzXG5cdCAgICB2YXIgUEMxID0gW1xuXHQgICAgICAgIDU3LCA0OSwgNDEsIDMzLCAyNSwgMTcsIDksICAxLFxuXHQgICAgICAgIDU4LCA1MCwgNDIsIDM0LCAyNiwgMTgsIDEwLCAyLFxuXHQgICAgICAgIDU5LCA1MSwgNDMsIDM1LCAyNywgMTksIDExLCAzLFxuXHQgICAgICAgIDYwLCA1MiwgNDQsIDM2LCA2MywgNTUsIDQ3LCAzOSxcblx0ICAgICAgICAzMSwgMjMsIDE1LCA3LCAgNjIsIDU0LCA0NiwgMzgsXG5cdCAgICAgICAgMzAsIDIyLCAxNCwgNiwgIDYxLCA1MywgNDUsIDM3LFxuXHQgICAgICAgIDI5LCAyMSwgMTMsIDUsICAyOCwgMjAsIDEyLCA0XG5cdCAgICBdO1xuXG5cdCAgICAvLyBQZXJtdXRlZCBDaG9pY2UgMiBjb25zdGFudHNcblx0ICAgIHZhciBQQzIgPSBbXG5cdCAgICAgICAgMTQsIDE3LCAxMSwgMjQsIDEsICA1LFxuXHQgICAgICAgIDMsICAyOCwgMTUsIDYsICAyMSwgMTAsXG5cdCAgICAgICAgMjMsIDE5LCAxMiwgNCwgIDI2LCA4LFxuXHQgICAgICAgIDE2LCA3LCAgMjcsIDIwLCAxMywgMixcblx0ICAgICAgICA0MSwgNTIsIDMxLCAzNywgNDcsIDU1LFxuXHQgICAgICAgIDMwLCA0MCwgNTEsIDQ1LCAzMywgNDgsXG5cdCAgICAgICAgNDQsIDQ5LCAzOSwgNTYsIDM0LCA1Myxcblx0ICAgICAgICA0NiwgNDIsIDUwLCAzNiwgMjksIDMyXG5cdCAgICBdO1xuXG5cdCAgICAvLyBDdW11bGF0aXZlIGJpdCBzaGlmdCBjb25zdGFudHNcblx0ICAgIHZhciBCSVRfU0hJRlRTID0gWzEsICAyLCAgNCwgIDYsICA4LCAgMTAsIDEyLCAxNCwgMTUsIDE3LCAxOSwgMjEsIDIzLCAyNSwgMjcsIDI4XTtcblxuXHQgICAgLy8gU0JPWGVzIGFuZCByb3VuZCBwZXJtdXRhdGlvbiBjb25zdGFudHNcblx0ICAgIHZhciBTQk9YX1AgPSBbXG5cdCAgICAgICAge1xuXHQgICAgICAgICAgICAweDA6IDB4ODA4MjAwLFxuXHQgICAgICAgICAgICAweDEwMDAwMDAwOiAweDgwMDAsXG5cdCAgICAgICAgICAgIDB4MjAwMDAwMDA6IDB4ODA4MDAyLFxuXHQgICAgICAgICAgICAweDMwMDAwMDAwOiAweDIsXG5cdCAgICAgICAgICAgIDB4NDAwMDAwMDA6IDB4MjAwLFxuXHQgICAgICAgICAgICAweDUwMDAwMDAwOiAweDgwODIwMixcblx0ICAgICAgICAgICAgMHg2MDAwMDAwMDogMHg4MDAyMDIsXG5cdCAgICAgICAgICAgIDB4NzAwMDAwMDA6IDB4ODAwMDAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDAwOiAweDIwMixcblx0ICAgICAgICAgICAgMHg5MDAwMDAwMDogMHg4MDAyMDAsXG5cdCAgICAgICAgICAgIDB4YTAwMDAwMDA6IDB4ODIwMCxcblx0ICAgICAgICAgICAgMHhiMDAwMDAwMDogMHg4MDgwMDAsXG5cdCAgICAgICAgICAgIDB4YzAwMDAwMDA6IDB4ODAwMixcblx0ICAgICAgICAgICAgMHhkMDAwMDAwMDogMHg4MDAwMDIsXG5cdCAgICAgICAgICAgIDB4ZTAwMDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHhmMDAwMDAwMDogMHg4MjAyLFxuXHQgICAgICAgICAgICAweDgwMDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHgxODAwMDAwMDogMHg4MDgyMDIsXG5cdCAgICAgICAgICAgIDB4MjgwMDAwMDA6IDB4ODIwMixcblx0ICAgICAgICAgICAgMHgzODAwMDAwMDogMHg4MDAwLFxuXHQgICAgICAgICAgICAweDQ4MDAwMDAwOiAweDgwODIwMCxcblx0ICAgICAgICAgICAgMHg1ODAwMDAwMDogMHgyMDAsXG5cdCAgICAgICAgICAgIDB4NjgwMDAwMDA6IDB4ODA4MDAyLFxuXHQgICAgICAgICAgICAweDc4MDAwMDAwOiAweDIsXG5cdCAgICAgICAgICAgIDB4ODgwMDAwMDA6IDB4ODAwMjAwLFxuXHQgICAgICAgICAgICAweDk4MDAwMDAwOiAweDgyMDAsXG5cdCAgICAgICAgICAgIDB4YTgwMDAwMDA6IDB4ODA4MDAwLFxuXHQgICAgICAgICAgICAweGI4MDAwMDAwOiAweDgwMDIwMixcblx0ICAgICAgICAgICAgMHhjODAwMDAwMDogMHg4MDAwMDIsXG5cdCAgICAgICAgICAgIDB4ZDgwMDAwMDA6IDB4ODAwMixcblx0ICAgICAgICAgICAgMHhlODAwMDAwMDogMHgyMDIsXG5cdCAgICAgICAgICAgIDB4ZjgwMDAwMDA6IDB4ODAwMDAwLFxuXHQgICAgICAgICAgICAweDE6IDB4ODAwMCxcblx0ICAgICAgICAgICAgMHgxMDAwMDAwMTogMHgyLFxuXHQgICAgICAgICAgICAweDIwMDAwMDAxOiAweDgwODIwMCxcblx0ICAgICAgICAgICAgMHgzMDAwMDAwMTogMHg4MDAwMDAsXG5cdCAgICAgICAgICAgIDB4NDAwMDAwMDE6IDB4ODA4MDAyLFxuXHQgICAgICAgICAgICAweDUwMDAwMDAxOiAweDgyMDAsXG5cdCAgICAgICAgICAgIDB4NjAwMDAwMDE6IDB4MjAwLFxuXHQgICAgICAgICAgICAweDcwMDAwMDAxOiAweDgwMDIwMixcblx0ICAgICAgICAgICAgMHg4MDAwMDAwMTogMHg4MDgyMDIsXG5cdCAgICAgICAgICAgIDB4OTAwMDAwMDE6IDB4ODA4MDAwLFxuXHQgICAgICAgICAgICAweGEwMDAwMDAxOiAweDgwMDAwMixcblx0ICAgICAgICAgICAgMHhiMDAwMDAwMTogMHg4MjAyLFxuXHQgICAgICAgICAgICAweGMwMDAwMDAxOiAweDIwMixcblx0ICAgICAgICAgICAgMHhkMDAwMDAwMTogMHg4MDAyMDAsXG5cdCAgICAgICAgICAgIDB4ZTAwMDAwMDE6IDB4ODAwMixcblx0ICAgICAgICAgICAgMHhmMDAwMDAwMTogMHgwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDE6IDB4ODA4MjAyLFxuXHQgICAgICAgICAgICAweDE4MDAwMDAxOiAweDgwODAwMCxcblx0ICAgICAgICAgICAgMHgyODAwMDAwMTogMHg4MDAwMDAsXG5cdCAgICAgICAgICAgIDB4MzgwMDAwMDE6IDB4MjAwLFxuXHQgICAgICAgICAgICAweDQ4MDAwMDAxOiAweDgwMDAsXG5cdCAgICAgICAgICAgIDB4NTgwMDAwMDE6IDB4ODAwMDAyLFxuXHQgICAgICAgICAgICAweDY4MDAwMDAxOiAweDIsXG5cdCAgICAgICAgICAgIDB4NzgwMDAwMDE6IDB4ODIwMixcblx0ICAgICAgICAgICAgMHg4ODAwMDAwMTogMHg4MDAyLFxuXHQgICAgICAgICAgICAweDk4MDAwMDAxOiAweDgwMDIwMixcblx0ICAgICAgICAgICAgMHhhODAwMDAwMTogMHgyMDIsXG5cdCAgICAgICAgICAgIDB4YjgwMDAwMDE6IDB4ODA4MjAwLFxuXHQgICAgICAgICAgICAweGM4MDAwMDAxOiAweDgwMDIwMCxcblx0ICAgICAgICAgICAgMHhkODAwMDAwMTogMHgwLFxuXHQgICAgICAgICAgICAweGU4MDAwMDAxOiAweDgyMDAsXG5cdCAgICAgICAgICAgIDB4ZjgwMDAwMDE6IDB4ODA4MDAyXG5cdCAgICAgICAgfSxcblx0ICAgICAgICB7XG5cdCAgICAgICAgICAgIDB4MDogMHg0MDA4NDAxMCxcblx0ICAgICAgICAgICAgMHgxMDAwMDAwOiAweDQwMDAsXG5cdCAgICAgICAgICAgIDB4MjAwMDAwMDogMHg4MDAwMCxcblx0ICAgICAgICAgICAgMHgzMDAwMDAwOiAweDQwMDgwMDEwLFxuXHQgICAgICAgICAgICAweDQwMDAwMDA6IDB4NDAwMDAwMTAsXG5cdCAgICAgICAgICAgIDB4NTAwMDAwMDogMHg0MDA4NDAwMCxcblx0ICAgICAgICAgICAgMHg2MDAwMDAwOiAweDQwMDA0MDAwLFxuXHQgICAgICAgICAgICAweDcwMDAwMDA6IDB4MTAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDogMHg4NDAwMCxcblx0ICAgICAgICAgICAgMHg5MDAwMDAwOiAweDQwMDA0MDEwLFxuXHQgICAgICAgICAgICAweGEwMDAwMDA6IDB4NDAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4YjAwMDAwMDogMHg4NDAxMCxcblx0ICAgICAgICAgICAgMHhjMDAwMDAwOiAweDgwMDEwLFxuXHQgICAgICAgICAgICAweGQwMDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHhlMDAwMDAwOiAweDQwMTAsXG5cdCAgICAgICAgICAgIDB4ZjAwMDAwMDogMHg0MDA4MDAwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDA6IDB4NDAwMDQwMDAsXG5cdCAgICAgICAgICAgIDB4MTgwMDAwMDogMHg4NDAxMCxcblx0ICAgICAgICAgICAgMHgyODAwMDAwOiAweDEwLFxuXHQgICAgICAgICAgICAweDM4MDAwMDA6IDB4NDAwMDQwMTAsXG5cdCAgICAgICAgICAgIDB4NDgwMDAwMDogMHg0MDA4NDAxMCxcblx0ICAgICAgICAgICAgMHg1ODAwMDAwOiAweDQwMDAwMDAwLFxuXHQgICAgICAgICAgICAweDY4MDAwMDA6IDB4ODAwMDAsXG5cdCAgICAgICAgICAgIDB4NzgwMDAwMDogMHg0MDA4MDAxMCxcblx0ICAgICAgICAgICAgMHg4ODAwMDAwOiAweDgwMDEwLFxuXHQgICAgICAgICAgICAweDk4MDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHhhODAwMDAwOiAweDQwMDAsXG5cdCAgICAgICAgICAgIDB4YjgwMDAwMDogMHg0MDA4MDAwMCxcblx0ICAgICAgICAgICAgMHhjODAwMDAwOiAweDQwMDAwMDEwLFxuXHQgICAgICAgICAgICAweGQ4MDAwMDA6IDB4ODQwMDAsXG5cdCAgICAgICAgICAgIDB4ZTgwMDAwMDogMHg0MDA4NDAwMCxcblx0ICAgICAgICAgICAgMHhmODAwMDAwOiAweDQwMTAsXG5cdCAgICAgICAgICAgIDB4MTAwMDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHgxMTAwMDAwMDogMHg0MDA4MDAxMCxcblx0ICAgICAgICAgICAgMHgxMjAwMDAwMDogMHg0MDAwNDAxMCxcblx0ICAgICAgICAgICAgMHgxMzAwMDAwMDogMHg0MDA4NDAwMCxcblx0ICAgICAgICAgICAgMHgxNDAwMDAwMDogMHg0MDA4MDAwMCxcblx0ICAgICAgICAgICAgMHgxNTAwMDAwMDogMHgxMCxcblx0ICAgICAgICAgICAgMHgxNjAwMDAwMDogMHg4NDAxMCxcblx0ICAgICAgICAgICAgMHgxNzAwMDAwMDogMHg0MDAwLFxuXHQgICAgICAgICAgICAweDE4MDAwMDAwOiAweDQwMTAsXG5cdCAgICAgICAgICAgIDB4MTkwMDAwMDA6IDB4ODAwMDAsXG5cdCAgICAgICAgICAgIDB4MWEwMDAwMDA6IDB4ODAwMTAsXG5cdCAgICAgICAgICAgIDB4MWIwMDAwMDA6IDB4NDAwMDAwMTAsXG5cdCAgICAgICAgICAgIDB4MWMwMDAwMDA6IDB4ODQwMDAsXG5cdCAgICAgICAgICAgIDB4MWQwMDAwMDA6IDB4NDAwMDQwMDAsXG5cdCAgICAgICAgICAgIDB4MWUwMDAwMDA6IDB4NDAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWYwMDAwMDA6IDB4NDAwODQwMTAsXG5cdCAgICAgICAgICAgIDB4MTA4MDAwMDA6IDB4ODQwMTAsXG5cdCAgICAgICAgICAgIDB4MTE4MDAwMDA6IDB4ODAwMDAsXG5cdCAgICAgICAgICAgIDB4MTI4MDAwMDA6IDB4NDAwODAwMDAsXG5cdCAgICAgICAgICAgIDB4MTM4MDAwMDA6IDB4NDAwMCxcblx0ICAgICAgICAgICAgMHgxNDgwMDAwMDogMHg0MDAwNDAwMCxcblx0ICAgICAgICAgICAgMHgxNTgwMDAwMDogMHg0MDA4NDAxMCxcblx0ICAgICAgICAgICAgMHgxNjgwMDAwMDogMHgxMCxcblx0ICAgICAgICAgICAgMHgxNzgwMDAwMDogMHg0MDAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxODgwMDAwMDogMHg0MDA4NDAwMCxcblx0ICAgICAgICAgICAgMHgxOTgwMDAwMDogMHg0MDAwMDAxMCxcblx0ICAgICAgICAgICAgMHgxYTgwMDAwMDogMHg0MDAwNDAxMCxcblx0ICAgICAgICAgICAgMHgxYjgwMDAwMDogMHg4MDAxMCxcblx0ICAgICAgICAgICAgMHgxYzgwMDAwMDogMHgwLFxuXHQgICAgICAgICAgICAweDFkODAwMDAwOiAweDQwMTAsXG5cdCAgICAgICAgICAgIDB4MWU4MDAwMDA6IDB4NDAwODAwMTAsXG5cdCAgICAgICAgICAgIDB4MWY4MDAwMDA6IDB4ODQwMDBcblx0ICAgICAgICB9LFxuXHQgICAgICAgIHtcblx0ICAgICAgICAgICAgMHgwOiAweDEwNCxcblx0ICAgICAgICAgICAgMHgxMDAwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHgyMDAwMDA6IDB4NDAwMDEwMCxcblx0ICAgICAgICAgICAgMHgzMDAwMDA6IDB4MTAxMDQsXG5cdCAgICAgICAgICAgIDB4NDAwMDAwOiAweDEwMDA0LFxuXHQgICAgICAgICAgICAweDUwMDAwMDogMHg0MDAwMDA0LFxuXHQgICAgICAgICAgICAweDYwMDAwMDogMHg0MDEwMTA0LFxuXHQgICAgICAgICAgICAweDcwMDAwMDogMHg0MDEwMDAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDogMHg0MDAwMDAwLFxuXHQgICAgICAgICAgICAweDkwMDAwMDogMHg0MDEwMTAwLFxuXHQgICAgICAgICAgICAweGEwMDAwMDogMHgxMDEwMCxcblx0ICAgICAgICAgICAgMHhiMDAwMDA6IDB4NDAxMDAwNCxcblx0ICAgICAgICAgICAgMHhjMDAwMDA6IDB4NDAwMDEwNCxcblx0ICAgICAgICAgICAgMHhkMDAwMDA6IDB4MTAwMDAsXG5cdCAgICAgICAgICAgIDB4ZTAwMDAwOiAweDQsXG5cdCAgICAgICAgICAgIDB4ZjAwMDAwOiAweDEwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDogMHg0MDEwMTAwLFxuXHQgICAgICAgICAgICAweDE4MDAwMDogMHg0MDEwMDA0LFxuXHQgICAgICAgICAgICAweDI4MDAwMDogMHgwLFxuXHQgICAgICAgICAgICAweDM4MDAwMDogMHg0MDAwMTAwLFxuXHQgICAgICAgICAgICAweDQ4MDAwMDogMHg0MDAwMDA0LFxuXHQgICAgICAgICAgICAweDU4MDAwMDogMHgxMDAwMCxcblx0ICAgICAgICAgICAgMHg2ODAwMDA6IDB4MTAwMDQsXG5cdCAgICAgICAgICAgIDB4NzgwMDAwOiAweDEwNCxcblx0ICAgICAgICAgICAgMHg4ODAwMDA6IDB4NCxcblx0ICAgICAgICAgICAgMHg5ODAwMDA6IDB4MTAwLFxuXHQgICAgICAgICAgICAweGE4MDAwMDogMHg0MDEwMDAwLFxuXHQgICAgICAgICAgICAweGI4MDAwMDogMHgxMDEwNCxcblx0ICAgICAgICAgICAgMHhjODAwMDA6IDB4MTAxMDAsXG5cdCAgICAgICAgICAgIDB4ZDgwMDAwOiAweDQwMDAxMDQsXG5cdCAgICAgICAgICAgIDB4ZTgwMDAwOiAweDQwMTAxMDQsXG5cdCAgICAgICAgICAgIDB4ZjgwMDAwOiAweDQwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MTAwMDAwMDogMHg0MDEwMTAwLFxuXHQgICAgICAgICAgICAweDExMDAwMDA6IDB4MTAwMDQsXG5cdCAgICAgICAgICAgIDB4MTIwMDAwMDogMHgxMDAwMCxcblx0ICAgICAgICAgICAgMHgxMzAwMDAwOiAweDQwMDAxMDAsXG5cdCAgICAgICAgICAgIDB4MTQwMDAwMDogMHgxMDAsXG5cdCAgICAgICAgICAgIDB4MTUwMDAwMDogMHg0MDEwMTA0LFxuXHQgICAgICAgICAgICAweDE2MDAwMDA6IDB4NDAwMDAwNCxcblx0ICAgICAgICAgICAgMHgxNzAwMDAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4MTgwMDAwMDogMHg0MDAwMTA0LFxuXHQgICAgICAgICAgICAweDE5MDAwMDA6IDB4NDAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxYTAwMDAwOiAweDQsXG5cdCAgICAgICAgICAgIDB4MWIwMDAwMDogMHgxMDEwMCxcblx0ICAgICAgICAgICAgMHgxYzAwMDAwOiAweDQwMTAwMDAsXG5cdCAgICAgICAgICAgIDB4MWQwMDAwMDogMHgxMDQsXG5cdCAgICAgICAgICAgIDB4MWUwMDAwMDogMHgxMDEwNCxcblx0ICAgICAgICAgICAgMHgxZjAwMDAwOiAweDQwMTAwMDQsXG5cdCAgICAgICAgICAgIDB4MTA4MDAwMDogMHg0MDAwMDAwLFxuXHQgICAgICAgICAgICAweDExODAwMDA6IDB4MTA0LFxuXHQgICAgICAgICAgICAweDEyODAwMDA6IDB4NDAxMDEwMCxcblx0ICAgICAgICAgICAgMHgxMzgwMDAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4MTQ4MDAwMDogMHgxMDAwNCxcblx0ICAgICAgICAgICAgMHgxNTgwMDAwOiAweDQwMDAxMDAsXG5cdCAgICAgICAgICAgIDB4MTY4MDAwMDogMHgxMDAsXG5cdCAgICAgICAgICAgIDB4MTc4MDAwMDogMHg0MDEwMDA0LFxuXHQgICAgICAgICAgICAweDE4ODAwMDA6IDB4MTAwMDAsXG5cdCAgICAgICAgICAgIDB4MTk4MDAwMDogMHg0MDEwMTA0LFxuXHQgICAgICAgICAgICAweDFhODAwMDA6IDB4MTAxMDQsXG5cdCAgICAgICAgICAgIDB4MWI4MDAwMDogMHg0MDAwMDA0LFxuXHQgICAgICAgICAgICAweDFjODAwMDA6IDB4NDAwMDEwNCxcblx0ICAgICAgICAgICAgMHgxZDgwMDAwOiAweDQwMTAwMDAsXG5cdCAgICAgICAgICAgIDB4MWU4MDAwMDogMHg0LFxuXHQgICAgICAgICAgICAweDFmODAwMDA6IDB4MTAxMDBcblx0ICAgICAgICB9LFxuXHQgICAgICAgIHtcblx0ICAgICAgICAgICAgMHgwOiAweDgwNDAxMDAwLFxuXHQgICAgICAgICAgICAweDEwMDAwOiAweDgwMDAxMDQwLFxuXHQgICAgICAgICAgICAweDIwMDAwOiAweDQwMTA0MCxcblx0ICAgICAgICAgICAgMHgzMDAwMDogMHg4MDQwMDAwMCxcblx0ICAgICAgICAgICAgMHg0MDAwMDogMHgwLFxuXHQgICAgICAgICAgICAweDUwMDAwOiAweDQwMTAwMCxcblx0ICAgICAgICAgICAgMHg2MDAwMDogMHg4MDAwMDA0MCxcblx0ICAgICAgICAgICAgMHg3MDAwMDogMHg0MDAwNDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDA6IDB4ODAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4OTAwMDA6IDB4NDAwMDAwLFxuXHQgICAgICAgICAgICAweGEwMDAwOiAweDQwLFxuXHQgICAgICAgICAgICAweGIwMDAwOiAweDgwMDAxMDAwLFxuXHQgICAgICAgICAgICAweGMwMDAwOiAweDgwNDAwMDQwLFxuXHQgICAgICAgICAgICAweGQwMDAwOiAweDEwNDAsXG5cdCAgICAgICAgICAgIDB4ZTAwMDA6IDB4MTAwMCxcblx0ICAgICAgICAgICAgMHhmMDAwMDogMHg4MDQwMTA0MCxcblx0ICAgICAgICAgICAgMHg4MDAwOiAweDgwMDAxMDQwLFxuXHQgICAgICAgICAgICAweDE4MDAwOiAweDQwLFxuXHQgICAgICAgICAgICAweDI4MDAwOiAweDgwNDAwMDQwLFxuXHQgICAgICAgICAgICAweDM4MDAwOiAweDgwMDAxMDAwLFxuXHQgICAgICAgICAgICAweDQ4MDAwOiAweDQwMTAwMCxcblx0ICAgICAgICAgICAgMHg1ODAwMDogMHg4MDQwMTA0MCxcblx0ICAgICAgICAgICAgMHg2ODAwMDogMHgwLFxuXHQgICAgICAgICAgICAweDc4MDAwOiAweDgwNDAwMDAwLFxuXHQgICAgICAgICAgICAweDg4MDAwOiAweDEwMDAsXG5cdCAgICAgICAgICAgIDB4OTgwMDA6IDB4ODA0MDEwMDAsXG5cdCAgICAgICAgICAgIDB4YTgwMDA6IDB4NDAwMDAwLFxuXHQgICAgICAgICAgICAweGI4MDAwOiAweDEwNDAsXG5cdCAgICAgICAgICAgIDB4YzgwMDA6IDB4ODAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4ZDgwMDA6IDB4NDAwMDQwLFxuXHQgICAgICAgICAgICAweGU4MDAwOiAweDQwMTA0MCxcblx0ICAgICAgICAgICAgMHhmODAwMDogMHg4MDAwMDA0MCxcblx0ICAgICAgICAgICAgMHgxMDAwMDA6IDB4NDAwMDQwLFxuXHQgICAgICAgICAgICAweDExMDAwMDogMHg0MDEwMDAsXG5cdCAgICAgICAgICAgIDB4MTIwMDAwOiAweDgwMDAwMDQwLFxuXHQgICAgICAgICAgICAweDEzMDAwMDogMHgwLFxuXHQgICAgICAgICAgICAweDE0MDAwMDogMHgxMDQwLFxuXHQgICAgICAgICAgICAweDE1MDAwMDogMHg4MDQwMDA0MCxcblx0ICAgICAgICAgICAgMHgxNjAwMDA6IDB4ODA0MDEwMDAsXG5cdCAgICAgICAgICAgIDB4MTcwMDAwOiAweDgwMDAxMDQwLFxuXHQgICAgICAgICAgICAweDE4MDAwMDogMHg4MDQwMTA0MCxcblx0ICAgICAgICAgICAgMHgxOTAwMDA6IDB4ODAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWEwMDAwOiAweDgwNDAwMDAwLFxuXHQgICAgICAgICAgICAweDFiMDAwMDogMHg0MDEwNDAsXG5cdCAgICAgICAgICAgIDB4MWMwMDAwOiAweDgwMDAxMDAwLFxuXHQgICAgICAgICAgICAweDFkMDAwMDogMHg0MDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWUwMDAwOiAweDQwLFxuXHQgICAgICAgICAgICAweDFmMDAwMDogMHgxMDAwLFxuXHQgICAgICAgICAgICAweDEwODAwMDogMHg4MDQwMDAwMCxcblx0ICAgICAgICAgICAgMHgxMTgwMDA6IDB4ODA0MDEwNDAsXG5cdCAgICAgICAgICAgIDB4MTI4MDAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4MTM4MDAwOiAweDQwMTAwMCxcblx0ICAgICAgICAgICAgMHgxNDgwMDA6IDB4NDAwMDQwLFxuXHQgICAgICAgICAgICAweDE1ODAwMDogMHg4MDAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxNjgwMDA6IDB4ODAwMDEwNDAsXG5cdCAgICAgICAgICAgIDB4MTc4MDAwOiAweDQwLFxuXHQgICAgICAgICAgICAweDE4ODAwMDogMHg4MDAwMDA0MCxcblx0ICAgICAgICAgICAgMHgxOTgwMDA6IDB4MTAwMCxcblx0ICAgICAgICAgICAgMHgxYTgwMDA6IDB4ODAwMDEwMDAsXG5cdCAgICAgICAgICAgIDB4MWI4MDAwOiAweDgwNDAwMDQwLFxuXHQgICAgICAgICAgICAweDFjODAwMDogMHgxMDQwLFxuXHQgICAgICAgICAgICAweDFkODAwMDogMHg4MDQwMTAwMCxcblx0ICAgICAgICAgICAgMHgxZTgwMDA6IDB4NDAwMDAwLFxuXHQgICAgICAgICAgICAweDFmODAwMDogMHg0MDEwNDBcblx0ICAgICAgICB9LFxuXHQgICAgICAgIHtcblx0ICAgICAgICAgICAgMHgwOiAweDgwLFxuXHQgICAgICAgICAgICAweDEwMDA6IDB4MTA0MDAwMCxcblx0ICAgICAgICAgICAgMHgyMDAwOiAweDQwMDAwLFxuXHQgICAgICAgICAgICAweDMwMDA6IDB4MjAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4NDAwMDogMHgyMDA0MDA4MCxcblx0ICAgICAgICAgICAgMHg1MDAwOiAweDEwMDAwODAsXG5cdCAgICAgICAgICAgIDB4NjAwMDogMHgyMTAwMDA4MCxcblx0ICAgICAgICAgICAgMHg3MDAwOiAweDQwMDgwLFxuXHQgICAgICAgICAgICAweDgwMDA6IDB4MTAwMDAwMCxcblx0ICAgICAgICAgICAgMHg5MDAwOiAweDIwMDQwMDAwLFxuXHQgICAgICAgICAgICAweGEwMDA6IDB4MjAwMDAwODAsXG5cdCAgICAgICAgICAgIDB4YjAwMDogMHgyMTA0MDA4MCxcblx0ICAgICAgICAgICAgMHhjMDAwOiAweDIxMDQwMDAwLFxuXHQgICAgICAgICAgICAweGQwMDA6IDB4MCxcblx0ICAgICAgICAgICAgMHhlMDAwOiAweDEwNDAwODAsXG5cdCAgICAgICAgICAgIDB4ZjAwMDogMHgyMTAwMDAwMCxcblx0ICAgICAgICAgICAgMHg4MDA6IDB4MTA0MDA4MCxcblx0ICAgICAgICAgICAgMHgxODAwOiAweDIxMDAwMDgwLFxuXHQgICAgICAgICAgICAweDI4MDA6IDB4ODAsXG5cdCAgICAgICAgICAgIDB4MzgwMDogMHgxMDQwMDAwLFxuXHQgICAgICAgICAgICAweDQ4MDA6IDB4NDAwMDAsXG5cdCAgICAgICAgICAgIDB4NTgwMDogMHgyMDA0MDA4MCxcblx0ICAgICAgICAgICAgMHg2ODAwOiAweDIxMDQwMDAwLFxuXHQgICAgICAgICAgICAweDc4MDA6IDB4MjAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4ODgwMDogMHgyMDA0MDAwMCxcblx0ICAgICAgICAgICAgMHg5ODAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4YTgwMDogMHgyMTA0MDA4MCxcblx0ICAgICAgICAgICAgMHhiODAwOiAweDEwMDAwODAsXG5cdCAgICAgICAgICAgIDB4YzgwMDogMHgyMDAwMDA4MCxcblx0ICAgICAgICAgICAgMHhkODAwOiAweDIxMDAwMDAwLFxuXHQgICAgICAgICAgICAweGU4MDA6IDB4MTAwMDAwMCxcblx0ICAgICAgICAgICAgMHhmODAwOiAweDQwMDgwLFxuXHQgICAgICAgICAgICAweDEwMDAwOiAweDQwMDAwLFxuXHQgICAgICAgICAgICAweDExMDAwOiAweDgwLFxuXHQgICAgICAgICAgICAweDEyMDAwOiAweDIwMDAwMDAwLFxuXHQgICAgICAgICAgICAweDEzMDAwOiAweDIxMDAwMDgwLFxuXHQgICAgICAgICAgICAweDE0MDAwOiAweDEwMDAwODAsXG5cdCAgICAgICAgICAgIDB4MTUwMDA6IDB4MjEwNDAwMDAsXG5cdCAgICAgICAgICAgIDB4MTYwMDA6IDB4MjAwNDAwODAsXG5cdCAgICAgICAgICAgIDB4MTcwMDA6IDB4MTAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxODAwMDogMHgyMTA0MDA4MCxcblx0ICAgICAgICAgICAgMHgxOTAwMDogMHgyMTAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxYTAwMDogMHgxMDQwMDAwLFxuXHQgICAgICAgICAgICAweDFiMDAwOiAweDIwMDQwMDAwLFxuXHQgICAgICAgICAgICAweDFjMDAwOiAweDQwMDgwLFxuXHQgICAgICAgICAgICAweDFkMDAwOiAweDIwMDAwMDgwLFxuXHQgICAgICAgICAgICAweDFlMDAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4MWYwMDA6IDB4MTA0MDA4MCxcblx0ICAgICAgICAgICAgMHgxMDgwMDogMHgyMTAwMDA4MCxcblx0ICAgICAgICAgICAgMHgxMTgwMDogMHgxMDAwMDAwLFxuXHQgICAgICAgICAgICAweDEyODAwOiAweDEwNDAwMDAsXG5cdCAgICAgICAgICAgIDB4MTM4MDA6IDB4MjAwNDAwODAsXG5cdCAgICAgICAgICAgIDB4MTQ4MDA6IDB4MjAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MTU4MDA6IDB4MTA0MDA4MCxcblx0ICAgICAgICAgICAgMHgxNjgwMDogMHg4MCxcblx0ICAgICAgICAgICAgMHgxNzgwMDogMHgyMTA0MDAwMCxcblx0ICAgICAgICAgICAgMHgxODgwMDogMHg0MDA4MCxcblx0ICAgICAgICAgICAgMHgxOTgwMDogMHgyMTA0MDA4MCxcblx0ICAgICAgICAgICAgMHgxYTgwMDogMHgwLFxuXHQgICAgICAgICAgICAweDFiODAwOiAweDIxMDAwMDAwLFxuXHQgICAgICAgICAgICAweDFjODAwOiAweDEwMDAwODAsXG5cdCAgICAgICAgICAgIDB4MWQ4MDA6IDB4NDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWU4MDA6IDB4MjAwNDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWY4MDA6IDB4MjAwMDAwODBcblx0ICAgICAgICB9LFxuXHQgICAgICAgIHtcblx0ICAgICAgICAgICAgMHgwOiAweDEwMDAwMDA4LFxuXHQgICAgICAgICAgICAweDEwMDogMHgyMDAwLFxuXHQgICAgICAgICAgICAweDIwMDogMHgxMDIwMDAwMCxcblx0ICAgICAgICAgICAgMHgzMDA6IDB4MTAyMDIwMDgsXG5cdCAgICAgICAgICAgIDB4NDAwOiAweDEwMDAyMDAwLFxuXHQgICAgICAgICAgICAweDUwMDogMHgyMDAwMDAsXG5cdCAgICAgICAgICAgIDB4NjAwOiAweDIwMDAwOCxcblx0ICAgICAgICAgICAgMHg3MDA6IDB4MTAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4ODAwOiAweDAsXG5cdCAgICAgICAgICAgIDB4OTAwOiAweDEwMDAyMDA4LFxuXHQgICAgICAgICAgICAweGEwMDogMHgyMDIwMDAsXG5cdCAgICAgICAgICAgIDB4YjAwOiAweDgsXG5cdCAgICAgICAgICAgIDB4YzAwOiAweDEwMjAwMDA4LFxuXHQgICAgICAgICAgICAweGQwMDogMHgyMDIwMDgsXG5cdCAgICAgICAgICAgIDB4ZTAwOiAweDIwMDgsXG5cdCAgICAgICAgICAgIDB4ZjAwOiAweDEwMjAyMDAwLFxuXHQgICAgICAgICAgICAweDgwOiAweDEwMjAwMDAwLFxuXHQgICAgICAgICAgICAweDE4MDogMHgxMDIwMjAwOCxcblx0ICAgICAgICAgICAgMHgyODA6IDB4OCxcblx0ICAgICAgICAgICAgMHgzODA6IDB4MjAwMDAwLFxuXHQgICAgICAgICAgICAweDQ4MDogMHgyMDIwMDgsXG5cdCAgICAgICAgICAgIDB4NTgwOiAweDEwMDAwMDA4LFxuXHQgICAgICAgICAgICAweDY4MDogMHgxMDAwMjAwMCxcblx0ICAgICAgICAgICAgMHg3ODA6IDB4MjAwOCxcblx0ICAgICAgICAgICAgMHg4ODA6IDB4MjAwMDA4LFxuXHQgICAgICAgICAgICAweDk4MDogMHgyMDAwLFxuXHQgICAgICAgICAgICAweGE4MDogMHgxMDAwMjAwOCxcblx0ICAgICAgICAgICAgMHhiODA6IDB4MTAyMDAwMDgsXG5cdCAgICAgICAgICAgIDB4YzgwOiAweDAsXG5cdCAgICAgICAgICAgIDB4ZDgwOiAweDEwMjAyMDAwLFxuXHQgICAgICAgICAgICAweGU4MDogMHgyMDIwMDAsXG5cdCAgICAgICAgICAgIDB4ZjgwOiAweDEwMDAwMDAwLFxuXHQgICAgICAgICAgICAweDEwMDA6IDB4MTAwMDIwMDAsXG5cdCAgICAgICAgICAgIDB4MTEwMDogMHgxMDIwMDAwOCxcblx0ICAgICAgICAgICAgMHgxMjAwOiAweDEwMjAyMDA4LFxuXHQgICAgICAgICAgICAweDEzMDA6IDB4MjAwOCxcblx0ICAgICAgICAgICAgMHgxNDAwOiAweDIwMDAwMCxcblx0ICAgICAgICAgICAgMHgxNTAwOiAweDEwMDAwMDAwLFxuXHQgICAgICAgICAgICAweDE2MDA6IDB4MTAwMDAwMDgsXG5cdCAgICAgICAgICAgIDB4MTcwMDogMHgyMDIwMDAsXG5cdCAgICAgICAgICAgIDB4MTgwMDogMHgyMDIwMDgsXG5cdCAgICAgICAgICAgIDB4MTkwMDogMHgwLFxuXHQgICAgICAgICAgICAweDFhMDA6IDB4OCxcblx0ICAgICAgICAgICAgMHgxYjAwOiAweDEwMjAwMDAwLFxuXHQgICAgICAgICAgICAweDFjMDA6IDB4MjAwMCxcblx0ICAgICAgICAgICAgMHgxZDAwOiAweDEwMDAyMDA4LFxuXHQgICAgICAgICAgICAweDFlMDA6IDB4MTAyMDIwMDAsXG5cdCAgICAgICAgICAgIDB4MWYwMDogMHgyMDAwMDgsXG5cdCAgICAgICAgICAgIDB4MTA4MDogMHg4LFxuXHQgICAgICAgICAgICAweDExODA6IDB4MjAyMDAwLFxuXHQgICAgICAgICAgICAweDEyODA6IDB4MjAwMDAwLFxuXHQgICAgICAgICAgICAweDEzODA6IDB4MTAwMDAwMDgsXG5cdCAgICAgICAgICAgIDB4MTQ4MDogMHgxMDAwMjAwMCxcblx0ICAgICAgICAgICAgMHgxNTgwOiAweDIwMDgsXG5cdCAgICAgICAgICAgIDB4MTY4MDogMHgxMDIwMjAwOCxcblx0ICAgICAgICAgICAgMHgxNzgwOiAweDEwMjAwMDAwLFxuXHQgICAgICAgICAgICAweDE4ODA6IDB4MTAyMDIwMDAsXG5cdCAgICAgICAgICAgIDB4MTk4MDogMHgxMDIwMDAwOCxcblx0ICAgICAgICAgICAgMHgxYTgwOiAweDIwMDAsXG5cdCAgICAgICAgICAgIDB4MWI4MDogMHgyMDIwMDgsXG5cdCAgICAgICAgICAgIDB4MWM4MDogMHgyMDAwMDgsXG5cdCAgICAgICAgICAgIDB4MWQ4MDogMHgwLFxuXHQgICAgICAgICAgICAweDFlODA6IDB4MTAwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWY4MDogMHgxMDAwMjAwOFxuXHQgICAgICAgIH0sXG5cdCAgICAgICAge1xuXHQgICAgICAgICAgICAweDA6IDB4MTAwMDAwLFxuXHQgICAgICAgICAgICAweDEwOiAweDIwMDA0MDEsXG5cdCAgICAgICAgICAgIDB4MjA6IDB4NDAwLFxuXHQgICAgICAgICAgICAweDMwOiAweDEwMDQwMSxcblx0ICAgICAgICAgICAgMHg0MDogMHgyMTAwNDAxLFxuXHQgICAgICAgICAgICAweDUwOiAweDAsXG5cdCAgICAgICAgICAgIDB4NjA6IDB4MSxcblx0ICAgICAgICAgICAgMHg3MDogMHgyMTAwMDAxLFxuXHQgICAgICAgICAgICAweDgwOiAweDIwMDA0MDAsXG5cdCAgICAgICAgICAgIDB4OTA6IDB4MTAwMDAxLFxuXHQgICAgICAgICAgICAweGEwOiAweDIwMDAwMDEsXG5cdCAgICAgICAgICAgIDB4YjA6IDB4MjEwMDQwMCxcblx0ICAgICAgICAgICAgMHhjMDogMHgyMTAwMDAwLFxuXHQgICAgICAgICAgICAweGQwOiAweDQwMSxcblx0ICAgICAgICAgICAgMHhlMDogMHgxMDA0MDAsXG5cdCAgICAgICAgICAgIDB4ZjA6IDB4MjAwMDAwMCxcblx0ICAgICAgICAgICAgMHg4OiAweDIxMDAwMDEsXG5cdCAgICAgICAgICAgIDB4MTg6IDB4MCxcblx0ICAgICAgICAgICAgMHgyODogMHgyMDAwNDAxLFxuXHQgICAgICAgICAgICAweDM4OiAweDIxMDA0MDAsXG5cdCAgICAgICAgICAgIDB4NDg6IDB4MTAwMDAwLFxuXHQgICAgICAgICAgICAweDU4OiAweDIwMDAwMDEsXG5cdCAgICAgICAgICAgIDB4Njg6IDB4MjAwMDAwMCxcblx0ICAgICAgICAgICAgMHg3ODogMHg0MDEsXG5cdCAgICAgICAgICAgIDB4ODg6IDB4MTAwNDAxLFxuXHQgICAgICAgICAgICAweDk4OiAweDIwMDA0MDAsXG5cdCAgICAgICAgICAgIDB4YTg6IDB4MjEwMDAwMCxcblx0ICAgICAgICAgICAgMHhiODogMHgxMDAwMDEsXG5cdCAgICAgICAgICAgIDB4Yzg6IDB4NDAwLFxuXHQgICAgICAgICAgICAweGQ4OiAweDIxMDA0MDEsXG5cdCAgICAgICAgICAgIDB4ZTg6IDB4MSxcblx0ICAgICAgICAgICAgMHhmODogMHgxMDA0MDAsXG5cdCAgICAgICAgICAgIDB4MTAwOiAweDIwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MTEwOiAweDEwMDAwMCxcblx0ICAgICAgICAgICAgMHgxMjA6IDB4MjAwMDQwMSxcblx0ICAgICAgICAgICAgMHgxMzA6IDB4MjEwMDAwMSxcblx0ICAgICAgICAgICAgMHgxNDA6IDB4MTAwMDAxLFxuXHQgICAgICAgICAgICAweDE1MDogMHgyMDAwNDAwLFxuXHQgICAgICAgICAgICAweDE2MDogMHgyMTAwNDAwLFxuXHQgICAgICAgICAgICAweDE3MDogMHgxMDA0MDEsXG5cdCAgICAgICAgICAgIDB4MTgwOiAweDQwMSxcblx0ICAgICAgICAgICAgMHgxOTA6IDB4MjEwMDQwMSxcblx0ICAgICAgICAgICAgMHgxYTA6IDB4MTAwNDAwLFxuXHQgICAgICAgICAgICAweDFiMDogMHgxLFxuXHQgICAgICAgICAgICAweDFjMDogMHgwLFxuXHQgICAgICAgICAgICAweDFkMDogMHgyMTAwMDAwLFxuXHQgICAgICAgICAgICAweDFlMDogMHgyMDAwMDAxLFxuXHQgICAgICAgICAgICAweDFmMDogMHg0MDAsXG5cdCAgICAgICAgICAgIDB4MTA4OiAweDEwMDQwMCxcblx0ICAgICAgICAgICAgMHgxMTg6IDB4MjAwMDQwMSxcblx0ICAgICAgICAgICAgMHgxMjg6IDB4MjEwMDAwMSxcblx0ICAgICAgICAgICAgMHgxMzg6IDB4MSxcblx0ICAgICAgICAgICAgMHgxNDg6IDB4MjAwMDAwMCxcblx0ICAgICAgICAgICAgMHgxNTg6IDB4MTAwMDAwLFxuXHQgICAgICAgICAgICAweDE2ODogMHg0MDEsXG5cdCAgICAgICAgICAgIDB4MTc4OiAweDIxMDA0MDAsXG5cdCAgICAgICAgICAgIDB4MTg4OiAweDIwMDAwMDEsXG5cdCAgICAgICAgICAgIDB4MTk4OiAweDIxMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MWE4OiAweDAsXG5cdCAgICAgICAgICAgIDB4MWI4OiAweDIxMDA0MDEsXG5cdCAgICAgICAgICAgIDB4MWM4OiAweDEwMDQwMSxcblx0ICAgICAgICAgICAgMHgxZDg6IDB4NDAwLFxuXHQgICAgICAgICAgICAweDFlODogMHgyMDAwNDAwLFxuXHQgICAgICAgICAgICAweDFmODogMHgxMDAwMDFcblx0ICAgICAgICB9LFxuXHQgICAgICAgIHtcblx0ICAgICAgICAgICAgMHgwOiAweDgwMDA4MjAsXG5cdCAgICAgICAgICAgIDB4MTogMHgyMDAwMCxcblx0ICAgICAgICAgICAgMHgyOiAweDgwMDAwMDAsXG5cdCAgICAgICAgICAgIDB4MzogMHgyMCxcblx0ICAgICAgICAgICAgMHg0OiAweDIwMDIwLFxuXHQgICAgICAgICAgICAweDU6IDB4ODAyMDgyMCxcblx0ICAgICAgICAgICAgMHg2OiAweDgwMjA4MDAsXG5cdCAgICAgICAgICAgIDB4NzogMHg4MDAsXG5cdCAgICAgICAgICAgIDB4ODogMHg4MDIwMDAwLFxuXHQgICAgICAgICAgICAweDk6IDB4ODAwMDgwMCxcblx0ICAgICAgICAgICAgMHhhOiAweDIwODAwLFxuXHQgICAgICAgICAgICAweGI6IDB4ODAyMDAyMCxcblx0ICAgICAgICAgICAgMHhjOiAweDgyMCxcblx0ICAgICAgICAgICAgMHhkOiAweDAsXG5cdCAgICAgICAgICAgIDB4ZTogMHg4MDAwMDIwLFxuXHQgICAgICAgICAgICAweGY6IDB4MjA4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDA6IDB4ODAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDAxOiAweDgwMjA4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDI6IDB4ODAwMDgyMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAwMzogMHg4MDAwMDAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDA0OiAweDgwMjAwMDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDU6IDB4MjA4MDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDY6IDB4MjA4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDc6IDB4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMDg6IDB4ODAwMDAyMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAwOTogMHg4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMGE6IDB4MjAwMjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMGI6IDB4ODAyMDgwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAwYzogMHgwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDBkOiAweDgwMjAwMjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMGU6IDB4ODAwMDgwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAwZjogMHgyMDAwMCxcblx0ICAgICAgICAgICAgMHgxMDogMHgyMDgyMCxcblx0ICAgICAgICAgICAgMHgxMTogMHg4MDIwODAwLFxuXHQgICAgICAgICAgICAweDEyOiAweDIwLFxuXHQgICAgICAgICAgICAweDEzOiAweDgwMCxcblx0ICAgICAgICAgICAgMHgxNDogMHg4MDAwODAwLFxuXHQgICAgICAgICAgICAweDE1OiAweDgwMDAwMjAsXG5cdCAgICAgICAgICAgIDB4MTY6IDB4ODAyMDAyMCxcblx0ICAgICAgICAgICAgMHgxNzogMHgyMDAwMCxcblx0ICAgICAgICAgICAgMHgxODogMHgwLFxuXHQgICAgICAgICAgICAweDE5OiAweDIwMDIwLFxuXHQgICAgICAgICAgICAweDFhOiAweDgwMjAwMDAsXG5cdCAgICAgICAgICAgIDB4MWI6IDB4ODAwMDgyMCxcblx0ICAgICAgICAgICAgMHgxYzogMHg4MDIwODIwLFxuXHQgICAgICAgICAgICAweDFkOiAweDIwODAwLFxuXHQgICAgICAgICAgICAweDFlOiAweDgyMCxcblx0ICAgICAgICAgICAgMHgxZjogMHg4MDAwMDAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDEwOiAweDIwMDAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDExOiAweDgwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAxMjogMHg4MDIwMDIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDEzOiAweDIwODIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDE0OiAweDIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDE1OiAweDgwMjAwMDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMTY6IDB4ODAwMDAwMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAxNzogMHg4MDAwODIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDE4OiAweDgwMjA4MjAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMTk6IDB4ODAwMDAyMCxcblx0ICAgICAgICAgICAgMHg4MDAwMDAxYTogMHg4MDAwODAwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDFiOiAweDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMWM6IDB4MjA4MDAsXG5cdCAgICAgICAgICAgIDB4ODAwMDAwMWQ6IDB4ODIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDFlOiAweDIwMDIwLFxuXHQgICAgICAgICAgICAweDgwMDAwMDFmOiAweDgwMjA4MDBcblx0ICAgICAgICB9XG5cdCAgICBdO1xuXG5cdCAgICAvLyBNYXNrcyB0aGF0IHNlbGVjdCB0aGUgU0JPWCBpbnB1dFxuXHQgICAgdmFyIFNCT1hfTUFTSyA9IFtcblx0ICAgICAgICAweGY4MDAwMDAxLCAweDFmODAwMDAwLCAweDAxZjgwMDAwLCAweDAwMWY4MDAwLFxuXHQgICAgICAgIDB4MDAwMWY4MDAsIDB4MDAwMDFmODAsIDB4MDAwMDAxZjgsIDB4ODAwMDAwMWZcblx0ICAgIF07XG5cblx0ICAgIC8qKlxuXHQgICAgICogREVTIGJsb2NrIGNpcGhlciBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBERVMgPSBDX2FsZ28uREVTID0gQmxvY2tDaXBoZXIuZXh0ZW5kKHtcblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIGtleSA9IHRoaXMuX2tleTtcblx0ICAgICAgICAgICAgdmFyIGtleVdvcmRzID0ga2V5LndvcmRzO1xuXG5cdCAgICAgICAgICAgIC8vIFNlbGVjdCA1NiBiaXRzIGFjY29yZGluZyB0byBQQzFcblx0ICAgICAgICAgICAgdmFyIGtleUJpdHMgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA1NjsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICB2YXIga2V5Qml0UG9zID0gUEMxW2ldIC0gMTtcblx0ICAgICAgICAgICAgICAgIGtleUJpdHNbaV0gPSAoa2V5V29yZHNba2V5Qml0UG9zID4+PiA1XSA+Pj4gKDMxIC0ga2V5Qml0UG9zICUgMzIpKSAmIDE7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBBc3NlbWJsZSAxNiBzdWJrZXlzXG5cdCAgICAgICAgICAgIHZhciBzdWJLZXlzID0gdGhpcy5fc3ViS2V5cyA9IFtdO1xuXHQgICAgICAgICAgICBmb3IgKHZhciBuU3ViS2V5ID0gMDsgblN1YktleSA8IDE2OyBuU3ViS2V5KyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBzdWJrZXlcblx0ICAgICAgICAgICAgICAgIHZhciBzdWJLZXkgPSBzdWJLZXlzW25TdWJLZXldID0gW107XG5cblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0XG5cdCAgICAgICAgICAgICAgICB2YXIgYml0U2hpZnQgPSBCSVRfU0hJRlRTW25TdWJLZXldO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBTZWxlY3QgNDggYml0cyBhY2NvcmRpbmcgdG8gUEMyXG5cdCAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDI0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgICAgICAvLyBTZWxlY3QgZnJvbSB0aGUgbGVmdCAyOCBrZXkgYml0c1xuXHQgICAgICAgICAgICAgICAgICAgIHN1YktleVsoaSAvIDYpIHwgMF0gfD0ga2V5Qml0c1soKFBDMltpXSAtIDEpICsgYml0U2hpZnQpICUgMjhdIDw8ICgzMSAtIGkgJSA2KTtcblxuXHQgICAgICAgICAgICAgICAgICAgIC8vIFNlbGVjdCBmcm9tIHRoZSByaWdodCAyOCBrZXkgYml0c1xuXHQgICAgICAgICAgICAgICAgICAgIHN1YktleVs0ICsgKChpIC8gNikgfCAwKV0gfD0ga2V5Qml0c1syOCArICgoKFBDMltpICsgMjRdIC0gMSkgKyBiaXRTaGlmdCkgJSAyOCldIDw8ICgzMSAtIGkgJSA2KTtcblx0ICAgICAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAgICAgLy8gU2luY2UgZWFjaCBzdWJrZXkgaXMgYXBwbGllZCB0byBhbiBleHBhbmRlZCAzMi1iaXQgaW5wdXQsXG5cdCAgICAgICAgICAgICAgICAvLyB0aGUgc3Via2V5IGNhbiBiZSBicm9rZW4gaW50byA4IHZhbHVlcyBzY2FsZWQgdG8gMzItYml0cyxcblx0ICAgICAgICAgICAgICAgIC8vIHdoaWNoIGFsbG93cyB0aGUga2V5IHRvIGJlIHVzZWQgd2l0aG91dCBleHBhbnNpb25cblx0ICAgICAgICAgICAgICAgIHN1YktleVswXSA9IChzdWJLZXlbMF0gPDwgMSkgfCAoc3ViS2V5WzBdID4+PiAzMSk7XG5cdCAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IDc7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgICAgIHN1YktleVtpXSA9IHN1YktleVtpXSA+Pj4gKChpIC0gMSkgKiA0ICsgMyk7XG5cdCAgICAgICAgICAgICAgICB9XG5cdCAgICAgICAgICAgICAgICBzdWJLZXlbN10gPSAoc3ViS2V5WzddIDw8IDUpIHwgKHN1YktleVs3XSA+Pj4gMjcpO1xuXHQgICAgICAgICAgICB9XG5cblx0ICAgICAgICAgICAgLy8gQ29tcHV0ZSBpbnZlcnNlIHN1YmtleXNcblx0ICAgICAgICAgICAgdmFyIGludlN1YktleXMgPSB0aGlzLl9pbnZTdWJLZXlzID0gW107XG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTY7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgaW52U3ViS2V5c1tpXSA9IHN1YktleXNbMTUgLSBpXTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBlbmNyeXB0QmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fZG9DcnlwdEJsb2NrKE0sIG9mZnNldCwgdGhpcy5fc3ViS2V5cyk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGRlY3J5cHRCbG9jazogZnVuY3Rpb24gKE0sIG9mZnNldCkge1xuXHQgICAgICAgICAgICB0aGlzLl9kb0NyeXB0QmxvY2soTSwgb2Zmc2V0LCB0aGlzLl9pbnZTdWJLZXlzKTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgX2RvQ3J5cHRCbG9jazogZnVuY3Rpb24gKE0sIG9mZnNldCwgc3ViS2V5cykge1xuXHQgICAgICAgICAgICAvLyBHZXQgaW5wdXRcblx0ICAgICAgICAgICAgdGhpcy5fbEJsb2NrID0gTVtvZmZzZXRdO1xuXHQgICAgICAgICAgICB0aGlzLl9yQmxvY2sgPSBNW29mZnNldCArIDFdO1xuXG5cdCAgICAgICAgICAgIC8vIEluaXRpYWwgcGVybXV0YXRpb25cblx0ICAgICAgICAgICAgZXhjaGFuZ2VMUi5jYWxsKHRoaXMsIDQsICAweDBmMGYwZjBmKTtcblx0ICAgICAgICAgICAgZXhjaGFuZ2VMUi5jYWxsKHRoaXMsIDE2LCAweDAwMDBmZmZmKTtcblx0ICAgICAgICAgICAgZXhjaGFuZ2VSTC5jYWxsKHRoaXMsIDIsICAweDMzMzMzMzMzKTtcblx0ICAgICAgICAgICAgZXhjaGFuZ2VSTC5jYWxsKHRoaXMsIDgsICAweDAwZmYwMGZmKTtcblx0ICAgICAgICAgICAgZXhjaGFuZ2VMUi5jYWxsKHRoaXMsIDEsICAweDU1NTU1NTU1KTtcblxuXHQgICAgICAgICAgICAvLyBSb3VuZHNcblx0ICAgICAgICAgICAgZm9yICh2YXIgcm91bmQgPSAwOyByb3VuZCA8IDE2OyByb3VuZCsrKSB7XG5cdCAgICAgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgICAgIHZhciBzdWJLZXkgPSBzdWJLZXlzW3JvdW5kXTtcblx0ICAgICAgICAgICAgICAgIHZhciBsQmxvY2sgPSB0aGlzLl9sQmxvY2s7XG5cdCAgICAgICAgICAgICAgICB2YXIgckJsb2NrID0gdGhpcy5fckJsb2NrO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBGZWlzdGVsIGZ1bmN0aW9uXG5cdCAgICAgICAgICAgICAgICB2YXIgZiA9IDA7XG5cdCAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDg7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgICAgIGYgfD0gU0JPWF9QW2ldWygockJsb2NrIF4gc3ViS2V5W2ldKSAmIFNCT1hfTUFTS1tpXSkgPj4+IDBdO1xuXHQgICAgICAgICAgICAgICAgfVxuXHQgICAgICAgICAgICAgICAgdGhpcy5fbEJsb2NrID0gckJsb2NrO1xuXHQgICAgICAgICAgICAgICAgdGhpcy5fckJsb2NrID0gbEJsb2NrIF4gZjtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIFVuZG8gc3dhcCBmcm9tIGxhc3Qgcm91bmRcblx0ICAgICAgICAgICAgdmFyIHQgPSB0aGlzLl9sQmxvY2s7XG5cdCAgICAgICAgICAgIHRoaXMuX2xCbG9jayA9IHRoaXMuX3JCbG9jaztcblx0ICAgICAgICAgICAgdGhpcy5fckJsb2NrID0gdDtcblxuXHQgICAgICAgICAgICAvLyBGaW5hbCBwZXJtdXRhdGlvblxuXHQgICAgICAgICAgICBleGNoYW5nZUxSLmNhbGwodGhpcywgMSwgIDB4NTU1NTU1NTUpO1xuXHQgICAgICAgICAgICBleGNoYW5nZVJMLmNhbGwodGhpcywgOCwgIDB4MDBmZjAwZmYpO1xuXHQgICAgICAgICAgICBleGNoYW5nZVJMLmNhbGwodGhpcywgMiwgIDB4MzMzMzMzMzMpO1xuXHQgICAgICAgICAgICBleGNoYW5nZUxSLmNhbGwodGhpcywgMTYsIDB4MDAwMGZmZmYpO1xuXHQgICAgICAgICAgICBleGNoYW5nZUxSLmNhbGwodGhpcywgNCwgIDB4MGYwZjBmMGYpO1xuXG5cdCAgICAgICAgICAgIC8vIFNldCBvdXRwdXRcblx0ICAgICAgICAgICAgTVtvZmZzZXRdID0gdGhpcy5fbEJsb2NrO1xuXHQgICAgICAgICAgICBNW29mZnNldCArIDFdID0gdGhpcy5fckJsb2NrO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBrZXlTaXplOiA2NC8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogNjQvMzIsXG5cblx0ICAgICAgICBibG9ja1NpemU6IDY0LzMyXG5cdCAgICB9KTtcblxuXHQgICAgLy8gU3dhcCBiaXRzIGFjcm9zcyB0aGUgbGVmdCBhbmQgcmlnaHQgd29yZHNcblx0ICAgIGZ1bmN0aW9uIGV4Y2hhbmdlTFIob2Zmc2V0LCBtYXNrKSB7XG5cdCAgICAgICAgdmFyIHQgPSAoKHRoaXMuX2xCbG9jayA+Pj4gb2Zmc2V0KSBeIHRoaXMuX3JCbG9jaykgJiBtYXNrO1xuXHQgICAgICAgIHRoaXMuX3JCbG9jayBePSB0O1xuXHQgICAgICAgIHRoaXMuX2xCbG9jayBePSB0IDw8IG9mZnNldDtcblx0ICAgIH1cblxuXHQgICAgZnVuY3Rpb24gZXhjaGFuZ2VSTChvZmZzZXQsIG1hc2spIHtcblx0ICAgICAgICB2YXIgdCA9ICgodGhpcy5fckJsb2NrID4+PiBvZmZzZXQpIF4gdGhpcy5fbEJsb2NrKSAmIG1hc2s7XG5cdCAgICAgICAgdGhpcy5fbEJsb2NrIF49IHQ7XG5cdCAgICAgICAgdGhpcy5fckJsb2NrIF49IHQgPDwgb2Zmc2V0O1xuXHQgICAgfVxuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9ucyB0byB0aGUgY2lwaGVyJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgY2lwaGVydGV4dCA9IENyeXB0b0pTLkRFUy5lbmNyeXB0KG1lc3NhZ2UsIGtleSwgY2ZnKTtcblx0ICAgICAqICAgICB2YXIgcGxhaW50ZXh0ICA9IENyeXB0b0pTLkRFUy5kZWNyeXB0KGNpcGhlcnRleHQsIGtleSwgY2ZnKTtcblx0ICAgICAqL1xuXHQgICAgQy5ERVMgPSBCbG9ja0NpcGhlci5fY3JlYXRlSGVscGVyKERFUyk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogVHJpcGxlLURFUyBibG9jayBjaXBoZXIgYWxnb3JpdGhtLlxuXHQgICAgICovXG5cdCAgICB2YXIgVHJpcGxlREVTID0gQ19hbGdvLlRyaXBsZURFUyA9IEJsb2NrQ2lwaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgX2RvUmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBrZXkgPSB0aGlzLl9rZXk7XG5cdCAgICAgICAgICAgIHZhciBrZXlXb3JkcyA9IGtleS53b3JkcztcblxuXHQgICAgICAgICAgICAvLyBDcmVhdGUgREVTIGluc3RhbmNlc1xuXHQgICAgICAgICAgICB0aGlzLl9kZXMxID0gREVTLmNyZWF0ZUVuY3J5cHRvcihXb3JkQXJyYXkuY3JlYXRlKGtleVdvcmRzLnNsaWNlKDAsIDIpKSk7XG5cdCAgICAgICAgICAgIHRoaXMuX2RlczIgPSBERVMuY3JlYXRlRW5jcnlwdG9yKFdvcmRBcnJheS5jcmVhdGUoa2V5V29yZHMuc2xpY2UoMiwgNCkpKTtcblx0ICAgICAgICAgICAgdGhpcy5fZGVzMyA9IERFUy5jcmVhdGVFbmNyeXB0b3IoV29yZEFycmF5LmNyZWF0ZShrZXlXb3Jkcy5zbGljZSg0LCA2KSkpO1xuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBlbmNyeXB0QmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgdGhpcy5fZGVzMS5lbmNyeXB0QmxvY2soTSwgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgdGhpcy5fZGVzMi5kZWNyeXB0QmxvY2soTSwgb2Zmc2V0KTtcblx0ICAgICAgICAgICAgdGhpcy5fZGVzMy5lbmNyeXB0QmxvY2soTSwgb2Zmc2V0KTtcblx0ICAgICAgICB9LFxuXG5cdCAgICAgICAgZGVjcnlwdEJsb2NrOiBmdW5jdGlvbiAoTSwgb2Zmc2V0KSB7XG5cdCAgICAgICAgICAgIHRoaXMuX2RlczMuZGVjcnlwdEJsb2NrKE0sIG9mZnNldCk7XG5cdCAgICAgICAgICAgIHRoaXMuX2RlczIuZW5jcnlwdEJsb2NrKE0sIG9mZnNldCk7XG5cdCAgICAgICAgICAgIHRoaXMuX2RlczEuZGVjcnlwdEJsb2NrKE0sIG9mZnNldCk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGtleVNpemU6IDE5Mi8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogNjQvMzIsXG5cblx0ICAgICAgICBibG9ja1NpemU6IDY0LzMyXG5cdCAgICB9KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbnMgdG8gdGhlIGNpcGhlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGNpcGhlcnRleHQgPSBDcnlwdG9KUy5UcmlwbGVERVMuZW5jcnlwdChtZXNzYWdlLCBrZXksIGNmZyk7XG5cdCAgICAgKiAgICAgdmFyIHBsYWludGV4dCAgPSBDcnlwdG9KUy5UcmlwbGVERVMuZGVjcnlwdChjaXBoZXJ0ZXh0LCBrZXksIGNmZyk7XG5cdCAgICAgKi9cblx0ICAgIEMuVHJpcGxlREVTID0gQmxvY2tDaXBoZXIuX2NyZWF0ZUhlbHBlcihUcmlwbGVERVMpO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLlRyaXBsZURFUztcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3RyaXBsZWRlcy5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9lbmMtYmFzZTY0XCIpLCByZXF1aXJlKFwiLi9tZDVcIiksIHJlcXVpcmUoXCIuL2V2cGtkZlwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vZW5jLWJhc2U2NFwiLCBcIi4vbWQ1XCIsIFwiLi9ldnBrZGZcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgU3RyZWFtQ2lwaGVyID0gQ19saWIuU3RyZWFtQ2lwaGVyO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLyoqXG5cdCAgICAgKiBSQzQgc3RyZWFtIGNpcGhlciBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBSQzQgPSBDX2FsZ28uUkM0ID0gU3RyZWFtQ2lwaGVyLmV4dGVuZCh7XG5cdCAgICAgICAgX2RvUmVzZXQ6IGZ1bmN0aW9uICgpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgICAgIHZhciBrZXkgPSB0aGlzLl9rZXk7XG5cdCAgICAgICAgICAgIHZhciBrZXlXb3JkcyA9IGtleS53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIGtleVNpZ0J5dGVzID0ga2V5LnNpZ0J5dGVzO1xuXG5cdCAgICAgICAgICAgIC8vIEluaXQgc2JveFxuXHQgICAgICAgICAgICB2YXIgUyA9IHRoaXMuX1MgPSBbXTtcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNTY7IGkrKykge1xuXHQgICAgICAgICAgICAgICAgU1tpXSA9IGk7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBLZXkgc2V0dXBcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGogPSAwOyBpIDwgMjU2OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIHZhciBrZXlCeXRlSW5kZXggPSBpICUga2V5U2lnQnl0ZXM7XG5cdCAgICAgICAgICAgICAgICB2YXIga2V5Qnl0ZSA9IChrZXlXb3Jkc1trZXlCeXRlSW5kZXggPj4+IDJdID4+PiAoMjQgLSAoa2V5Qnl0ZUluZGV4ICUgNCkgKiA4KSkgJiAweGZmO1xuXG5cdCAgICAgICAgICAgICAgICBqID0gKGogKyBTW2ldICsga2V5Qnl0ZSkgJSAyNTY7XG5cblx0ICAgICAgICAgICAgICAgIC8vIFN3YXBcblx0ICAgICAgICAgICAgICAgIHZhciB0ID0gU1tpXTtcblx0ICAgICAgICAgICAgICAgIFNbaV0gPSBTW2pdO1xuXHQgICAgICAgICAgICAgICAgU1tqXSA9IHQ7XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBDb3VudGVyc1xuXHQgICAgICAgICAgICB0aGlzLl9pID0gdGhpcy5faiA9IDA7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIF9kb1Byb2Nlc3NCbG9jazogZnVuY3Rpb24gKE0sIG9mZnNldCkge1xuXHQgICAgICAgICAgICBNW29mZnNldF0gXj0gZ2VuZXJhdGVLZXlzdHJlYW1Xb3JkLmNhbGwodGhpcyk7XG5cdCAgICAgICAgfSxcblxuXHQgICAgICAgIGtleVNpemU6IDI1Ni8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogMFxuXHQgICAgfSk7XG5cblx0ICAgIGZ1bmN0aW9uIGdlbmVyYXRlS2V5c3RyZWFtV29yZCgpIHtcblx0ICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICB2YXIgUyA9IHRoaXMuX1M7XG5cdCAgICAgICAgdmFyIGkgPSB0aGlzLl9pO1xuXHQgICAgICAgIHZhciBqID0gdGhpcy5fajtcblxuXHQgICAgICAgIC8vIEdlbmVyYXRlIGtleXN0cmVhbSB3b3JkXG5cdCAgICAgICAgdmFyIGtleXN0cmVhbVdvcmQgPSAwO1xuXHQgICAgICAgIGZvciAodmFyIG4gPSAwOyBuIDwgNDsgbisrKSB7XG5cdCAgICAgICAgICAgIGkgPSAoaSArIDEpICUgMjU2O1xuXHQgICAgICAgICAgICBqID0gKGogKyBTW2ldKSAlIDI1NjtcblxuXHQgICAgICAgICAgICAvLyBTd2FwXG5cdCAgICAgICAgICAgIHZhciB0ID0gU1tpXTtcblx0ICAgICAgICAgICAgU1tpXSA9IFNbal07XG5cdCAgICAgICAgICAgIFNbal0gPSB0O1xuXG5cdCAgICAgICAgICAgIGtleXN0cmVhbVdvcmQgfD0gU1soU1tpXSArIFNbal0pICUgMjU2XSA8PCAoMjQgLSBuICogOCk7XG5cdCAgICAgICAgfVxuXG5cdCAgICAgICAgLy8gVXBkYXRlIGNvdW50ZXJzXG5cdCAgICAgICAgdGhpcy5faSA9IGk7XG5cdCAgICAgICAgdGhpcy5faiA9IGo7XG5cblx0ICAgICAgICByZXR1cm4ga2V5c3RyZWFtV29yZDtcblx0ICAgIH1cblxuXHQgICAgLyoqXG5cdCAgICAgKiBTaG9ydGN1dCBmdW5jdGlvbnMgdG8gdGhlIGNpcGhlcidzIG9iamVjdCBpbnRlcmZhY2UuXG5cdCAgICAgKlxuXHQgICAgICogQGV4YW1wbGVcblx0ICAgICAqXG5cdCAgICAgKiAgICAgdmFyIGNpcGhlcnRleHQgPSBDcnlwdG9KUy5SQzQuZW5jcnlwdChtZXNzYWdlLCBrZXksIGNmZyk7XG5cdCAgICAgKiAgICAgdmFyIHBsYWludGV4dCAgPSBDcnlwdG9KUy5SQzQuZGVjcnlwdChjaXBoZXJ0ZXh0LCBrZXksIGNmZyk7XG5cdCAgICAgKi9cblx0ICAgIEMuUkM0ID0gU3RyZWFtQ2lwaGVyLl9jcmVhdGVIZWxwZXIoUkM0KTtcblxuXHQgICAgLyoqXG5cdCAgICAgKiBNb2RpZmllZCBSQzQgc3RyZWFtIGNpcGhlciBhbGdvcml0aG0uXG5cdCAgICAgKi9cblx0ICAgIHZhciBSQzREcm9wID0gQ19hbGdvLlJDNERyb3AgPSBSQzQuZXh0ZW5kKHtcblx0ICAgICAgICAvKipcblx0ICAgICAgICAgKiBDb25maWd1cmF0aW9uIG9wdGlvbnMuXG5cdCAgICAgICAgICpcblx0ICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcn0gZHJvcCBUaGUgbnVtYmVyIG9mIGtleXN0cmVhbSB3b3JkcyB0byBkcm9wLiBEZWZhdWx0IDE5MlxuXHQgICAgICAgICAqL1xuXHQgICAgICAgIGNmZzogUkM0LmNmZy5leHRlbmQoe1xuXHQgICAgICAgICAgICBkcm9wOiAxOTJcblx0ICAgICAgICB9KSxcblxuXHQgICAgICAgIF9kb1Jlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIFJDNC5fZG9SZXNldC5jYWxsKHRoaXMpO1xuXG5cdCAgICAgICAgICAgIC8vIERyb3Bcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IHRoaXMuY2ZnLmRyb3A7IGkgPiAwOyBpLS0pIHtcblx0ICAgICAgICAgICAgICAgIGdlbmVyYXRlS2V5c3RyZWFtV29yZC5jYWxsKHRoaXMpO1xuXHQgICAgICAgICAgICB9XG5cdCAgICAgICAgfVxuXHQgICAgfSk7XG5cblx0ICAgIC8qKlxuXHQgICAgICogU2hvcnRjdXQgZnVuY3Rpb25zIHRvIHRoZSBjaXBoZXIncyBvYmplY3QgaW50ZXJmYWNlLlxuXHQgICAgICpcblx0ICAgICAqIEBleGFtcGxlXG5cdCAgICAgKlxuXHQgICAgICogICAgIHZhciBjaXBoZXJ0ZXh0ID0gQ3J5cHRvSlMuUkM0RHJvcC5lbmNyeXB0KG1lc3NhZ2UsIGtleSwgY2ZnKTtcblx0ICAgICAqICAgICB2YXIgcGxhaW50ZXh0ICA9IENyeXB0b0pTLlJDNERyb3AuZGVjcnlwdChjaXBoZXJ0ZXh0LCBrZXksIGNmZyk7XG5cdCAgICAgKi9cblx0ICAgIEMuUkM0RHJvcCA9IFN0cmVhbUNpcGhlci5fY3JlYXRlSGVscGVyKFJDNERyb3ApO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLlJDNDtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3JjNC5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9lbmMtYmFzZTY0XCIpLCByZXF1aXJlKFwiLi9tZDVcIiksIHJlcXVpcmUoXCIuL2V2cGtkZlwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vZW5jLWJhc2U2NFwiLCBcIi4vbWQ1XCIsIFwiLi9ldnBrZGZcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgU3RyZWFtQ2lwaGVyID0gQ19saWIuU3RyZWFtQ2lwaGVyO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLy8gUmV1c2FibGUgb2JqZWN0c1xuXHQgICAgdmFyIFMgID0gW107XG5cdCAgICB2YXIgQ18gPSBbXTtcblx0ICAgIHZhciBHICA9IFtdO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFJhYmJpdCBzdHJlYW0gY2lwaGVyIGFsZ29yaXRobVxuXHQgICAgICovXG5cdCAgICB2YXIgUmFiYml0ID0gQ19hbGdvLlJhYmJpdCA9IFN0cmVhbUNpcGhlci5leHRlbmQoe1xuXHQgICAgICAgIF9kb1Jlc2V0OiBmdW5jdGlvbiAoKSB7XG5cdCAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICB2YXIgSyA9IHRoaXMuX2tleS53b3Jkcztcblx0ICAgICAgICAgICAgdmFyIGl2ID0gdGhpcy5jZmcuaXY7XG5cblx0ICAgICAgICAgICAgLy8gU3dhcCBlbmRpYW5cblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIEtbaV0gPSAoKChLW2ldIDw8IDgpICB8IChLW2ldID4+PiAyNCkpICYgMHgwMGZmMDBmZikgfFxuXHQgICAgICAgICAgICAgICAgICAgICAgICgoKEtbaV0gPDwgMjQpIHwgKEtbaV0gPj4+IDgpKSAgJiAweGZmMDBmZjAwKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIEdlbmVyYXRlIGluaXRpYWwgc3RhdGUgdmFsdWVzXG5cdCAgICAgICAgICAgIHZhciBYID0gdGhpcy5fWCA9IFtcblx0ICAgICAgICAgICAgICAgIEtbMF0sIChLWzNdIDw8IDE2KSB8IChLWzJdID4+PiAxNiksXG5cdCAgICAgICAgICAgICAgICBLWzFdLCAoS1swXSA8PCAxNikgfCAoS1szXSA+Pj4gMTYpLFxuXHQgICAgICAgICAgICAgICAgS1syXSwgKEtbMV0gPDwgMTYpIHwgKEtbMF0gPj4+IDE2KSxcblx0ICAgICAgICAgICAgICAgIEtbM10sIChLWzJdIDw8IDE2KSB8IChLWzFdID4+PiAxNilcblx0ICAgICAgICAgICAgXTtcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBpbml0aWFsIGNvdW50ZXIgdmFsdWVzXG5cdCAgICAgICAgICAgIHZhciBDID0gdGhpcy5fQyA9IFtcblx0ICAgICAgICAgICAgICAgIChLWzJdIDw8IDE2KSB8IChLWzJdID4+PiAxNiksIChLWzBdICYgMHhmZmZmMDAwMCkgfCAoS1sxXSAmIDB4MDAwMGZmZmYpLFxuXHQgICAgICAgICAgICAgICAgKEtbM10gPDwgMTYpIHwgKEtbM10gPj4+IDE2KSwgKEtbMV0gJiAweGZmZmYwMDAwKSB8IChLWzJdICYgMHgwMDAwZmZmZiksXG5cdCAgICAgICAgICAgICAgICAoS1swXSA8PCAxNikgfCAoS1swXSA+Pj4gMTYpLCAoS1syXSAmIDB4ZmZmZjAwMDApIHwgKEtbM10gJiAweDAwMDBmZmZmKSxcblx0ICAgICAgICAgICAgICAgIChLWzFdIDw8IDE2KSB8IChLWzFdID4+PiAxNiksIChLWzNdICYgMHhmZmZmMDAwMCkgfCAoS1swXSAmIDB4MDAwMGZmZmYpXG5cdCAgICAgICAgICAgIF07XG5cblx0ICAgICAgICAgICAgLy8gQ2FycnkgYml0XG5cdCAgICAgICAgICAgIHRoaXMuX2IgPSAwO1xuXG5cdCAgICAgICAgICAgIC8vIEl0ZXJhdGUgdGhlIHN5c3RlbSBmb3VyIHRpbWVzXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNDsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIE1vZGlmeSB0aGUgY291bnRlcnNcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIENbaV0gXj0gWFsoaSArIDQpICYgN107XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBJViBzZXR1cFxuXHQgICAgICAgICAgICBpZiAoaXYpIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIElWID0gaXYud29yZHM7XG5cdCAgICAgICAgICAgICAgICB2YXIgSVZfMCA9IElWWzBdO1xuXHQgICAgICAgICAgICAgICAgdmFyIElWXzEgPSBJVlsxXTtcblxuXHQgICAgICAgICAgICAgICAgLy8gR2VuZXJhdGUgZm91ciBzdWJ2ZWN0b3JzXG5cdCAgICAgICAgICAgICAgICB2YXIgaTAgPSAoKChJVl8wIDw8IDgpIHwgKElWXzAgPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8ICgoKElWXzAgPDwgMjQpIHwgKElWXzAgPj4+IDgpKSAmIDB4ZmYwMGZmMDApO1xuXHQgICAgICAgICAgICAgICAgdmFyIGkyID0gKCgoSVZfMSA8PCA4KSB8IChJVl8xID4+PiAyNCkpICYgMHgwMGZmMDBmZikgfCAoKChJVl8xIDw8IDI0KSB8IChJVl8xID4+PiA4KSkgJiAweGZmMDBmZjAwKTtcblx0ICAgICAgICAgICAgICAgIHZhciBpMSA9IChpMCA+Pj4gMTYpIHwgKGkyICYgMHhmZmZmMDAwMCk7XG5cdCAgICAgICAgICAgICAgICB2YXIgaTMgPSAoaTIgPDwgMTYpICB8IChpMCAmIDB4MDAwMGZmZmYpO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBNb2RpZnkgY291bnRlciB2YWx1ZXNcblx0ICAgICAgICAgICAgICAgIENbMF0gXj0gaTA7XG5cdCAgICAgICAgICAgICAgICBDWzFdIF49IGkxO1xuXHQgICAgICAgICAgICAgICAgQ1syXSBePSBpMjtcblx0ICAgICAgICAgICAgICAgIENbM10gXj0gaTM7XG5cdCAgICAgICAgICAgICAgICBDWzRdIF49IGkwO1xuXHQgICAgICAgICAgICAgICAgQ1s1XSBePSBpMTtcblx0ICAgICAgICAgICAgICAgIENbNl0gXj0gaTI7XG5cdCAgICAgICAgICAgICAgICBDWzddIF49IGkzO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBJdGVyYXRlIHRoZSBzeXN0ZW0gZm91ciB0aW1lc1xuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9Qcm9jZXNzQmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIFggPSB0aGlzLl9YO1xuXG5cdCAgICAgICAgICAgIC8vIEl0ZXJhdGUgdGhlIHN5c3RlbVxuXHQgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBmb3VyIGtleXN0cmVhbSB3b3Jkc1xuXHQgICAgICAgICAgICBTWzBdID0gWFswXSBeIChYWzVdID4+PiAxNikgXiAoWFszXSA8PCAxNik7XG5cdCAgICAgICAgICAgIFNbMV0gPSBYWzJdIF4gKFhbN10gPj4+IDE2KSBeIChYWzVdIDw8IDE2KTtcblx0ICAgICAgICAgICAgU1syXSA9IFhbNF0gXiAoWFsxXSA+Pj4gMTYpIF4gKFhbN10gPDwgMTYpO1xuXHQgICAgICAgICAgICBTWzNdID0gWFs2XSBeIChYWzNdID4+PiAxNikgXiAoWFsxXSA8PCAxNik7XG5cblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIFN3YXAgZW5kaWFuXG5cdCAgICAgICAgICAgICAgICBTW2ldID0gKCgoU1tpXSA8PCA4KSAgfCAoU1tpXSA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAgICAoKChTW2ldIDw8IDI0KSB8IChTW2ldID4+PiA4KSkgICYgMHhmZjAwZmYwMCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICAgICAgICAgIE1bb2Zmc2V0ICsgaV0gXj0gU1tpXTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBibG9ja1NpemU6IDEyOC8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogNjQvMzJcblx0ICAgIH0pO1xuXG5cdCAgICBmdW5jdGlvbiBuZXh0U3RhdGUoKSB7XG5cdCAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgdmFyIFggPSB0aGlzLl9YO1xuXHQgICAgICAgIHZhciBDID0gdGhpcy5fQztcblxuXHQgICAgICAgIC8vIFNhdmUgb2xkIGNvdW50ZXIgdmFsdWVzXG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgQ19baV0gPSBDW2ldO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIC8vIENhbGN1bGF0ZSBuZXcgY291bnRlciB2YWx1ZXNcblx0ICAgICAgICBDWzBdID0gKENbMF0gKyAweDRkMzRkMzRkICsgdGhpcy5fYikgfCAwO1xuXHQgICAgICAgIENbMV0gPSAoQ1sxXSArIDB4ZDM0ZDM0ZDMgKyAoKENbMF0gPj4+IDApIDwgKENfWzBdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbMl0gPSAoQ1syXSArIDB4MzRkMzRkMzQgKyAoKENbMV0gPj4+IDApIDwgKENfWzFdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbM10gPSAoQ1szXSArIDB4NGQzNGQzNGQgKyAoKENbMl0gPj4+IDApIDwgKENfWzJdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNF0gPSAoQ1s0XSArIDB4ZDM0ZDM0ZDMgKyAoKENbM10gPj4+IDApIDwgKENfWzNdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNV0gPSAoQ1s1XSArIDB4MzRkMzRkMzQgKyAoKENbNF0gPj4+IDApIDwgKENfWzRdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNl0gPSAoQ1s2XSArIDB4NGQzNGQzNGQgKyAoKENbNV0gPj4+IDApIDwgKENfWzVdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbN10gPSAoQ1s3XSArIDB4ZDM0ZDM0ZDMgKyAoKENbNl0gPj4+IDApIDwgKENfWzZdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIHRoaXMuX2IgPSAoQ1s3XSA+Pj4gMCkgPCAoQ19bN10gPj4+IDApID8gMSA6IDA7XG5cblx0ICAgICAgICAvLyBDYWxjdWxhdGUgdGhlIGctdmFsdWVzXG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgdmFyIGd4ID0gWFtpXSArIENbaV07XG5cblx0ICAgICAgICAgICAgLy8gQ29uc3RydWN0IGhpZ2ggYW5kIGxvdyBhcmd1bWVudCBmb3Igc3F1YXJpbmdcblx0ICAgICAgICAgICAgdmFyIGdhID0gZ3ggJiAweGZmZmY7XG5cdCAgICAgICAgICAgIHZhciBnYiA9IGd4ID4+PiAxNjtcblxuXHQgICAgICAgICAgICAvLyBDYWxjdWxhdGUgaGlnaCBhbmQgbG93IHJlc3VsdCBvZiBzcXVhcmluZ1xuXHQgICAgICAgICAgICB2YXIgZ2ggPSAoKCgoZ2EgKiBnYSkgPj4+IDE3KSArIGdhICogZ2IpID4+PiAxNSkgKyBnYiAqIGdiO1xuXHQgICAgICAgICAgICB2YXIgZ2wgPSAoKChneCAmIDB4ZmZmZjAwMDApICogZ3gpIHwgMCkgKyAoKChneCAmIDB4MDAwMGZmZmYpICogZ3gpIHwgMCk7XG5cblx0ICAgICAgICAgICAgLy8gSGlnaCBYT1IgbG93XG5cdCAgICAgICAgICAgIEdbaV0gPSBnaCBeIGdsO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIC8vIENhbGN1bGF0ZSBuZXcgc3RhdGUgdmFsdWVzXG5cdCAgICAgICAgWFswXSA9IChHWzBdICsgKChHWzddIDw8IDE2KSB8IChHWzddID4+PiAxNikpICsgKChHWzZdIDw8IDE2KSB8IChHWzZdID4+PiAxNikpKSB8IDA7XG5cdCAgICAgICAgWFsxXSA9IChHWzFdICsgKChHWzBdIDw8IDgpICB8IChHWzBdID4+PiAyNCkpICsgR1s3XSkgfCAwO1xuXHQgICAgICAgIFhbMl0gPSAoR1syXSArICgoR1sxXSA8PCAxNikgfCAoR1sxXSA+Pj4gMTYpKSArICgoR1swXSA8PCAxNikgfCAoR1swXSA+Pj4gMTYpKSkgfCAwO1xuXHQgICAgICAgIFhbM10gPSAoR1szXSArICgoR1syXSA8PCA4KSAgfCAoR1syXSA+Pj4gMjQpKSArIEdbMV0pIHwgMDtcblx0ICAgICAgICBYWzRdID0gKEdbNF0gKyAoKEdbM10gPDwgMTYpIHwgKEdbM10gPj4+IDE2KSkgKyAoKEdbMl0gPDwgMTYpIHwgKEdbMl0gPj4+IDE2KSkpIHwgMDtcblx0ICAgICAgICBYWzVdID0gKEdbNV0gKyAoKEdbNF0gPDwgOCkgIHwgKEdbNF0gPj4+IDI0KSkgKyBHWzNdKSB8IDA7XG5cdCAgICAgICAgWFs2XSA9IChHWzZdICsgKChHWzVdIDw8IDE2KSB8IChHWzVdID4+PiAxNikpICsgKChHWzRdIDw8IDE2KSB8IChHWzRdID4+PiAxNikpKSB8IDA7XG5cdCAgICAgICAgWFs3XSA9IChHWzddICsgKChHWzZdIDw8IDgpICB8IChHWzZdID4+PiAyNCkpICsgR1s1XSkgfCAwO1xuXHQgICAgfVxuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9ucyB0byB0aGUgY2lwaGVyJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgY2lwaGVydGV4dCA9IENyeXB0b0pTLlJhYmJpdC5lbmNyeXB0KG1lc3NhZ2UsIGtleSwgY2ZnKTtcblx0ICAgICAqICAgICB2YXIgcGxhaW50ZXh0ICA9IENyeXB0b0pTLlJhYmJpdC5kZWNyeXB0KGNpcGhlcnRleHQsIGtleSwgY2ZnKTtcblx0ICAgICAqL1xuXHQgICAgQy5SYWJiaXQgPSBTdHJlYW1DaXBoZXIuX2NyZWF0ZUhlbHBlcihSYWJiaXQpO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLlJhYmJpdDtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3JhYmJpdC5qcyIsIjsoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnksIHVuZGVmKSB7XG5cdGlmICh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIikge1xuXHRcdC8vIENvbW1vbkpTXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gZmFjdG9yeShyZXF1aXJlKFwiLi9jb3JlXCIpLCByZXF1aXJlKFwiLi9lbmMtYmFzZTY0XCIpLCByZXF1aXJlKFwiLi9tZDVcIiksIHJlcXVpcmUoXCIuL2V2cGtkZlwiKSwgcmVxdWlyZShcIi4vY2lwaGVyLWNvcmVcIikpO1xuXHR9XG5cdGVsc2UgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG5cdFx0Ly8gQU1EXG5cdFx0ZGVmaW5lKFtcIi4vY29yZVwiLCBcIi4vZW5jLWJhc2U2NFwiLCBcIi4vbWQ1XCIsIFwiLi9ldnBrZGZcIiwgXCIuL2NpcGhlci1jb3JlXCJdLCBmYWN0b3J5KTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBHbG9iYWwgKGJyb3dzZXIpXG5cdFx0ZmFjdG9yeShyb290LkNyeXB0b0pTKTtcblx0fVxufSh0aGlzLCBmdW5jdGlvbiAoQ3J5cHRvSlMpIHtcblxuXHQoZnVuY3Rpb24gKCkge1xuXHQgICAgLy8gU2hvcnRjdXRzXG5cdCAgICB2YXIgQyA9IENyeXB0b0pTO1xuXHQgICAgdmFyIENfbGliID0gQy5saWI7XG5cdCAgICB2YXIgU3RyZWFtQ2lwaGVyID0gQ19saWIuU3RyZWFtQ2lwaGVyO1xuXHQgICAgdmFyIENfYWxnbyA9IEMuYWxnbztcblxuXHQgICAgLy8gUmV1c2FibGUgb2JqZWN0c1xuXHQgICAgdmFyIFMgID0gW107XG5cdCAgICB2YXIgQ18gPSBbXTtcblx0ICAgIHZhciBHICA9IFtdO1xuXG5cdCAgICAvKipcblx0ICAgICAqIFJhYmJpdCBzdHJlYW0gY2lwaGVyIGFsZ29yaXRobS5cblx0ICAgICAqXG5cdCAgICAgKiBUaGlzIGlzIGEgbGVnYWN5IHZlcnNpb24gdGhhdCBuZWdsZWN0ZWQgdG8gY29udmVydCB0aGUga2V5IHRvIGxpdHRsZS1lbmRpYW4uXG5cdCAgICAgKiBUaGlzIGVycm9yIGRvZXNuJ3QgYWZmZWN0IHRoZSBjaXBoZXIncyBzZWN1cml0eSxcblx0ICAgICAqIGJ1dCBpdCBkb2VzIGFmZmVjdCBpdHMgY29tcGF0aWJpbGl0eSB3aXRoIG90aGVyIGltcGxlbWVudGF0aW9ucy5cblx0ICAgICAqL1xuXHQgICAgdmFyIFJhYmJpdExlZ2FjeSA9IENfYWxnby5SYWJiaXRMZWdhY3kgPSBTdHJlYW1DaXBoZXIuZXh0ZW5kKHtcblx0ICAgICAgICBfZG9SZXNldDogZnVuY3Rpb24gKCkge1xuXHQgICAgICAgICAgICAvLyBTaG9ydGN1dHNcblx0ICAgICAgICAgICAgdmFyIEsgPSB0aGlzLl9rZXkud29yZHM7XG5cdCAgICAgICAgICAgIHZhciBpdiA9IHRoaXMuY2ZnLml2O1xuXG5cdCAgICAgICAgICAgIC8vIEdlbmVyYXRlIGluaXRpYWwgc3RhdGUgdmFsdWVzXG5cdCAgICAgICAgICAgIHZhciBYID0gdGhpcy5fWCA9IFtcblx0ICAgICAgICAgICAgICAgIEtbMF0sIChLWzNdIDw8IDE2KSB8IChLWzJdID4+PiAxNiksXG5cdCAgICAgICAgICAgICAgICBLWzFdLCAoS1swXSA8PCAxNikgfCAoS1szXSA+Pj4gMTYpLFxuXHQgICAgICAgICAgICAgICAgS1syXSwgKEtbMV0gPDwgMTYpIHwgKEtbMF0gPj4+IDE2KSxcblx0ICAgICAgICAgICAgICAgIEtbM10sIChLWzJdIDw8IDE2KSB8IChLWzFdID4+PiAxNilcblx0ICAgICAgICAgICAgXTtcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBpbml0aWFsIGNvdW50ZXIgdmFsdWVzXG5cdCAgICAgICAgICAgIHZhciBDID0gdGhpcy5fQyA9IFtcblx0ICAgICAgICAgICAgICAgIChLWzJdIDw8IDE2KSB8IChLWzJdID4+PiAxNiksIChLWzBdICYgMHhmZmZmMDAwMCkgfCAoS1sxXSAmIDB4MDAwMGZmZmYpLFxuXHQgICAgICAgICAgICAgICAgKEtbM10gPDwgMTYpIHwgKEtbM10gPj4+IDE2KSwgKEtbMV0gJiAweGZmZmYwMDAwKSB8IChLWzJdICYgMHgwMDAwZmZmZiksXG5cdCAgICAgICAgICAgICAgICAoS1swXSA8PCAxNikgfCAoS1swXSA+Pj4gMTYpLCAoS1syXSAmIDB4ZmZmZjAwMDApIHwgKEtbM10gJiAweDAwMDBmZmZmKSxcblx0ICAgICAgICAgICAgICAgIChLWzFdIDw8IDE2KSB8IChLWzFdID4+PiAxNiksIChLWzNdICYgMHhmZmZmMDAwMCkgfCAoS1swXSAmIDB4MDAwMGZmZmYpXG5cdCAgICAgICAgICAgIF07XG5cblx0ICAgICAgICAgICAgLy8gQ2FycnkgYml0XG5cdCAgICAgICAgICAgIHRoaXMuX2IgPSAwO1xuXG5cdCAgICAgICAgICAgIC8vIEl0ZXJhdGUgdGhlIHN5c3RlbSBmb3VyIHRpbWVzXG5cdCAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNDsgaSsrKSB7XG5cdCAgICAgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblx0ICAgICAgICAgICAgfVxuXG5cdCAgICAgICAgICAgIC8vIE1vZGlmeSB0aGUgY291bnRlcnNcblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIENbaV0gXj0gWFsoaSArIDQpICYgN107XG5cdCAgICAgICAgICAgIH1cblxuXHQgICAgICAgICAgICAvLyBJViBzZXR1cFxuXHQgICAgICAgICAgICBpZiAoaXYpIHtcblx0ICAgICAgICAgICAgICAgIC8vIFNob3J0Y3V0c1xuXHQgICAgICAgICAgICAgICAgdmFyIElWID0gaXYud29yZHM7XG5cdCAgICAgICAgICAgICAgICB2YXIgSVZfMCA9IElWWzBdO1xuXHQgICAgICAgICAgICAgICAgdmFyIElWXzEgPSBJVlsxXTtcblxuXHQgICAgICAgICAgICAgICAgLy8gR2VuZXJhdGUgZm91ciBzdWJ2ZWN0b3JzXG5cdCAgICAgICAgICAgICAgICB2YXIgaTAgPSAoKChJVl8wIDw8IDgpIHwgKElWXzAgPj4+IDI0KSkgJiAweDAwZmYwMGZmKSB8ICgoKElWXzAgPDwgMjQpIHwgKElWXzAgPj4+IDgpKSAmIDB4ZmYwMGZmMDApO1xuXHQgICAgICAgICAgICAgICAgdmFyIGkyID0gKCgoSVZfMSA8PCA4KSB8IChJVl8xID4+PiAyNCkpICYgMHgwMGZmMDBmZikgfCAoKChJVl8xIDw8IDI0KSB8IChJVl8xID4+PiA4KSkgJiAweGZmMDBmZjAwKTtcblx0ICAgICAgICAgICAgICAgIHZhciBpMSA9IChpMCA+Pj4gMTYpIHwgKGkyICYgMHhmZmZmMDAwMCk7XG5cdCAgICAgICAgICAgICAgICB2YXIgaTMgPSAoaTIgPDwgMTYpICB8IChpMCAmIDB4MDAwMGZmZmYpO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBNb2RpZnkgY291bnRlciB2YWx1ZXNcblx0ICAgICAgICAgICAgICAgIENbMF0gXj0gaTA7XG5cdCAgICAgICAgICAgICAgICBDWzFdIF49IGkxO1xuXHQgICAgICAgICAgICAgICAgQ1syXSBePSBpMjtcblx0ICAgICAgICAgICAgICAgIENbM10gXj0gaTM7XG5cdCAgICAgICAgICAgICAgICBDWzRdIF49IGkwO1xuXHQgICAgICAgICAgICAgICAgQ1s1XSBePSBpMTtcblx0ICAgICAgICAgICAgICAgIENbNl0gXj0gaTI7XG5cdCAgICAgICAgICAgICAgICBDWzddIF49IGkzO1xuXG5cdCAgICAgICAgICAgICAgICAvLyBJdGVyYXRlIHRoZSBzeXN0ZW0gZm91ciB0aW1lc1xuXHQgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblx0ICAgICAgICAgICAgICAgIH1cblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBfZG9Qcm9jZXNzQmxvY2s6IGZ1bmN0aW9uIChNLCBvZmZzZXQpIHtcblx0ICAgICAgICAgICAgLy8gU2hvcnRjdXRcblx0ICAgICAgICAgICAgdmFyIFggPSB0aGlzLl9YO1xuXG5cdCAgICAgICAgICAgIC8vIEl0ZXJhdGUgdGhlIHN5c3RlbVxuXHQgICAgICAgICAgICBuZXh0U3RhdGUuY2FsbCh0aGlzKTtcblxuXHQgICAgICAgICAgICAvLyBHZW5lcmF0ZSBmb3VyIGtleXN0cmVhbSB3b3Jkc1xuXHQgICAgICAgICAgICBTWzBdID0gWFswXSBeIChYWzVdID4+PiAxNikgXiAoWFszXSA8PCAxNik7XG5cdCAgICAgICAgICAgIFNbMV0gPSBYWzJdIF4gKFhbN10gPj4+IDE2KSBeIChYWzVdIDw8IDE2KTtcblx0ICAgICAgICAgICAgU1syXSA9IFhbNF0gXiAoWFsxXSA+Pj4gMTYpIF4gKFhbN10gPDwgMTYpO1xuXHQgICAgICAgICAgICBTWzNdID0gWFs2XSBeIChYWzNdID4+PiAxNikgXiAoWFsxXSA8PCAxNik7XG5cblx0ICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcblx0ICAgICAgICAgICAgICAgIC8vIFN3YXAgZW5kaWFuXG5cdCAgICAgICAgICAgICAgICBTW2ldID0gKCgoU1tpXSA8PCA4KSAgfCAoU1tpXSA+Pj4gMjQpKSAmIDB4MDBmZjAwZmYpIHxcblx0ICAgICAgICAgICAgICAgICAgICAgICAoKChTW2ldIDw8IDI0KSB8IChTW2ldID4+PiA4KSkgICYgMHhmZjAwZmYwMCk7XG5cblx0ICAgICAgICAgICAgICAgIC8vIEVuY3J5cHRcblx0ICAgICAgICAgICAgICAgIE1bb2Zmc2V0ICsgaV0gXj0gU1tpXTtcblx0ICAgICAgICAgICAgfVxuXHQgICAgICAgIH0sXG5cblx0ICAgICAgICBibG9ja1NpemU6IDEyOC8zMixcblxuXHQgICAgICAgIGl2U2l6ZTogNjQvMzJcblx0ICAgIH0pO1xuXG5cdCAgICBmdW5jdGlvbiBuZXh0U3RhdGUoKSB7XG5cdCAgICAgICAgLy8gU2hvcnRjdXRzXG5cdCAgICAgICAgdmFyIFggPSB0aGlzLl9YO1xuXHQgICAgICAgIHZhciBDID0gdGhpcy5fQztcblxuXHQgICAgICAgIC8vIFNhdmUgb2xkIGNvdW50ZXIgdmFsdWVzXG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgQ19baV0gPSBDW2ldO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIC8vIENhbGN1bGF0ZSBuZXcgY291bnRlciB2YWx1ZXNcblx0ICAgICAgICBDWzBdID0gKENbMF0gKyAweDRkMzRkMzRkICsgdGhpcy5fYikgfCAwO1xuXHQgICAgICAgIENbMV0gPSAoQ1sxXSArIDB4ZDM0ZDM0ZDMgKyAoKENbMF0gPj4+IDApIDwgKENfWzBdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbMl0gPSAoQ1syXSArIDB4MzRkMzRkMzQgKyAoKENbMV0gPj4+IDApIDwgKENfWzFdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbM10gPSAoQ1szXSArIDB4NGQzNGQzNGQgKyAoKENbMl0gPj4+IDApIDwgKENfWzJdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNF0gPSAoQ1s0XSArIDB4ZDM0ZDM0ZDMgKyAoKENbM10gPj4+IDApIDwgKENfWzNdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNV0gPSAoQ1s1XSArIDB4MzRkMzRkMzQgKyAoKENbNF0gPj4+IDApIDwgKENfWzRdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbNl0gPSAoQ1s2XSArIDB4NGQzNGQzNGQgKyAoKENbNV0gPj4+IDApIDwgKENfWzVdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIENbN10gPSAoQ1s3XSArIDB4ZDM0ZDM0ZDMgKyAoKENbNl0gPj4+IDApIDwgKENfWzZdID4+PiAwKSA/IDEgOiAwKSkgfCAwO1xuXHQgICAgICAgIHRoaXMuX2IgPSAoQ1s3XSA+Pj4gMCkgPCAoQ19bN10gPj4+IDApID8gMSA6IDA7XG5cblx0ICAgICAgICAvLyBDYWxjdWxhdGUgdGhlIGctdmFsdWVzXG5cdCAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpKyspIHtcblx0ICAgICAgICAgICAgdmFyIGd4ID0gWFtpXSArIENbaV07XG5cblx0ICAgICAgICAgICAgLy8gQ29uc3RydWN0IGhpZ2ggYW5kIGxvdyBhcmd1bWVudCBmb3Igc3F1YXJpbmdcblx0ICAgICAgICAgICAgdmFyIGdhID0gZ3ggJiAweGZmZmY7XG5cdCAgICAgICAgICAgIHZhciBnYiA9IGd4ID4+PiAxNjtcblxuXHQgICAgICAgICAgICAvLyBDYWxjdWxhdGUgaGlnaCBhbmQgbG93IHJlc3VsdCBvZiBzcXVhcmluZ1xuXHQgICAgICAgICAgICB2YXIgZ2ggPSAoKCgoZ2EgKiBnYSkgPj4+IDE3KSArIGdhICogZ2IpID4+PiAxNSkgKyBnYiAqIGdiO1xuXHQgICAgICAgICAgICB2YXIgZ2wgPSAoKChneCAmIDB4ZmZmZjAwMDApICogZ3gpIHwgMCkgKyAoKChneCAmIDB4MDAwMGZmZmYpICogZ3gpIHwgMCk7XG5cblx0ICAgICAgICAgICAgLy8gSGlnaCBYT1IgbG93XG5cdCAgICAgICAgICAgIEdbaV0gPSBnaCBeIGdsO1xuXHQgICAgICAgIH1cblxuXHQgICAgICAgIC8vIENhbGN1bGF0ZSBuZXcgc3RhdGUgdmFsdWVzXG5cdCAgICAgICAgWFswXSA9IChHWzBdICsgKChHWzddIDw8IDE2KSB8IChHWzddID4+PiAxNikpICsgKChHWzZdIDw8IDE2KSB8IChHWzZdID4+PiAxNikpKSB8IDA7XG5cdCAgICAgICAgWFsxXSA9IChHWzFdICsgKChHWzBdIDw8IDgpICB8IChHWzBdID4+PiAyNCkpICsgR1s3XSkgfCAwO1xuXHQgICAgICAgIFhbMl0gPSAoR1syXSArICgoR1sxXSA8PCAxNikgfCAoR1sxXSA+Pj4gMTYpKSArICgoR1swXSA8PCAxNikgfCAoR1swXSA+Pj4gMTYpKSkgfCAwO1xuXHQgICAgICAgIFhbM10gPSAoR1szXSArICgoR1syXSA8PCA4KSAgfCAoR1syXSA+Pj4gMjQpKSArIEdbMV0pIHwgMDtcblx0ICAgICAgICBYWzRdID0gKEdbNF0gKyAoKEdbM10gPDwgMTYpIHwgKEdbM10gPj4+IDE2KSkgKyAoKEdbMl0gPDwgMTYpIHwgKEdbMl0gPj4+IDE2KSkpIHwgMDtcblx0ICAgICAgICBYWzVdID0gKEdbNV0gKyAoKEdbNF0gPDwgOCkgIHwgKEdbNF0gPj4+IDI0KSkgKyBHWzNdKSB8IDA7XG5cdCAgICAgICAgWFs2XSA9IChHWzZdICsgKChHWzVdIDw8IDE2KSB8IChHWzVdID4+PiAxNikpICsgKChHWzRdIDw8IDE2KSB8IChHWzRdID4+PiAxNikpKSB8IDA7XG5cdCAgICAgICAgWFs3XSA9IChHWzddICsgKChHWzZdIDw8IDgpICB8IChHWzZdID4+PiAyNCkpICsgR1s1XSkgfCAwO1xuXHQgICAgfVxuXG5cdCAgICAvKipcblx0ICAgICAqIFNob3J0Y3V0IGZ1bmN0aW9ucyB0byB0aGUgY2lwaGVyJ3Mgb2JqZWN0IGludGVyZmFjZS5cblx0ICAgICAqXG5cdCAgICAgKiBAZXhhbXBsZVxuXHQgICAgICpcblx0ICAgICAqICAgICB2YXIgY2lwaGVydGV4dCA9IENyeXB0b0pTLlJhYmJpdExlZ2FjeS5lbmNyeXB0KG1lc3NhZ2UsIGtleSwgY2ZnKTtcblx0ICAgICAqICAgICB2YXIgcGxhaW50ZXh0ICA9IENyeXB0b0pTLlJhYmJpdExlZ2FjeS5kZWNyeXB0KGNpcGhlcnRleHQsIGtleSwgY2ZnKTtcblx0ICAgICAqL1xuXHQgICAgQy5SYWJiaXRMZWdhY3kgPSBTdHJlYW1DaXBoZXIuX2NyZWF0ZUhlbHBlcihSYWJiaXRMZWdhY3kpO1xuXHR9KCkpO1xuXG5cblx0cmV0dXJuIENyeXB0b0pTLlJhYmJpdExlZ2FjeTtcblxufSkpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL34vY3J5cHRvLWpzL3JhYmJpdC1sZWdhY3kuanMiXSwic291cmNlUm9vdCI6IiJ9