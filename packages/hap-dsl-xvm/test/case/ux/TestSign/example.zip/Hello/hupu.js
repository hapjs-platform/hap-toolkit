/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var $miapp_template$ = __webpack_require__(11)
	var $miapp_style$ = __webpack_require__(12)
	var $miapp_script$ = __webpack_require__(13)
	
	$miapp_define$('@miapp-component/hupu', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})
	
	$miapp_bootstrap$('@miapp-component/hupu',{ packagerVersion: '0.0.2'})

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "container"
	  ],
	  "children": [
	    {
	      "type": "text",
	      "attr": {
	        "value": function () {return this.content.title}
	      },
	      "classList": [
	        "article_title"
	      ]
	    },
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "article_header"
	      ],
	      "children": [
	        {
	          "type": "div",
	          "attr": {},
	          "classList": [
	            "subtitle"
	          ],
	          "children": [
	            {
	              "type": "text",
	              "attr": {
	                "value": function () {return this.content.addtime}
	              },
	              "classList": [
	                "addtime"
	              ]
	            },
	            {
	              "type": "text",
	              "attr": {
	                "value": function () {return this.content.origin}
	              },
	              "classList": [
	                "origin"
	              ],
	              "shown": function () {return this.content.origin}
	            }
	          ]
	        }
	      ]
	    },
	    {
	      "type": "image",
	      "attr": {
	        "src": function () {return this.content.img_m}
	      },
	      "classList": [
	        "photo"
	      ],
	      "shown": function () {return this.content.img_m}
	    },
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "article_content"
	      ],
	      "children": [
	        {
	          "type": "text",
	          "attr": {
	            "type": "html",
	            "value": function () {return this.content.content}
	          }
	        }
	      ]
	    },
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "lists"
	      ],
	      "shown": function () {return this.lights.length},
	      "children": [
	        {
	          "type": "text",
	          "attr": {
	            "value": "这些回复亮了"
	          },
	          "classList": [
	            "comment_title"
	          ]
	        },
	        {
	          "type": "div",
	          "attr": {},
	          "classList": [
	            "item"
	          ],
	          "repeat": function () {return this.lights},
	          "children": [
	            {
	              "type": "div",
	              "attr": {},
	              "classList": [
	                "operations-user"
	              ],
	              "children": [
	                {
	                  "type": "image",
	                  "attr": {
	                    "src": function () {return this.$item.header}
	                  },
	                  "classList": [
	                    "user-avatar"
	                  ]
	                },
	                {
	                  "type": "div",
	                  "attr": {},
	                  "classList": [
	                    "user-info"
	                  ],
	                  "children": [
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return this.$item.user_name}
	                      },
	                      "classList": [
	                        "user-name"
	                      ]
	                    },
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return this.$item.format_time}
	                      },
	                      "classList": [
	                        "reply-time"
	                      ]
	                    }
	                  ]
	                },
	                {
	                  "type": "text",
	                  "attr": {
	                    "value": function () {return '亮了(' + (this.$item.light_count-this.$item.unlight_count) + ')'}
	                  },
	                  "classList": [
	                    "operations"
	                  ]
	                }
	              ]
	            },
	            {
	              "type": "div",
	              "attr": {},
	              "classList": [
	                "reply-content"
	              ],
	              "children": [
	                {
	                  "type": "div",
	                  "attr": {},
	                  "shown": function () {return this.$item.quote_data},
	                  "classList": [
	                    "reply-quote-content"
	                  ],
	                  "children": [
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return this.$item.quote_data.user_name}
	                      },
	                      "classList": [
	                        "reply-quote-hd"
	                      ]
	                    },
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return this.$item.quote_data.content}
	                      },
	                      "classList": [
	                        "short-quote-content"
	                      ]
	                    }
	                  ]
	                },
	                {
	                  "type": "text",
	                  "attr": {
	                    "value": function () {return this.$item.content}
	                  },
	                  "classList": [
	                    "short-content"
	                  ]
	                }
	              ]
	            }
	          ]
	        }
	      ]
	    },
	    {
	      "type": "list",
	      "attr": {},
	      "events": {
	        "scrollbottom": function (evt) {this.load(true,evt)}
	      },
	      "children": [
	        {
	          "type": "block",
	          "attr": {},
	          "shown": function () {return this.replys.length},
	          "children": [
	            {
	              "type": "list-item",
	              "attr": {
	                "type": "text"
	              },
	              "classList": [
	                "lists"
	              ],
	              "children": [
	                {
	                  "type": "text",
	                  "attr": {
	                    "value": "最新评论"
	                  },
	                  "classList": [
	                    "comment_title"
	                  ]
	                },
	                {
	                  "type": "div",
	                  "attr": {},
	                  "classList": [
	                    "item"
	                  ],
	                  "repeat": function () {return this.replys},
	                  "children": [
	                    {
	                      "type": "div",
	                      "attr": {},
	                      "classList": [
	                        "operations-user"
	                      ],
	                      "children": [
	                        {
	                          "type": "image",
	                          "attr": {
	                            "src": function () {return this.$item.header}
	                          },
	                          "classList": [
	                            "user-avatar"
	                          ]
	                        },
	                        {
	                          "type": "div",
	                          "attr": {},
	                          "classList": [
	                            "user-info"
	                          ],
	                          "children": [
	                            {
	                              "type": "text",
	                              "attr": {
	                                "value": function () {return this.$item.user_name}
	                              },
	                              "classList": [
	                                "user-name"
	                              ]
	                            },
	                            {
	                              "type": "text",
	                              "attr": {
	                                "value": function () {return this.$item.format_time}
	                              },
	                              "classList": [
	                                "reply-time"
	                              ]
	                            }
	                          ]
	                        },
	                        {
	                          "type": "text",
	                          "attr": {
	                            "value": function () {return '亮了(' + (this.$item.light_count-this.$item.unlight_count) + ')'}
	                          },
	                          "classList": [
	                            "operations"
	                          ]
	                        }
	                      ]
	                    },
	                    {
	                      "type": "div",
	                      "attr": {},
	                      "classList": [
	                        "reply-content"
	                      ],
	                      "children": [
	                        {
	                          "type": "div",
	                          "attr": {},
	                          "shown": function () {return this.$item.quote_data},
	                          "classList": [
	                            "reply-quote-content"
	                          ],
	                          "children": [
	                            {
	                              "type": "text",
	                              "attr": {
	                                "value": function () {return this.$item.quote_data.user_name}
	                              },
	                              "classList": [
	                                "reply-quote-hd"
	                              ]
	                            },
	                            {
	                              "type": "text",
	                              "attr": {
	                                "value": function () {return this.$item.quote_data.content}
	                              },
	                              "classList": [
	                                "short-quote-content"
	                              ]
	                            }
	                          ]
	                        },
	                        {
	                          "type": "text",
	                          "attr": {
	                            "value": function () {return this.$item.content}
	                          },
	                          "classList": [
	                            "short-content"
	                          ]
	                        }
	                      ]
	                    }
	                  ]
	                }
	              ]
	            }
	          ]
	        }
	      ]
	    }
	  ]
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = {
	  ".operations-user": {
	    "height": "64px",
	    "marginTop": "5px",
	    "marginRight": "2px"
	  },
	  ".user-avatar": {
	    "width": "64px",
	    "height": "64px",
	    "borderRadius": "64px"
	  },
	  ".user-info": {
	    "paddingLeft": "10px",
	    "flex": 1,
	    "display": "block",
	    "flexDirection": "column"
	  },
	  ".user-name": {
	    "flex": 1,
	    "fontSize": "28px",
	    "color": "#444444"
	  },
	  ".reply-time": {
	    "flex": 1,
	    "marginTop": "1px",
	    "fontSize": "25px",
	    "color": "#a9a9b2"
	  },
	  ".operations": {
	    "color": "#a9a9b2"
	  },
	  ".reply-content": {
	    "fontSize": "36px",
	    "paddingLeft": "71px",
	    "paddingTop": "5px",
	    "flex": 1,
	    "display": "block",
	    "flexDirection": "column"
	  },
	  ".reply-quote-content": {
	    "padding": "10px",
	    "marginBottom": "10px",
	    "flex": 1,
	    "flexDirection": "column",
	    "color": "#a9a9b3",
	    "backgroundColor": "#eeebeb"
	  },
	  ".reply-quote-hd": {
	    "color": "#434141"
	  },
	  ".container": {
	    "padding": "20px",
	    "flex": 1,
	    "backgroundColor": "#ffffff",
	    "flexDirection": "column",
	    "fontSize": "14px"
	  },
	  ".photo": {
	    "marginTop": "15px",
	    "marginBottom": "15px",
	    "height": "300px"
	  },
	  ".article_header": {
	    "marginBottom": "20px"
	  },
	  ".article_title": {
	    "fontSize": "44px",
	    "fontWeight": "bold",
	    "paddingTop": "20px",
	    "paddingBottom": "10px",
	    "color": "#434141"
	  },
	  ".subtitle": {
	    "color": "#a9a9b2"
	  },
	  ".addtime": {
	    "flex": 1
	  },
	  ".origin": {
	    "paddingLeft": "10px"
	  },
	  ".article_content": {
	    "fontSize": "24px",
	    "color": "#FF0000"
	  },
	  ".favor": {
	    "backgroundColor": "#2a90d7",
	    "paddingTop": "20px",
	    "paddingBottom": "20px",
	    "paddingLeft": "40px",
	    "paddingRight": "40px",
	    "color": "#ffffff",
	    "textAlign": "center",
	    "borderRadius": "20px"
	  },
	  ".comment": {
	    "marginBottom": "50px"
	  },
	  ".comment_title": {
	    "paddingBottom": "20px",
	    "paddingTop": "20px",
	    "borderStyle": "solid",
	    "borderBottomWidth": "2px",
	    "borderTopWidth": "2px",
	    "paddingLeft": "-17px",
	    "fontSize": "35px",
	    "color": "#c01e2f",
	    "borderColor": "#eeebeb"
	  },
	  ".lists": {
	    "display": "block",
	    "flexDirection": "column"
	  },
	  ".item": {
	    "borderColor": "#bbbbbb",
	    "borderStyle": "solid",
	    "borderBottomWidth": "1px",
	    "paddingTop": "20px",
	    "paddingBottom": "20px",
	    "display": "block",
	    "flexDirection": "column"
	  },
	  ".user-reply-time": {
	    "color": "#a9a9b2"
	  },
	  ".short-content": {
	    "color": "#444444",
	    "fontSize": "32px",
	    "lineHeight": "17px"
	  }
	}

/***/ },
/* 13 */
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){"use strict";
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _miui = $miapp_require$("@miapp-module/miui.fetch");
	
	var _miui2 = _interopRequireDefault(_miui);
	
	var _miui3 = $miapp_require$("@miapp-module/miui.prompt");
	
	var _miui4 = _interopRequireDefault(_miui3);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	exports.default = {
	  data: {
	    content: {
	      title: ''
	    },
	    lights: [],
	    replys: [],
	    has_next: false,
	    reply_loading: true,
	    load_ncid: "",
	    create_time: ""
	  },
	  onReady: function onReady() {
	    var that_ = this;
	    this.get({
	      url: "https://games.mobileapi.hupu.com/4/7.0.19/news/createNewsDetailH5",
	      nid: this.item_id
	    }, function (data) {
	      that_.content = data.data.news;
	      that_.getLights();
	
	      that_.loads(false);
	    });
	  },
	  filterHtml: function filterHtml(content) {
	    return content.replace(/<[^<]*>/g, "");
	  },
	  filterContent: function filterContent(list) {
	    var ret = [];
	    var that_ = this;
	    for (var i = 0; i < list.length; i++) {
	      var item = list[i];
	
	      if (!item.is_delete && item.audit_status != 1) {
	        item.content = that_.filterHtml(item.content);
	
	        if (item.quote_data && item.quote_data.content) {
	          item.quote_data.content = that_.filterHtml(item.quote_data.content);
	        }
	
	        ret.push(item);
	      }
	    }
	    return ret;
	  },
	  getLights: function getLights() {
	    var that_ = this;
	    this.get({
	      url: "https://games.mobileapi.hupu.com/4/7.0.19/news/getLightComment",
	      nid: this.item_id
	    }, function (ret) {
	
	      var data = that_.filterContent(ret.data.light_comments);
	
	      that_.lights = data;
	    });
	  },
	  getReplys: function getReplys() {
	    var that_ = this;
	    this.get({
	      url: "https://games.mobileapi.hupu.com/4/7.0.19/news/getCommentH5",
	      nid: this.item_id
	    }, function (ret) {
	      var replys = that_.replys.concat(that_.filterContent(ret.data.data));
	      _miui4.default.showToast({ message: "请求成功reply：" + replys.length });
	      that_.replys = replys;
	      that_.has_next = ret.data.hasNextPage;
	      that_.reply_loading = false;
	      that_.load_ncid = ret.data.data[ret.data.data.length - 1].ncid;
	      that_.create_time = ret.data.data[ret.data.data.length - 1].create_time;
	    });
	  },
	  load: function load() {
	    _miui4.default.showToast({ message: "滚动了" });
	
	    var that_ = this;
	    if (this.has_next && !this.reply_loading) {
	      this.get({
	        url: "https://games.mobileapi.hupu.com/4/7.0.19/news/getCommentH5",
	        nid: this.item_id,
	        load_ncid: this.load_ncid,
	        create_time: this.create_time
	      }, function (ret) {
	
	        var replys = that_.replys.concat(that_.filterContent(ret.data.data));
	        that_.replys = replys;
	        _miui4.default.showToast({ message: "请求成功scroll：" + replys.length });
	
	        that_.has_next = ret.data.hasNextPage;
	        that_.reply_loading = false;
	        that_.load_ncid = ret.data.data[ret.data.data.length - 1].ncid;
	        that_.create_time = ret.data.data[ret.data.data.length - 1].create_time;
	      });
	    }
	  },
	
	  loads: function loads(more) {
	    var that_ = this;
	    var param = {};
	    if (more) {
	      if (this.has_next && !this.reply_loading) {
	        param = {
	          url: "https://games.mobileapi.hupu.com/4/7.0.19/news/getCommentH5",
	          nid: this.item_id,
	          load_ncid: this.load_ncid,
	          create_time: this.create_time
	        };
	        _miui4.default.showToast({ message: "scroll：了并有更多" });
	      }
	      return _miui4.default.showToast({ message: "scroll：了但没有更多了" });
	    } else {
	      param = {
	        url: "https://games.mobileapi.hupu.com/4/7.0.19/news/getCommentH5",
	        nid: this.item_id
	      };
	      _miui4.default.showToast({ message: "没有scroll：" });
	    }
	    this.get(param, function (ret) {
	      var replys = that_.replys.concat(that_.filterContent(ret.data.data));
	      that_.replys = replys;
	      _miui4.default.showToast({ message: "请求成功：" + replys.length });
	
	      that_.has_next = ret.data.hasNextPage;
	      that_.reply_loading = false;
	      that_.load_ncid = ret.data.data[ret.data.data.length - 1].ncid;
	      that_.create_time = ret.data.data[ret.data.data.length - 1].create_time;
	    });
	  },
	
	  get: function get(param, callback) {
	    var common = {
	      offline: 'json',
	      night: 0,
	      nopic: 0,
	      client: 'minba'
	    };
	    common.nid = param.nid;
	    if (param.ncid) {
	      common.ncid = param.ncid;
	    }
	    if (param.create_time) {
	      common.create_time = param.create_time;
	    }
	    var paramstring = "";
	    for (var x in common) {
	      paramstring += "&" + x + "=" + common[x];
	    }
	    var requestUrl = param.url + "?" + paramstring;
	
	    console.log("##########" + requestUrl);
	
	    this.reply_loading = true;
	    _miui2.default.fetch({
	      url: requestUrl,
	      success: function success(ret) {
	        console.log("##########" + ret.data);
	        callback && callback(JSON.parse(ret.data));
	      },
	      fail: function fail(ret) {
	        _miui4.default.showToast({ message: "请求失败：" + ret });
	      }
	    });
	  },
	  resetTime: function resetTime(time) {
	    var date = new Date(time);
	    var M = date.getMonth() + 1;
	    var D = date.getDate();
	    var H = date.getHours();
	    var m = date.getMinutes();
	    return M + "-" + D + " " + H + ":" + m;
	  }
	};}

/***/ }
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgNTU4ZDllOWRjNTcyY2I5NzkyZmI/NzEyNCIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaHVwdS5taXg/NGIwMCIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaHVwdS5taXg/ZTE1NyIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaHVwdS5taXg/MjQ5YSIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vaHVwdS5taXgiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHVCQUFlO0FBQ2Y7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7QUN0Q0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFDOztBQUVELDRDQUEyQywwQkFBMEIsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ2RyRTtBQUNBO0FBQ0EsYUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQThCO0FBQzlCLFFBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxNQUFLO0FBQ0w7QUFDQTtBQUNBLGlCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBc0M7QUFDdEMsZ0JBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQSxjQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsdUNBQXNDO0FBQ3RDLGdCQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0EscUNBQW9DO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLDZCQUE0QjtBQUM1QixRQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsNkJBQTRCO0FBQzVCLE1BQUs7QUFDTDtBQUNBO0FBQ0EsaUJBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0EsTUFBSztBQUNMO0FBQ0E7QUFDQSxpQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0EsNkJBQTRCLDBCQUEwQjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFVBQVM7QUFDVDtBQUNBO0FBQ0EscUJBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBLGtDQUFpQyxtQkFBbUI7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EseUJBQXdCO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXdDO0FBQ3hDLG9CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQSxrQkFBaUI7QUFDakI7QUFDQTtBQUNBLDZCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUE4QztBQUM5Qyx3QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0Esc0JBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLCtDQUE4QztBQUM5Qyx3QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSwyQ0FBMEM7QUFDMUMsb0JBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFhO0FBQ2I7QUFDQTtBQUNBLHlCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNEI7QUFDNUIseUNBQXdDLDZCQUE2QjtBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUE4QztBQUM5Qyx3QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0Esc0JBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLCtDQUE4QztBQUM5Qyx3QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSwyQ0FBMEM7QUFDMUMsb0JBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUs7QUFDTDtBQUNBO0FBQ0EsaUJBQWdCO0FBQ2hCO0FBQ0EseUNBQXdDO0FBQ3hDLFFBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxxQkFBb0I7QUFDcEIsaUNBQWdDLDBCQUEwQjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLGtCQUFpQjtBQUNqQjtBQUNBO0FBQ0EsNkJBQTRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBLDBDQUF5QyxtQkFBbUI7QUFDNUQ7QUFDQTtBQUNBO0FBQ0EsaUNBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWdEO0FBQ2hELDRCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQSwwQkFBeUI7QUFDekI7QUFDQTtBQUNBLHFDQUFvQztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUFzRDtBQUN0RCxnQ0FBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0EsOEJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLHVEQUFzRDtBQUN0RCxnQ0FBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSxtREFBa0Q7QUFDbEQsNEJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBcUI7QUFDckI7QUFDQTtBQUNBLGlDQUFnQztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBb0M7QUFDcEMsaURBQWdELDZCQUE2QjtBQUM3RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUFzRDtBQUN0RCxnQ0FBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0EsOEJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLHVEQUFzRDtBQUN0RCxnQ0FBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSxtREFBa0Q7QUFDbEQsNEJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7OztBQ25XQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7QUNxRkE7Ozs7QUFFQTs7Ozs7Ozs7O2NBS0E7QUFGQTthQUdBO2FBQ0E7ZUFDQTtvQkFDQTtnQkFDQTtrQkFFQTtBQVZBOytCQVdBO2lCQUNBOztZQUVBO2lCQUNBO0FBRkEsd0JBR0E7aUNBQ0E7YUFFQTs7bUJBR0E7QUFFQTtBQUNBOzRDQUVBO3dDQUNBO0FBQ0E7K0NBQ0E7ZUFDQTtpQkFDQTsyQ0FDQTt1QkFFQTs7c0RBQ0E7OENBRUE7O3lEQUNBO3NFQUNBO0FBRUE7O2tCQUNBO0FBQ0E7QUFDQTtZQUNBO0FBQ0E7bUNBQ0E7aUJBQ0E7O1lBRUE7aUJBQ0E7QUFGQSx1QkFJQTs7K0NBR0E7O3NCQUNBO0FBQ0E7QUFDQTttQ0FDQTtpQkFDQTs7WUFFQTtpQkFDQTtBQUZBLHVCQUdBO3FFQUNBO2lFQUNBO3NCQUNBO2lDQUNBOzZCQUNBO2lFQUNBO21FQUNBO0FBQ0E7QUFDQTt5QkFDQTt5Q0FFQTs7aUJBQ0E7K0NBQ0E7O2NBRUE7bUJBQ0E7eUJBQ0E7MkJBQ0E7QUFKQSx5QkFNQTs7dUVBQ0E7d0JBQ0E7b0VBRUE7O21DQUNBOytCQUNBO21FQUNBO3FFQUNBO0FBQ0E7QUFDQTtBQUVBOzsrQkFDQTtpQkFDQTtpQkFDQTtlQUNBO2lEQUNBOztnQkFFQTtxQkFDQTsyQkFDQTs2QkFFQTtBQUxBOzZDQU1BO0FBQ0E7a0RBQ0E7WUFDQTs7Y0FFQTttQkFFQTtBQUhBOzJDQUlBO0FBQ0E7b0NBQ0E7cUVBQ0E7c0JBQ0E7NERBRUE7O2lDQUNBOzZCQUNBO2lFQUNBO21FQUNBO0FBRUE7QUFRQTs7c0NBQ0E7O2dCQUVBO2NBQ0E7Y0FDQTtlQUVBO0FBTEE7d0JBTUE7cUJBQ0E7MkJBQ0E7QUFDQTs0QkFDQTtrQ0FDQTtBQUNBO3VCQUNBOzJCQUNBOzZDQUNBO0FBQ0E7d0NBRUE7O2dDQUVBOzswQkFDQTs7WUFFQTtzQ0FDQTt3Q0FDQTs2Q0FDQTtBQUNBO2dDQUNBO3VEQUNBO0FBRUE7QUFUQTtBQVVBO3VDQUNBO3lCQUNBOytCQUNBO2tCQUNBO2tCQUNBO2tCQUNBOzBDQUNBO0FBQ0E7QUF0TEEsSSIsImZpbGUiOiJidWlsZC9IZWxsby9odXB1LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pXG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG5cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGV4cG9ydHM6IHt9LFxuIFx0XHRcdGlkOiBtb2R1bGVJZCxcbiBcdFx0XHRsb2FkZWQ6IGZhbHNlXG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmxvYWRlZCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oMCk7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgNTU4ZDllOWRjNTcyY2I5NzkyZmIiLCJ2YXIgJG1pYXBwX3RlbXBsYXRlJCA9IHJlcXVpcmUoXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL2h1cHUubWl4XCIpXG52YXIgJG1pYXBwX3N0eWxlJCA9IHJlcXVpcmUoXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLXN0eWxlLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXN0eWxlcyZyZXNvdXJjZVBhdGg9L2hvbWUvdW5pcXVlL1paWi9zcmMvSGVsbG8vaHVwdS5taXghLi9odXB1Lm1peFwiKVxudmFyICRtaWFwcF9zY3JpcHQkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc2NyaXB0LWxvYWRlci5qcyFiYWJlbC1sb2FkZXI/cHJlc2V0c1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcHJlc2V0cz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wcmVzZXQtZXMyMDE1JnBsdWdpbnNbXT0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmcGx1Z2lucz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmY29tbWVudHM9ZmFsc2UhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zY3JpcHRzIS4vaHVwdS5taXhcIilcblxuJG1pYXBwX2RlZmluZSQoJ0BtaWFwcC1jb21wb25lbnQvaHVwdScsIFxuICAgICAgICAgICAgICAgIFtdLCBmdW5jdGlvbigkbWlhcHBfcmVxdWlyZSQsICRtaWFwcF9leHBvcnRzJCwgJG1pYXBwX21vZHVsZSQpe1xuICAgICAkbWlhcHBfc2NyaXB0JCgkbWlhcHBfbW9kdWxlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfcmVxdWlyZSQpXG4gICAgIGlmICgkbWlhcHBfZXhwb3J0cyQuX19lc01vZHVsZSAmJiAkbWlhcHBfZXhwb3J0cyQuZGVmYXVsdCkge1xuICAgICAgICAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cyA9ICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0XG4gICAgICAgIH1cbiAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cy50ZW1wbGF0ZSA9ICRtaWFwcF90ZW1wbGF0ZSRcbiAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cy5zdHlsZSA9ICRtaWFwcF9zdHlsZSRcbn0pXG5cbiRtaWFwcF9ib290c3RyYXAkKCdAbWlhcHAtY29tcG9uZW50L2h1cHUnLHsgcGFja2FnZXJWZXJzaW9uOiAnMC4wLjInfSlcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL3NyYy9IZWxsby9odXB1Lm1peFxuLy8gbW9kdWxlIGlkID0gMFxuLy8gbW9kdWxlIGNodW5rcyA9IDEiLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gIFwiYXR0clwiOiB7fSxcbiAgXCJjbGFzc0xpc3RcIjogW1xuICAgIFwiY29udGFpbmVyXCJcbiAgXSxcbiAgXCJjaGlsZHJlblwiOiBbXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuY29udGVudC50aXRsZX1cbiAgICAgIH0sXG4gICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgIFwiYXJ0aWNsZV90aXRsZVwiXG4gICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgXCJhcnRpY2xlX2hlYWRlclwiXG4gICAgICBdLFxuICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgXCJzdWJ0aXRsZVwiXG4gICAgICAgICAgXSxcbiAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgIFwidmFsdWVcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLmNvbnRlbnQuYWRkdGltZX1cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgIFwiYWRkdGltZVwiXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy5jb250ZW50Lm9yaWdpbn1cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgIFwib3JpZ2luXCJcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgXCJzaG93blwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuY29udGVudC5vcmlnaW59XG4gICAgICAgICAgICB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJpbWFnZVwiLFxuICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgXCJzcmNcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLmNvbnRlbnQuaW1nX219XG4gICAgICB9LFxuICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICBcInBob3RvXCJcbiAgICAgIF0sXG4gICAgICBcInNob3duXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy5jb250ZW50LmltZ19tfVxuICAgIH0sXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgIFwiYXJ0aWNsZV9jb250ZW50XCJcbiAgICAgIF0sXG4gICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAge1xuICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaHRtbFwiLFxuICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuY29udGVudC5jb250ZW50fVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgXVxuICAgIH0sXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgIFwibGlzdHNcIlxuICAgICAgXSxcbiAgICAgIFwic2hvd25cIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLmxpZ2h0cy5sZW5ndGh9LFxuICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgIFwidmFsdWVcIjogXCLov5nkupvlm57lpI3kuq7kuoZcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgXCJjb21tZW50X3RpdGxlXCJcbiAgICAgICAgICBdXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgXCJpdGVtXCJcbiAgICAgICAgICBdLFxuICAgICAgICAgIFwicmVwZWF0XCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy5saWdodHN9LFxuICAgICAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgXCJvcGVyYXRpb25zLXVzZXJcIlxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJpbWFnZVwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgXCJzcmNcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLiRpdGVtLmhlYWRlcn1cbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgIFwidXNlci1hdmF0YXJcIlxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgIFwidXNlci1pbmZvXCJcbiAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0udXNlcl9uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ1c2VyLW5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0uZm9ybWF0X3RpbWV9XG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICBcInJlcGx5LXRpbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuICfkuq7kuoYoJyArICh0aGlzLiRpdGVtLmxpZ2h0X2NvdW50LXRoaXMuJGl0ZW0udW5saWdodF9jb3VudCkgKyAnKSd9XG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICBcIm9wZXJhdGlvbnNcIlxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICAgICAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgIFwicmVwbHktY29udGVudFwiXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICAgICAgXCJzaG93blwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0ucXVvdGVfZGF0YX0sXG4gICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgIFwicmVwbHktcXVvdGUtY29udGVudFwiXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLiRpdGVtLnF1b3RlX2RhdGEudXNlcl9uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJyZXBseS1xdW90ZS1oZFwiXG4gICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS5xdW90ZV9kYXRhLmNvbnRlbnR9XG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICBcInNob3J0LXF1b3RlLWNvbnRlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0uY29udGVudH1cbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgIFwic2hvcnQtY29udGVudFwiXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJsaXN0XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImV2ZW50c1wiOiB7XG4gICAgICAgIFwic2Nyb2xsYm90dG9tXCI6IGZ1bmN0aW9uIChldnQpIHt0aGlzLmxvYWQodHJ1ZSxldnQpfVxuICAgICAgfSxcbiAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICB7XG4gICAgICAgICAgXCJ0eXBlXCI6IFwiYmxvY2tcIixcbiAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgXCJzaG93blwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMucmVwbHlzLmxlbmd0aH0sXG4gICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpc3QtaXRlbVwiLFxuICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIlxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgXCJsaXN0c1wiXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjogXCLmnIDmlrDor4TorrpcIlxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICAgICAgXCJjb21tZW50X3RpdGxlXCJcbiAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICBcIml0ZW1cIlxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIFwicmVwZWF0XCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy5yZXBseXN9LFxuICAgICAgICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJvcGVyYXRpb25zLXVzZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImltYWdlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzcmNcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLiRpdGVtLmhlYWRlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidXNlci1hdmF0YXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ1c2VyLWluZm9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS51c2VyX25hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInVzZXItbmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS5mb3JtYXRfdGltZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVwbHktdGltZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuICfkuq7kuoYoJyArICh0aGlzLiRpdGVtLmxpZ2h0X2NvdW50LXRoaXMuJGl0ZW0udW5saWdodF9jb3VudCkgKyAnKSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm9wZXJhdGlvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwicmVwbHktY29udGVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzaG93blwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0ucXVvdGVfZGF0YX0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJlcGx5LXF1b3RlLWNvbnRlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS5xdW90ZV9kYXRhLnVzZXJfbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVwbHktcXVvdGUtaGRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0ucXVvdGVfZGF0YS5jb250ZW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzaG9ydC1xdW90ZS1jb250ZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS5jb250ZW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJzaG9ydC1jb250ZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgXVxuICAgIH1cbiAgXVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL3NyYy9IZWxsby9odXB1Lm1peFxuLy8gbW9kdWxlIGlkID0gMTFcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIFwiLm9wZXJhdGlvbnMtdXNlclwiOiB7XG4gICAgXCJoZWlnaHRcIjogXCI2NHB4XCIsXG4gICAgXCJtYXJnaW5Ub3BcIjogXCI1cHhcIixcbiAgICBcIm1hcmdpblJpZ2h0XCI6IFwiMnB4XCJcbiAgfSxcbiAgXCIudXNlci1hdmF0YXJcIjoge1xuICAgIFwid2lkdGhcIjogXCI2NHB4XCIsXG4gICAgXCJoZWlnaHRcIjogXCI2NHB4XCIsXG4gICAgXCJib3JkZXJSYWRpdXNcIjogXCI2NHB4XCJcbiAgfSxcbiAgXCIudXNlci1pbmZvXCI6IHtcbiAgICBcInBhZGRpbmdMZWZ0XCI6IFwiMTBweFwiLFxuICAgIFwiZmxleFwiOiAxLFxuICAgIFwiZGlzcGxheVwiOiBcImJsb2NrXCIsXG4gICAgXCJmbGV4RGlyZWN0aW9uXCI6IFwiY29sdW1uXCJcbiAgfSxcbiAgXCIudXNlci1uYW1lXCI6IHtcbiAgICBcImZsZXhcIjogMSxcbiAgICBcImZvbnRTaXplXCI6IFwiMjhweFwiLFxuICAgIFwiY29sb3JcIjogXCIjNDQ0NDQ0XCJcbiAgfSxcbiAgXCIucmVwbHktdGltZVwiOiB7XG4gICAgXCJmbGV4XCI6IDEsXG4gICAgXCJtYXJnaW5Ub3BcIjogXCIxcHhcIixcbiAgICBcImZvbnRTaXplXCI6IFwiMjVweFwiLFxuICAgIFwiY29sb3JcIjogXCIjYTlhOWIyXCJcbiAgfSxcbiAgXCIub3BlcmF0aW9uc1wiOiB7XG4gICAgXCJjb2xvclwiOiBcIiNhOWE5YjJcIlxuICB9LFxuICBcIi5yZXBseS1jb250ZW50XCI6IHtcbiAgICBcImZvbnRTaXplXCI6IFwiMzZweFwiLFxuICAgIFwicGFkZGluZ0xlZnRcIjogXCI3MXB4XCIsXG4gICAgXCJwYWRkaW5nVG9wXCI6IFwiNXB4XCIsXG4gICAgXCJmbGV4XCI6IDEsXG4gICAgXCJkaXNwbGF5XCI6IFwiYmxvY2tcIixcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJjb2x1bW5cIlxuICB9LFxuICBcIi5yZXBseS1xdW90ZS1jb250ZW50XCI6IHtcbiAgICBcInBhZGRpbmdcIjogXCIxMHB4XCIsXG4gICAgXCJtYXJnaW5Cb3R0b21cIjogXCIxMHB4XCIsXG4gICAgXCJmbGV4XCI6IDEsXG4gICAgXCJmbGV4RGlyZWN0aW9uXCI6IFwiY29sdW1uXCIsXG4gICAgXCJjb2xvclwiOiBcIiNhOWE5YjNcIixcbiAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiNlZWViZWJcIlxuICB9LFxuICBcIi5yZXBseS1xdW90ZS1oZFwiOiB7XG4gICAgXCJjb2xvclwiOiBcIiM0MzQxNDFcIlxuICB9LFxuICBcIi5jb250YWluZXJcIjoge1xuICAgIFwicGFkZGluZ1wiOiBcIjIwcHhcIixcbiAgICBcImZsZXhcIjogMSxcbiAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJjb2x1bW5cIixcbiAgICBcImZvbnRTaXplXCI6IFwiMTRweFwiXG4gIH0sXG4gIFwiLnBob3RvXCI6IHtcbiAgICBcIm1hcmdpblRvcFwiOiBcIjE1cHhcIixcbiAgICBcIm1hcmdpbkJvdHRvbVwiOiBcIjE1cHhcIixcbiAgICBcImhlaWdodFwiOiBcIjMwMHB4XCJcbiAgfSxcbiAgXCIuYXJ0aWNsZV9oZWFkZXJcIjoge1xuICAgIFwibWFyZ2luQm90dG9tXCI6IFwiMjBweFwiXG4gIH0sXG4gIFwiLmFydGljbGVfdGl0bGVcIjoge1xuICAgIFwiZm9udFNpemVcIjogXCI0NHB4XCIsXG4gICAgXCJmb250V2VpZ2h0XCI6IFwiYm9sZFwiLFxuICAgIFwicGFkZGluZ1RvcFwiOiBcIjIwcHhcIixcbiAgICBcInBhZGRpbmdCb3R0b21cIjogXCIxMHB4XCIsXG4gICAgXCJjb2xvclwiOiBcIiM0MzQxNDFcIlxuICB9LFxuICBcIi5zdWJ0aXRsZVwiOiB7XG4gICAgXCJjb2xvclwiOiBcIiNhOWE5YjJcIlxuICB9LFxuICBcIi5hZGR0aW1lXCI6IHtcbiAgICBcImZsZXhcIjogMVxuICB9LFxuICBcIi5vcmlnaW5cIjoge1xuICAgIFwicGFkZGluZ0xlZnRcIjogXCIxMHB4XCJcbiAgfSxcbiAgXCIuYXJ0aWNsZV9jb250ZW50XCI6IHtcbiAgICBcImZvbnRTaXplXCI6IFwiMjRweFwiLFxuICAgIFwiY29sb3JcIjogXCIjRkYwMDAwXCJcbiAgfSxcbiAgXCIuZmF2b3JcIjoge1xuICAgIFwiYmFja2dyb3VuZENvbG9yXCI6IFwiIzJhOTBkN1wiLFxuICAgIFwicGFkZGluZ1RvcFwiOiBcIjIwcHhcIixcbiAgICBcInBhZGRpbmdCb3R0b21cIjogXCIyMHB4XCIsXG4gICAgXCJwYWRkaW5nTGVmdFwiOiBcIjQwcHhcIixcbiAgICBcInBhZGRpbmdSaWdodFwiOiBcIjQwcHhcIixcbiAgICBcImNvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgIFwidGV4dEFsaWduXCI6IFwiY2VudGVyXCIsXG4gICAgXCJib3JkZXJSYWRpdXNcIjogXCIyMHB4XCJcbiAgfSxcbiAgXCIuY29tbWVudFwiOiB7XG4gICAgXCJtYXJnaW5Cb3R0b21cIjogXCI1MHB4XCJcbiAgfSxcbiAgXCIuY29tbWVudF90aXRsZVwiOiB7XG4gICAgXCJwYWRkaW5nQm90dG9tXCI6IFwiMjBweFwiLFxuICAgIFwicGFkZGluZ1RvcFwiOiBcIjIwcHhcIixcbiAgICBcImJvcmRlclN0eWxlXCI6IFwic29saWRcIixcbiAgICBcImJvcmRlckJvdHRvbVdpZHRoXCI6IFwiMnB4XCIsXG4gICAgXCJib3JkZXJUb3BXaWR0aFwiOiBcIjJweFwiLFxuICAgIFwicGFkZGluZ0xlZnRcIjogXCItMTdweFwiLFxuICAgIFwiZm9udFNpemVcIjogXCIzNXB4XCIsXG4gICAgXCJjb2xvclwiOiBcIiNjMDFlMmZcIixcbiAgICBcImJvcmRlckNvbG9yXCI6IFwiI2VlZWJlYlwiXG4gIH0sXG4gIFwiLmxpc3RzXCI6IHtcbiAgICBcImRpc3BsYXlcIjogXCJibG9ja1wiLFxuICAgIFwiZmxleERpcmVjdGlvblwiOiBcImNvbHVtblwiXG4gIH0sXG4gIFwiLml0ZW1cIjoge1xuICAgIFwiYm9yZGVyQ29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgXCJib3JkZXJTdHlsZVwiOiBcInNvbGlkXCIsXG4gICAgXCJib3JkZXJCb3R0b21XaWR0aFwiOiBcIjFweFwiLFxuICAgIFwicGFkZGluZ1RvcFwiOiBcIjIwcHhcIixcbiAgICBcInBhZGRpbmdCb3R0b21cIjogXCIyMHB4XCIsXG4gICAgXCJkaXNwbGF5XCI6IFwiYmxvY2tcIixcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJjb2x1bW5cIlxuICB9LFxuICBcIi51c2VyLXJlcGx5LXRpbWVcIjoge1xuICAgIFwiY29sb3JcIjogXCIjYTlhOWIyXCJcbiAgfSxcbiAgXCIuc2hvcnQtY29udGVudFwiOiB7XG4gICAgXCJjb2xvclwiOiBcIiM0NDQ0NDRcIixcbiAgICBcImZvbnRTaXplXCI6IFwiMzJweFwiLFxuICAgIFwibGluZUhlaWdodFwiOiBcIjE3cHhcIlxuICB9XG59XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9+L21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtc3R5bGUtbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9c3R5bGVzJnJlc291cmNlUGF0aD0vaG9tZS91bmlxdWUvWlpaL3NyYy9IZWxsby9odXB1Lm1peCEuL3NyYy9IZWxsby9odXB1Lm1peFxuLy8gbW9kdWxlIGlkID0gMTJcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwiPHRlbXBsYXRlPlxuPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICA8dGV4dCBjbGFzcz1cImFydGljbGVfdGl0bGVcIiA+e3tjb250ZW50LnRpdGxlfX08L3RleHQ+XG48ZGl2IGNsYXNzPVwiYXJ0aWNsZV9oZWFkZXJcIj5cbiAgPGRpdiBjbGFzcz1cInN1YnRpdGxlXCI+XG4gIDx0ZXh0IGNsYXNzPVwiYWRkdGltZVwiPnt7Y29udGVudC5hZGR0aW1lfX08L3RleHQ+XG48dGV4dCBjbGFzcz1cIm9yaWdpblwiIGlmPVwiY29udGVudC5vcmlnaW5cIj57e2NvbnRlbnQub3JpZ2lufX08L3RleHQ+XG48L2Rpdj5cbjwvZGl2PlxuXG48aW1hZ2UgY2xhc3M9XCJwaG90b1wiIHNyYz1cInt7Y29udGVudC5pbWdfbX19XCIgaWY9XCJ7e2NvbnRlbnQuaW1nX219fVwiIC8+XG4gIDxkaXYgY2xhc3M9XCJhcnRpY2xlX2NvbnRlbnRcIj5cbiAgPHRleHQgIHR5cGU9XCJodG1sXCI+e3tjb250ZW50LmNvbnRlbnR9fTwvdGV4dD5cbjwvZGl2PlxuXG48ZGl2IGNsYXNzPVwibGlzdHNcIiBpZj1cInt7bGlnaHRzLmxlbmd0aH19XCIgPlxuICA8dGV4dCBjbGFzcz1cImNvbW1lbnRfdGl0bGVcIj7ov5nkupvlm57lpI3kuq7kuoY8L3RleHQ+XG4gIDxkaXYgY2xhc3M9XCJpdGVtXCIgZm9yPVwie3tsaWdodHN9fVwiPlxuICA8ZGl2IGNsYXNzPVwib3BlcmF0aW9ucy11c2VyXCI+XG4gIDxpbWFnZSBjbGFzcz1cInVzZXItYXZhdGFyXCIgc3JjPVwie3skaXRlbS5oZWFkZXJ9fVwiPjwvaW1hZ2U+XG4gIDxkaXYgY2xhc3M9XCJ1c2VyLWluZm9cIj5cbiAgPHRleHQgY2xhc3M9XCJ1c2VyLW5hbWVcIj57eyRpdGVtLnVzZXJfbmFtZX19PC90ZXh0PlxuPHRleHQgY2xhc3M9XCJyZXBseS10aW1lXCI+e3skaXRlbS5mb3JtYXRfdGltZX19PC90ZXh0PlxuPC9kaXY+XG48dGV4dCBjbGFzcz1cIm9wZXJhdGlvbnNcIj7kuq7kuoYoe3skaXRlbS5saWdodF9jb3VudCAtICRpdGVtLnVubGlnaHRfY291bnR9fSk8L3RleHQ+XG48L2Rpdj5cbjxkaXYgY2xhc3M9XCJyZXBseS1jb250ZW50XCI+XG4gIDxkaXYgaWY9XCJ7eyRpdGVtLnF1b3RlX2RhdGF9fVwiIGNsYXNzPVwicmVwbHktcXVvdGUtY29udGVudFwiPlxuICA8dGV4dCBjbGFzcz1cInJlcGx5LXF1b3RlLWhkXCI+e3skaXRlbS5xdW90ZV9kYXRhLnVzZXJfbmFtZX19PC90ZXh0PlxuPHRleHQgY2xhc3M9XCJzaG9ydC1xdW90ZS1jb250ZW50XCI+e3skaXRlbS5xdW90ZV9kYXRhLmNvbnRlbnR9fTwvdGV4dD5cbjwvZGl2PlxuPHRleHQgY2xhc3M9XCJzaG9ydC1jb250ZW50XCI+e3skaXRlbS5jb250ZW50fX08L3RleHQ+XG48L2Rpdj5cbjwvZGl2PlxuPC9kaXY+XG5cblxuPGxpc3Qgb25zY3JvbGxib3R0b209XCJsb2FkKHRydWUpXCI+XG4gIDxibG9jayBpZj1cInt7cmVwbHlzLmxlbmd0aH19XCI+XG4gIDxsaXN0LWl0ZW0gdHlwZT1cInRleHRcIiBjbGFzcz1cImxpc3RzXCI+XG4gIDx0ZXh0IGNsYXNzPVwiY29tbWVudF90aXRsZVwiPuacgOaWsOivhOiuujwvdGV4dD5cbiAgPGRpdiBjbGFzcz1cIml0ZW1cIiBmb3I9XCJ7e3JlcGx5c319XCI+XG4gIDxkaXYgY2xhc3M9XCJvcGVyYXRpb25zLXVzZXJcIj5cbiAgPGltYWdlIGNsYXNzPVwidXNlci1hdmF0YXJcIiBzcmM9XCJ7eyRpdGVtLmhlYWRlcn19XCI+PC9pbWFnZT5cbiAgPGRpdiBjbGFzcz1cInVzZXItaW5mb1wiPlxuICA8dGV4dCBjbGFzcz1cInVzZXItbmFtZVwiPnt7JGl0ZW0udXNlcl9uYW1lfX08L3RleHQ+XG48dGV4dCBjbGFzcz1cInJlcGx5LXRpbWVcIj57eyRpdGVtLmZvcm1hdF90aW1lfX08L3RleHQ+XG48L2Rpdj5cbjx0ZXh0IGNsYXNzPVwib3BlcmF0aW9uc1wiPuS6ruS6hih7eyRpdGVtLmxpZ2h0X2NvdW50IC0gJGl0ZW0udW5saWdodF9jb3VudH19KTwvdGV4dD5cbjwvZGl2PlxuPGRpdiBjbGFzcz1cInJlcGx5LWNvbnRlbnRcIj5cbiAgPGRpdiBpZj1cInt7JGl0ZW0ucXVvdGVfZGF0YX19XCIgY2xhc3M9XCJyZXBseS1xdW90ZS1jb250ZW50XCI+XG4gIDx0ZXh0IGNsYXNzPVwicmVwbHktcXVvdGUtaGRcIj57eyRpdGVtLnF1b3RlX2RhdGEudXNlcl9uYW1lfX08L3RleHQ+XG48dGV4dCBjbGFzcz1cInNob3J0LXF1b3RlLWNvbnRlbnRcIj57eyRpdGVtLnF1b3RlX2RhdGEuY29udGVudH19PC90ZXh0PlxuPC9kaXY+XG48dGV4dCBjbGFzcz1cInNob3J0LWNvbnRlbnRcIj57eyRpdGVtLmNvbnRlbnR9fTwvdGV4dD5cbjwvZGl2PlxuPC9kaXY+XG48L2xpc3QtaXRlbT5cbjwvYmxvY2s+XG48L2xpc3Q+XG5cblxuPC9kaXY+XG48L3RlbXBsYXRlPlxuPHN0eWxlPlxuLm9wZXJhdGlvbnMtdXNlcntcbiAgaGVpZ2h0OiA2NHB4O1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1yaWdodDogMnB4O1xufVxuLnVzZXItYXZhdGFye1xuICB3aWR0aDogNjRweDtcbiAgaGVpZ2h0OiA2NHB4O1xuICBib3JkZXItcmFkaXVzOiA2NHB4O1xufVxuXG4udXNlci1pbmZve1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIGZsZXg6IDE7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuLnVzZXItbmFtZXtcbiAgZmxleDoxO1xuICBmb250LXNpemU6IDI4cHg7XG59XG4ucmVwbHktdGltZXtcbiAgZmxleDoxO1xuICBtYXJnaW4tdG9wOiAxcHg7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICNhOWE5YjI7XG59XG4ub3BlcmF0aW9uc3tcbiAgY29sb3I6ICNhOWE5YjI7XG59XG4ucmVwbHktY29udGVudHtcbiAgZm9udC1zaXplOiAzNnB4O1xuICBwYWRkaW5nLWxlZnQ6IDcxcHg7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG4gIGZsZXg6IDE7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuLnJlcGx5LXF1b3RlLWNvbnRlbnR7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGZsZXg6IDE7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGNvbG9yOiAjYTlhOWIzO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVlYmViO1xuXG59XG5cbi5yZXBseS1xdW90ZS1oZCB7XG4gIGNvbG9yOiAjNDM0MTQxO1xufVxuXG5cblxuLmNvbnRhaW5lcntcbiAgcGFkZGluZzogMjBweDtcbiAgZmxleDogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZm9udC1zaXplOiAxNHB4O1xuXG59XG5cbi5waG90b3tcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgaGVpZ2h0OiAzMDBweDtcbn1cbi5hcnRpY2xlX2hlYWRlcntcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cbi5hcnRpY2xlX3RpdGxle1xuICBmb250LXNpemU6IDQ0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBwYWRkaW5nLXRvcDogMjBweDtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG4gIGNvbG9yOiAjNDM0MTQxO1xuXG59XG4uc3VidGl0bGV7Y29sb3I6ICNhOWE5YjI7fVxuLmFkZHRpbWV7XG4gIGZsZXg6IDE7XG59XG4ub3JpZ2lue1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG5cbn1cbi5hcnRpY2xlX2NvbnRlbnR7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6IHJlZDtcbn1cbi5mYXZvcntcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJhOTBkNztcbiAgcGFkZGluZy10b3A6IDIwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDQwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDQwcHg7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG59XG4uY29tbWVudHtcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcbn1cbi5jb21tZW50X3RpdGxle1xuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgcGFkZGluZy10b3A6IDIwcHg7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDJweDtcbiAgYm9yZGVyLXRvcC13aWR0aDogMnB4O1xuXG4gIHBhZGRpbmctbGVmdDogLTE3cHg7XG4gIGZvbnQtc2l6ZTogMzVweDtcbiAgY29sb3I6ICNjMDFlMmY7XG4gIGJvcmRlci1jb2xvcjogI2VlZWJlYjtcbn1cblxuLmxpc3Rze1xuICBkaXNwbGF5OiBibG9jaztcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5pdGVte1xuICBib3JkZXItY29sb3I6ICNiYmI7XG5cbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuXG4gIHBhZGRpbmctdG9wOiAyMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbn1cblxuLnVzZXItbmFtZXtcbiAgY29sb3I6ICM0NDQ0NDQ7XG59XG4udXNlci1yZXBseS10aW1le1xuICBjb2xvcjogI2E5YTliMjtcbn1cbi5zaG9ydC1jb250ZW50e1xuICBjb2xvcjogIzQ0NDQ0NDtcbiAgZm9udC1zaXplOiAzMnB4O1xuICBsaW5lLWhlaWdodDogMTdweDtcblxuXG59XG48L3N0eWxlPlxuPHNjcmlwdD5cbmltcG9ydCBmZXRjaCBmcm9tIFwiQG1peC9taXVpLmZldGNoXCJcbmltcG9ydCBwcm9tcHQgZnJvbSBcIkBtaXgvbWl1aS5wcm9tcHRcIlxuZXhwb3J0IGRlZmF1bHQge1xuICBkYXRhOiB7XG4gICAgY29udGVudDoge1xuICAgICAgdGl0bGU6ICcnXG4gICAgfSxcbiAgICBsaWdodHM6IFtdLFxuICAgIHJlcGx5czogW10sXG4gICAgaGFzX25leHQ6IGZhbHNlLFxuICAgIHJlcGx5X2xvYWRpbmc6IHRydWUsXG4gICAgbG9hZF9uY2lkOiBcIlwiLFxuICAgIGNyZWF0ZV90aW1lOiBcIlwiXG4gIH0sXG4gIG9uUmVhZHk6IGZ1bmN0aW9uKCl7XG4gICAgdmFyIHRoYXRfID0gdGhpcztcbiAgICB0aGlzLmdldCh7XG4gICAgICB1cmw6IFwiaHR0cHM6Ly9nYW1lcy5tb2JpbGVhcGkuaHVwdS5jb20vNC83LjAuMTkvbmV3cy9jcmVhdGVOZXdzRGV0YWlsSDVcIixcbiAgICAgIG5pZDogdGhpcy5pdGVtX2lkXG4gICAgfSxmdW5jdGlvbihkYXRhKXtcbiAgICAgIHRoYXRfLmNvbnRlbnQgPSBkYXRhLmRhdGEubmV3cztcbiAgICAgIHRoYXRfLmdldExpZ2h0cygpO1xuICAgICAgLy90aGF0Xy5nZXRSZXBseXMoKTtcbiAgICAgIHRoYXRfLmxvYWRzKGZhbHNlKTtcbiAgICAgIC8vdGhhdF8ubG9hZHModHJ1ZSk7XG5cbiAgICB9KTtcblxuICB9LFxuICBmaWx0ZXJIdG1sOiBmdW5jdGlvbiggY29udGVudCApe1xuICAgIC8v6L+H5rukaHRtbOagh+etvlxuICAgIHJldHVybiBjb250ZW50LnJlcGxhY2UoLzxbXjxdKj4vZywgXCJcIilcbiAgfSxcbiAgZmlsdGVyQ29udGVudDogZnVuY3Rpb24obGlzdCl7XG4gICAgdmFyIHJldCA9IFtdXG4gICAgdmFyIHRoYXRfID0gdGhpcztcbiAgICBmb3IodmFyIGk9MDtpPGxpc3QubGVuZ3RoO2krKyl7XG4gICAgICB2YXIgaXRlbSA9IGxpc3RbaV07XG4gICAgICAvL+i/h+a7pOS4jemAguWQiOWxleekuuivhOiuulxuICAgICAgaWYoICFpdGVtLmlzX2RlbGV0ZSAmJiBpdGVtLmF1ZGl0X3N0YXR1cyAhPSAxICl7XG4gICAgICAgIGl0ZW0uY29udGVudCA9IHRoYXRfLmZpbHRlckh0bWwoaXRlbS5jb250ZW50KTtcblxuICAgICAgICBpZihpdGVtLnF1b3RlX2RhdGEgJiYgaXRlbS5xdW90ZV9kYXRhLmNvbnRlbnQpe1xuICAgICAgICAgIGl0ZW0ucXVvdGVfZGF0YS5jb250ZW50ID0gdGhhdF8uZmlsdGVySHRtbChpdGVtLnF1b3RlX2RhdGEuY29udGVudCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXQucHVzaChpdGVtKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJldFxuICB9LFxuICBnZXRMaWdodHM6IGZ1bmN0aW9uKCl7XG4gICAgdmFyIHRoYXRfID0gdGhpcztcbiAgICB0aGlzLmdldCh7XG4gICAgICB1cmw6IFwiaHR0cHM6Ly9nYW1lcy5tb2JpbGVhcGkuaHVwdS5jb20vNC83LjAuMTkvbmV3cy9nZXRMaWdodENvbW1lbnRcIixcbiAgICAgIG5pZDogdGhpcy5pdGVtX2lkXG4gICAgfSxmdW5jdGlvbihyZXQpe1xuXG4gICAgICB2YXIgZGF0YSA9IHRoYXRfLmZpbHRlckNvbnRlbnQocmV0LmRhdGEubGlnaHRfY29tbWVudHMpO1xuICAgICAgLy9jb25zb2xlLmxvZygnbGlnaHRzZGF0YTonICsgZGF0YSk7XG4gICAgICAvL3Byb21wdC5zaG93VG9hc3Qoe21lc3NhZ2U6IFwi6K+35rGC5oiQ5Yqf5Lqu5LqG77yaXCIgKyBkYXRhLmxlbmd0aH0pXG4gICAgICB0aGF0Xy5saWdodHMgPSBkYXRhO1xuICAgIH0pXG4gIH0sXG4gIGdldFJlcGx5czogZnVuY3Rpb24oKXtcbiAgICB2YXIgdGhhdF8gPSB0aGlzO1xuICAgIHRoaXMuZ2V0KHtcbiAgICAgIHVybDogXCJodHRwczovL2dhbWVzLm1vYmlsZWFwaS5odXB1LmNvbS80LzcuMC4xOS9uZXdzL2dldENvbW1lbnRINVwiLFxuICAgICAgbmlkOiB0aGlzLml0ZW1faWRcbiAgICB9LGZ1bmN0aW9uKHJldCl7XG4gICAgICB2YXIgcmVwbHlzID0gdGhhdF8ucmVwbHlzLmNvbmNhdCh0aGF0Xy5maWx0ZXJDb250ZW50KHJldC5kYXRhLmRhdGEpKSA7XG4gICAgICBwcm9tcHQuc2hvd1RvYXN0KHttZXNzYWdlOiBcIuivt+axguaIkOWKn3JlcGx577yaXCIgKyByZXBseXMubGVuZ3RofSlcbiAgICAgIHRoYXRfLnJlcGx5cyA9IHJlcGx5cztcbiAgICAgIHRoYXRfLmhhc19uZXh0ID0gcmV0LmRhdGEuaGFzTmV4dFBhZ2U7XG4gICAgICB0aGF0Xy5yZXBseV9sb2FkaW5nID0gZmFsc2U7XG4gICAgICB0aGF0Xy5sb2FkX25jaWQgPSByZXQuZGF0YS5kYXRhW3JldC5kYXRhLmRhdGEubGVuZ3RoIC0gMV0ubmNpZDtcbiAgICAgIHRoYXRfLmNyZWF0ZV90aW1lID0gcmV0LmRhdGEuZGF0YVtyZXQuZGF0YS5kYXRhLmxlbmd0aCAtIDFdLmNyZWF0ZV90aW1lO1xuICAgIH0pXG4gIH0sXG4gIGxvYWQ6IGZ1bmN0aW9uKCl7XG4gICAgcHJvbXB0LnNob3dUb2FzdCh7bWVzc2FnZTogXCLmu5rliqjkuoZcIn0pXG5cbiAgICB2YXIgdGhhdF8gPSB0aGlzO1xuICAgIGlmKHRoaXMuaGFzX25leHQgJiYgIXRoaXMucmVwbHlfbG9hZGluZyl7XG4gICAgICB0aGlzLmdldCh7XG4gICAgICAgIHVybDogXCJodHRwczovL2dhbWVzLm1vYmlsZWFwaS5odXB1LmNvbS80LzcuMC4xOS9uZXdzL2dldENvbW1lbnRINVwiLFxuICAgICAgICBuaWQ6IHRoaXMuaXRlbV9pZCxcbiAgICAgICAgbG9hZF9uY2lkOiB0aGlzLmxvYWRfbmNpZCxcbiAgICAgICAgY3JlYXRlX3RpbWU6IHRoaXMuY3JlYXRlX3RpbWVcbiAgICAgIH0sZnVuY3Rpb24ocmV0KXtcblxuICAgICAgICB2YXIgcmVwbHlzID0gdGhhdF8ucmVwbHlzLmNvbmNhdCh0aGF0Xy5maWx0ZXJDb250ZW50KHJldC5kYXRhLmRhdGEpKSA7XG4gICAgICAgIHRoYXRfLnJlcGx5cyA9IHJlcGx5cztcbiAgICAgICAgcHJvbXB0LnNob3dUb2FzdCh7bWVzc2FnZTogXCLor7fmsYLmiJDlip9zY3JvbGzvvJpcIiArIHJlcGx5cy5sZW5ndGh9KVxuXG4gICAgICAgIHRoYXRfLmhhc19uZXh0ID0gcmV0LmRhdGEuaGFzTmV4dFBhZ2U7XG4gICAgICAgIHRoYXRfLnJlcGx5X2xvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgdGhhdF8ubG9hZF9uY2lkID0gcmV0LmRhdGEuZGF0YVtyZXQuZGF0YS5kYXRhLmxlbmd0aCAtIDFdLm5jaWQ7XG4gICAgICAgIHRoYXRfLmNyZWF0ZV90aW1lID0gcmV0LmRhdGEuZGF0YVtyZXQuZGF0YS5kYXRhLmxlbmd0aCAtIDFdLmNyZWF0ZV90aW1lO1xuICAgICAgfSlcbiAgICB9XG4gIH0sXG5cbiAgbG9hZHM6IGZ1bmN0aW9uKG1vcmUpe1xuICAgIHZhciB0aGF0XyA9IHRoaXM7XG4gICAgdmFyIHBhcmFtID0ge307XG4gICAgaWYgKG1vcmUpIHtcbiAgICAgIGlmICh0aGlzLmhhc19uZXh0ICYmICF0aGlzLnJlcGx5X2xvYWRpbmcpIHtcbiAgICAgICAgcGFyYW0gPSB7XG4gICAgICAgICAgdXJsOiBcImh0dHBzOi8vZ2FtZXMubW9iaWxlYXBpLmh1cHUuY29tLzQvNy4wLjE5L25ld3MvZ2V0Q29tbWVudEg1XCIsXG4gICAgICAgICAgbmlkOiB0aGlzLml0ZW1faWQsXG4gICAgICAgICAgbG9hZF9uY2lkOiB0aGlzLmxvYWRfbmNpZCxcbiAgICAgICAgICBjcmVhdGVfdGltZTogdGhpcy5jcmVhdGVfdGltZVxuICAgICAgICB9O1xuICAgICAgICBwcm9tcHQuc2hvd1RvYXN0KHttZXNzYWdlOiBcInNjcm9sbO+8muS6huW5tuacieabtOWkmlwifSlcbiAgICAgIH1cbiAgICAgIHJldHVybiBwcm9tcHQuc2hvd1RvYXN0KHttZXNzYWdlOiBcInNjcm9sbO+8muS6huS9huayoeacieabtOWkmuS6hlwifSlcbiAgICB9IGVsc2Uge1xuICAgICAgcGFyYW0gPSB7XG4gICAgICAgIHVybDogXCJodHRwczovL2dhbWVzLm1vYmlsZWFwaS5odXB1LmNvbS80LzcuMC4xOS9uZXdzL2dldENvbW1lbnRINVwiLFxuICAgICAgICBuaWQ6IHRoaXMuaXRlbV9pZFxuICAgICAgfTtcbiAgICAgIHByb21wdC5zaG93VG9hc3Qoe21lc3NhZ2U6IFwi5rKh5pyJc2Nyb2xs77yaXCJ9KVxuICAgIH1cbiAgICB0aGlzLmdldChwYXJhbSwgZnVuY3Rpb24ocmV0KXtcbiAgICAgIHZhciByZXBseXMgPSB0aGF0Xy5yZXBseXMuY29uY2F0KHRoYXRfLmZpbHRlckNvbnRlbnQocmV0LmRhdGEuZGF0YSkpIDtcbiAgICAgIHRoYXRfLnJlcGx5cyA9IHJlcGx5cztcbiAgICAgIHByb21wdC5zaG93VG9hc3Qoe21lc3NhZ2U6IFwi6K+35rGC5oiQ5Yqf77yaXCIgKyByZXBseXMubGVuZ3RofSlcblxuICAgICAgdGhhdF8uaGFzX25leHQgPSByZXQuZGF0YS5oYXNOZXh0UGFnZTtcbiAgICAgIHRoYXRfLnJlcGx5X2xvYWRpbmcgPSBmYWxzZTtcbiAgICAgIHRoYXRfLmxvYWRfbmNpZCA9IHJldC5kYXRhLmRhdGFbcmV0LmRhdGEuZGF0YS5sZW5ndGggLSAxXS5uY2lkO1xuICAgICAgdGhhdF8uY3JlYXRlX3RpbWUgPSByZXQuZGF0YS5kYXRhW3JldC5kYXRhLmRhdGEubGVuZ3RoIC0gMV0uY3JlYXRlX3RpbWU7XG4gICAgfSlcblxuICB9LFxuXG5cblxuXG5cblxuXG4gIGdldDogZnVuY3Rpb24ocGFyYW0sIGNhbGxiYWNrKXtcbiAgICB2YXIgY29tbW9uID0ge1xuICAgICAgb2ZmbGluZTogJ2pzb24nLFxuICAgICAgbmlnaHQ6IDAsXG4gICAgICBub3BpYzogMCxcbiAgICAgIGNsaWVudDogJ21pbmJhJ1xuICAgIH1cbiAgICBjb21tb24ubmlkID0gcGFyYW0ubmlkO1xuICAgIGlmKHBhcmFtLm5jaWQpe1xuICAgICAgY29tbW9uLm5jaWQgPSBwYXJhbS5uY2lkO1xuICAgIH1cbiAgICBpZihwYXJhbS5jcmVhdGVfdGltZSl7XG4gICAgICBjb21tb24uY3JlYXRlX3RpbWUgPSBwYXJhbS5jcmVhdGVfdGltZTtcbiAgICB9XG4gICAgdmFyIHBhcmFtc3RyaW5nID0gXCJcIjtcbiAgICBmb3IodmFyIHggaW4gY29tbW9uKXtcbiAgICAgIHBhcmFtc3RyaW5nICs9IFwiJlwiICsgeCArIFwiPVwiICsgY29tbW9uW3hdO1xuICAgIH1cbiAgICB2YXIgcmVxdWVzdFVybCA9IHBhcmFtLnVybCArIFwiP1wiICsgcGFyYW1zdHJpbmc7XG5cbiAgICBjb25zb2xlLmxvZyhcIiMjIyMjIyMjIyNcIiArIHJlcXVlc3RVcmwpO1xuXG4gICAgdGhpcy5yZXBseV9sb2FkaW5nID0gdHJ1ZTtcbiAgICBmZXRjaC5mZXRjaCh7XG4gICAgICB1cmw6IHJlcXVlc3RVcmwsXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXQpe1xuICAgICAgICBjb25zb2xlLmxvZyhcIiMjIyMjIyMjIyNcIiArIHJldC5kYXRhKTtcbiAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soSlNPTi5wYXJzZShyZXQuZGF0YSkpO1xuICAgICAgfSxcbiAgICAgIGZhaWw6IGZ1bmN0aW9uKHJldCl7XG4gICAgICAgIHByb21wdC5zaG93VG9hc3Qoe21lc3NhZ2U6IFwi6K+35rGC5aSx6LSl77yaXCIgKyByZXR9KVxuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIHJlc2V0VGltZTogZnVuY3Rpb24odGltZSl7XG4gICAgdmFyIGRhdGUgPSBuZXcgRGF0ZSh0aW1lKTtcbiAgICB2YXIgTSA9IGRhdGUuZ2V0TW9udGgoKSArMTtcbiAgICB2YXIgRCA9IGRhdGUuZ2V0RGF0ZSgpO1xuICAgIHZhciBIID0gZGF0ZS5nZXRIb3VycygpO1xuICAgIHZhciBtID0gZGF0ZS5nZXRNaW51dGVzKCk7XG4gICAgcmV0dXJuIE0gK1wiLVwiK0QrXCIgXCIrSCtcIjpcIittO1xuICB9XG59XG48L3NjcmlwdD5cblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9IZWxsby9odXB1Lm1peD8yNjVkNjIxMiJdLCJzb3VyY2VSb290IjoiIn0=