/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var $miapp_template$ = __webpack_require__(11)
	var $miapp_style$ = __webpack_require__(12)
	var $miapp_script$ = __webpack_require__(13)
	
	$miapp_define$('@miapp-component/test', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})
	
	$miapp_bootstrap$('@miapp-component/test',{ packagerVersion: '0.0.2'})

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "container"
	  ],
	  "children": [
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "title"
	      ],
	      "children": [
	        {
	          "type": "div",
	          "attr": {},
	          "classList": [
	            "button"
	          ],
	          "events": {
	            "click": function (evt) {this.toggleList(0,evt)}
	          },
	          "children": [
	            {
	              "type": "text",
	              "attr": {
	                "value": "List1"
	              }
	            }
	          ]
	        },
	        {
	          "type": "div",
	          "attr": {},
	          "classList": [
	            "button"
	          ],
	          "events": {
	            "click": function (evt) {this.toggleList(1,evt)}
	          },
	          "children": [
	            {
	              "type": "text",
	              "attr": {
	                "value": "List2"
	              }
	            }
	          ]
	        }
	      ]
	    },
	    {
	      "type": "list",
	      "attr": {},
	      "children": [
	        {
	          "type": "block",
	          "attr": {
	            "tid": function () {return this.$item.id}
	          },
	          "repeat": function () {return this.lists[this.currentList]},
	          "children": [
	            {
	              "type": "list-item",
	              "attr": {
	                "type": function () {return this.$item.id}
	              },
	              "classList": [
	                "item"
	              ],
	              "children": [
	                {
	                  "type": "div",
	                  "attr": {},
	                  "children": [
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return 'name: ' + (this.$item.name)}
	                      }
	                    }
	                  ]
	                },
	                {
	                  "type": "div",
	                  "attr": {},
	                  "shown": function () {return this.hasItem(this.$item)},
	                  "children": [
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": function () {return this.hasItem(this.$item)&&this.hasItem(this.$item).quantity}
	                      },
	                      "style": {
	                        "backgroundColor": "#0000FF"
	                      }
	                    }
	                  ]
	                },
	                {
	                  "type": "div",
	                  "attr": {},
	                  "classList": [
	                    "inline-button"
	                  ],
	                  "events": {
	                    "click": function (evt) {this.addToCart(this.$item,evt)}
	                  },
	                  "children": [
	                    {
	                      "type": "text",
	                      "attr": {
	                        "value": "加入购物车"
	                      }
	                    }
	                  ]
	                }
	              ]
	            }
	          ]
	        }
	      ]
	    }
	  ]
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = {
	  "text": {
	    "color": "#333333",
	    "fontSize": "30px"
	  },
	  "list": {
	    "height": "300px"
	  },
	  ".container": {
	    "flexDirection": "column"
	  },
	  ".item": {
	    "height": "100px"
	  },
	  ".title": {
	    "flexDirection": "row",
	    "height": "200px"
	  },
	  ".button": {
	    "flex": 1,
	    "padding": "10px",
	    "marginRight": "10px",
	    "borderWidth": "1px",
	    "borderColor": "#333333"
	  },
	  ".inline-button": {
	    "marginLeft": "50px",
	    "width": "150px",
	    "backgroundColor": "#FF0000"
	  }
	}

/***/ },
/* 13 */
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){'use strict';
	
	module.exports = {
	  data: function data() {
	    return {
	      lists: [[{
	        id: 1,
	        name: 'item1',
	        quantity: 1
	      }, {
	        id: 2,
	        name: 'item2',
	        quantity: 1
	      }], [{
	        id: 3,
	        name: 'item3',
	        quantity: 1
	      }, {
	        id: 4,
	        name: 'item4',
	        quantity: 1
	      }]],
	      added: [],
	      currentList: 0
	    };
	  },
	  hasItem: function hasItem(item) {
	    return this.added.find(function (addedItem) {
	      return addedItem.id === item.id;
	    });
	  },
	  addToCart: function addToCart(item) {
	    var hasItem = this.hasItem(item);
	
	    if (hasItem) {
	      hasItem.quantity++;
	    } else {
	      this.added.push(item);
	    }
	  },
	  toggleList: function toggleList(id) {
	    this.currentList = id;
	  }
	};}

/***/ }
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgZjUwYWM3OTY3MjQ1ZGM5ZjBkZTg/NThjNiIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vdGVzdC5taXg/MTliNCIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vdGVzdC5taXg/ZGE3NSIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vdGVzdC5taXg/Njg4MCIsIndlYnBhY2s6Ly8vLi9zcmMvSGVsbG8vdGVzdC5taXgiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHVCQUFlO0FBQ2Y7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7QUN0Q0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFDOztBQUVELDRDQUEyQywwQkFBMEIsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ2RyRTtBQUNBO0FBQ0EsYUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBcUM7QUFDckMsWUFBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFTO0FBQ1Q7QUFDQTtBQUNBLHFCQUFvQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFxQztBQUNyQyxZQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFLO0FBQ0w7QUFDQTtBQUNBLGlCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFnQztBQUNoQyxZQUFXO0FBQ1gsa0NBQWlDLG9DQUFvQztBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFxQztBQUNyQyxnQkFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQSxrQkFBaUI7QUFDakI7QUFDQTtBQUNBLDZCQUE0QjtBQUM1Qix5Q0FBd0MsZ0NBQWdDO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQThDO0FBQzlDLHdCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWlCO0FBQ2pCO0FBQ0E7QUFDQSw2QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBNkM7QUFDN0Msb0JBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7O0FDN0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0EsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLElBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7O0FDcUNBO3lCQUVBOzs7YUFLQTtlQUNBO21CQUVBO0FBSkEsUUFEQTthQU9BO2VBQ0E7bUJBR0E7QUFMQSxTQVBBO2FBZUE7ZUFDQTttQkFFQTtBQUpBLFFBREE7YUFPQTtlQUNBO21CQUlBO0FBTkE7Y0FPQTtvQkFFQTtBQTdCQTtBQStCQTttQ0FDQTs7b0NBQ0E7O0FBRUE7dUNBQ0E7Z0NBRUE7O2tCQUNBO2VBQ0E7WUFDQTt1QkFDQTtBQUNBO0FBRUE7dUNBQ0E7d0JBQ0E7QUFDQTtBQWxEQSxJIiwiZmlsZSI6ImJ1aWxkL0hlbGxvL3Rlc3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSlcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcblxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0ZXhwb3J0czoge30sXG4gXHRcdFx0aWQ6IG1vZHVsZUlkLFxuIFx0XHRcdGxvYWRlZDogZmFsc2VcbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubG9hZGVkID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXygwKTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyB3ZWJwYWNrL2Jvb3RzdHJhcCBmNTBhYzc5NjcyNDVkYzlmMGRlOCIsInZhciAkbWlhcHBfdGVtcGxhdGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtdGVtcGxhdGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9dGVtcGxhdGVzIS4vdGVzdC5taXhcIilcbnZhciAkbWlhcHBfc3R5bGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc3R5bGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9c3R5bGVzJnJlc291cmNlUGF0aD0vaG9tZS91bmlxdWUvWlpaL3NyYy9IZWxsby90ZXN0Lm1peCEuL3Rlc3QubWl4XCIpXG52YXIgJG1pYXBwX3NjcmlwdCQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1zY3JpcHQtbG9hZGVyLmpzIWJhYmVsLWxvYWRlcj9wcmVzZXRzW109L2hvbWUvdW5pcXVlL1paWi9ub2RlX21vZHVsZXMvYmFiZWwtcHJlc2V0LWVzMjAxNSZwcmVzZXRzPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcGx1Z2luc1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZwbHVnaW5zPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZjb21tZW50cz1mYWxzZSEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXNjcmlwdHMhLi90ZXN0Lm1peFwiKVxuXG4kbWlhcHBfZGVmaW5lJCgnQG1pYXBwLWNvbXBvbmVudC90ZXN0JywgXG4gICAgICAgICAgICAgICAgW10sIGZ1bmN0aW9uKCRtaWFwcF9yZXF1aXJlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfbW9kdWxlJCl7XG4gICAgICRtaWFwcF9zY3JpcHQkKCRtaWFwcF9tb2R1bGUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9yZXF1aXJlJClcbiAgICAgaWYgKCRtaWFwcF9leHBvcnRzJC5fX2VzTW9kdWxlICYmICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0KSB7XG4gICAgICAgICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzID0gJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHRcbiAgICAgICAgfVxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnRlbXBsYXRlID0gJG1pYXBwX3RlbXBsYXRlJFxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnN0eWxlID0gJG1pYXBwX3N0eWxlJFxufSlcblxuJG1pYXBwX2Jvb3RzdHJhcCQoJ0BtaWFwcC1jb21wb25lbnQvdGVzdCcseyBwYWNrYWdlclZlcnNpb246ICcwLjAuMid9KVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vc3JjL0hlbGxvL3Rlc3QubWl4XG4vLyBtb2R1bGUgaWQgPSAwXG4vLyBtb2R1bGUgY2h1bmtzID0gMSIsIm1vZHVsZS5leHBvcnRzID0ge1xuICBcInR5cGVcIjogXCJkaXZcIixcbiAgXCJhdHRyXCI6IHt9LFxuICBcImNsYXNzTGlzdFwiOiBbXG4gICAgXCJjb250YWluZXJcIlxuICBdLFxuICBcImNoaWxkcmVuXCI6IFtcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgXCJ0aXRsZVwiXG4gICAgICBdLFxuICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgXCJjbGFzc0xpc3RcIjogW1xuICAgICAgICAgICAgXCJidXR0b25cIlxuICAgICAgICAgIF0sXG4gICAgICAgICAgXCJldmVudHNcIjoge1xuICAgICAgICAgICAgXCJjbGlja1wiOiBmdW5jdGlvbiAoZXZ0KSB7dGhpcy50b2dnbGVMaXN0KDAsZXZ0KX1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBcIkxpc3QxXCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIFwidHlwZVwiOiBcImRpdlwiLFxuICAgICAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICBcImJ1dHRvblwiXG4gICAgICAgICAgXSxcbiAgICAgICAgICBcImV2ZW50c1wiOiB7XG4gICAgICAgICAgICBcImNsaWNrXCI6IGZ1bmN0aW9uIChldnQpIHt0aGlzLnRvZ2dsZUxpc3QoMSxldnQpfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICBcInZhbHVlXCI6IFwiTGlzdDJcIlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJsaXN0XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAge1xuICAgICAgICAgIFwidHlwZVwiOiBcImJsb2NrXCIsXG4gICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgIFwidGlkXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy4kaXRlbS5pZH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVwZWF0XCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gdGhpcy5saXN0c1t0aGlzLmN1cnJlbnRMaXN0XX0sXG4gICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpc3QtaXRlbVwiLFxuICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgIFwidHlwZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuJGl0ZW0uaWR9XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwiY2xhc3NMaXN0XCI6IFtcbiAgICAgICAgICAgICAgICBcIml0ZW1cIlxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJkaXZcIixcbiAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7fSxcbiAgICAgICAgICAgICAgICAgIFwiY2hpbGRyZW5cIjogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IGZ1bmN0aW9uICgpIHtyZXR1cm4gJ25hbWU6ICcgKyAodGhpcy4kaXRlbS5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHt9LFxuICAgICAgICAgICAgICAgICAgXCJzaG93blwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuaGFzSXRlbSh0aGlzLiRpdGVtKX0sXG4gICAgICAgICAgICAgICAgICBcImNoaWxkcmVuXCI6IFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgICAgICBcImF0dHJcIjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuaGFzSXRlbSh0aGlzLiRpdGVtKSYmdGhpcy5oYXNJdGVtKHRoaXMuJGl0ZW0pLnF1YW50aXR5fVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgXCJzdHlsZVwiOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiMwMDAwRkZcIlxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICBcImF0dHJcIjoge30sXG4gICAgICAgICAgICAgICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgICAgICAgICAgICAgIFwiaW5saW5lLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgXCJldmVudHNcIjoge1xuICAgICAgICAgICAgICAgICAgICBcImNsaWNrXCI6IGZ1bmN0aW9uIChldnQpIHt0aGlzLmFkZFRvQ2FydCh0aGlzLiRpdGVtLGV2dCl9XG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjogXCLliqDlhaXotK3nianovaZcIlxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgXVxuICAgIH1cbiAgXVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL3NyYy9IZWxsby90ZXN0Lm1peFxuLy8gbW9kdWxlIGlkID0gMTFcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIFwidGV4dFwiOiB7XG4gICAgXCJjb2xvclwiOiBcIiMzMzMzMzNcIixcbiAgICBcImZvbnRTaXplXCI6IFwiMzBweFwiXG4gIH0sXG4gIFwibGlzdFwiOiB7XG4gICAgXCJoZWlnaHRcIjogXCIzMDBweFwiXG4gIH0sXG4gIFwiLmNvbnRhaW5lclwiOiB7XG4gICAgXCJmbGV4RGlyZWN0aW9uXCI6IFwiY29sdW1uXCJcbiAgfSxcbiAgXCIuaXRlbVwiOiB7XG4gICAgXCJoZWlnaHRcIjogXCIxMDBweFwiXG4gIH0sXG4gIFwiLnRpdGxlXCI6IHtcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJyb3dcIixcbiAgICBcImhlaWdodFwiOiBcIjIwMHB4XCJcbiAgfSxcbiAgXCIuYnV0dG9uXCI6IHtcbiAgICBcImZsZXhcIjogMSxcbiAgICBcInBhZGRpbmdcIjogXCIxMHB4XCIsXG4gICAgXCJtYXJnaW5SaWdodFwiOiBcIjEwcHhcIixcbiAgICBcImJvcmRlcldpZHRoXCI6IFwiMXB4XCIsXG4gICAgXCJib3JkZXJDb2xvclwiOiBcIiMzMzMzMzNcIlxuICB9LFxuICBcIi5pbmxpbmUtYnV0dG9uXCI6IHtcbiAgICBcIm1hcmdpbkxlZnRcIjogXCI1MHB4XCIsXG4gICAgXCJ3aWR0aFwiOiBcIjE1MHB4XCIsXG4gICAgXCJiYWNrZ3JvdW5kQ29sb3JcIjogXCIjRkYwMDAwXCJcbiAgfVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXN0eWxlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXN0eWxlcyZyZXNvdXJjZVBhdGg9L2hvbWUvdW5pcXVlL1paWi9zcmMvSGVsbG8vdGVzdC5taXghLi9zcmMvSGVsbG8vdGVzdC5taXhcbi8vIG1vZHVsZSBpZCA9IDEyXG4vLyBtb2R1bGUgY2h1bmtzID0gMSIsIjx0ZW1wbGF0ZT5cbiAgICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvblwiIEBjbGljaz1cInRvZ2dsZUxpc3QoMClcIj5cbiAgICAgICAgICAgICAgICA8dGV4dD5MaXN0MTwvdGV4dD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvblwiIEBjbGljaz1cInRvZ2dsZUxpc3QoMSlcIj5cbiAgICAgICAgICAgICAgICA8dGV4dD5MaXN0MjwvdGV4dD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGxpc3Q+XG4gICAgICAgICAgICA8YmxvY2sgZm9yPVwibGlzdHNbY3VycmVudExpc3RdXCIgdGlkPVwie3skaXRlbS5pZH19XCI+XG4gICAgICAgICAgICAgICAgPGxpc3QtaXRlbSB0eXBlPVwie3sgJGl0ZW0uaWQgfX1cIiBjbGFzcz1cIml0ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0Pm5hbWU6IHt7ICRpdGVtLm5hbWUgfX0gPC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBpZj1cInt7IGhhc0l0ZW0oJGl0ZW0pIH19XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCBzdHlsZT1cImJhY2tncm91bmQtY29sb3I6IGJsdWU7XCI+e3sgaGFzSXRlbSgkaXRlbSkgJiYgaGFzSXRlbSgkaXRlbSkucXVhbnRpdHkgfX08L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5saW5lLWJ1dHRvblwiIEBjbGljaz1cImFkZFRvQ2FydCgkaXRlbSlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0PuWKoOWFpei0reeJqei9pjwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9saXN0LWl0ZW0+XG4gICAgICAgICAgICA8L2Jsb2NrPlxuICAgICAgICA8L2xpc3Q+XG4gICAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGU+XG4gICAgdGV4dCB7XG4gICAgICAgIGNvbG9yOiAjMzMzO1xuICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgfVxuXG4gICAgbGlzdCB7XG4gICAgICAgIGhlaWdodDogMzAwcHg7XG4gICAgfVxuXG4gICAgLmNvbnRhaW5lciB7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgfVxuXG4gICAgLml0ZW0ge1xuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIH1cblxuICAgIC50aXRsZSB7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgIGhlaWdodDogMjAwcHg7XG4gICAgfVxuXG4gICAgLmJ1dHRvbiB7XG4gICAgICAgIGZsZXg6IDE7XG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gICAgICAgIGJvcmRlci1jb2xvcjogIzMzMztcbiAgICB9XG5cbiAgICAuaW5saW5lLWJ1dHRvbiB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xuICAgICAgICB3aWR0aDogMTUwcHg7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbiAgICB9XG48L3N0eWxlPlxuXG48c2NyaXB0PlxuICBtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBkYXRhKCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGlzdHM6IFtcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAxLFxuICAgICAgICAgICAgICBuYW1lOiAnaXRlbTEnLFxuICAgICAgICAgICAgICBxdWFudGl0eTogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6IDIsXG4gICAgICAgICAgICAgIG5hbWU6ICdpdGVtMicsXG4gICAgICAgICAgICAgIHF1YW50aXR5OiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgXSxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAzLFxuICAgICAgICAgICAgICBuYW1lOiAnaXRlbTMnLFxuICAgICAgICAgICAgICBxdWFudGl0eTogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6IDQsXG4gICAgICAgICAgICAgIG5hbWU6ICdpdGVtNCcsXG4gICAgICAgICAgICAgIHF1YW50aXR5OiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgXVxuICAgICAgICBdLFxuICAgICAgICBhZGRlZDogW10sXG4gICAgICAgIGN1cnJlbnRMaXN0OiAwXG4gICAgICB9XG4gICAgfSxcblxuICAgIGhhc0l0ZW0oaXRlbSkge1xuICAgICAgcmV0dXJuIHRoaXMuYWRkZWQuZmluZChhZGRlZEl0ZW0gPT4gYWRkZWRJdGVtLmlkID09PSBpdGVtLmlkKVxuICAgIH0sXG5cbiAgICBhZGRUb0NhcnQoaXRlbSkge1xuICAgICAgY29uc3QgaGFzSXRlbSA9IHRoaXMuaGFzSXRlbShpdGVtKVxuXG4gICAgICBpZiAoaGFzSXRlbSkge1xuICAgICAgICBoYXNJdGVtLnF1YW50aXR5KytcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuYWRkZWQucHVzaChpdGVtKVxuICAgICAgfVxuICAgIH0sXG5cbiAgICB0b2dnbGVMaXN0KGlkKSB7XG4gICAgICB0aGlzLmN1cnJlbnRMaXN0ID0gaWRcbiAgICB9XG4gIH1cbjwvc2NyaXB0PlxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9IZWxsby90ZXN0Lm1peD8wMGVhNjE1MiJdLCJzb3VyY2VSb290IjoiIn0=