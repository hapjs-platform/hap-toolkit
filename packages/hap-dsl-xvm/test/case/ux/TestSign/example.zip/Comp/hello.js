/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(1)
	var $miapp_template$ = __webpack_require__(8)
	var $miapp_style$ = __webpack_require__(9)
	var $miapp_script$ = __webpack_require__(10)
	
	$miapp_define$('@miapp-component/hello', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})
	
	$miapp_bootstrap$('@miapp-component/hello',{ packagerVersion: '0.0.3'})

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(2)
	var $miapp_template$ = __webpack_require__(5)
	var $miapp_style$ = __webpack_require__(6)
	var $miapp_script$ = __webpack_require__(7)
	
	$miapp_define$('@miapp-component/one', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	     $miapp_module$.exports.style = $miapp_style$
	})


/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	var $miapp_template$ = __webpack_require__(3)
	var $miapp_script$ = __webpack_require__(4)
	
	$miapp_define$('@miapp-component/module', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	     $miapp_module$.exports.template = $miapp_template$
	})


/***/ },
/* 3 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "text",
	  "attr": {
	    "value": function () {return this.value}
	  }
	}

/***/ },
/* 4 */
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = {
		props: ['value'],
		data: {
			value: ""
		}
	};}

/***/ },
/* 5 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "content"
	  ],
	  "children": [
	    {
	      "type": "text",
	      "attr": {
	        "value": "one_header"
	      }
	    },
	    {
	      "type": "module",
	      "attr": {
	        "value": function () {return this.data_1}
	      }
	    },
	    {
	      "type": "module",
	      "attr": {
	        "value": function () {return this.data_2}
	      }
	    },
	    {
	      "type": "text",
	      "attr": {
	        "value": "one_footer"
	      }
	    }
	  ]
	}

/***/ },
/* 6 */
/***/ function(module, exports) {

	module.exports = {
	  ".content": {
	    "flexDirection": "column"
	  }
	}

/***/ },
/* 7 */
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = {
		data: {
			data_1: "one",
			data_2: "two"
		}
	};}

/***/ },
/* 8 */
/***/ function(module, exports) {

	module.exports = {
	  "type": "div",
	  "attr": {},
	  "classList": [
	    "container"
	  ],
	  "children": [
	    {
	      "type": "div",
	      "attr": {},
	      "classList": [
	        "stack"
	      ]
	    }
	  ]
	}

/***/ },
/* 9 */
/***/ function(module, exports) {

	module.exports = {
	  ".container": {
	    "flex": 1,
	    "backgroundColor": "#ffffff",
	    "flexDirection": "column"
	  },
	  ".stack": {
	    "flex": 1,
	    "backgroundColor": "#FF0000",
	    "animationTimingFunction": "ease",
	    "animationFillMode": "none",
	    "animationDelay": "200ms",
	    "animationIterationCount": 3,
	    "animationDuration": "5000ms",
	    "animationName": "abc",
	    "transformOrigin": "30px 40px"
	  },
	  "@KEYFRAMES": {
	    "abc": [
	      {
	        "backgroundColor": "#FF0000",
	        "time": 0
	      },
	      {
	        "left": "30px",
	        "time": 100
	      }
	    ]
	  }
	}

/***/ },
/* 10 */
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = {
	  data: {
	    list: [],
	    a: {
	      b: {
	        text: '33243432'
	      }
	    }
	  },
	  onInit: function onInit() {
	    var anim = mix.createAnimation({
	      delay: 2000
	    });
	    console.log('========================================', anim.scale(1.0).step().export());
	  },
	  abc: function abc() {
	    this.a.b = undefined;
	  }
	};}

/***/ }
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMzEzYWY0ZjQ0MTQ4OTRiMWVkYTMiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvaGVsbG8ubWl4PzA1NzkiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvb25lLm1peD85Y2QzIiwid2VicGFjazovLy8uL3NyYy9Db21wL21vZHVsZS5taXg/YWM0YyIsIndlYnBhY2s6Ly8vLi9zcmMvQ29tcC9tb2R1bGUubWl4P2ZhODgiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvbW9kdWxlLm1peCIsIndlYnBhY2s6Ly8vLi9zcmMvQ29tcC9vbmUubWl4P2Y4NDciLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvb25lLm1peD9iMmI3Iiwid2VicGFjazovLy8uL3NyYy9Db21wL29uZS5taXgiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvaGVsbG8ubWl4PzRlODMiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvaGVsbG8ubWl4Pzc4N2IiLCJ3ZWJwYWNrOi8vLy4vc3JjL0NvbXAvaGVsbG8ubWl4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1QkFBZTtBQUNmO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7O0FDdENBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFDOztBQUVELDZDQUE0QywwQkFBMEIsQzs7Ozs7O0FDZnRFO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFDOzs7Ozs7O0FDYkQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUM7Ozs7Ozs7QUNWRDtBQUNBO0FBQ0E7QUFDQSwyQkFBMEI7QUFDMUI7QUFDQSxFOzs7Ozs7Ozs7Ozs7VUNDQTs7VUFHQTtBQUZBO0FBRkEsSTs7Ozs7O0FDTEE7QUFDQTtBQUNBLGFBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsK0JBQThCO0FBQzlCO0FBQ0EsTUFBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLCtCQUE4QjtBQUM5QjtBQUNBLE1BQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7OztBQ2hDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7V0NjQTtXQUVBO0FBSEE7QUFEQSxJOzs7Ozs7QUNoQkE7QUFDQTtBQUNBLGFBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7O1dDT0E7OztlQU1BO0FBSkE7QUFEQTtBQUZBOzZCQVFBOztjQUdBO0FBRkE7b0ZBR0E7QUFDQTt1QkFDQTtnQkFDQTtBQUNBO0FBakJBLEkiLCJmaWxlIjoiYnVpbGQvQ29tcC9oZWxsby5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKVxuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuXG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRleHBvcnRzOiB7fSxcbiBcdFx0XHRpZDogbW9kdWxlSWQsXG4gXHRcdFx0bG9hZGVkOiBmYWxzZVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sb2FkZWQgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKDApO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHdlYnBhY2svYm9vdHN0cmFwIDMxM2FmNGY0NDE0ODk0YjFlZGEzIiwicmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbG9hZGVyLmpzP3R5cGU9Y29tcG9uZW50IS4vb25lLm1peD9uYW1lPW9uZVwiKVxudmFyICRtaWFwcF90ZW1wbGF0ZSQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC10ZW1wbGF0ZS1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT10ZW1wbGF0ZXMhLi9oZWxsby5taXhcIilcbnZhciAkbWlhcHBfc3R5bGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc3R5bGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9c3R5bGVzJnJlc291cmNlUGF0aD0vaG9tZS91bmlxdWUvWlpaL3NyYy9Db21wL2hlbGxvLm1peCEuL2hlbGxvLm1peFwiKVxudmFyICRtaWFwcF9zY3JpcHQkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc2NyaXB0LWxvYWRlci5qcyFiYWJlbC1sb2FkZXI/cHJlc2V0c1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcHJlc2V0cz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wcmVzZXQtZXMyMDE1JnBsdWdpbnNbXT0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmcGx1Z2lucz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmY29tbWVudHM9ZmFsc2UhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zY3JpcHRzIS4vaGVsbG8ubWl4XCIpXG5cbiRtaWFwcF9kZWZpbmUkKCdAbWlhcHAtY29tcG9uZW50L2hlbGxvJywgXG4gICAgICAgICAgICAgICAgW10sIGZ1bmN0aW9uKCRtaWFwcF9yZXF1aXJlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfbW9kdWxlJCl7XG4gICAgICRtaWFwcF9zY3JpcHQkKCRtaWFwcF9tb2R1bGUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9yZXF1aXJlJClcbiAgICAgaWYgKCRtaWFwcF9leHBvcnRzJC5fX2VzTW9kdWxlICYmICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0KSB7XG4gICAgICAgICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzID0gJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHRcbiAgICAgICAgfVxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnRlbXBsYXRlID0gJG1pYXBwX3RlbXBsYXRlJFxuICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzLnN0eWxlID0gJG1pYXBwX3N0eWxlJFxufSlcblxuJG1pYXBwX2Jvb3RzdHJhcCQoJ0BtaWFwcC1jb21wb25lbnQvaGVsbG8nLHsgcGFja2FnZXJWZXJzaW9uOiAnMC4wLjMnfSlcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL3NyYy9Db21wL2hlbGxvLm1peFxuLy8gbW9kdWxlIGlkID0gMFxuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCJyZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9sb2FkZXIuanM/dHlwZT1jb21wb25lbnQhLi9tb2R1bGUubWl4P25hbWU9bW9kdWxlXCIpXG52YXIgJG1pYXBwX3RlbXBsYXRlJCA9IHJlcXVpcmUoXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL29uZS5taXhcIilcbnZhciAkbWlhcHBfc3R5bGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc3R5bGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9c3R5bGVzJnJlc291cmNlUGF0aD0vaG9tZS91bmlxdWUvWlpaL3NyYy9Db21wL29uZS5taXghLi9vbmUubWl4XCIpXG52YXIgJG1pYXBwX3NjcmlwdCQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1zY3JpcHQtbG9hZGVyLmpzIWJhYmVsLWxvYWRlcj9wcmVzZXRzW109L2hvbWUvdW5pcXVlL1paWi9ub2RlX21vZHVsZXMvYmFiZWwtcHJlc2V0LWVzMjAxNSZwcmVzZXRzPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcGx1Z2luc1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZwbHVnaW5zPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXBsdWdpbi10cmFuc2Zvcm0tcnVudGltZSZjb21tZW50cz1mYWxzZSEuLi8uLi9ub2RlX21vZHVsZXMvbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXNjcmlwdHMhLi9vbmUubWl4XCIpXG5cbiRtaWFwcF9kZWZpbmUkKCdAbWlhcHAtY29tcG9uZW50L29uZScsIFxuICAgICAgICAgICAgICAgIFtdLCBmdW5jdGlvbigkbWlhcHBfcmVxdWlyZSQsICRtaWFwcF9leHBvcnRzJCwgJG1pYXBwX21vZHVsZSQpe1xuICAgICAkbWlhcHBfc2NyaXB0JCgkbWlhcHBfbW9kdWxlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfcmVxdWlyZSQpXG4gICAgIGlmICgkbWlhcHBfZXhwb3J0cyQuX19lc01vZHVsZSAmJiAkbWlhcHBfZXhwb3J0cyQuZGVmYXVsdCkge1xuICAgICAgICAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cyA9ICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0XG4gICAgICAgIH1cbiAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cy50ZW1wbGF0ZSA9ICRtaWFwcF90ZW1wbGF0ZSRcbiAgICAgJG1pYXBwX21vZHVsZSQuZXhwb3J0cy5zdHlsZSA9ICRtaWFwcF9zdHlsZSRcbn0pXG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9sb2FkZXIuanM/dHlwZT1jb21wb25lbnQhLi9zcmMvQ29tcC9vbmUubWl4P25hbWU9b25lXG4vLyBtb2R1bGUgaWQgPSAxXG4vLyBtb2R1bGUgY2h1bmtzID0gMCIsInZhciAkbWlhcHBfdGVtcGxhdGUkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtdGVtcGxhdGUtbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9dGVtcGxhdGVzIS4vbW9kdWxlLm1peFwiKVxudmFyICRtaWFwcF9zY3JpcHQkID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc2NyaXB0LWxvYWRlci5qcyFiYWJlbC1sb2FkZXI/cHJlc2V0c1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcHJlc2V0cz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wcmVzZXQtZXMyMDE1JnBsdWdpbnNbXT0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmcGx1Z2lucz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmY29tbWVudHM9ZmFsc2UhLi4vLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zY3JpcHRzIS4vbW9kdWxlLm1peFwiKVxuXG4kbWlhcHBfZGVmaW5lJCgnQG1pYXBwLWNvbXBvbmVudC9tb2R1bGUnLCBcbiAgICAgICAgICAgICAgICBbXSwgZnVuY3Rpb24oJG1pYXBwX3JlcXVpcmUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9tb2R1bGUkKXtcbiAgICAgJG1pYXBwX3NjcmlwdCQoJG1pYXBwX21vZHVsZSQsICRtaWFwcF9leHBvcnRzJCwgJG1pYXBwX3JlcXVpcmUkKVxuICAgICBpZiAoJG1pYXBwX2V4cG9ydHMkLl9fZXNNb2R1bGUgJiYgJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHQpIHtcbiAgICAgICAgICAgICRtaWFwcF9tb2R1bGUkLmV4cG9ydHMgPSAkbWlhcHBfZXhwb3J0cyQuZGVmYXVsdFxuICAgICAgICB9XG4gICAgICRtaWFwcF9tb2R1bGUkLmV4cG9ydHMudGVtcGxhdGUgPSAkbWlhcHBfdGVtcGxhdGUkXG59KVxuXG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9+L21peC10b29scy9saWIvbG9hZGVyLmpzP3R5cGU9Y29tcG9uZW50IS4vc3JjL0NvbXAvbW9kdWxlLm1peD9uYW1lPW1vZHVsZVxuLy8gbW9kdWxlIGlkID0gMlxuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICBcImF0dHJcIjoge1xuICAgIFwidmFsdWVcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLnZhbHVlfVxuICB9XG59XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9+L21peC10b29scy9saWIvbWlhcHAtanNvbi1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtdGVtcGxhdGUtbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLWZyYWdtZW50LWxvYWRlci5qcz9pbmRleD0wJnR5cGU9dGVtcGxhdGVzIS4vc3JjL0NvbXAvbW9kdWxlLm1peFxuLy8gbW9kdWxlIGlkID0gM1xuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCI8dGVtcGxhdGU+XHJcblx0PHRleHQ+e3t2YWx1ZX19PC90ZXh0PlxyXG48L3RlbXBsYXRlPlxyXG48c2NyaXB0PlxyXG5cdGV4cG9ydCBkZWZhdWx0IHtcclxuXHRcdHByb3BzOiBbJ3ZhbHVlJ10sXHJcblx0XHRkYXRhOiB7XHJcblx0XHRcdHZhbHVlOlwiXCJcclxuXHRcdH1cclxuXHR9XHJcbjwvc2NyaXB0PlxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvQ29tcC9tb2R1bGUubWl4PzdmNGUzNDk3IiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIFwidHlwZVwiOiBcImRpdlwiLFxuICBcImF0dHJcIjoge30sXG4gIFwiY2xhc3NMaXN0XCI6IFtcbiAgICBcImNvbnRlbnRcIlxuICBdLFxuICBcImNoaWxkcmVuXCI6IFtcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJ0ZXh0XCIsXG4gICAgICBcImF0dHJcIjoge1xuICAgICAgICBcInZhbHVlXCI6IFwib25lX2hlYWRlclwiXG4gICAgICB9XG4gICAgfSxcbiAgICB7XG4gICAgICBcInR5cGVcIjogXCJtb2R1bGVcIixcbiAgICAgIFwiYXR0clwiOiB7XG4gICAgICAgIFwidmFsdWVcIjogZnVuY3Rpb24gKCkge3JldHVybiB0aGlzLmRhdGFfMX1cbiAgICAgIH1cbiAgICB9LFxuICAgIHtcbiAgICAgIFwidHlwZVwiOiBcIm1vZHVsZVwiLFxuICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgXCJ2YWx1ZVwiOiBmdW5jdGlvbiAoKSB7cmV0dXJuIHRoaXMuZGF0YV8yfVxuICAgICAgfVxuICAgIH0sXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwidGV4dFwiLFxuICAgICAgXCJhdHRyXCI6IHtcbiAgICAgICAgXCJ2YWx1ZVwiOiBcIm9uZV9mb290ZXJcIlxuICAgICAgfVxuICAgIH1cbiAgXVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL3NyYy9Db21wL29uZS5taXhcbi8vIG1vZHVsZSBpZCA9IDVcbi8vIG1vZHVsZSBjaHVua3MgPSAwIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIFwiLmNvbnRlbnRcIjoge1xuICAgIFwiZmxleERpcmVjdGlvblwiOiBcImNvbHVtblwiXG4gIH1cbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1zdHlsZS1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zdHlsZXMmcmVzb3VyY2VQYXRoPS9ob21lL3VuaXF1ZS9aWlovc3JjL0NvbXAvb25lLm1peCEuL3NyYy9Db21wL29uZS5taXhcbi8vIG1vZHVsZSBpZCA9IDZcbi8vIG1vZHVsZSBjaHVua3MgPSAwIiwiPGltcG9ydCBuYW1lPVwibW9kdWxlXCIgc3JjPVwiLi9tb2R1bGUubWl4XCI+PC9pbXBvcnQ+XHJcbjx0ZW1wbGF0ZT5cclxuXHQ8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxyXG5cdFx0PHRleHQ+b25lX2hlYWRlcjwvdGV4dD5cclxuXHRcdDxtb2R1bGUgdmFsdWU9XCJ7e2RhdGFfMX19XCI+PC9tb2R1bGU+XHJcblx0XHQ8bW9kdWxlIHZhbHVlPVwie3tkYXRhXzJ9fVwiPjwvbW9kdWxlPlxyXG5cdFx0PHRleHQ+b25lX2Zvb3RlcjwvdGV4dD5cclxuXHQ8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuPHN0eWxlPlxyXG5cdC5jb250ZW50e1xyXG5cdFx0ZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHR9XHJcbjwvc3R5bGU+XHJcbjxzY3JpcHQ+XHJcblx0ZXhwb3J0IGRlZmF1bHQge1xyXG5cdFx0ZGF0YToge1xyXG5cdFx0XHRkYXRhXzE6XCJvbmVcIixcclxuXHRcdFx0ZGF0YV8yOlwidHdvXCJcclxuXHRcdH1cclxuXHR9XHJcbjwvc2NyaXB0PlxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3NyYy9Db21wL29uZS5taXg/NmI4M2FhYmIiLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gIFwiYXR0clwiOiB7fSxcbiAgXCJjbGFzc0xpc3RcIjogW1xuICAgIFwiY29udGFpbmVyXCJcbiAgXSxcbiAgXCJjaGlsZHJlblwiOiBbXG4gICAge1xuICAgICAgXCJ0eXBlXCI6IFwiZGl2XCIsXG4gICAgICBcImF0dHJcIjoge30sXG4gICAgICBcImNsYXNzTGlzdFwiOiBbXG4gICAgICAgIFwic3RhY2tcIlxuICAgICAgXVxuICAgIH1cbiAgXVxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vfi9taXgtdG9vbHMvbGliL21pYXBwLWpzb24tbG9hZGVyLmpzIS4vfi9taXgtdG9vbHMvbGliL21pYXBwLXRlbXBsYXRlLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1mcmFnbWVudC1sb2FkZXIuanM/aW5kZXg9MCZ0eXBlPXRlbXBsYXRlcyEuL3NyYy9Db21wL2hlbGxvLm1peFxuLy8gbW9kdWxlIGlkID0gOFxuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCIuY29udGFpbmVyXCI6IHtcbiAgICBcImZsZXhcIjogMSxcbiAgICBcImJhY2tncm91bmRDb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICBcImZsZXhEaXJlY3Rpb25cIjogXCJjb2x1bW5cIlxuICB9LFxuICBcIi5zdGFja1wiOiB7XG4gICAgXCJmbGV4XCI6IDEsXG4gICAgXCJiYWNrZ3JvdW5kQ29sb3JcIjogXCIjRkYwMDAwXCIsXG4gICAgXCJhbmltYXRpb25UaW1pbmdGdW5jdGlvblwiOiBcImVhc2VcIixcbiAgICBcImFuaW1hdGlvbkZpbGxNb2RlXCI6IFwibm9uZVwiLFxuICAgIFwiYW5pbWF0aW9uRGVsYXlcIjogXCIyMDBtc1wiLFxuICAgIFwiYW5pbWF0aW9uSXRlcmF0aW9uQ291bnRcIjogMyxcbiAgICBcImFuaW1hdGlvbkR1cmF0aW9uXCI6IFwiNTAwMG1zXCIsXG4gICAgXCJhbmltYXRpb25OYW1lXCI6IFwiYWJjXCIsXG4gICAgXCJ0cmFuc2Zvcm1PcmlnaW5cIjogXCIzMHB4IDQwcHhcIlxuICB9LFxuICBcIkBLRVlGUkFNRVNcIjoge1xuICAgIFwiYWJjXCI6IFtcbiAgICAgIHtcbiAgICAgICAgXCJiYWNrZ3JvdW5kQ29sb3JcIjogXCIjRkYwMDAwXCIsXG4gICAgICAgIFwidGltZVwiOiAwXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBcImxlZnRcIjogXCIzMHB4XCIsXG4gICAgICAgIFwidGltZVwiOiAxMDBcbiAgICAgIH1cbiAgICBdXG4gIH1cbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1qc29uLWxvYWRlci5qcyEuL34vbWl4LXRvb2xzL2xpYi9taWFwcC1zdHlsZS1sb2FkZXIuanMhLi9+L21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zdHlsZXMmcmVzb3VyY2VQYXRoPS9ob21lL3VuaXF1ZS9aWlovc3JjL0NvbXAvaGVsbG8ubWl4IS4vc3JjL0NvbXAvaGVsbG8ubWl4XG4vLyBtb2R1bGUgaWQgPSA5XG4vLyBtb2R1bGUgY2h1bmtzID0gMCIsIjxpbXBvcnQgbmFtZT1cIm9uZVwiIHNyYz1cIi4vb25lLm1peFwiPjwvaW1wb3J0PlxyXG48dGVtcGxhdGU+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInN0YWNrXCI+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzdHlsZT5cclxuICAuY29udGFpbmVye1xyXG4gICAgZmxleDogMTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuICAuc3RhY2t7XHJcbiAgICAgIGZsZXg6MTtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xyXG4gICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlO1xyXG4gICAgICBhbmltYXRpb24tZmlsbC1tb2RlOiBub25lO1xyXG4gICAgICBhbmltYXRpb24tZGVsYXk6IDIwMG1zO1xyXG4gICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiAzO1xyXG4gICAgICBhbmltYXRpb24tZHVyYXRpb246IDUwMDBtcztcclxuICAgICAgYW5pbWF0aW9uLW5hbWU6IGFiYztcclxuICAgICAgdHJhbnNmb3JtLW9yaWdpbjogMzAgNDA7XHJcbiAgfVxyXG4gIEBrZXlmcmFtZXMgYWJjIHtcclxuICAgICAgMCUge2JhY2tncm91bmQtY29sb3I6cmVkO31cclxuICAgICAgNTAlIHtsZWZ0OmJsdWU7fVxyXG4gICAgICAxMDAlIHtsZWZ0OjMwO31cclxuICB9XHJcbjwvc3R5bGU+XHJcblxyXG48c2NyaXB0PlxyXG4gIGV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGRhdGE6IHtcclxuICAgICAgbGlzdDogW10sXHJcbiAgICAgIGE6e1xyXG4gICAgICAgIGI6e1xyXG4gICAgICAgICAgdGV4dDonMzMyNDM0MzInXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25Jbml0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgIHZhciBhbmltID0gbWl4LmNyZWF0ZUFuaW1hdGlvbih7XHJcbiAgICAgICAgZGVsYXk6IDIwMDBcclxuICAgICAgfSlcclxuICAgICAgY29uc29sZS5sb2coJz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0nLCBhbmltLnNjYWxlKDEuMCkuc3RlcCgpLmV4cG9ydCgpKVxyXG4gICAgfSxcclxuICAgIGFiYzogZnVuY3Rpb24gKCkge1xyXG4gICAgICB0aGlzLmEuYiA9IHVuZGVmaW5lZFxyXG4gICAgfVxyXG4gIH1cclxuPC9zY3JpcHQ+XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vc3JjL0NvbXAvaGVsbG8ubWl4PzY2ZTMxYzBmIl0sInNvdXJjZVJvb3QiOiIifQ==