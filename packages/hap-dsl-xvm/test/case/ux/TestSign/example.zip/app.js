/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	var $miapp_script$ = __webpack_require__(17)
	
	$miapp_define$('@miapp-application/app', 
	                [], function($miapp_require$, $miapp_exports$, $miapp_module$){
	     $miapp_script$($miapp_module$, $miapp_exports$, $miapp_require$)
	     if ($miapp_exports$.__esModule && $miapp_exports$.default) {
	            $miapp_module$.exports = $miapp_exports$.default
	        }
	})
	
	$miapp_bootstrap$('@miapp-application/app',{ packagerVersion: '0.0.3'})

/***/ },

/***/ 17:
/***/ function(module, exports) {

	module.exports = function(module, exports, $miapp_require$){"use strict";
	
	module.exports = {
	    manifest: { "package": "com.miui.hybrid.o2o", "name": "O2O", "versionName": "1.0", "versionCode": "1", "icon": "/common/icon.png", "features": [{ "name": "com.miui.hybrid.features.Network" }], "permissions": [{ "origin": "*" }], "config": { "logLevel": "debug" }, "router": { "entry": "Hello", "pages": { "Hello": { "component": "hello" }, "Comp": { "component": "hello" } } }, "display": { "backgroundColor": "#ffffff", "fullScreen": false, "titleBar": true, "titleBarBackgroundColor": "#000000", "titleBarTextColor": "#ffffff", "pages": { "Hello": { "backgroundColor": "#eeeeee", "fullScreen": true, "titleBarBackgroundColor": "#0000ff", "titleBarText": "Hello" } } } }
	};}

/***/ }

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMzEzYWY0ZjQ0MTQ4OTRiMWVkYTM/M2ZiNSoiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FwcC5taXg/N2RhYSIsIndlYnBhY2s6Ly8vLi9zcmMvYXBwLm1peCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUJBQWU7QUFDZjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7QUN0Q0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBQzs7QUFFRCw2Q0FBNEMsMEJBQTBCLEM7Ozs7Ozs7OztBQ1R0RTtxcEJBRUE7QUFEQSxJIiwiZmlsZSI6ImJ1aWxkL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKVxuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuXG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRleHBvcnRzOiB7fSxcbiBcdFx0XHRpZDogbW9kdWxlSWQsXG4gXHRcdFx0bG9hZGVkOiBmYWxzZVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sb2FkZWQgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKDApO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHdlYnBhY2svYm9vdHN0cmFwIDMxM2FmNGY0NDE0ODk0YjFlZGEzIiwidmFyICRtaWFwcF9zY3JpcHQkID0gcmVxdWlyZShcIiEhLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtc2NyaXB0LWxvYWRlci5qcyFiYWJlbC1sb2FkZXI/cHJlc2V0c1tdPS9ob21lL3VuaXF1ZS9aWlovbm9kZV9tb2R1bGVzL2JhYmVsLXByZXNldC1lczIwMTUmcHJlc2V0cz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wcmVzZXQtZXMyMDE1JnBsdWdpbnNbXT0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmcGx1Z2lucz0vaG9tZS91bmlxdWUvWlpaL25vZGVfbW9kdWxlcy9iYWJlbC1wbHVnaW4tdHJhbnNmb3JtLXJ1bnRpbWUmY29tbWVudHM9ZmFsc2UhLi4vbm9kZV9tb2R1bGVzL21peC10b29scy9saWIvbWlhcHAtZnJhZ21lbnQtbG9hZGVyLmpzP2luZGV4PTAmdHlwZT1zY3JpcHRzIS4uL25vZGVfbW9kdWxlcy9taXgtdG9vbHMvbGliL21pYXBwLW1hbmlmZXN0LWxvYWRlci5qcz9wYXRoPS9ob21lL3VuaXF1ZS9aWlovc3JjL2FwcC5taXghLi9hcHAubWl4XCIpXG5cbiRtaWFwcF9kZWZpbmUkKCdAbWlhcHAtYXBwbGljYXRpb24vYXBwJywgXG4gICAgICAgICAgICAgICAgW10sIGZ1bmN0aW9uKCRtaWFwcF9yZXF1aXJlJCwgJG1pYXBwX2V4cG9ydHMkLCAkbWlhcHBfbW9kdWxlJCl7XG4gICAgICRtaWFwcF9zY3JpcHQkKCRtaWFwcF9tb2R1bGUkLCAkbWlhcHBfZXhwb3J0cyQsICRtaWFwcF9yZXF1aXJlJClcbiAgICAgaWYgKCRtaWFwcF9leHBvcnRzJC5fX2VzTW9kdWxlICYmICRtaWFwcF9leHBvcnRzJC5kZWZhdWx0KSB7XG4gICAgICAgICAgICAkbWlhcHBfbW9kdWxlJC5leHBvcnRzID0gJG1pYXBwX2V4cG9ydHMkLmRlZmF1bHRcbiAgICAgICAgfVxufSlcblxuJG1pYXBwX2Jvb3RzdHJhcCQoJ0BtaWFwcC1hcHBsaWNhdGlvbi9hcHAnLHsgcGFja2FnZXJWZXJzaW9uOiAnMC4wLjMnfSlcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL3NyYy9hcHAubWl4XG4vLyBtb2R1bGUgaWQgPSAwXG4vLyBtb2R1bGUgY2h1bmtzID0gMiIsIjxzY3JpcHQ+XG4gIG1vZHVsZS5leHBvcnRzID0ge1xuICAgIG1hbmlmZXN0OntcInBhY2thZ2VcIjpcImNvbS5taXVpLmh5YnJpZC5vMm9cIixcIm5hbWVcIjpcIk8yT1wiLFwidmVyc2lvbk5hbWVcIjpcIjEuMFwiLFwidmVyc2lvbkNvZGVcIjpcIjFcIixcImljb25cIjpcIi9jb21tb24vaWNvbi5wbmdcIixcImZlYXR1cmVzXCI6W3tcIm5hbWVcIjpcImNvbS5taXVpLmh5YnJpZC5mZWF0dXJlcy5OZXR3b3JrXCJ9XSxcInBlcm1pc3Npb25zXCI6W3tcIm9yaWdpblwiOlwiKlwifV0sXCJjb25maWdcIjp7XCJsb2dMZXZlbFwiOlwiZGVidWdcIn0sXCJyb3V0ZXJcIjp7XCJlbnRyeVwiOlwiSGVsbG9cIixcInBhZ2VzXCI6e1wiSGVsbG9cIjp7XCJjb21wb25lbnRcIjpcImhlbGxvXCJ9LFwiQ29tcFwiOntcImNvbXBvbmVudFwiOlwiaGVsbG9cIn19fSxcImRpc3BsYXlcIjp7XCJiYWNrZ3JvdW5kQ29sb3JcIjpcIiNmZmZmZmZcIixcImZ1bGxTY3JlZW5cIjpmYWxzZSxcInRpdGxlQmFyXCI6dHJ1ZSxcInRpdGxlQmFyQmFja2dyb3VuZENvbG9yXCI6XCIjMDAwMDAwXCIsXCJ0aXRsZUJhclRleHRDb2xvclwiOlwiI2ZmZmZmZlwiLFwicGFnZXNcIjp7XCJIZWxsb1wiOntcImJhY2tncm91bmRDb2xvclwiOlwiI2VlZWVlZVwiLFwiZnVsbFNjcmVlblwiOnRydWUsXCJ0aXRsZUJhckJhY2tncm91bmRDb2xvclwiOlwiIzAwMDBmZlwiLFwidGl0bGVCYXJUZXh0XCI6XCJIZWxsb1wifX19fVxuICB9XG48L3NjcmlwdD5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zcmMvYXBwLm1peD8xZGYwMGVlMiJdLCJzb3VyY2VSb290IjoiIn0=